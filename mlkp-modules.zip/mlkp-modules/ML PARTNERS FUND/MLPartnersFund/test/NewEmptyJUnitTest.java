import java.rmi.server.UID;
import junit.framework.*;

public class NewEmptyJUnitTest extends TestCase {
    
    public NewEmptyJUnitTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {

    }

    protected void tearDown() throws Exception {
    }
    
}
