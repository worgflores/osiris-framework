
package ml.partners.fund;

import java.io.Serializable;
import javax.persistence.Embeddable;

@Embeddable
public class PartnersFundLogPK implements Serializable{

    private String objid;
    
    private int intmonth;
    
    private int intyear;
    
    private String currencyid;

    public PartnersFundLogPK() {
    }

    public String getObjid() {
        return objid;
    }

    public void setObjid(String objid) {
        this.objid = objid;
    }

    public int getIntmonth() {
        return intmonth;
    }

    public void setIntmonth(int intmonth) {
        this.intmonth = intmonth;
    }

    public int getIntyear() {
        return intyear;
    }

    public void setIntyear(int intyear) {
        this.intyear = intyear;
    }

    public String getCurrencyid() {
        return currencyid;
    }

    public void setCurrencyid(String currencyid) {
        this.currencyid = currencyid;
    }
    
}
