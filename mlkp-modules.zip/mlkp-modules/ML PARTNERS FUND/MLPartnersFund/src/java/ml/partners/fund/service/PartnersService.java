package ml.partners.fund.service;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Map;
import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import ml.partners.fund.PartnersFund;
import ml.partners.fund.PartnersFundDetail;
import ml.partners.fund.PartnersFundLog;

@Local(PartnersServiceLocal.class)
@Stateless
public class PartnersService implements PartnersServiceLocal{
    
    @PersistenceContext(unitName="parntersPU")
    private EntityManager em;
    
    private SimpleDateFormat monthFormat = new SimpleDateFormat("MM");
    private SimpleDateFormat yearFormat = new SimpleDateFormat("yyyy");
    
    public PartnersService() {
    }
    
    public PartnersFund saveFund(PartnersFund fund) throws Exception {
        Query q = em.createQuery("Select o from " + PartnersFund.class.getSimpleName() + " o where o.acctid=:acctid and o.currency=:currency");
        q.setParameter("acctid", fund.getAcctid());
        q.setParameter("currency", fund.getCurrency());
        PartnersFund pf = null;
        try{
            pf = (PartnersFund) q.getSingleResult();
        } catch(Exception ex){}
        
        if(pf != null) {
            throw new Exception("Partner with the currency specified already created.");
        }
        
        
        PartnersFundDetail d = new PartnersFundDetail();
        
        Date serverdate = getServerDate();
        
        fund.setRefid(d.getObjid());
        fund.setDtfiled(serverdate);
        fund.setLocked(0);
        fund.setState(1);
        fund.setBalance(fund.getAmount());
        em.persist(fund);
        
        d.setAmount(fund.getAmount());
        d.setBegbalance(new BigDecimal(0.0));
        d.setBranch(fund.getBranch());
        d.setDttxndate(serverdate);
        d.setUser(fund.getUser());
        d.setTerminal(fund.getTerminal());
        d.setParent(fund);
        em.persist(d);
        
        int month = Integer.parseInt(monthFormat.format(serverdate));
        int year = Integer.parseInt(yearFormat.format(serverdate));
        
        PartnersFundLog log = new PartnersFundLog();
        log.setObjid(fund.getObjid());
        log.setIntmonth(month);
        log.setIntyear(year);
        log.setBalance(fund.getBalance());
        log.setCurrencyid(fund.getCurrency());
        em.persist(log);        
        return fund;
    }
    
    public Date getServerDate() {
        Query q = em.createNativeQuery("Select now()");
        return (Date) q.getSingleResult();
    }
    
    public List fetchFundDetail(String parentid) {
        String ql = "SELECT o FROM " + PartnersFundDetail.class.getSimpleName() + " o WHERE o.parent.objid=:parentid order by o.begbalance desc";
        Query q = em.createQuery(ql);
        q.setParameter("parentid", parentid);
        return q.getResultList();
    }
    
    public PartnersFund loadAccount(PartnersFund newFund, Map map) {        
        PartnersFund pf = em.find(PartnersFund.class, newFund.getObjid());
        PartnersFundDetail df = new PartnersFundDetail();
        df.setBegbalance(pf.getBalance());
        df.setBankid(map.get("bank").toString());
        df.setBankacctno(map.get("acctno").toString());

        Date date = getServerDate();

        pf.setBalance(pf.getBalance().add( newFund.getAmount()) );
        pf.setRefid(df.getObjid());
        pf.setDtmodified(date);
        em.merge(pf);

        df.setAmount(newFund.getAmount());
        df.setBranch(newFund.getBranch());
        df.setDttxndate(date);
        df.setUser(newFund.getUser());
        df.setParent(pf);
        em.persist(df);

        Calendar cal = new GregorianCalendar();
        cal.setTime(date);

        int month = Integer.parseInt(monthFormat.format(date));
        int year = Integer.parseInt(yearFormat.format(date));

        String ql = "SELECT o FROM " + PartnersFundLog.class.getSimpleName() + " o WHERE o.objid=:objid and o.intyear=:year and o.intmonth=:month and o.currencyid=:currencyid";
        Query q = em.createQuery(ql);
        q.setParameter("objid", pf.getObjid());
        q.setParameter("year", year);
        q.setParameter("month", month);
        q.setParameter("currencyid", newFund.getCurrency());
        PartnersFundLog log = null;
        try{
            log = (PartnersFundLog) q.getSingleResult();
            System.out.println(log.getIntyear() + "  month " + log.getIntmonth() );
        }catch(Exception e){}


        if(log ==null) {
            log = new PartnersFundLog();
            log.setObjid(pf.getObjid());
            log.setIntmonth(month);
            log.setIntyear(year);
            log.setBalance(pf.getBalance());
            log.setCurrencyid(newFund.getCurrency());
            em.persist(log);
        } else {
            log.setLocked(0);
            em.merge(log);

            BigDecimal bal = log.getBalance().add(newFund.getAmount());
            log.setBalance(bal);
            em.merge(log);
        }
        return pf;        
    }
    
    public PartnersFund fetchFund(String objid) {
        PartnersFund pf = em.find(PartnersFund.class, objid);
        return pf;
    }
    
}
