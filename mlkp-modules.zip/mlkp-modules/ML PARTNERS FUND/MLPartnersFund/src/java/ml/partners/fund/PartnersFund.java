
package ml.partners.fund;

import java.io.Serializable;
import java.math.BigDecimal;
import java.rmi.server.UID;
import java.sql.PreparedStatement;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="tblpartnerfund")
public class PartnersFund implements Serializable{
    
    @Id
    @Column(length=32)
    private String objid;
    
    private int state;
    
    @Temporal(value=TemporalType.TIMESTAMP)
    private Date dtfiled;
    
    @Temporal(value=TemporalType.TIMESTAMP)
    private Date dtmodified;
    
    @Column(length=20, name="stracctid")
    private String acctid;
    
    @Column(name="curbalance")
    private BigDecimal balance;
    
    @Column(name="curamount")
    private BigDecimal amount;
    
    @Column(name="strcurrencyid", length=3)
    private String currency;
    
    @Column(name="strbranchid", length=10)
    private String branch;
    
    @Column(name="struserid", length=40)
    private String user;
    
    @Column(name="strterminalid", length=15)
    private String terminal;
    
    @Column(name="strrefid", length=32)
    private String refid;
    
    @Column(name="intlocked")
    private int locked;
    
    @Column(name="strbankid", length=32)
    private String bankid;
    
    @Column(name="strbankacctno", length=32)
    private String bankacctno;
    
    public PartnersFund() {
        objid = "FUND" + new UID();             
    }
    
    public String getObjid() {
        return objid;
    }
    
    public int getState() {
        return state;
    }
    
    public void setState(int state) {
        this.state = state;
    }
    
    public Date getDtfiled() {
        return dtfiled;
    }
    
    public void setDtfiled(Date dtfiled) {
        this.dtfiled = dtfiled;
    }
    
    public Date getDtmodified() {
        return dtmodified;
    }
    
    public void setDtmodified(Date dtmodified) {
        this.dtmodified = dtmodified;
    }
    
    public String getAcctid() {
        return acctid;
    }
    
    public void setAcctid(String acctid) {
        this.acctid = acctid;
    }
    
    public BigDecimal getBalance() {
        return balance;
    }
    
    public void setBalance(BigDecimal balance) {
        this.balance = balance;
    }
    
    public BigDecimal getAmount() {
        return amount;
    }
    
    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }
    
    public String getCurrency() {
        return currency;
    }
    
    public void setCurrency(String currency) {
        this.currency = currency;
    }
    
    public String getBranch() {
        return branch;
    }
    
    public void setBranch(String branch) {
        this.branch = branch;
    }
    
    public String getUser() {
        return user;
    }
    
    public void setUser(String user) {
        this.user = user;
    }
    
    public String getTerminal() {
        return terminal;
    }
    
    public void setTerminal(String terminal) {
        this.terminal = terminal;
    }
    
    public String getRefid() {
        return refid;
    }
    
    public void setRefid(String refid) {
        this.refid = refid;
    }
    
    public int getLocked() {
        return locked;
    }
    
    public void setLocked(int locked) {
        this.locked = locked;
    }
    
    public String getBankid() {
        return bankid;
    }
    
    public void setBankid(String bankid) {
        this.bankid = bankid;
    }
    
    public String getBankacctno() {
        return bankacctno;
    }
    
    public void setBankacctno(String bankacctno) {
        this.bankacctno = bankacctno;
    }
    
    public boolean equals(Object obj) {
        if(obj == null || !(obj instanceof PartnersFund)) return false;
        
        PartnersFund other = (PartnersFund) obj;
        return getObjid().equals(other.getObjid());
    }
    
}

