
package ml.partners.fund.service;

import java.util.List;
import java.util.Map;
import ml.partners.fund.PartnersFund;

public interface PartnersServiceLocal {
    
    PartnersFund saveFund(PartnersFund fund) throws Exception;
    
    List fetchFundDetail(String parentid);
    
    PartnersFund loadAccount(PartnersFund newFund, Map map);
    
    PartnersFund fetchFund(String objid);
}