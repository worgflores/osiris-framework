
package ml.partners.fund;

import java.io.Serializable;
import java.math.BigDecimal;
import java.rmi.server.UID;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="tblpartnerfunddetail")
public class PartnersFundDetail implements Serializable{
    
    @Id
    @Column(length=32)
    private String objid;
    
    @ManyToOne
    @JoinColumn(name="parentid")
    private PartnersFund parent;
    
    @Temporal(value=TemporalType.TIMESTAMP)
    private Date dttxndate;
    
    @Column(name="curamount")
    private BigDecimal amount;
    
    @Column(name="curbegbalance")
    private BigDecimal begbalance;
    
    @Column(name="strbankid", length=32)
    private String bankid;
    
    @Column(name="strbankacctno", length=32)
    private String bankacctno;
    
    @Column(name="strbranchid", length=10)
    private String branch;
    
    @Column(name="struserid", length=40)
    private String user;
    
    @Column(name="strterminalid", length=15)
    private String terminal;
    
    public PartnersFundDetail() {
        objid = "FNDD" + new UID();
    }
    
    public String getObjid() {
        return objid;
    }
    
    public PartnersFund getParent() {
        return parent;
    }
    
    public void setParent(PartnersFund parent) {
        this.parent = parent;
    }
    
    public Date getDttxndate() {
        return dttxndate;
    }
    
    public void setDttxndate(Date dttxndate) {
        this.dttxndate = dttxndate;
    }
    
    public BigDecimal getAmount() {
        return amount;
    }
    
    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }
    
    public BigDecimal getBegbalance() {
        return begbalance;
    }
    
    public void setBegbalance(BigDecimal begbalance) {
        this.begbalance = begbalance;
    }
    
    public String getBranch() {
        return branch;
    }
    
    public void setBranch(String branch) {
        this.branch = branch;
    }
    
    public String getUser() {
        return user;
    }
    
    public void setUser(String user) {
        this.user = user;
    }
    
    public String getTerminal() {
        return terminal;
    }
    
    public void setTerminal(String terminal) {
        this.terminal = terminal;
    }
    
    public String getBankid() {
        return bankid;
    }
    
    public void setBankid(String bankid) {
        this.bankid = bankid;
    }
    
    public String getBankacctno() {
        return bankacctno;
    }
    
    public void setBankacctno(String bankacctno) {
        this.bankacctno = bankacctno;
    }
    
    public boolean equals(Object obj) {
        if(obj == null || !(obj instanceof PartnersFundDetail)) return false;
        
        PartnersFundDetail other = (PartnersFundDetail) obj;
        return getObjid().equals(other.getObjid());
    }
    
}

