
package ml.partners.fund;

import java.math.BigDecimal;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

@Entity
@Table(name="tblpartnerfundlog")
@IdClass(value=ml.partners.fund.PartnersFundLogPK.class)
public class PartnersFundLog implements java.io.Serializable{
 
    @Id
    @Column(length=32)
    private String objid;
    
    @Id
    private int intyear;
    
    @Id
    private int intmonth;
    
    @Id
    @Column(length=10)
    private String currencyid;
    
    @Column(name="curbalance")
    private BigDecimal balance;
    
    @Column(name="intlocked")    
    private int locked=0;
    
    public PartnersFundLog() {
    }

    public String getObjid() {
        return objid;
    }

    public void setObjid(String objid) {
        this.objid = objid;
    }

    public int getIntyear() {
        return intyear;
    }

    public void setIntyear(int intyear) {
        this.intyear = intyear;
    }

    public int getIntmonth() {
        return intmonth;
    }

    public void setIntmonth(int intmonth) {
        this.intmonth = intmonth;
    }

    public BigDecimal getBalance() {
        return balance;
    }

    public void setBalance(BigDecimal balance) {
        this.balance = balance;
    }

    public int getLocked() {
        return locked;
    }

    public void setLocked(int locked) {
        this.locked = locked;
    }

    public String getCurrencyid() {
        return currencyid;
    }

    public void setCurrencyid(String currencyid) {
        this.currencyid = currencyid;
    }
    
}
