/*
 * NewEmptyJUnitTest.java
 * JUnit based test
 *
 * Created on December 23, 2008, 1:48 PM
 */

package test;

import java.util.Calendar;
import java.util.GregorianCalendar;
import junit.framework.*;

/**
 *
 * @author ML
 */
public class NewEmptyJUnitTest extends TestCase {
    
    public NewEmptyJUnitTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
    }

    protected void tearDown() throws Exception {
    }
    
    public void test0() throws Exception 
    {
        java.util.Date dtfrom = java.sql.Date.valueOf("2008-07-10");
        Calendar cal = new GregorianCalendar();
        cal.setTime(dtfrom);
        System.out.println(cal.getActualMaximum(Calendar.DATE));
    }

}
