package com.mlhuillier.billpayment;

import java.io.File;
import java.io.FileWriter;
import java.util.List;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileFilter;

public class PreviewPage extends javax.swing.JPanel implements IPage
{
    private PageNavigator nav;
    private JFileChooser chooser;
    private List companies;
    
    public PreviewPage() 
    {
        initComponents(); 
    }
    
    // <editor-fold defaultstate="collapsed" desc=" Generated Code ">//GEN-BEGIN:initComponents
    private void initComponents() {
        jLabel1 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        editorPane = new javax.swing.JEditorPane();
        jPanel2 = new javax.swing.JPanel();
        cmdSave = new javax.swing.JButton();
        cmdCancel = new javax.swing.JButton();
        cmdBack = new javax.swing.JButton();

        setLayout(new java.awt.BorderLayout());

        setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setBackground(new java.awt.Color(0, 51, 153));
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("<html><font size=\"5\"><b>BillsPayment Feedback File Generator</b></font></html>");
        jLabel1.setBorder(javax.swing.BorderFactory.createEmptyBorder(5, 5, 5, 5));
        jLabel1.setOpaque(true);
        add(jLabel1, java.awt.BorderLayout.NORTH);

        jPanel1.setLayout(new java.awt.BorderLayout());

        jPanel1.setOpaque(false);
        editorPane.setEditable(false);
        editorPane.setContentType("text/html");
        jScrollPane1.setViewportView(editorPane);

        jPanel1.add(jScrollPane1, java.awt.BorderLayout.CENTER);

        add(jPanel1, java.awt.BorderLayout.CENTER);

        jPanel2.setPreferredSize(new java.awt.Dimension(100, 50));
        cmdSave.setMnemonic('s');
        cmdSave.setText("Save");
        cmdSave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmdSaveActionPerformed(evt);
            }
        });

        cmdCancel.setMnemonic('c');
        cmdCancel.setText("Close");
        cmdCancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmdCancelActionPerformed(evt);
            }
        });

        cmdBack.setMnemonic('b');
        cmdBack.setText("Back");
        cmdBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmdBackActionPerformed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout jPanel2Layout = new org.jdesktop.layout.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(306, Short.MAX_VALUE)
                .add(cmdBack, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 72, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .add(18, 18, 18)
                .add(cmdSave, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 72, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(cmdCancel, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 73, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(cmdCancel, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 28, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(cmdSave, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 28, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(cmdBack, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 28, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        add(jPanel2, java.awt.BorderLayout.SOUTH);

    }// </editor-fold>//GEN-END:initComponents

    private void cmdBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmdBackActionPerformed

        nav.setPage("default");
        
    }//GEN-LAST:event_cmdBackActionPerformed

    private void cmdSaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmdSaveActionPerformed

        try
        {
            if (chooser == null)
            {
                chooser = new JFileChooser();
                chooser.setFileFilter(new FileFilter() 
                {
                    public boolean accept(File f) 
                    {
                        if (f.isDirectory()) return true;
                        
                        return (f.getName().endsWith(".html") ||
                                f.getName().endsWith(".htm"));
                    }
                    
                    public String getDescription() {
                        return "Html Files (.html,.htm)";
                    }
                });
            }
            
            int opt = chooser.showSaveDialog(this);
            if (opt == JFileChooser.APPROVE_OPTION) 
            {
                File f = chooser.getSelectedFile(); 
                writeToFile(f); 
                JOptionPane.showMessageDialog(this, "Successfully saved");
            }
        }
        catch(Exception ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE); 
        }
        
    }//GEN-LAST:event_cmdSaveActionPerformed

    private void cmdCancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmdCancelActionPerformed

        Launcher.dispose();
        
    }//GEN-LAST:event_cmdCancelActionPerformed
    
    private boolean isEmpty(Object value)
    {
        if (value == null) 
            return true;
        else if (value instanceof String)
            return (value.toString().trim().length() == 0);
        else
            return false;
    }
    
    private void required(Object value, String title) 
    {
        if (isEmpty(value))
            throw new NullPointerException(title + " is required");
    }
    
    private void writeToFile(File f) throws Exception
    {
        FileWriter writer = null;
        try
        {
            writer = new FileWriter(f);
            writer.write(editorPane.getText());
            writer.flush();
        }
        catch(Exception ex) {
            throw ex;
        }
        finally {
            try { writer.close(); }catch(Exception ign){;}
        }
    }
    
    public void bindData(PageNavigator nav) throws Exception 
    {
        this.nav = nav;
        Launcher.getMainWindow().getRootPane().setDefaultButton(cmdSave); 
        
        editorPane.setText("");
        List items = (List) nav.get("items");
        ReportHtmlBuilder builder = new ReportHtmlBuilder();
        builder.setStartDate(nav.get("startdate")+"");
        builder.setEndDate(nav.get("enddate")+"");
        editorPane.setText(builder.build(items));
    }
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton cmdBack;
    private javax.swing.JButton cmdCancel;
    private javax.swing.JButton cmdSave;
    private javax.swing.JEditorPane editorPane;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
    
}
