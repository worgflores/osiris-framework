package com.mlhuillier.billpayment;

import java.text.SimpleDateFormat;
import java.util.Iterator;
import java.util.List;
import javax.swing.JOptionPane;
import rameses.osiris.client.app.App;
import rameses.osiris.common.interfaces.IDataSetModel;
import rameses.osiris.common.service.Request;
import rameses.osiris.common.service.Response;

public class MainPage_1 extends javax.swing.JPanel implements IPage
{
    private List companies;
    
    public MainPage_1() 
    {
        initComponents(); 
    }
    
    // <editor-fold defaultstate="collapsed" desc=" Generated Code ">//GEN-BEGIN:initComponents
    private void initComponents() {
        jLabel1 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        txtDate = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        cboCompanies = new javax.swing.JComboBox();
        jPanel2 = new javax.swing.JPanel();
        cmdNext = new javax.swing.JButton();
        cmdCancel = new javax.swing.JButton();

        setLayout(new java.awt.BorderLayout());

        setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setBackground(new java.awt.Color(0, 51, 153));
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("<html><font size=\"5\"><b>BillsPayment Feedback File Generator</b></font></html>");
        jLabel1.setBorder(javax.swing.BorderFactory.createEmptyBorder(5, 5, 5, 5));
        jLabel1.setOpaque(true);
        add(jLabel1, java.awt.BorderLayout.NORTH);

        jPanel1.setLayout(null);

        jPanel1.setOpaque(false);
        jLabel2.setFont(new java.awt.Font("Dialog", 1, 14));
        jLabel2.setText("Date :");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(45, 87, 50, 24);

        txtDate.setFont(new java.awt.Font("Dialog", 1, 18));
        txtDate.setForeground(new java.awt.Color(153, 0, 51));
        jPanel1.add(txtDate);
        txtDate.setBounds(147, 87, 140, 24);

        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setText("( YYYY-MM-DD )");
        jPanel1.add(jLabel3);
        jLabel3.setBounds(147, 111, 140, 20);

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 11));
        jLabel4.setText("Please fill in the required fields");
        jPanel1.add(jLabel4);
        jLabel4.setBounds(21, 21, 216, 18);

        jLabel5.setFont(new java.awt.Font("Dialog", 1, 14));
        jLabel5.setText("Company :");
        jPanel1.add(jLabel5);
        jLabel5.setBounds(42, 57, 99, 24);

        jPanel1.add(cboCompanies);
        cboCompanies.setBounds(147, 57, 342, 24);

        add(jPanel1, java.awt.BorderLayout.CENTER);

        jPanel2.setPreferredSize(new java.awt.Dimension(100, 50));
        cmdNext.setMnemonic('n');
        cmdNext.setText("Next");
        cmdNext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmdNextActionPerformed(evt);
            }
        });

        cmdCancel.setMnemonic('c');
        cmdCancel.setText("Cancel");
        cmdCancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmdCancelActionPerformed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout jPanel2Layout = new org.jdesktop.layout.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(396, Short.MAX_VALUE)
                .add(cmdNext, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 72, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(cmdCancel, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 73, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(cmdCancel, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 28, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(cmdNext, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 28, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        add(jPanel2, java.awt.BorderLayout.SOUTH);

    }// </editor-fold>//GEN-END:initComponents

    private void cmdNextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmdNextActionPerformed

        try
        {
            required(cboCompanies.getSelectedItem(), "Company");
            required(txtDate.getText(), "Date");

            try {
                java.sql.Date.valueOf(txtDate.getText()); 
            } 
            catch(Exception ex) {
                throw new Exception("Invalid date value");
            }
            
            String sdate = txtDate.getText();
            java.sql.Date dt = java.sql.Date.valueOf(sdate); 
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd"); 
            
            String sdate2 = sdf.format(dt); 
            if (!sdate.equals(sdate2))
                throw new Exception("Invalid date value");
            
            Request req = new Request(); 
            req.addParameter("TXNDATE", sdate); 
            
            Company company = (Company) cboCompanies.getSelectedItem();
            req.addParameter("COMPANYID", company.getObjid());
            
            Response res = App.getServiceManager().invoke("billpayment.getDailyTransactions", req); 
            IDataSetModel idsm = (IDataSetModel) res.getValue("list"); 
            if (idsm.size() == 0)
            {
                JOptionPane.showMessageDialog(this, "No record(s) found");
                return;
            } 
                
            PageNavigator nav = (PageNavigator) getClientProperty("PageNavigator"); 
            nav.set("txndate", sdate); 
            nav.set("items", idsm); 
            nav.setPage("preview"); 
        }
        catch(Exception ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE); 
        }
        
    }//GEN-LAST:event_cmdNextActionPerformed

    private void cmdCancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmdCancelActionPerformed

        Launcher.dispose();
        
    }//GEN-LAST:event_cmdCancelActionPerformed
    
    private boolean isEmpty(Object value)
    {
        if (value == null) 
            return true;
        else if (value instanceof String)
            return (value.toString().trim().length() == 0);
        else
            return false;
    }
    
    private void required(Object value, String title) 
    {
        if (isEmpty(value))
        {
            txtDate.grabFocus();
            throw new NullPointerException(title + " is required");
        }
    }
    
    public void bindData(PageNavigator nav) throws Exception 
    {
        Launcher.getMainWindow().getRootPane().setDefaultButton(cmdNext);         
        if (companies == null)
        {
            cboCompanies.removeAllItems();
            companies = CompanyService.getList();
            Iterator itr = companies.iterator();
            while (itr.hasNext()) {
                cboCompanies.addItem(itr.next());
            }

            if (!companies.isEmpty()) cboCompanies.setSelectedIndex(0);
        }
    }
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox cboCompanies;
    private javax.swing.JButton cmdCancel;
    private javax.swing.JButton cmdNext;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JTextField txtDate;
    // End of variables declaration//GEN-END:variables
    
}
