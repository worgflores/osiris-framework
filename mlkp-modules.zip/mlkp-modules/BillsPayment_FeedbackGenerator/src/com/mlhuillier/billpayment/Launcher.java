package com.mlhuillier.billpayment;

import java.awt.BorderLayout;
import java.io.File;
import java.io.FileInputStream;
import java.net.URL;
import java.util.Iterator;
import java.util.Properties;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.UIManager;

public class Launcher 
{
    private static JFrame mainWindow;

    public static void main(String[] args) throws Exception 
    {
        if (mainWindow != null) return;

        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch(Exception ign) {;}
        
        loadProperties();
        
        JPanel container = new JPanel(new BorderLayout());
        
        mainWindow = new JFrame("BillsPayment Feedback File Generator");
        mainWindow.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        mainWindow.setContentPane(container); 
        mainWindow.setSize(800, 600); 
        
        try
        {
            URL url = Launcher.class.getResource("/resource/export.gif");
            ImageIcon iicon = new ImageIcon(url);
            mainWindow.setIconImage(iicon.getImage());
        }
        catch(Exception ign) {;}

        PageNavigator nav = new PageNavigator(container); 
        nav.addPage("default", new MainPage());
        nav.addPage("preview", new PreviewPage());
        nav.setPage("default");
        
        mainWindow.setVisible(true);
    }
    
    private static void loadProperties() throws Exception
    {
        File file = new File("config.properties");
        if (!file.exists())
            throw new NullPointerException("Could not locate configuration file");
        
        Properties props = new Properties(); 
        props.load(new FileInputStream(file)); 
        
        Iterator itr = props.keySet().iterator();
        while (itr.hasNext())
        {
            String key = itr.next().toString();
            System.setProperty(key, props.getProperty(key, ""));
        }
    }
    
    public static JFrame getMainWindow() { return mainWindow; }
    
    public static void dispose() { 
        mainWindow.dispose();
    }
    
    private Launcher() {}
    
}
