package com.mlhuillier.billpayment;

import java.awt.Container;
import java.util.HashMap;
import java.util.Map;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

public class PageNavigator 
{
    private Container container;
    private Map pages;
    private Map data;
    
    public PageNavigator(Container container) 
    {
        this.container = container;
        this.pages = new HashMap();
        this.data = new HashMap();
    }
    
    public void addPage(String name, JComponent component) 
    {
        if (component == null) return;
        
        pages.put(name, component);
    }
    
    public void setPage(String name)
    {
        try
        {
            JComponent page = (JComponent) pages.get(name);
            container.removeAll();
            container.add(page);

            page.putClientProperty("PageNavigator", this);        
            if (page instanceof IPage)
                ((IPage) page).bindData(this);

            if (container.isVisible()) 
                SwingUtilities.updateComponentTreeUI(page);
        }
        catch(Exception ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE); 
        }
    }

    public Object get(String name) { return data.get(name); }
    public void set(String name, Object value) {
        data.put(name, value);
    }
    
}
