package com.mlhuillier.billpayment;

import java.util.ArrayList;
import java.util.List;
import rameses.osiris.client.app.App;
import rameses.osiris.common.interfaces.IDataModel;
import rameses.osiris.common.interfaces.IDataSetModel;
import rameses.osiris.common.service.Request;
import rameses.osiris.common.service.Response;

public class CompanyService 
{
    
    public static List getList() throws Exception 
    {
        Request req = new Request();
        Response res = App.getServiceManager().invoke("billpayment.getCompanies", req); 
        IDataSetModel idsm = (IDataSetModel) res.getValue("list");
        
        List list = new ArrayList(); 
        for (int i=0; i<idsm.size(); i++) 
        {
            IDataModel doc = idsm.getItem(i); 
            Company c = new Company();
            c.setObjid(doc.getValue("objid")+"");
            c.setCode(doc.getValue("strcode")+"");
            c.setDescription(doc.getValue("strcompany")+"");
            c.setAddress(doc.getValue("straddress")+"");
            c.setContactno(doc.getValue("strcontactno")+"");
            c.setActive("1".equals(doc.getValue("intactive")+""));
            c.setCollectCharge("1".equals(doc.getValue("intcollectcharge")+""));
            list.add(c);
        }
        return list; 
    }
    
    private CompanyService() {}
    
}
