package com.mlhuillier.billpayment;

import java.io.InputStream;
import java.math.BigDecimal;
import java.net.URL;
import java.text.DecimalFormat;
import java.util.List;
import rameses.osiris.common.interfaces.IDataModel;

public class ReportHtmlBuilder 
{
    private String startDate;
    private String endDate;
    
    public ReportHtmlBuilder() {
    }
    
    public String getStartDate() { return startDate; }
    public void setStartDate(String startDate) { this.startDate = startDate; }

    public String getEndDate() { return endDate; }
    public void setEndDate(String endDate) { this.endDate = endDate; }    

    public String build(List items) throws Exception 
    {
        IDataModel doc = null;
        
        long tcount = 0;
        BigDecimal tamt = new BigDecimal(0.0);
        BigDecimal tcharge = new BigDecimal(0.0);
        
        StringBuffer sb = new StringBuffer();
        for (int i=0; i<items.size(); i++)
        {
            doc = (IDataModel) items.get(i); 
            sb.append("<tr>"); 
            sb.append("<td class=\"colvalue\" valign=\"top\">"+ doc.getValue("dttxndate") +"</td>");
            sb.append("<td class=\"colvalue\" valign=\"top\">"+ doc.getValue("stracctno") +"</td>");
            sb.append("<td class=\"colvalue\" valign=\"top\">"+ doc.getValue("strcompany") +"</td>");
            sb.append("<td class=\"colvalue\" valign=\"top\" align=\"right\">"+ formatNumber(doc.getValue("curamtpaid"), "#,##0.00") +"</td>");
            sb.append("<td class=\"colvalue\" valign=\"top\" align=\"right\">"+ formatNumber(doc.getValue("curcharge"), "#,##0.00") +"</td>");
            sb.append("<td class=\"colvalue\" valign=\"top\">"+ doc.getValue("strbranchid") +"</td>");
            sb.append("<td class=\"colvalue\" valign=\"top\">"+ doc.getValue("struserid") +"</td>");
            sb.append("<td class=\"colvalue\" valign=\"top\">"+ doc.getValue("strpayeename") +"</td>");
            sb.append("<td class=\"colvalue\" valign=\"top\">"+ doc.getValue("strpayeecontactno") +"</td>");
            sb.append("<td class=\"colvalue\" valign=\"top\">"+ doc.getValue("strotherdetail") +"</td>");
            sb.append("</tr>");
            
            double damt = Double.parseDouble(doc.getValue("curamtpaid")+"");
            double dcharge = Double.parseDouble(doc.getValue("curcharge")+"");
            tamt = tamt.add(new BigDecimal(damt));
            tcharge = tcharge.add(new BigDecimal(dcharge));
            tcount += 1;
        }
        
        String template = getTemplate().toString();
        template = template.replaceAll("@TXNDATE", getStartDate() + " TO " + getEndDate());
        template = template.replaceAll("@RUNDATE", doc.getValue("dtrundate")+"");
        template = template.replaceAll("@TOTALCOUNT", formatNumber(tcount+"", "#,##0"));        
        template = template.replaceAll("@TOTALAMTPAID", formatNumber(tamt+"", "#,##0.00"));        
        template = template.replaceAll("@TOTALCHARGE", formatNumber(tcharge+"", "#,##0.00"));        
        template = template.replaceAll("@DETAILS", sb.toString());
        return template; 
    }
    
    private String formatNumber(Object value, String pattern)
    {
        try
        {
            DecimalFormat dF = new DecimalFormat(pattern);
            if (value instanceof String)
                return dF.format(Double.valueOf(value.toString()));
            else 
                return dF.format(value);
        }
        catch(Exception ex) {
            return "";
        }
    }
    
    private StringBuffer getTemplate() throws Exception 
    {
        URL url = getClass().getResource("/resource/template.html");
        if (url == null)
            throw new NullPointerException("Template '/resource/template.html' not found");
            
        InputStream in = url.openStream();
        StringBuffer sb = new StringBuffer();

        int i=-1;
        while ((i=in.read()) != -1) {
            sb.append((char) i);
        }
        
        in.close();
        return sb;
    }
    
}
