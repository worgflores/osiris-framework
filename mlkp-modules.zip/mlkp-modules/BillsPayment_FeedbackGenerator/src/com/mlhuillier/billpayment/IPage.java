package com.mlhuillier.billpayment;

public interface IPage 
{
    void bindData(PageNavigator nav) throws Exception;
}
