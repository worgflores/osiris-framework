package com.mlhuillier.billpayment;

public class Company 
{
    private String objid;
    private String code;
    private String description;
    private String address;
    private String contactno;
    private boolean active;
    private boolean collectCharge;
    
    public Company() {
    }

    public String getObjid() {
        return objid;
    }

    public void setObjid(String objid) {
        this.objid = objid;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getContactno() {
        return contactno;
    }

    public void setContactno(String contactno) {
        this.contactno = contactno;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public boolean isCollectCharge() {
        return collectCharge;
    }

    public void setCollectCharge(boolean collectCharge) {
        this.collectCharge = collectCharge;
    }

    public String toString() 
    {
        String desc = getDescription();
        return (desc == null ? "" : desc);
    }
    
}
