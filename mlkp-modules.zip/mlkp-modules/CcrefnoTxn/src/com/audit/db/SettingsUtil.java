package com.audit.db;
import java.io.File;
import java.io.FileInputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

public class SettingsUtil {
    public static SettingsUtil shared = new SettingsUtil();
    
    protected Map props = new HashMap();
    
    private SettingsUtil() {
        try {
            String path = System.getProperty("user.dir") + File.separator + "settings.properties";
            
            Properties pr = new Properties();
            pr.load(new FileInputStream(path));
            props.putAll(pr);
            pr.clear();
        } catch(Exception ex) {
            System.out.println("[WARN] " + ex.getMessage());
        }
    }
    
    public String getProperty(String name) {
        if (props.containsKey(name))
            return props.get(name).toString();
        else
            return null;
    }
    
}
