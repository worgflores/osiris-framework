
package com.audit.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DB {
    
    private static Connection sourceConnection;
    private static Connection targetConnection;
    private static DB db = null;
    SettingsUtil su = SettingsUtil.shared;
    
    public DB() throws Exception{
        Class.forName("com.mysql.jdbc.Driver");
        sourceConnection = DriverManager.getConnection(su.getProperty("source.host"), su.getProperty("source.user"), su.getProperty("source.pwd"));
        targetConnection = DriverManager.getConnection(su.getProperty("target.host"), su.getProperty("target.user"), su.getProperty("target.pwd"));
    }
    
    public static DB getInstance() throws Exception {
        if(db == null) {
            db = new DB();
        }
        return db;
    }
    
    public static void close() {
        try {sourceConnection.close();} catch(Exception ex){;}
        try {targetConnection.close();} catch(Exception ex){;}
    }
    
    public void createCcrefnoTable(String table) throws Exception {
        StringBuffer sb = new StringBuffer("CREATE TABLE if not exists audit." + table + " (   ");
        sb.append("    objid varchar(32) NOT NULL default '',");
        sb.append("    dtfiled datetime default NULL,");
        sb.append("    kptn varchar(32) default NULL,");
        sb.append("    ccrefno varchar(10) default NULL,");
        sb.append("    sender varchar(100) default NULL,");
        sb.append("    receiver varchar(100) default NULL,");
        sb.append("    amount decimal(16,2) default NULL,");
        sb.append("    currency varchar(5) default NULL,");
        sb.append("    status varchar(20) default NULL,");
        sb.append("    branchid varchar(6) default NULL,");
        sb.append("    userid varchar(32) default NULL,");
        sb.append("    PRIMARY KEY  (objid),");
        sb.append("    UNIQUE KEY uix_kptn (kptn),");
        sb.append("    KEY ix_dtfiled (dtfiled),");
        sb.append("    KEY ix_ccrefno (ccrefno),");
        sb.append("    KEY ix_branchid (branchid),");
        sb.append("    KEY ix_userid (userid),");
        sb.append("    KEY ix_sender (sender),");
        sb.append("    KEY ix_receiver (receiver)");
        sb.append("    ) ENGINE=MyISAM DEFAULT CHARSET=latin1");
        PreparedStatement ps = null;
        try{
            ps = targetConnection.prepareStatement(sb.toString());
            ps.executeUpdate();
        } catch(Exception ex) {
            throw ex;
        } finally {
            try{ps.close();}catch(Exception ex){;}
        }
    }
    
    public List<Map> getData(Date startdate, Date enddate ) throws Exception {
        List<Map> list = new ArrayList<Map>();
        String sql = "" +
                "select " +
                "   s.objid, s.dtfiled, s.strkptn as kptn ,sif.strccrefno as ccrefno, " +
                "   trim(concat(s.strsenderlname, ', ', s.strsenderfname, ' ', ifnull(s.strsendermname,''))) as sender, " +
                "   trim(concat(s.strreceiverlname, ', ', s.strreceiverfname, ' ', ifnull(s.strreceivermname,''))) as receiver, " +
                "   s.curprincipal as amount, sif.strcurrencyid as currency, " +
                "   case  " +
                "	when state = '0' then 'UNCLAIMED' " +
                "	when state = '1' then 'CLAIMED' " +
                "	when state = '3' then 'REINSTATED' " +
                "	when state = '5' then 'RETURN TO SENDER' " +
                "   else '' END AS status, " +
                "   s.strbranchid as branchid, s.struserid as userid	" +
                "from( " +
                "	select objid from mlkp.tblsendout " +
                "	where dtfiled >= ? and dtfiled < ? " +
                " ) bt " +
                " inner join mlkp.tblsendout s on s.objid = bt.objid " +
                " inner join mlkp.tblsendoutinfo sif on sif.objid=s.objid " + 
                " inner join mlkp.tblbranch b on s.strbranchid=b.objid " + 
                " inner join mlkp.tblorganization o on b.strorganizationid=o.objid " + 
                " where ifnull(sif.strccrefno,'') > 0 and o.intcorporate=0 and s.state in (0,1,3,5) ";
        PreparedStatement ps = null;
        ResultSet rs = null;
        ResultSetMetaData meta = null;
        try{
            ps = sourceConnection.prepareStatement(sql);
            ps.setObject(1, startdate);
            ps.setObject(2, enddate);
            rs = ps.executeQuery();
            meta = rs.getMetaData();
            while(rs.next()) {
                Map data = new HashMap();
                for(int i=0; i < meta.getColumnCount(); i++) {
                    int idx = i+1;
                    data.put(meta.getColumnName(idx), rs.getObject(idx));
                }
                list.add(data);
            }
            return list;
        }catch(Exception ex) {
            throw ex;
        } finally {
            try{rs.close();}catch(Exception ex) {;}
            try{ps.close();}catch(Exception ex) {;}
        }
    }
    
    public void insertData(Map map, String target) throws Exception{
        StringBuffer b = new StringBuffer();
        b.append("insert ignore into audit." + target);
        b.append("  (objid, dtfiled, kptn, ccrefno, sender, receiver, ");
        b.append("   amount, currency, status, branchid, userid ) ");
        b.append(" values ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? )" );        
        PreparedStatement ps = null;
        try{
            ps = targetConnection.prepareStatement(b.toString());
            ps.setObject(1, map.get("objid"));
            ps.setObject(2, map.get("dtfiled"));
            ps.setObject(3, map.get("kptn"));
            ps.setObject(4, map.get("ccrefno"));
            ps.setObject(5, map.get("sender"));
            ps.setObject(6, map.get("receiver"));
            ps.setObject(7, map.get("amount"));
            ps.setObject(8, map.get("currency"));
            ps.setObject(9, map.get("status"));
            ps.setObject(10, map.get("branchid"));
            ps.setObject(11, map.get("userid"));
            ps.executeUpdate();
        }catch(Exception ex) {
            throw ex;
        }finally {
            try{ps.close();}catch(Exception ex) {;}
        }
    }
    
}
