
package com.audit.ccrefno.transfer;

import javax.swing.UIManager;

public class Main {

    public Main() {
    }

    public static void main(String[] args) {
        try{
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        }catch(Exception ex){
            ex.printStackTrace();
        }
        FMain f = new FMain();
        f.launch();
    }
            
}
