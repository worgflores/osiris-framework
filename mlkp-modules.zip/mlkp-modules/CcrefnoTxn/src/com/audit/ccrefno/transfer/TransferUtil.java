
package com.audit.ccrefno.transfer;

import com.audit.db.DB;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

public class TransferUtil {
    
    private Date startdate;
    private Date enddate;
    private DB db;
    
    private SimpleDateFormat sdf1 = new SimpleDateFormat("yyyyMM");
    private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    
    public TransferUtil(Date startdate, Date enddate, DB db) {
        this.startdate = startdate;
        this.enddate = enddate;
        this.db = db;
    }
    
    public Date getStartdate() {
        return startdate;
    }
    
    public Date getEnddate() {
        return enddate;
    }
    
    public void startTransfer() throws Exception{
        try{
            String target = "ccrefnotxn" + sdf1.format(startdate);            
            getDb().createCcrefnoTable(target);
            System.out.println("Starting fetching data......" );
            System.out.println("    Start date " + sdf.format(startdate) );
            System.out.println("    End date " + sdf.format(enddate) );
            List<Map> l = getDb().getData(startdate, enddate);
            System.out.println("Finish fetching data......" );
            System.out.println("Starting to insert data ");
            int i=0;
            for(Map o : l){
                i++;
                System.out.println("Processing sendout id : counter = " + i + ", objid = " + o.get("objid"));
                getDb().insertData(o, target);
            }
            System.out.println("Finish to insert data ");
        }catch(Exception ex) {
            throw ex;
        }
    }

    public DB getDb() {
        return db;
    }
}
