
package com.audit.ccrefno.transfer;

import com.audit.db.DB;
import java.awt.Component;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import javax.swing.JComponent;
import javax.swing.JOptionPane;

public class TransferPage extends javax.swing.JPanel {
    
    private FetchData data;
    private Date lastDate;
    
    public TransferPage() {
        initComponents();
    }
    
    // <editor-fold defaultstate="collapsed" desc=" Generated Code ">//GEN-BEGIN:initComponents
    private void initComponents() {
        jLabel1 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        txtStartdate = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txtEnddate = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        btnStart = new javax.swing.JButton();
        btnCancel = new javax.swing.JButton();

        setLayout(new java.awt.BorderLayout());

        jLabel1.setBackground(new java.awt.Color(0, 51, 153));
        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 24));
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("  Transfer Invalid CCRefno");
        jLabel1.setOpaque(true);
        jLabel1.setPreferredSize(new java.awt.Dimension(162, 40));
        add(jLabel1, java.awt.BorderLayout.NORTH);

        jPanel1.setLayout(null);

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 18));
        jLabel2.setText("Start Date :");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(20, 50, 110, 20);

        txtStartdate.setFont(new java.awt.Font("Tahoma", 1, 24));
        txtStartdate.setForeground(new java.awt.Color(153, 0, 0));
        jPanel1.add(txtStartdate);
        txtStartdate.setBounds(130, 40, 190, 40);

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 18));
        jLabel3.setText("End Date :");
        jPanel1.add(jLabel3);
        jLabel3.setBounds(20, 100, 100, 20);

        txtEnddate.setFont(new java.awt.Font("Tahoma", 1, 24));
        txtEnddate.setForeground(new java.awt.Color(153, 0, 0));
        jPanel1.add(txtEnddate);
        txtEnddate.setBounds(130, 90, 190, 40);

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 18));
        jLabel4.setText("(yyyy-mm-dd)");
        jPanel1.add(jLabel4);
        jLabel4.setBounds(330, 50, 130, 30);

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 18));
        jLabel5.setText("(yyyy-mm-dd)");
        jPanel1.add(jLabel5);
        jLabel5.setBounds(330, 100, 130, 30);

        btnStart.setFont(new java.awt.Font("Tahoma", 1, 14));
        btnStart.setMnemonic('s');
        btnStart.setText("Start");
        btnStart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnStartActionPerformed(evt);
            }
        });

        jPanel1.add(btnStart);
        btnStart.setBounds(70, 170, 110, 40);

        btnCancel.setFont(new java.awt.Font("Tahoma", 1, 14));
        btnCancel.setMnemonic('c');
        btnCancel.setText("Cancel");
        btnCancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelActionPerformed(evt);
            }
        });

        jPanel1.add(btnCancel);
        btnCancel.setBounds(190, 170, 110, 40);

        add(jPanel1, java.awt.BorderLayout.CENTER);

    }// </editor-fold>//GEN-END:initComponents
    
    private void btnCancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelActionPerformed
        int i = JOptionPane.showConfirmDialog(this, "Are you sure want to cancel the transferring of data?", "Confirm", JOptionPane.YES_NO_OPTION);
        if(i == JOptionPane.NO_OPTION) return;
        
        if(data != null){            
            data.setInterrupt(true);
        }
        txtStartdate.setEnabled(true);
        txtEnddate.setEnabled(true);
        btnStart.setEnabled(true);
        txtStartdate.requestFocus();
    }//GEN-LAST:event_btnCancelActionPerformed
    
    private void btnStartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnStartActionPerformed
        try{
            validateDate(txtStartdate, txtStartdate.getText(), "Start Date");
            validateDate(txtEnddate, txtEnddate.getText(), "End Date");
            data = new FetchData(this);
            Thread t = new Thread(data);
            t.start();
        }catch(Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Error ", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_btnStartActionPerformed
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCancel;
    private javax.swing.JButton btnStart;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField txtEnddate;
    private javax.swing.JTextField txtStartdate;
    // End of variables declaration//GEN-END:variables
    
    public void validateDate(Component comp, Object value, String caption) throws Exception {
        if(! isDate(value)) {
            comp.requestFocus();
            throw new Exception(caption + " is invalid                       ");
        }
    }
    
    private boolean isEmpty(Object val){
        if(val == null)
            return true;
        else
            return (val.toString().trim().length() == 0);
    }
    
    private boolean isDate(Object value) {
        if(isEmpty(value)) return false;
        String 	s = value+"";
        java.util.Date	dt = null;
        
        try {
            if (dt == null) {
                dt = new java.util.Date(s);
            }
        }catch(Exception ex){;}
        
        try {
            if (dt == null) {
                dt = java.sql.Date.valueOf(s);
            }
        }catch(Exception ex){;}
        
        try {
            if (dt == null) {
                dt = java.sql.Timestamp.valueOf(s);
            }
        }catch(Exception ex){;}
        
        if (dt == null) return false;
        
        java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd");
        String res = sdf.format(dt);
        return res.equals(s);
    }
    
    public void afterRun() {
        System.out.println("Finish Transferring the Invalid Ccrefno.");
    }
    
    private class FetchData implements Runnable {        
        private boolean interrupt = false;
        private JComponent jc;
        
        public FetchData(JComponent jc) {
            this.jc = jc;
        }
        
        public void setInterrupt(boolean interrupt) {
            this.interrupt = interrupt;
        }
        
        public void run() {
            try{
                txtStartdate.setEnabled(false);
                txtEnddate.setEnabled(false);
                btnStart.setEnabled(false);
                Date dtStart = java.sql.Date.valueOf(txtStartdate.getText());
                Date dtEnd = java.sql.Date.valueOf(txtEnddate.getText());
                if(dtEnd.before(dtStart)) {
                    throw new Exception("End Date must not less than the Start Date. ");
                }
                Calendar cal = new GregorianCalendar();
                cal.setTime(dtEnd);
                DB db = DB.getInstance();
                while(true) {
                    if(interrupt) break;
                    Date dt = cal.getTime();
                    cal.add(cal.HOUR, -1);
                    TransferUtil util = new TransferUtil(cal.getTime(), dt, db);
                    util.startTransfer();
                    if(! cal.getTime().after(dtStart)) break;
                }
                if(! interrupt)
                    JOptionPane.showMessageDialog(jc, "Invalid ccrefno is successfully transferred.", "Infomation", JOptionPane.INFORMATION_MESSAGE);
                else
                    JOptionPane.showMessageDialog(jc, "Interupted.", "Infomation", JOptionPane.INFORMATION_MESSAGE);
            }catch(Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(jc, ex.getMessage(), "Error ", JOptionPane.ERROR_MESSAGE);
                throw new IllegalStateException(ex.getMessage(), ex);
            }finally {
                txtStartdate.setEnabled(true);
                txtEnddate.setEnabled(true);
                btnStart.setEnabled(true);
            }
        }
    }
}
