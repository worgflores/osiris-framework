package com.mlhuillier.fu.c2p;

public class SelectCustomerPage extends com.rameses.osiris.client.Page
{
    
    /** Creates new form CheckRemotePage */
    public SelectCustomerPage()
{
        initComponents();
    }
    
    // <editor-fold defaultstate="collapsed" desc=" Generated Code ">//GEN-BEGIN:initComponents
    private void initComponents() {
        xLabel1 = new com.rameses.osiris.client.component.XLabel();
        xPanel1 = new com.rameses.osiris.client.component.XPanel();
        xLabel5 = new com.rameses.osiris.client.component.XLabel();
        xCombo1 = new com.rameses.osiris.client.component.XCombo();
        xPanel2 = new com.rameses.osiris.client.component.XPanel();
        xGlue1 = new com.rameses.osiris.client.component.spacer.XGlue();
        xStrut2 = new com.rameses.osiris.client.component.spacer.XStrut();
        xButton2 = new com.rameses.osiris.client.component.XButton();
        xStrut1 = new com.rameses.osiris.client.component.spacer.XStrut();
        xButton1 = new com.rameses.osiris.client.component.XButton();

        setLayout(new java.awt.BorderLayout());

        xLabel1.setBackground(new java.awt.Color(0, 0, 153));
        xLabel1.setForeground(new java.awt.Color(255, 255, 255));
        xLabel1.setOpaque(true);
        xLabel1.setPadding(new java.awt.Insets(10, 10, 10, 10));
        xLabel1.setText("<html> <font size=\"5\">FileUpload : Select Customer</font> </html>");
        add(xLabel1, java.awt.BorderLayout.NORTH);

        xPanel1.setLayout(null);

        xLabel5.setFont(new java.awt.Font("Tahoma", 1, 11));
        xLabel5.setText("Please select a customer from the list");
        xPanel1.add(xLabel5);
        xLabel5.setBounds(30, 30, 460, 20);

        xCombo1.setModelName("fileupload");
        xCombo1.setDefaultFocus(true);
        xCombo1.setName("senderid");
        xCombo1.setSrc("branchuser");
        xCombo1.setSrckey("branchcode");
        xCombo1.setSrcvalue("branchdesc");
        xPanel1.add(xCombo1);
        xCombo1.setBounds(30, 60, 330, 22);

        add(xPanel1, java.awt.BorderLayout.CENTER);

        xPanel2.setLayout(new javax.swing.BoxLayout(xPanel2, javax.swing.BoxLayout.X_AXIS));

        xPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        xPanel2.setOpaque(true);
        xPanel2.setPadding(new java.awt.Insets(5, 5, 5, 5));
        xPanel2.add(xGlue1);

        xStrut2.setLength(5);
        xPanel2.add(xStrut2);

        xButton2.setIconResource("shared/images/16/next.png");
        xButton2.setAlt('n');
        xButton2.setDefaultFocusInWindow(true);
        xButton2.setOnclick("doValidateCustomer");
        xButton2.setText(" Next  ");
        xPanel2.add(xButton2);

        xPanel2.add(xStrut1);

        xButton1.setIconResource("shared/images/16/close.png");
        xButton1.setAlt('c');
        xButton1.setOnclick("doClose");
        xButton1.setText("Cancel");
        xPanel2.add(xButton1);

        add(xPanel2, java.awt.BorderLayout.SOUTH);

    }// </editor-fold>//GEN-END:initComponents
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private com.rameses.osiris.client.component.XButton xButton1;
    private com.rameses.osiris.client.component.XButton xButton2;
    private com.rameses.osiris.client.component.XCombo xCombo1;
    private com.rameses.osiris.client.component.spacer.XGlue xGlue1;
    private com.rameses.osiris.client.component.XLabel xLabel1;
    private com.rameses.osiris.client.component.XLabel xLabel5;
    private com.rameses.osiris.client.component.XPanel xPanel1;
    private com.rameses.osiris.client.component.XPanel xPanel2;
    private com.rameses.osiris.client.component.spacer.XStrut xStrut1;
    private com.rameses.osiris.client.component.spacer.XStrut xStrut2;
    // End of variables declaration//GEN-END:variables
    
}
