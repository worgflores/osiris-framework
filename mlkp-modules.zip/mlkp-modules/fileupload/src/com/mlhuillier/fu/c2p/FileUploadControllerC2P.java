package com.mlhuillier.fu.c2p;

import com.rameses.osiris.client.AbstractFormController;
import java.awt.Dimension;
import java.io.InputStream;

public class FileUploadControllerC2P extends AbstractFormController
{
    
    public FileUploadControllerC2P() 
    {
        addPage("create", CreatePage.class);
        addPage("confirm", ConfirmPage.class);
        addPage("readonly", ReadOnlyPage.class);
    }

    protected Class getDefaultPageClass() { return SelectCustomerPage.class; }

    protected InputStream getCodeBaseAsStream() { 
        return getClass().getResourceAsStream("FileUploadControllerC2P.xml");
    }

    public String getPreferredID() { return "fileuploadC2P.frm"; }

    public String getTitle() { return "File Upload (Company-To-Person)"; }
    
    public Dimension getPreferredSize() {
        return new Dimension(720, 610);
    }

    public boolean isDocument() { return true; }

    public String getDocumentName() { return "fileupload"; }

    public String[] getDataNames() {
        return new String[]
        {
            "fileuploaditem"
        };
    }
    
}
