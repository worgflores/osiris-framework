package com.mlhuillier.fu.c2p;

import java.io.File;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;

public final class C2PTextBuilder 
{
    private String NUMBERS = "0123456789";
    private String LETTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
    private String GENDERS = "123";
    
    public C2PTextBuilder()
    {
    }

    public void generate(String branchid, String userid, String terminalid) throws Exception
    {
        StringBuffer sbh = new StringBuffer();
        sbh.append(formatDate(new Date(), "yyyy-MM-dd"));
        sbh.append(branchid + replicate(" ", (6-branchid.length())));
        sbh.append(userid + replicate(" ", (20-userid.length())));
        sbh.append(terminalid + replicate(" ", (10-terminalid.length())));
        sbh.append("TB09!DMX$G");
        sbh.append("00005");
        sbh.append("000025");
        sbh.append("\n");
        
        StringBuffer sb = new StringBuffer();
        for (int i=1; i<=5; i++)
        {
            sb.append("0000" + i);
            sb.append(formatDate(new Date(), "yyyy-MM-dd hh:mm:ss"));
            sb.append(generateControlNo(10) + replicate(" ", 10));
            sb.append("000000500.00");
            sb.append("PHP");
            sb.append(replicate(" ",20));
            sb.append(replicate(" ",20));
            sb.append(replicate(" ",30));
            sb.append("DELA CRUZ" + replicate(" ",11));
            sb.append("JUAN" + replicate(" ",16));
            sb.append("JOHN" + replicate(" ",16));
            sb.append(generateRandom("123",1));
            sb.append(generateRandom(NUMBERS,4) + "-" + generateRandom(NUMBERS,2) + "-" + generateRandom(NUMBERS,2));
            sb.append("ORCHID ST. CAPITOL SITE" + replicate(" ", 27));
            sb.append("CEBU" + replicate(" ", 46));
            sb.append("PHILIPPINES" + replicate(" ", 39));
            sb.append(replicate(" ", 20));
            sb.append(replicate(" ", 100));
            sb.append("\n");
        }
                
        sb.insert(0, sbh);
        
        FileWriter fw = null;
        try
        {
            String filename = getClass().getSimpleName() + System.currentTimeMillis();
            File file = new File("test/" + filename + ".txt");
            fw = new FileWriter(file);
            fw.write(sb.toString());
            fw.flush();
            
            JOptionPane.showMessageDialog(null, "Successfully saved. File is " + file.getAbsolutePath());
        }
        catch(Exception ex) {
            throw ex;
        }
        finally {
            try { fw.close(); }catch(Exception ign) {;}
        }
    }
    
    private String formatDate(Date date, String pattern)
    {
        SimpleDateFormat sdf = new SimpleDateFormat(pattern);
        return sdf.format(date);
    }
    
    private String generateControlNo(int length) {
        return generateRandom(NUMBERS, length);
    }
    
    private String replicate(String text, int length)
    {
        StringBuffer sb = new StringBuffer();
        for (int i=0; i<length; i++) {
            sb.append(text);
        }
        return sb.toString();        
    }
    
    private String generateRandomLetters(int length) {
        return generateRandom(LETTERS, length);
    }
    
    private String generateRandom(String text, int length)
    {
        StringBuffer sb = new StringBuffer();
        for (int i=0; i<length; i++) 
        {
            int idx = (int) (Math.random() * text.length());
            sb.append(text.charAt(idx));
        }
        return sb.toString();        
    }
    
}
