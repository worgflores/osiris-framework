package com.mlhuillier.fu.metrobank.converter;

class Data 
{
    private int index;
    private String dtfiled;
    private String refno;
    private String principal;
    private String currencyid;
    private String sourceoffund;
    private String relationtoreceiver;
    private String purpose;
    private String lastname;
    private String firstname;
    private String middlename;
    private String gender = "3";
    private String birthdate;
    private String street;
    private String province = "";
    private String country = "Philippines";
    private String phone = "";
    private String msg = "";

    // <editor-fold defaultstate="collapsed" desc=" Generated Code ">
    public String getDtfiled() {
        return dtfiled;
    }

    public void setDtfiled(String dtfiled) {
        this.dtfiled = dtfiled;
    }

    public String getRefno() {
        return refno;
    }

    public void setRefno(String refno) {
        this.refno = refno;
    }
    
    public String getPrincipal() {
        return principal;
    }

    public void setPrincipal(String principal) {
        this.principal = principal;
    }

    public String getCurrencyid() {
        return currencyid;
    }

    public void setCurrencyid(String currencyid) {
        this.currencyid = currencyid;
    }

    public String getSourceoffund() {
        return sourceoffund;
    }

    public void setSourceoffund(String sourceoffund) {
        this.sourceoffund = sourceoffund;
    }

    public String getRelationtoreceiver() {
        return relationtoreceiver;
    }

    public void setRelationtoreceiver(String relationtoreceiver) {
        this.relationtoreceiver = relationtoreceiver;
    }

    public String getPurpose() {
        return purpose;
    }

    public void setPurpose(String purpose) {
        this.purpose = purpose;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getMiddlename() {
        return middlename;
    }

    public void setMiddlename(String middlename) {
        this.middlename = middlename;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getBirthdate() {
        return birthdate;
    }

    public void setBirthdate(String birthdate) {
        this.birthdate = birthdate;
    }

    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
    // </editor-fold>

    public int getIndex() {
        return index;
    }

    public void setIndex(int index) {
        this.index = index;
    }

}
