package com.mlhuillier.fu.metrobank.converter;

import java.text.DecimalFormat;

public class DataFormatter 
{
    
    public DataFormatter() {
    }
    
    public StringBuffer format(Data data)
    {
        StringBuffer sb = new StringBuffer();
        String value = data.getDtfiled();
        sb.append(value.substring(4) + "-" + value.substring(0,2) + "-" + value.substring(2, 4) + " 00:00:00");
        
        value = data.getRefno();
        if (value.length() >= 20)
            sb.append(value.substring(0, 20));
        else
            sb.append(value + replicate(" ", 20-value.length()));
        
        DecimalFormat decf = new DecimalFormat("#0.00");
        value = decf.format(Double.parseDouble(data.getPrincipal()));
        if (value.length() >= 12)
            sb.append(value.substring(0, 12));
        else
            sb.append(replicate("0", 12-value.length()) + value);
        
        value = data.getCurrencyid();
        if (value.length() >= 3)
            sb.append(value.substring(0, 3));
        else
            sb.append(value + replicate(" ", 3-value.length()));
        
        sb.append(replicate(" ", 20));
        sb.append(replicate(" ", 20));
        sb.append(replicate(" ", 30));
        
        value = data.getLastname();
        if (value.length() >= 20)
            sb.append(value.substring(0, 20));
        else
            sb.append(value + replicate(" ", 20-value.length()));
        
        value = data.getFirstname();
        if (value.length() >= 20)
        {
            sb.append(value.substring(0, 20));
            
            value = value.substring(20);
            if (value.length() >= 20)
                sb.append(value.substring(0, 20));
            else
                sb.append(value + replicate(" ", 20-value.length()));
        }
        else
        {
            sb.append(value + replicate(" ", 20-value.length()));
            sb.append(value + replicate(" ", 20-value.length()));
        }

        sb.append(data.getGender());
        sb.append(replicate(" ", 10));
        
        value = data.getStreet();
        if (value.length() >= 50)
            sb.append(value.substring(0, 50));
        else
            sb.append(value + replicate(" ", 50-value.length()));
        
        value = data.getProvince();
        if (value.length() >= 50)
            sb.append(value.substring(0, 50));
        else
            sb.append(value + replicate(" ", 50-value.length()));        
        
        value = data.getCountry();
        if (value.length() >= 50)
            sb.append(value.substring(0, 50));
        else
            sb.append(value + replicate(" ", 50-value.length()));                
        
        value = data.getPhone();
        if (value.length() >= 20)
            sb.append(value.substring(0, 20));
        else
            sb.append(value + replicate(" ", 20-value.length()));
        
        value = data.getMsg();
        if (value.length() >= 100)
            sb.append(value.substring(0, 100));
        else
            sb.append(value + replicate(" ", 100-value.length()));
        
        return sb;
    }
    
    public final String replicate(String value, int length)
    {
        StringBuffer sb = new StringBuffer();
        for (int i=0; i<length; i++) {
            sb.append(value);
        }
        return sb.toString();
    }
    
    public final boolean isEmpty(Object value)
    {
        if (value == null) 
            return true;
        else if (value instanceof String)
            return (value.toString().trim().length() == 0);
        else
            return false;
    }
    
}
