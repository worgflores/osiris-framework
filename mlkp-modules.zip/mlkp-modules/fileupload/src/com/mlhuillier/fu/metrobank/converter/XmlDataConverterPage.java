package com.mlhuillier.fu.metrobank.converter;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.filechooser.FileFilter;

public class XmlDataConverterPage extends javax.swing.JPanel 
{
    private XmlDataConverter converter;
    private JFileChooser jfc;
    private StringBuffer buffer;
    
    public XmlDataConverterPage() 
    {
        initComponents();
    }

    private void processFile(File file)
    {
        try
        {
            txtFile.setText(file.getAbsolutePath());
            txtValid.setText("");
            
            converter = new XmlDataConverter();
            buffer = converter.convert(new FileInputStream(file));
            txtValid.setText(buffer.toString());
            SwingUtilities.updateComponentTreeUI(this);
        }
        catch(Exception ex) 
        {
            buffer = new StringBuffer();
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // <editor-fold defaultstate="collapsed" desc=" Generated Code ">//GEN-BEGIN:initComponents
    private void initComponents() {
        jLabel1 = new javax.swing.JLabel();
        cmdBrowse = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        txtFile = new javax.swing.JTextField();
        cmd = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtValid = new javax.swing.JTextArea();
        jLabel4 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtInvalid = new javax.swing.JTextArea();
        jPanel1 = new javax.swing.JPanel();
        cmdSave = new javax.swing.JButton();
        cmdCancel = new javax.swing.JButton();

        setLayout(new java.awt.BorderLayout());

        setPreferredSize(new java.awt.Dimension(581, 488));
        jLabel1.setBackground(new java.awt.Color(0, 102, 153));
        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18));
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("METROBANK DATA CONVERTER");
        jLabel1.setBorder(javax.swing.BorderFactory.createEmptyBorder(10, 10, 10, 10));
        jLabel1.setOpaque(true);
        add(jLabel1, java.awt.BorderLayout.NORTH);

        cmdBrowse.setLayout(null);

        cmdBrowse.setBackground(new java.awt.Color(255, 255, 255));
        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 11));
        jLabel2.setText("Please select the xml file :");
        cmdBrowse.add(jLabel2);
        jLabel2.setBounds(18, 18, 162, 18);

        txtFile.setEditable(false);
        cmdBrowse.add(txtFile);
        txtFile.setBounds(18, 36, 351, 19);

        cmd.setText("Browse...");
        cmd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmdActionPerformed(evt);
            }
        });

        cmdBrowse.add(cmd);
        cmd.setBounds(372, 33, 87, 23);

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 11));
        jLabel3.setText("Valid Entries : ");
        cmdBrowse.add(jLabel3);
        jLabel3.setBounds(18, 69, 93, 18);

        txtValid.setColumns(20);
        txtValid.setEditable(false);
        txtValid.setRows(5);
        jScrollPane1.setViewportView(txtValid);

        cmdBrowse.add(jScrollPane1);
        jScrollPane1.setBounds(18, 87, 552, 171);

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 11));
        jLabel4.setText("Invalid Entries :");
        cmdBrowse.add(jLabel4);
        jLabel4.setBounds(18, 267, 102, 18);

        txtInvalid.setColumns(20);
        txtInvalid.setEditable(false);
        txtInvalid.setRows(5);
        jScrollPane2.setViewportView(txtInvalid);

        cmdBrowse.add(jScrollPane2);
        jScrollPane2.setBounds(18, 285, 552, 92);

        add(cmdBrowse, java.awt.BorderLayout.CENTER);

        jPanel1.setLayout(null);

        jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel1.setPreferredSize(new java.awt.Dimension(539, 43));
        cmdSave.setText("Save");
        cmdSave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmdSaveActionPerformed(evt);
            }
        });

        jPanel1.add(cmdSave);
        cmdSave.setBounds(402, 9, 75, 23);

        cmdCancel.setText(" Cancel ");
        cmdCancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmdCancelActionPerformed(evt);
            }
        });

        jPanel1.add(cmdCancel);
        cmdCancel.setBounds(492, 9, 71, 23);

        add(jPanel1, java.awt.BorderLayout.SOUTH);

    }// </editor-fold>//GEN-END:initComponents

    private void cmdCancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmdCancelActionPerformed

        System.exit(0);
        
    }//GEN-LAST:event_cmdCancelActionPerformed

    private void cmdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmdActionPerformed
     
        if (jfc == null)
        {
            jfc = new JFileChooser();
            jfc.setFileFilter(new FileFilter() 
            {
                public boolean accept(File f) 
                {
                    if (f.isDirectory()) 
                        return true;
                    else
                        return (f.getName().endsWith(".xml"));
                }

                public String getDescription() {
                    return "XML Files (*.xml)";
                }
            });
        }
        int retOpt = jfc.showOpenDialog(this);
        if (retOpt == JFileChooser.APPROVE_OPTION) 
            processFile(jfc.getSelectedFile());
            
    }//GEN-LAST:event_cmdActionPerformed

    private void cmdSaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmdSaveActionPerformed

        int retOpt = jfc.showSaveDialog(this);
        if (retOpt == JFileChooser.APPROVE_OPTION)
        {
            FileWriter writer = null;
            try
            {
                writer = new FileWriter(jfc.getSelectedFile());
                writer.write(buffer.toString());
                JOptionPane.showMessageDialog(this, "Successfully saved");
            }
            catch(Exception ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
            finally {
                try { writer.close(); }catch(Exception ign){;}
            }
        }
        
    }//GEN-LAST:event_cmdSaveActionPerformed
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton cmd;
    private javax.swing.JPanel cmdBrowse;
    private javax.swing.JButton cmdCancel;
    private javax.swing.JButton cmdSave;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextField txtFile;
    private javax.swing.JTextArea txtInvalid;
    private javax.swing.JTextArea txtValid;
    // End of variables declaration//GEN-END:variables
    
}
