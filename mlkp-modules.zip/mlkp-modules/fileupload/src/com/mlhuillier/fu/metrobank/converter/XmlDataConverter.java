package com.mlhuillier.fu.metrobank.converter;

import com.rameses.osiris.client.xml.XmlNode;
import com.rameses.osiris.client.xml.XmlParser;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class XmlDataConverter 
{
    private String branchid = "MTRBNK";
    private String userid = "MTRBNKU1";
    private String terminalid = "MTRBNKT1";
    private String secretkey = "TB09!DMX$G";
    private StringBuffer errorBuffer = new StringBuffer();
    
    public XmlDataConverter() 
    {
    }
    
    public StringBuffer getErrorBuffer() {
        return errorBuffer;
    }

    public StringBuffer convert(InputStream in) throws Exception
    {
        try
        {
            errorBuffer = new StringBuffer();
            
            int counter = -1;
            List list = new ArrayList();
            XmlParser parser = new XmlParser();
            XmlNode node = parser.parse(in);
            Iterator rows = node.getNodes("Worksheet/Table/Row");
            while (rows.hasNext())
            {
                XmlNode xn = (XmlNode) rows.next();
                
                counter += 1;
                if (counter == 0) continue; 
                
                parse(list, xn, counter);
            }
            
            counter = 0;
            rows = list.iterator();
            
            double amount = 0.0;
            StringBuffer buffer = new StringBuffer();
            DataFormatter formatter = new DataFormatter();
            while (rows.hasNext())
            {
                Data data = (Data) rows.next();
                try
                {
                    counter += 1;
                    StringBuffer sb0 = formatter.format(data);
                    int length = ("" + counter).length();
                    sb0.insert(0, replicate("0", 5-length) + counter);
                    
                    if (buffer.length() > 0) 
                        buffer.append("\n");
                    
                    buffer.append(sb0);
                    
                    amount += Double.parseDouble(data.getPrincipal());
                }
                catch(Exception ex) 
                {
                    counter -= 1;
                    errorBuffer.append("Error at line #" + data.getIndex() + "\n");
                    errorBuffer.append("   caused by, " + ex.getMessage());
                }
            }

            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            StringBuffer sbh = new StringBuffer();
            sbh.append(sdf.format(new Date()));
            if (branchid.length() >= 6)
                sbh.append(branchid.substring(0, 6));
            else 
                sbh.append(branchid + replicate(" ", 6-branchid.length()));
            
            if (userid.length() >= 20)
                sbh.append(userid.substring(0, 20));
            else 
                sbh.append(userid + replicate(" ", 20-userid.length()));            
            
            if (terminalid.length() >= 10)
                sbh.append(terminalid.substring(0, 10));
            else 
                sbh.append(terminalid + replicate(" ", 10-terminalid.length()));            
            
            sbh.append(secretkey);
            
            String scount = counter+"";
            sbh.append(replicate("0", 5-scount.length()) + scount);
            
            if (amount < 100.0) amount = 0.0;
            String samt = ((long) (amount / 100.0))+"";
            sbh.append(replicate("0", 6-samt.length()) + samt);
            sbh.append("\n");
            
            buffer.insert(0, sbh);
            return buffer;
        }
        catch(Exception ex) {
            throw ex;
        }
        finally {
            try { in.close(); }catch(Exception ign) {;}
        }
    }

    private void parse(List list, XmlNode node, int index)
    {
        Data ctx = new Data();
        ctx.setIndex(index);
        ctx.setDtfiled(getValueAt(node, 27));
        ctx.setRefno(getValueAt(node, 1));
        ctx.setPrincipal(getValueAt(node, 13));
        ctx.setCurrencyid(getValueAt(node, 16));
        
        String[] arr = getValueAt(node, 3).split(",");
        ctx.setLastname(arr[0]);
        if (arr.length >= 2) ctx.setFirstname(arr[1]);
        
        String address = getValueAt(node, 4) + " " + getValueAt(node, 5);
        try 
        {
            ctx.setStreet(address.substring(0, 50).trim());
            address = address.substring(50).trim();
        } catch(Exception ign) {
            ctx.setStreet(address.trim());
        }
        
        try {
            ctx.setProvince(address.substring(0, 50).trim());
        } catch(Exception ign) {
            ctx.setProvince(address.trim());
        }
        
        ctx.setPhone(getValueAt(node, 6));
        list.add(ctx);
    }
    
    private String replicate(String value, int length)
    {
        StringBuffer sb = new StringBuffer();
        for (int i=0; i<length; i++) {
            sb.append(value);
        }
        return sb.toString();
    }
    
    private String getValueAt(XmlNode data, int index)
    {
        int counter = 0;
        Map map = new HashMap();
        Iterator nodes = data.getNodes("Cell");
        while (nodes.hasNext())
        {
            XmlNode xn = (XmlNode) nodes.next();
            int colIndex = -1;
            try { 
                colIndex = Integer.parseInt(xn.getAttribute("ss:Index"));
            } catch(Exception ing) {;}
            
            if (colIndex < 0)
                counter += 1;
            else
                counter = colIndex;
            
            map.put(counter+"", xn.getValue("Data"));
        }
        
        Object value = map.get(index+"");
        return (value == null ? "" : value.toString());
    }
    
}
