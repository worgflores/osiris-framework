package com.mlhuillier.fu.p2p;

public class ReadOnlyPage extends com.rameses.osiris.client.Page
{
    
    /** Creates new form CheckRemotePage */
    public ReadOnlyPage()
{
        initComponents();
    }
    
    // <editor-fold defaultstate="collapsed" desc=" Generated Code ">//GEN-BEGIN:initComponents
    private void initComponents() {
        xPanel1 = new com.rameses.osiris.client.component.XPanel();
        xPanel3 = new com.rameses.osiris.client.component.XPanel();
        xLabel2 = new com.rameses.osiris.client.component.XLabel();
        xLabel3 = new com.rameses.osiris.client.component.XLabel();
        xLabel4 = new com.rameses.osiris.client.component.XLabel();
        xTextField1 = new com.rameses.osiris.client.component.XTextField();
        xTextField2 = new com.rameses.osiris.client.component.XTextField();
        xTextField3 = new com.rameses.osiris.client.component.XTextField();
        xPanel5 = new com.rameses.osiris.client.component.XPanel();
        xLabel012 = new com.rameses.osiris.client.component.template.XLabel01();
        xLabel5 = new com.rameses.osiris.client.component.XLabel();
        xTable1 = new com.rameses.osiris.client.component.XTable();
        xLabel6 = new com.rameses.osiris.client.component.XLabel();
        xTextField4 = new com.rameses.osiris.client.component.XTextField();
        xLabel7 = new com.rameses.osiris.client.component.XLabel();
        xLabel8 = new com.rameses.osiris.client.component.XLabel();
        xTextField5 = new com.rameses.osiris.client.component.XTextField();
        xTextField6 = new com.rameses.osiris.client.component.XTextField();
        xLabel9 = new com.rameses.osiris.client.component.XLabel();
        xTextField7 = new com.rameses.osiris.client.component.XTextField();
        xPanel2 = new com.rameses.osiris.client.component.XPanel();
        xLabel1 = new com.rameses.osiris.client.component.XLabel();
        xToolbar1 = new com.rameses.osiris.client.component.XToolbar();
        xButton5 = new com.rameses.osiris.client.component.XButton();
        xButton6 = new com.rameses.osiris.client.component.XButton();

        setLayout(new java.awt.BorderLayout());

        xPanel1.setLayout(null);

        xPanel3.setLayout(null);

        xPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(" Customer Information "));
        xLabel2.setText("<html>Name: <font color=\"red\"><b>*</b></font></html>");
        xPanel3.add(xLabel2);
        xLabel2.setBounds(20, 30, 80, 20);

        xLabel3.setText("<html>Address: <font color=\"red\"><b>*</b></font></html>");
        xPanel3.add(xLabel3);
        xLabel3.setBounds(20, 50, 80, 20);

        xLabel4.setText("Contact No:");
        xPanel3.add(xLabel4);
        xLabel4.setBounds(20, 70, 80, 20);

        xTextField1.setEnabled(false);
        xTextField1.setModelName("fileupload");
        xTextField1.setName("sendercontactno");
        xPanel3.add(xTextField1);
        xTextField1.setBounds(110, 70, 340, 19);

        xTextField2.setEnabled(false);
        xTextField2.setModelName("fileupload");
        xTextField2.setName("senderaddress");
        xPanel3.add(xTextField2);
        xTextField2.setBounds(110, 50, 340, 19);

        xTextField3.setEnabled(false);
        xTextField3.setModelName("fileupload");
        xTextField3.setName("sendername");
        xPanel3.add(xTextField3);
        xTextField3.setBounds(110, 30, 340, 19);

        xPanel1.add(xPanel3);
        xPanel3.setBounds(10, 10, 470, 110);

        xPanel5.setLayout(null);

        xPanel5.setBorder(javax.swing.BorderFactory.createTitledBorder(" Batch No. "));
        xLabel012.setModelName("fileupload");
        xLabel012.setName("controlno");
        xPanel5.add(xLabel012);
        xLabel012.setBounds(10, 30, 210, 40);

        xPanel1.add(xPanel5);
        xPanel5.setBounds(480, 10, 230, 110);

        xLabel5.setText("<html><font style=\"font-size:11;\"><b>List of Transactions:</b></font></html>");
        xPanel1.add(xLabel5);
        xLabel5.setBounds(10, 124, 150, 20);

        xTable1.setAutoresize(false);
        xTable1.setColumnAsXml("<column name=\"itemno\" caption=\"Item\" />\n<column name=\"kptn\" caption=\"KPTN\" />\n<column name=\"ccrefno\" caption=\"Ref No\" />\n<column name=\"dtfiled\" caption=\"DT Filed\"/>\n<column name=\"principal\" caption=\"Principal\"/>\n<column name=\"charge\" caption=\"Charge\"/>\n<column name=\"sendername\" caption=\"Sender Name\"/>\n<column name=\"senderaddress\" caption=\"Sender Address\"/>\n<column name=\"ssendergender\" caption=\"Gender\"/>\n<column name=\"receivername\" caption=\"Receiver Name\"/>\n<column name=\"receiveraddress\" caption=\"Receiver Address\"/>\n<column name=\"sreceivergender\" caption=\"Gender\"/>\n<column name=\"message\" caption=\"Message\"/>\n");
        xTable1.setDefaultFocus(true);
        xTable1.setModelName("fileuploaditem");
        xPanel1.add(xTable1);
        xTable1.setBounds(10, 150, 700, 270);

        xLabel6.setFont(new java.awt.Font("Tahoma", 1, 12));
        xLabel6.setText("Txn Count:");
        xPanel1.add(xLabel6);
        xLabel6.setBounds(10, 430, 80, 20);

        xTextField4.setEnabled(false);
        xTextField4.setFont(new java.awt.Font("Tahoma", 1, 14));
        xTextField4.setModelName("fileupload");
        xTextField4.setName("txncount");
        xPanel1.add(xTextField4);
        xTextField4.setBounds(90, 430, 70, 19);

        xLabel7.setFont(new java.awt.Font("Tahoma", 1, 12));
        xLabel7.setText("Total Principal:");
        xPanel1.add(xLabel7);
        xLabel7.setBounds(180, 430, 100, 20);

        xLabel8.setFont(new java.awt.Font("Tahoma", 1, 12));
        xLabel8.setText("Total Charge:");
        xPanel1.add(xLabel8);
        xLabel8.setBounds(180, 450, 100, 20);

        xTextField5.setEnabled(false);
        xTextField5.setFont(new java.awt.Font("Tahoma", 1, 14));
        xTextField5.setModelName("fileupload");
        xTextField5.setName("totalprincipal");
        xTextField5.setType("currency");
        xPanel1.add(xTextField5);
        xTextField5.setBounds(280, 430, 140, 19);

        xTextField6.setEnabled(false);
        xTextField6.setFont(new java.awt.Font("Tahoma", 1, 14));
        xTextField6.setModelName("fileupload");
        xTextField6.setName("totalcharge");
        xTextField6.setType("currency");
        xPanel1.add(xTextField6);
        xTextField6.setBounds(280, 450, 140, 20);

        xLabel9.setFont(new java.awt.Font("Tahoma", 1, 12));
        xLabel9.setText("Amount Due:");
        xPanel1.add(xLabel9);
        xLabel9.setBounds(440, 430, 90, 20);

        xTextField7.setEnabled(false);
        xTextField7.setFont(new java.awt.Font("Tahoma", 1, 18));
        xTextField7.setModelName("fileupload");
        xTextField7.setName("amtdue");
        xTextField7.setType("currency");
        xPanel1.add(xTextField7);
        xTextField7.setBounds(530, 430, 180, 40);

        add(xPanel1, java.awt.BorderLayout.CENTER);

        xPanel2.setLayout(new java.awt.BorderLayout());

        xPanel2.setOpaque(true);
        xLabel1.setBackground(new java.awt.Color(0, 0, 153));
        xLabel1.setForeground(new java.awt.Color(255, 255, 255));
        xLabel1.setOpaque(true);
        xLabel1.setPadding(new java.awt.Insets(10, 10, 10, 10));
        xLabel1.setText("<html> <font size=\"5\">Detail Information (Read Only)</font> </html>");
        xPanel2.add(xLabel1, java.awt.BorderLayout.SOUTH);

        xButton5.setIconResource("shared/images/close.png");
        xButton5.setAlt('c');
        xButton5.setOnclick("doClose");
        xButton5.setText("Close");
        xToolbar1.add(xButton5);

        xButton6.setIconResource("shared/images/print.png");
        xButton6.setAlt('p');
        xButton6.setOnclick("doPrintDocument");
        xButton6.setText("Print");
        xToolbar1.add(xButton6);

        xPanel2.add(xToolbar1, java.awt.BorderLayout.CENTER);

        add(xPanel2, java.awt.BorderLayout.NORTH);

    }// </editor-fold>//GEN-END:initComponents
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private com.rameses.osiris.client.component.XButton xButton5;
    private com.rameses.osiris.client.component.XButton xButton6;
    private com.rameses.osiris.client.component.template.XLabel01 xLabel012;
    private com.rameses.osiris.client.component.XLabel xLabel1;
    private com.rameses.osiris.client.component.XLabel xLabel2;
    private com.rameses.osiris.client.component.XLabel xLabel3;
    private com.rameses.osiris.client.component.XLabel xLabel4;
    private com.rameses.osiris.client.component.XLabel xLabel5;
    private com.rameses.osiris.client.component.XLabel xLabel6;
    private com.rameses.osiris.client.component.XLabel xLabel7;
    private com.rameses.osiris.client.component.XLabel xLabel8;
    private com.rameses.osiris.client.component.XLabel xLabel9;
    private com.rameses.osiris.client.component.XPanel xPanel1;
    private com.rameses.osiris.client.component.XPanel xPanel2;
    private com.rameses.osiris.client.component.XPanel xPanel3;
    private com.rameses.osiris.client.component.XPanel xPanel5;
    private com.rameses.osiris.client.component.XTable xTable1;
    private com.rameses.osiris.client.component.XTextField xTextField1;
    private com.rameses.osiris.client.component.XTextField xTextField2;
    private com.rameses.osiris.client.component.XTextField xTextField3;
    private com.rameses.osiris.client.component.XTextField xTextField4;
    private com.rameses.osiris.client.component.XTextField xTextField5;
    private com.rameses.osiris.client.component.XTextField xTextField6;
    private com.rameses.osiris.client.component.XTextField xTextField7;
    private com.rameses.osiris.client.component.XToolbar xToolbar1;
    // End of variables declaration//GEN-END:variables
    
}
