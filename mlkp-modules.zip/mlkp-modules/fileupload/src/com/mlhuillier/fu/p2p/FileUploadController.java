package com.mlhuillier.fu.p2p;

import com.rameses.osiris.client.AbstractFormController;
import java.awt.Dimension;
import java.io.InputStream;

public class FileUploadController extends AbstractFormController
{
    
    public FileUploadController() 
    {
        addPage("create", CreatePage.class);
        addPage("confirm", ConfirmPage.class);
        addPage("readonly", ReadOnlyPage.class);
    }

    protected Class getDefaultPageClass() { return SelectCustomerPage.class; }

    protected InputStream getCodeBaseAsStream() { 
        return getClass().getResourceAsStream("FileUploadController.xml");
    }

    public String getPreferredID() { return "fileupload.frm"; }

    public String getTitle() { return "File Upload (Person-To-Person)"; }
    
    public Dimension getPreferredSize() {
        return new Dimension(720, 610);
    }

    public boolean isDocument() { return true; }

    public String getDocumentName() { return "fileupload"; }

    public String[] getDataNames() {
        return new String[]
        {
            "fileuploaditem"
        };
    }
    
}
