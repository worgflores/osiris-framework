package CZARINA;

import junit.framework.*;

public class NewEmptyJUnitTest extends TestCase 
{
    
    public NewEmptyJUnitTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
    }

    protected void tearDown() throws Exception {
    }
    
    public void test00000() throws Exception
    {
        String branchid = "FSD37";
        long branchid_hash = branchid.hashCode();
        String userid =   "U1" + branchid_hash;
        System.out.println(userid);
        
        //U167186107
        //T167186107
        //MLWSFSD37
    }

}
