package philhealth;

import java.util.Iterator;
import junit.framework.*;
import rameses.osiris.client.app.App;
import rameses.osiris.common.interfaces.IDataModel;
import rameses.osiris.common.service.Request;
import rameses.osiris.common.service.Response;

public class NewEmptyJUnitTest extends TestCase 
{
    
    public NewEmptyJUnitTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
        System.setProperty("app.host","http://192.168.3.210:8080/mlhuillier/action");        
    }

    protected void tearDown() throws Exception {
    }
    
    public void xtestMemberInfo() throws Exception 
    {
        Request req = new Request();
        Response res = App.getServiceManager().invoke("philhealth.getTestInfo", req);
        IDataModel idm = (IDataModel) res.getValue("data");
        Iterator itr = idm.getFields();
        while (itr.hasNext())
        {
            String key = itr.next().toString();
            System.out.println(key + "=" + idm.getValue(key));
        }
    }
    
    public void testBillPayment() throws Exception 
    {
        Request req = new Request();
        
        req.addParameter("USERID",  "KPUSER");
        req.addParameter("REPORTTYPE", "BILL_PAYMENT");
        req.addParameter("LOCATION", "");
        req.addParameter("GROUPBY", "ALL");
        req.addParameter("PERIOD", "DAILY");
        req.addParameter("COMPANYID", "");

        req.addParameter("FROMDATE",  "2008-10-29");
        req.addParameter("TODATE",  "2008-10-29");

        Response res = App.getServiceManager().invoke("report.fsd", req);   
        System.out.println(res.getValues());
    }    

}
