/*
 * ConvertTestUnit.java
 * JUnit based test
 *
 * Created on June 5, 2008, 2:38 PM
 */

package test;

import com.mlhuillier.fu.metrobank.converter.XmlDataConverter;
import com.mlhuillier.fu.metrobank.converter.XmlDataConverterPage;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import javax.swing.JDialog;
import javax.swing.UIManager;
import junit.framework.*;
import rameses.osiris.common.interfaces.IDataSetModel;

/**
 *
 * @author user
 */
public class ConvertTestUnit extends TestCase {
    
    public ConvertTestUnit(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception 
    {
        UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
    }

    protected void tearDown() throws Exception {
    }
    
    // TODO add test methods here. The name must begin with 'test'. For example:
    public void xtestHello() throws Exception 
    {
        File file = new File("D:/shared-folder/metrobanktestfiles/HOA8B3ML.xml");
        InputStream in = new FileInputStream(file);
        XmlDataConverter converter = new XmlDataConverter();
        StringBuffer sb = converter.convert(in);
        System.out.println(sb);
        
        IDataSetModel idsm = null;
    }
    
    public void test2() throws Exception 
    {
        XmlDataConverterPage page = new XmlDataConverterPage(); 
        JDialog d = new JDialog();
        d.setModal(true);
        d.setContentPane(page);
        d.pack();
        d.setVisible(true);
    }    

}
