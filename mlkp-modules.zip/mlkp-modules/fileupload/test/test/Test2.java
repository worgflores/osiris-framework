package test;

import java.util.Iterator;
import javax.swing.JOptionPane;
import javax.swing.UIManager;
import junit.framework.*;
import rameses.osiris.client.app.App;
import rameses.osiris.common.data.DefaultDataSetModel;
import rameses.osiris.common.service.Request;
import rameses.osiris.common.service.Response;

public class Test2 extends TestCase 
{
    
    public Test2(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception 
    {
        UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        System.setProperty("app.host","http://192.168.3.210:8080/mlhuillier/action");
    }

    protected void tearDown() throws Exception {
    }
    
    public void xtest0() throws Exception
    {
        StringBuffer sb = new StringBuffer();
        sb.append("<html>");
        sb.append("<table cellpadding=3 cellspacing=0 width=300>");
        sb.append("<tr bgcolor=#808080 color=#ffffff>");
        sb.append("   <th>Currency</th>");
        sb.append("   <th align=center>Buying <br>(PHP)</th>");
        sb.append("   <th align=center>Selling <br>(PHP)</th>");
        sb.append("</tr>");
        sb.append("<tr bgcolor=#ffffff>");
        sb.append("   <td style=font-weight:bold;>1 USD</td>");
        sb.append("   <td align=center style=font-weight:bold;>44.15</td>");
        sb.append("   <td align=center style=font-weight:bold;>45.0000000000</td>");
        sb.append("</tr>");
        sb.append("<tr bgcolor=#ffffff>");
        sb.append("   <td style=font-weight:bold;>1 EURO</td>");
        sb.append("   <td align=center style=font-weight:bold;>60.15</td>");
        sb.append("   <td align=center style=font-weight:bold;>62.00</td>");
        sb.append("</tr>");        
        sb.append("</table>");
        sb.append("</html>");
        JOptionPane.showMessageDialog(null, sb);
        System.exit(0);

    }
    
    public void xtest1() throws Exception
    {
        Request req = new Request();
        req.addParameter("DSNAME", "java:mlreportdaily");
        
        Response res = App.getServiceManager().invoke("showProcessListAsXML", req);
        System.out.println(res.getValue("xmldata"));
        
//        Response res = App.getServiceManager().invoke("showProcessList", req);
//        IDataSetModel idsm = (IDataSetModel) res.getValue("processlist");
//        for (int i=0; i<idsm.size(); i++) 
//        {
//            IDataModel dm = idsm.getItem(i);
//            System.out.println("[Index #"+ i +"]");
//            Iterator fields = dm.getFields();
//            while (fields.hasNext()) 
//            {
//                String fld = fields.next().toString();
//                System.out.println("  " + fld + "=" + dm.getValue(fld));
//            }
//        }
    }
    
    public void xtest2() throws Exception
    {
        Request req = new Request();
        req.addParameter("USERID", "KPUSER");
        req.addParameter("BRANCHID", "OROQU1");
        req.addParameter("STATUS", "valid");
        req.addParameter("REPORTNAME", "wu.report");
        req.addParameter("PERIOD", "RANGE");
        req.addParameter("FROMDATE", "2008-07-01");
        req.addParameter("TODATE", "2008-07-31");

        Response res = App.getServiceManager().invoke("report.wuReport", req);
        String report = (String) res.getValue("REPORT");
        System.out.println(report);
    }

    public void xtest3() throws Exception
    {
        Request req = new Request();
        req.addParameter("BRANCHID", "BUHANG");
        req.addParameter("PRINCIPAL", "300.00");
        req.addParameter("CURRENCYID", "PHP");
        req.addParameter("RATESID", "CHG506a464b:11b53513510:2c5c");
        
        Response res = App.getServiceManager().invoke("calculateCharge", req);
        System.out.println(res.getValues());
    }
    
    public void test4() throws Exception
    {
        String pwd   = "ABCdefjklmno  pqrSTU\tVWXyZ    "; 
        String value = "abcDEF   JKLMO   pQrStUvWxYz   "; 
        System.out.println(pwd); 
        System.out.println(pwd.replaceAll("\\s", "")); 
        
        DefaultDataSetModel dm = new DefaultDataSetModel(); 
        Iterator itr = dm.getFields(); 
        while (itr.hasNext())
        {
            
        }
    }
    
}
