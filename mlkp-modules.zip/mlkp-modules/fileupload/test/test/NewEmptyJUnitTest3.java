package test;

import junit.framework.*;

public class NewEmptyJUnitTest3 extends TestCase 
{
    
    public NewEmptyJUnitTest3(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
    }

    protected void tearDown() throws Exception {
    }
    
    public void test00001() throws Exception 
    {
        String branchid = "MBGULF";
        String hash = new java.text.DecimalFormat("0000000000").format(Long.parseLong((branchid.hashCode()+"").replaceAll("-", "")));
        String userid = "U1" + hash;
        String terminalid = "T1" + hash.substring(0, 8);
//        String terminalid = "T1" + ("T1MBGULF".hashCode()+"").replaceAll("-",""); 
        
        System.out.println(branchid);
        System.out.println(userid);
        System.out.println(terminalid);
//        System.out.println("U1" + branchid_hash);
//        System.out.println(terminalid);
    }

}
