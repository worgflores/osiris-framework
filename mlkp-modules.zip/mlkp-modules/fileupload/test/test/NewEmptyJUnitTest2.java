/*
 * NewEmptyJUnitTest2.java
 * JUnit based test
 *
 * Created on May 29, 2008, 3:15 PM
 */

package test;

import junit.framework.*;

/**
 *
 * @author user
 */
public class NewEmptyJUnitTest2 extends TestCase {
    
    public NewEmptyJUnitTest2(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
    }

    protected void tearDown() throws Exception {
    }
    
    public void testHello() throws Exception
    {
        String value = "000012008-30-04 00:00:0000000APR0000325485SG000006006.00PHP                                                                      Test                Test                                    3          SAN PEDRO LAGUNA                                  .                                                 .                                                                                                                                                                        ";
        String msg = value.substring(370,470);
        System.out.println("msg=" + msg + ", length=" + msg.length());
    }

}
