package test;

import com.mlhuillier.fu.p2p.FileUploadController;
import com.rameses.osiris.client.AbstractFormController;
import com.rameses.osiris.client.FormLauncher;
import java.awt.Container;
import java.util.HashMap;
import java.util.Map;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.UIManager;
import junit.framework.*;
import rameses.osiris.client.app.App;
import rameses.osiris.common.service.Request;

public class NewEmptyJUnitTest extends TestCase 
{
    public NewEmptyJUnitTest(String testName) {
        super(testName);
    }
    
    protected void setUp() throws Exception 
    {
        UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        System.setProperty("app.host","http://192.168.50.111:18080/mlhuillier/action");
        //System.setProperty("app.res.system","mlkp.Resource");
        //System.setProperty("app.res.shared","shared.Resource");
        System.setProperty("app.res.svr","rameses.osiris.client.app.ScreenResource2");
        System.setProperty("screen.host","http://192.168.50.111:18080/mlhuillier/screen");        
    }
    
    protected void tearDown() throws Exception {
    }
    
    public void test1() throws Exception 
    {
        //C2PTextBuilder b = new C2PTextBuilder();
        //b.generate("CHNBNK","CHNBNKU1","CHNBNKT1");
        
        Map props = new HashMap();
        //props.put("TERMINALID", "UAKPDSXC");
        props.put("TERMINALID", "KGZZ3AQ8");
        
        //props.put("TERMINALID", "UMN1LCYE");
        App.getSecurityManager().login("KPUSER", "1234", props);
        
        //props.put("TERMINALID", "NB3NXB3D");
        //App.getSecurityManager().login("SHANE", "1234", props);
        
        //launch(new FileUploadControllerC2P());
        launch(new FileUploadController());
    }
    
    private void launch(AbstractFormController afc) throws Exception
    {
        //FormGenerator.getInstance().dump(afc);
        FormLauncher.newInstance().launch(afc);
    }
    
    private void showDialog(Container con)
    {
        JDialog d = new JDialog();
        d.setModal(true);
        d.setContentPane(con);
        d.setSize(640,480);
        d.setVisible(true);
    }
}
