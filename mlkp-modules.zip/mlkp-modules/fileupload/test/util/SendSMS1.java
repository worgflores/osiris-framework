package util;

import junit.framework.*;
import rameses.osiris.client.app.App;
import rameses.osiris.common.service.Request;

public class SendSMS1 extends TestCase 
{
    
    public SendSMS1(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception 
    {
        System.setProperty("app.host","http://192.168.3.247:8080/mlhuillier/action");
    }

    protected void tearDown() throws Exception {
    }
    
    public void test0() throws Exception
    {
        String msg = "HUWG MGBIGAY NG IMPORMSYON SA MGA PRMOTERS NG GOLDCRD BKA MERON MGPANGAP NA IBANG RECVR NG PERA NYO! DI CLA TAUHAN NG MLHUILLIER. MAGINGAT";
        
        Request req = new Request();
        req.addParameter("TABLENAME", "sendercontacts200810a");
        req.addParameter("USERID", "system");
        req.addParameter("MESSAGE", msg);
        req.addParameter("LIMIT", "100000");
	req.addParameter("SUBJECT", "");
        req.addParameter("FOOTER", "");
        req.addParameter("INCSUBJECT", "NO");
        req.addParameter("INCFOOTER", "NO");
        App.getServiceManager().invoke("sms.sendBatch", req);
    }
    
}
