package util;

import junit.framework.*;
import rameses.osiris.client.app.App;
import rameses.osiris.common.service.Request;
import rameses.osiris.common.service.Response;

public class ShowProcessList extends TestCase 
{
    
    public ShowProcessList(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
        System.setProperty("app.host","http://192.168.3.247:8080/mlhuillier/action");
    }

    protected void tearDown() throws Exception {
    }
    
    public void test0() throws Exception
    {
        //execProcessList("java:mlauditordb"); 
        execProcessList("java:mlreport"); 
    }
    
    public void execProcessList(String dsname) throws Exception
    {
        Request req = new Request();
        req.addParameter("DSNAME", dsname);
        
        Response res = App.getServiceManager().invoke("showProcessListAsXML", req);
        Object data = res.getValue("xmldata");
        System.out.println(data);
    }

    private Response exec(String rulename, Request req) throws Exception {
        return App.getServiceManager().invoke(rulename, req);
    }
    
}
