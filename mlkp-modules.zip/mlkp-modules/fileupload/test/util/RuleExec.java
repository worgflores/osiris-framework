package util;

import junit.framework.*;
import rameses.osiris.client.app.App;
import rameses.osiris.common.service.Request;
import rameses.osiris.common.service.Response;

public class RuleExec extends TestCase 
{
    
    public RuleExec(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception 
    {
        System.setProperty("app.host","http://192.168.3.220:8080/mlhuillier/action");
    }

    protected void tearDown() throws Exception {
    }
    
    public void test0() throws Exception
    {
        exec("update mlcs.tblpostbill set curtotalcharge=125.00 where objid='PB65bc1eb9:11edddf1b20:10ef'");
    }
    
    private Response exec(String rulename, Request req) throws Exception {
        return App.getServiceManager().invoke(rulename, req);
    }
    
    private void exec(String sql) throws Exception
    {
        Request req = new Request(); 
        req.addParameter("QUERY", "0"); 
        req.addParameter("DSNAME", "java:mldb"); 
        req.addParameter("SQLSTMT", sql); 
        
        exec("system.exec", req);
    }
    
}
