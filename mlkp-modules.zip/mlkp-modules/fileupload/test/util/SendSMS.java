package util;

import junit.framework.*;
import rameses.osiris.client.app.App;
import rameses.osiris.common.service.Request;

public class SendSMS extends TestCase 
{
    
    public SendSMS(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception 
    {
        System.setProperty("app.host","http://192.168.3.220:8080/mlhuillier/action");
    }

    protected void tearDown() throws Exception {
    }
    
    public void xtestBuildContacts() throws Exception
    {
        Request req = new Request();
        req.addParameter("TABLENAME","contacts200810a");
        req.addParameter("STARTDATE","2008-10-05");
        req.addParameter("ENDDATE","2008-10-13");
        req.addParameter("USERID","system");
        App.getServiceManager().invoke("sms.buildContacts", req);
    }
    
    public void xtestSendSMS() throws Exception
    {
        Request req = new Request();
        req.addParameter("TABLENAME", "contacts200810a");
        req.addParameter("USERID", "system");
        req.addParameter("MESSAGE", "To our valued customers n ML KwartaPadala! U cn now send ur donations 2 bantay bata thru ML KwartaPadala.We luk 4ward 2ur kind support!tnx");
        req.addParameter("LIMIT", "140000");
	req.addParameter("SUBJECT", "");
        req.addParameter("FOOTER", "");
        req.addParameter("INCSUBJECT", "NO");
        req.addParameter("INCFOOTER", "NO");
        App.getServiceManager().invoke("sms.send", req);
    }
    
}
