package util;

import junit.framework.*;
import rameses.osiris.client.app.App;
import rameses.osiris.common.service.Request;

public class SendSMS3 extends TestCase 
{
    
    public SendSMS3(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception 
    {
        System.setProperty("app.host","http://192.168.3.247:8080/mlhuillier/action");
    }

    protected void tearDown() throws Exception {
    }
    
    public void test0() throws Exception
    {
        String msg = "ADVISORY!!! DON'T GIVE MLKP INFO TO STRANGERS. DEY MYT PRETEND 2 BE UR RECEIVER & CLAIM D FUNDS U SENT! KEP ALL INFO CONFIDENTIAL!";
        
        Request req = new Request();
        req.addParameter("TABLENAME", "sendercontacts200810b");
        req.addParameter("USERID", "system");
        req.addParameter("MESSAGE", msg);
        req.addParameter("LIMIT", "100000");
	req.addParameter("SUBJECT", "");
        req.addParameter("FOOTER", "");
        req.addParameter("INCSUBJECT", "NO");
        req.addParameter("INCFOOTER", "NO");
        App.getServiceManager().invoke("sms.sendBatch", req);
    }
    
}
