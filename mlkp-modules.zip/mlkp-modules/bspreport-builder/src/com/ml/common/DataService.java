package com.ml.common;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class DataService 
{
    public static interface Handler
    {
        void beforeExecute(Connection connSrc, Connection connDest, Map data) throws Exception;
        void afterExecute(Connection connSrc, Connection connDest, Map data) throws Exception;
    }
    
    public boolean debug; 
    
    public DataService() {
    }
        
    public int exec(Connection conn, String sql) throws Exception
    {
        PreparedStatement ps = null;
        try
        {
            ps = conn.prepareStatement(sql);
            return ps.executeUpdate();
        }
        catch(Exception ex) {
            throw ex;
        }
        finally {
            try { ps.close(); }catch(Exception ign) {;}
        }
    }        
    
    public void transferData(Connection connSrc, Connection connDest, String sql, String targetTable) throws Exception {
        transferData(connSrc, connDest, sql, targetTable, false);
    }

    public void transferData(Connection connSrc, Connection connDest, String sql, String targetTable, boolean ignore) throws Exception { 
        transferData(connSrc, connDest, sql, targetTable, ignore, null); 
    } 
    
    
    public void transferData(Connection connSrc, Connection connDest, String sql, String targetTable, boolean ignore, Handler handler) throws Exception
    {
        PreparedStatement ps = null;
        ResultSet rs = null;

        int startRow = 0;
        int limit = 100000;
        while (true)
        {
            int batchSize = limit + 1;
            int counter = 0;
            
            try
            {
                ps = connSrc.prepareStatement(sql + " LIMIT " + startRow + "," + batchSize);
                rs = ps.executeQuery();
                while (rs.next()) 
                {
                    copyData(connDest, rs, targetTable, ignore, new WrapperHandler(handler, connDest)); 
                    counter +=1 ; 
                } 
            }
            catch(Exception ex) {
                throw ex;
            }
            finally 
            {
                try { rs.close(); }catch(Exception ign) {;}
                try { ps.close(); }catch(Exception ign) {;}
            }
            
            if (counter <= limit) break;
            
            startRow += limit;
        }
    }

    private Map copyData(Connection conn, ResultSet rs, String targetTable, boolean ignore, WrapperHandler handler) throws Exception
    {
        ResultSetMetaData meta = rs.getMetaData();
        int columnCount = meta.getColumnCount();
        
        Map map = new HashMap(); 
        for (int i=1; i<=columnCount; i++) 
        {
            Object ov = null; 
            try {
                ov = rs.getObject(i);  
            }
            catch(SQLException sqle)
            {
                if (meta.getColumnType(i) == java.sql.Types.DATE) {;} 
                else if (meta.getColumnType(i) == java.sql.Types.TIMESTAMP) {;} 
                else throw sqle; 
            } 
            
            map.put(meta.getColumnName(i), ov); 
        } 
        
        if (debug) System.out.println("[copyData] " + targetTable + " " + map);
        
        if (handler != null) 
            handler.event_beforeExecute(conn, map); 

        int index = 0; 
        Object[] values = new Object[map.size()];
        StringBuffer fieldBuff = new StringBuffer();
        StringBuffer valueBuff = new StringBuffer();
        Iterator keys = map.entrySet().iterator(); 
        while (keys.hasNext()) 
        {
            Map.Entry entry = (Map.Entry) keys.next(); 
            String fldname = entry.getKey().toString(); 
            values[index] = entry.getValue();
            if (index > 0) 
            {
                fieldBuff.append(", ");
                valueBuff.append(", ");
            }
            fieldBuff.append(fldname);
            valueBuff.append("?");
            index++;
        } 
        
        StringBuffer sql = new StringBuffer();
        sql.append(" INSERT ");
        if (ignore) sql.append(" IGNORE ");
        
        sql.append(" INTO " + targetTable +"\n\t (" + fieldBuff + ") \n");
        sql.append(" VALUES \n\t (" + valueBuff + ")");
        
        PreparedStatement ps = null;
        try
        {
            ps = conn.prepareStatement(sql.toString());
            for (int i=0; i<values.length; i++) {
                ps.setObject(i+1, values[i]); 
            }

            try { 
                ps.execute();
            } 
            catch(Exception e) 
            {
                System.out.println("[ERROR] " + e.getMessage()); 
                System.out.println("        " + map);
                throw e; 
            }
        }
        catch(Exception ex) {
            throw ex;
        }
        finally {
            try { ps.close(); }catch(Exception ign) {;}
        } 
        
        if (handler != null) 
            handler.event_afterExecute(conn, map); 
        
        return map;
    }
    
    public void replaceData(Connection connSrc, Connection connDest, String sql, String targetTable) throws Exception
    {
        PreparedStatement ps = null;
        ResultSet rs = null;

        int startRow = 0;
        int limit = 100000;
        while (true)
        {
            int batchSize = limit + 1;
            int counter = 0;
            
            try
            {
                ps = connSrc.prepareStatement(sql + " LIMIT " + startRow + "," + batchSize);
                rs = ps.executeQuery();
                while (rs.next()) 
                {
                    replaceDataImpl(connDest, rs, targetTable);
                    counter +=1 ;
                }
            }
            catch(Exception ex) {
                throw ex;
            }
            finally 
            {
                try { rs.close(); }catch(Exception ign) {;}
                try { ps.close(); }catch(Exception ign) {;}
            }
            
            if (counter <= limit) break;
            
            startRow += limit;
        }
    }
    
    private void replaceDataImpl(Connection conn, ResultSet rs, String targetTable) throws Exception
    {
        ResultSetMetaData meta = rs.getMetaData();
        int columnCount = meta.getColumnCount();
        
        StringBuffer sql = new StringBuffer();
        sql.append(" REPLACE INTO " + targetTable +"\n\t (");
        for (int i=1; i<=columnCount; i++) 
        {
            if (i > 1) sql.append(",");
            
            sql.append(meta.getColumnName(i));
        }
        sql.append(" ) \n");
        sql.append(" VALUES \n\t (");
        for (int i=0; i<columnCount; i++)
        {
            if (i > 0) sql.append(",");
            
            sql.append("?");
        }        
        sql.append(")");

        PreparedStatement ps = null;
        try
        {
            ps = conn.prepareStatement(sql.toString());
            
            for (int i=1; i<=columnCount; i++) 
            {
                Object ov = null;
                try {
                    ov = rs.getObject(i); 
                }
                catch(SQLException sqle) 
                { 
                    if (meta.getColumnType(i) == java.sql.Types.DATE) {;} 
                    else if (meta.getColumnType(i) == java.sql.Types.TIMESTAMP) {;} 
                    else throw sqle; 
                } 
                
                ps.setObject(i, ov); 
            }
            
            ps.execute();
        }
        catch(Exception ex) {
            throw ex;
        }
        finally {
            try { ps.close(); }catch(Exception ign) {;}
        } 
    }   
    
    public void insertOnDuplicateKey(Connection connSrc, Connection connDest, String sql, String targetTable) throws Exception {
        insertOnDuplicateKey(connSrc, connDest, sql, targetTable, null);
    }
    
    public void insertOnDuplicateKey(Connection connSrc, Connection connDest, String sql, String targetTable, Handler handler) throws Exception
    {
        PreparedStatement ps = null;
        ResultSet rs = null;

        int startRow = 0;
        int limit = 100000;
        while (true)
        {
            int batchSize = limit + 1;
            int counter = 0;
            
            try
            {
                ps = connSrc.prepareStatement(sql + " LIMIT " + startRow + "," + batchSize);
                rs = ps.executeQuery();
                while (rs.next()) 
                {
                    Map map = insertOnDuplicateKeyImpl(connDest, rs, targetTable);
                    if (handler != null) handler.afterExecute(connSrc, connDest, map); 
                    
                    counter +=1 ;
                }
            }
            catch(Exception ex) {
                throw ex;
            }
            finally 
            {
                try { rs.close(); }catch(Exception ign) {;}
                try { ps.close(); }catch(Exception ign) {;}
            }
            
            if (counter <= limit) break;
            
            startRow += limit;
        }
    }
    
    private Map insertOnDuplicateKeyImpl(Connection conn, ResultSet rs, String targetTable) throws Exception
    {
        ResultSetMetaData meta = rs.getMetaData();
        int columnCount = meta.getColumnCount();
        
        StringBuffer sql = new StringBuffer();
        sql.append(" INSERT INTO " + targetTable +"\n\t (");
        for (int i=1; i<=columnCount; i++) 
        {
            if (i > 1) sql.append(",");
            
            sql.append(meta.getColumnName(i));
        }
        sql.append(" ) \n");
        sql.append(" VALUES \n\t (");
        for (int i=0; i<columnCount; i++)
        {
            if (i > 0) sql.append(",");
            
            sql.append("?");
        }        
        sql.append(") \n");
        sql.append(" ON DUPLICATE KEY UPDATE \n"); 
        for (int i=1; i<=columnCount; i++) 
        {
            if (i > 1) sql.append(", ");
            
            String cname = meta.getColumnName(i);
            sql.append(cname + "=VALUES("+cname+")"); 
        }        

        PreparedStatement ps = null;
        try
        {
            ps = conn.prepareStatement(sql.toString());
            
            Map map = new HashMap(); 
            for (int i=1; i<=columnCount; i++) 
            {
                Object ov = null;
                try {
                    ov = rs.getObject(i); 
                }
                catch(SQLException sqle) 
                { 
                    if (meta.getColumnType(i) == java.sql.Types.DATE) {;} 
                    else if (meta.getColumnType(i) == java.sql.Types.TIMESTAMP) {;} 
                    else throw sqle; 
                } 
                
                ps.setObject(i, ov);
                map.put(meta.getColumnName(i), ov); 
            }
            
            if (debug) System.out.println("[insertOnDuplicateKeyImpl] " + targetTable + " " + map);
            
            ps.execute();
            return map;
        }
        catch(Exception ex) {
            throw ex;
        }
        finally {
            try { ps.close(); }catch(Exception ign) {;}
        } 
    }   
 
    
    private class WrapperHandler implements Handler
    {
        private Handler handler;
        private Connection connDest;
        
        WrapperHandler(Handler handler, Connection connDest) 
        {
            this.handler = handler; 
            this.connDest = connDest;
        } 
        
        void event_beforeExecute(Connection connSrc, Map data) throws Exception {  
            beforeExecute(connSrc, connDest, data); 
        } 
        
        void event_afterExecute(Connection connSrc, Map data) throws Exception {  
            afterExecute(connSrc, connDest, data); 
        } 
        
        public void beforeExecute(Connection connSrc, Connection connDest, Map data) throws Exception 
        { 
            if (handler != null) handler.beforeExecute(connSrc, connDest, data); 
        }

        public void afterExecute(Connection connSrc, Connection connDest, Map data) throws Exception 
        {
            if (handler != null) handler.afterExecute(connSrc, connDest, data);             
        }
    }
}
