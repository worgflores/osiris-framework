package main;
import com.ml.common.DBConfig;
import com.ml.common.DataService;
import com.ml.common.SQLDB;
import java.io.File;
import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import jxl.Workbook;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;

public class Main 
{
    
    public static void main(String[] args) throws Exception 
    {
        try {
            new Main().process("2011-10-01", "2011-10-01");
        } catch (Exception e) {
            e.printStackTrace(); 
        }        
    }
    
    
    private DBConfig dbConfig = new DBConfig();
    private DataService dataService = new DataService(); 
    private SQLDB sqlDB = new SQLDB();
    
    private void process(String startdate, String enddate) throws Exception 
    {
        Date dtfrom = java.sql.Date.valueOf(startdate); 
        Date dtto = java.sql.Date.valueOf(enddate); 
        
        Connection conn = null; 
        
        try 
        {
            conn = dbConfig.createConnection("main");
            
            SimpleDateFormat YMD = new SimpleDateFormat("yyyy-MM-dd"); 
            Calendar cal = Calendar.getInstance(); 
            cal.setTime(dtfrom); 
            while (true) 
            {
                Date dt = cal.getTime();
                if (dt.after(dtto)) break; 
                
                String sdate = YMD.format(dt); 
                process(conn, sdate); 
                
                cal.add(Calendar.DATE, 1); 
            }
        }
        catch(Exception ex) {
            throw ex; 
        } 
        finally 
        {
            try { conn.close(); }catch(Exception ing){;} 
        }
    }

    private void process(Connection conn, String sdate) throws Exception 
    {
        
        String tableName = "kplog" + sdate.replaceAll("-", "");
        String sql = "" + 
            " select " + 
            "     s.txndate,  " + 
            "     case  " + 
            "         when s.txntype=1 then 'SENDOUT'   " + 
            "         when s.txntype=2 then 'SENDOUT_CHANGE'   " + 
            "         when s.txntype=3 then 'SENDOUT_CREDIT'   " + 
            "         when s.txntype=10 then 'PAYOUT'   " + 
            "         when s.txntype=11 then 'PAYOUT_CREDIT'   " + 
            "         when s.txntype=20 then 'RETURNED'  " + 
            "         when s.txntype=30 then 'CANCELLED' else ''  " + 
            "     end as txntype,  " + 
            "     s.soutdate as dtfiled, s.kptn,  " + 
            "     concat(s.senderlname,', ',s.senderfname,' ',ifnull(s.sendermname,'')) as sendername,  " + 
            "     concat(s.receiverlname,', ',s.receiverfname,' ',ifnull(s.receivermname,'')) as receivername,  " + 
            "     case  " + 
            "         when s.txntype in (1,2,3,30) then s.soutprincipalcurrency   " + 
            "         when s.txntype in (10,11,20) then ifnull(s.poutcurrency,s.soutprincipalcurrency) else ''   " + 
            "     end as currency,   " + 
            "     case  " + 
            "         when s.txntype in (1,2,3) then s.soutprincipaldr  " + 
            "         when s.txntype in (10,11,20) then s.poutamountcr  " + 
            "         when s.txntype in (30) then s.soutprincipalcr else 0.0  " + 
            "     end as principal, s.soutcharge as charge,   s.soutchargecurrency as chrgcurrency,  " + 
            "     case  " + 
            "         when s.txntype in (10,11) then s.branch else ''  " + 
            "     end as poutbranch,  " + 
            "     case  " + 
            "         when s.txntype in (2,3,11,20,30) then s.reqreason else ''  " + 
            "     end as remarks   " + 
            " from (  " + 
            "         select objid from mldw."+tableName+" " + 
            "         where txntype in (1,2,3,10,11,20,30) order by txndate  " + 
            "         limit ?, ? " + 
            "      )bt " +  
            "     inner join mldw."+tableName+" s on bt.objid=s.objid  " + 
            " order by txndate  ";
                
        WritableWorkbook wrk = null; 
        WritableSheet ws = null;
        int rowSize = 1000;
        int startIdx = 0;
        
        try 
        {
            wrk = Workbook.createWorkbook(new File("BSPReport-DailyTrxns-" + sdate.replaceAll("-", "") + ".xls"));
            ws = wrk.createSheet("Sheet 1", 0); 
            
            Object[] columns = new Object[]
            {
                new String[]{"txndate", "TxnDate"}, 
                new String[]{"txntype", "TxnType"}, 
                new String[]{"dtfiled", "SoutDate"}, 
                new String[]{"kptn", "KPTN"}, 
                new String[]{"sendername", "Sender"}, 
                new String[]{"receivername", "Receiver"}, 
                new String[]{"currency", "Currency"}, 
                new String[]{"principal", "Principal"}, 
                new String[]{"charge", "Charge"}, 
                new String[]{"chrgcurrency", "ChrgCurrency"}, 
                new String[]{"poutbranch", "PoutBranch"}, 
                new String[]{"remarks", "Remarks"}  
            };
            
            for (int c=0; c<columns.length; c++) 
            {
                String[] colDef = (String[]) columns[c]; 
                ws.addCell(new jxl.write.Label(c, 0, colDef[1]));                
            }
            
            while (true) 
            {
                System.out.println("fetching records... [sdate="+sdate+", startIdx="+startIdx+", rowSize="+rowSize+"] ");
                List list = sqlDB.getList(conn, sql, new Object[]{startIdx, rowSize+1});
                int size = list.size(); 
                if (size == 0) break; 
                
                boolean hasMoreRecords = (size > rowSize); 
                if (hasMoreRecords) 
                {
                    list.remove(rowSize); 
                    size = list.size(); 
                } 
                
                int rowID = (startIdx+1); 
                while (!list.isEmpty()) 
                {
                    Map item = (Map) list.remove(0); 
                    for (int c=0; c<columns.length; c++) 
                    {
                        String[] colDef = (String[]) columns[c]; 
                        ws.addCell(new jxl.write.Label(c, rowID, item.get(colDef[0]).toString())); 
                    } 
                    rowID += 1; 
                } 
                
                if (!hasMoreRecords) break; 
                
                startIdx += rowSize; 
                if (startIdx > 5000) break; 
            } 
            
            wrk.write();
        }
        catch(Exception ex) {
            throw ex; 
        } 
        finally 
        {
            try { wrk.close(); }catch(Exception ign){;} 
        }
    } 
    
}     