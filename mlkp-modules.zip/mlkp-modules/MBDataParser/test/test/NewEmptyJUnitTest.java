/*
 * NewEmptyJUnitTest.java
 * JUnit based test
 *
 * Created on June 3, 2008, 10:00 AM
 */

package test;

import com.rameses.common.xml.XmlNode;
import com.rameses.common.xml.XmlParser;
import fileparser.xml.XmlDataParser;
import java.io.InputStream;
import java.util.Iterator;
import junit.framework.*;

/**
 *
 * @author Administrator
 */
public class NewEmptyJUnitTest extends TestCase {
    
    public NewEmptyJUnitTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
    }

    protected void tearDown() throws Exception {
    }
    
    public void testHello() throws Exception
    {
        InputStream in = getClass().getResourceAsStream("test2.xml");
        XmlDataParser parser = new XmlDataParser();
        System.out.println(parser.parse(in)[0].toString());
//        XmlParser parser = new XmlParser();
//        XmlNode node = parser.parse(in);
//        printChildNodes(node, "Worksheet/Table/Row");
    }
    
    private void printImmediateChildren(XmlNode node) throws Exception
    {
        Iterator itr = node.getNodes();
        while (itr.hasNext())
        {
            XmlNode xn = (XmlNode) itr.next();
            System.out.println(xn.getName());
        }
    }
    
    private void printChildNodes(XmlNode node, String name) throws Exception {
        Iterator itr = node.getNodes(name);
        if (name.equals("Worksheet/Table/Row")) {
            itr.next();
        }
        while (itr.hasNext()) {
            XmlNode child = (XmlNode) itr.next();
            if (name.equals("Cell/Data")) {
                System.out.println(child.getValue());
            }
            else {
                printChildNodes(child, "Cell/Data");
            }
        }
    }
    
    private void print(Iterator nodes) throws Exception
    {
        while (nodes.hasNext())
        {
            XmlNode xn = (XmlNode) nodes.next();
            System.out.println(xn.getName());
            print(xn.getNodes("Cell/Data"));
        }
    }    

}
