package com.rameses.common.xml;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Iterator;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

public class XmlParser 
{
    private SAXParserFactory factory;
    
    public XmlParser() 
    {
        factory = SAXParserFactory.newInstance();
    }
    
    public SAXParserFactory getFactory() { return factory; }

    public XmlNode parse(File file) throws Exception {
        return parse(new FileInputStream(file));
    }
    
    public XmlNode parse(InputStream in) throws Exception
    {
        SAXParser parser = factory.newSAXParser();
        XmlParserHandler handler = new XmlParserHandler();
        parser.parse(in, handler);
        return handler.getNode();
    }

    /*
    public static void main(String[] args) throws Exception
    {
        InputStream in = new FileInputStream(new File("D:/mlkp/projects/osiris-rule-tags/data.xml"));
        XmlParser parser = new XmlParser();
        XmlNode node = parser.parse(in);
        Iterator itr = node.getNodes("row");
        while (itr.hasNext())
        {
            XmlNode xn = (XmlNode) itr.next();
            System.out.println(xn.getName() + "=" + xn.getValue());
        }
    }
    */
}
