package com.rameses.common.xml;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

class XmlParserHandler extends DefaultHandler
{
    private XmlNode root;
    private XmlNode currentNode;
    
    public XmlParserHandler() {;}
    
    public XmlNode getNode() { return root; }

    public void startDocument() throws SAXException 
    {
        root = null;
        currentNode = null;
    }
    
    public void startElement(String uri, String localName, String qName, Attributes attrs) throws SAXException 
    {
        if (root == null)
        {
            root = new XmlNode(qName, null);
            setAttributes(root, attrs);
            currentNode = root;
        }
        else
        {
            XmlNode xn = new XmlNode(qName, currentNode);
            setAttributes(xn, attrs);
            currentNode = xn;
        }
    }

    public void characters(char[] ch, int start, int length) throws SAXException 
    {
        String innerText = String.valueOf(ch, start, length);
        if (innerText.length() > 0) currentNode.insertText(innerText);
    }

    public void endElement(String uri, String localName, String qName) throws SAXException {
        currentNode = currentNode.getParent();
    }

    private void setAttributes(XmlNode node, Attributes attrs) 
    {
        for (int i=0; i<attrs.getLength(); i++) {
            node.setAttribute(attrs.getQName(i), attrs.getValue(i));
        }
    }
    
}
