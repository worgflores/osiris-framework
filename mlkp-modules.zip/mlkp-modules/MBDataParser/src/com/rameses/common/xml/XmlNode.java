package com.rameses.common.xml;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class XmlNode {
    private XmlNode parent;
    private String name;
    private Map attributes;
    private StringBuffer buffer;
    private List children;
    
    XmlNode(String name, XmlNode parent) 
    {
        this.name = name;
        this.parent = parent;
        this.attributes = new HashMap();
        this.buffer = new StringBuffer();
        this.children = new ArrayList();
        
        if (parent != null) 
            parent.children.add(this);
    }
    
    public String getName() { return name; }
    public XmlNode getParent() { return parent; }
    public int getChildCount() { return children.size(); }
    
    public String getValue() { return buffer.toString(); }
    void insertText(String text) { buffer.append(text); }

    public boolean containsAttribute(String name) {
        return attributes.containsKey(name);
    }
    
    public Iterator getAttributeKeys() {
        return attributes.keySet().iterator();
    }
    
    public String getAttribute(String name)
    {
        String attrValue = (String) attributes.get(name);
        return (attrValue != null) ? attrValue : "";
    }
    
    public String getAttribute(String name, String defaultValue)
    {
        String attrValue = (String) attributes.get(name);
        return (attrValue != null) ? attrValue : defaultValue;
    }    
    
    void setAttribute(String key, String value) {
        attributes.put(key, value);
    }
    
    public Iterator getNodes() { return children.iterator(); }
    
    public Iterator getNodes(String name) 
    {
        XmlNodeUtil u = new XmlNodeUtil();
        return u.getNodes(children, name).iterator();
    }
    
    public XmlNode getNode(String name)
    {
        XmlNodeUtil u = new XmlNodeUtil();
        return u.getNode(children, name);
    }
    
    public String getValue(String name)
    {
        XmlNode node = getNode(name);
        return (node != null) ? node.getValue() : "";
    }
    
    List getChildren() { return children; } 
    
}
