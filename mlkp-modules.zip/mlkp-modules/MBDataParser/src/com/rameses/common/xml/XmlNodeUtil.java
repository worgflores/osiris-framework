package com.rameses.common.xml;

import java.util.ArrayList;
import java.util.List;

class XmlNodeUtil 
{
    
    public XmlNodeUtil() {;}

    public XmlNode getNode(List children, String name) 
    {
        String[] paths = name.split("/");
        return findNode(children, paths);
    }
    
    private XmlNode findNode(List children, String[] paths)
    {
        XmlNode node = null;
        for (int i=0; i<children.size(); i++)
        {
            XmlNode xn = (XmlNode) children.get(i);
            if ("*".equals(paths[0]) || xn.getName().equals(paths[0]))
            {
                String[] array = subarray(paths, 1);
                if (array == null)
                    node = xn;
                else
                    node = findNode(xn.getChildren(), array);
                
                if (node != null) break;
            }
        }
        return node;
    }
    
    public List getNodes(List children, String name) 
    {
        List results = new ArrayList();
        String[] paths = name.split("/");
        findNodes(results, children, paths);
        return results;
    }

    private void findNodes(List results, List children, String[] paths)
    {
        for (int i=0; i<children.size(); i++)
        {
            XmlNode xn = (XmlNode) children.get(i);
            if ("*".equals(paths[0]) || xn.getName().equals(paths[0]))
            {
                String[] array = subarray(paths, 1);
                if (array == null)
                    results.add(xn);
                else
                    findNodes(results, xn.getChildren(), array);
            }
        }        
    }
    
    private String[] subarray(String[] array, int start)
    {
        List list = new ArrayList();
        for (int i=start; i<array.length; i++) {
            list.add(array[i]);
        }
        
        if (list.isEmpty())
            return null;
        else
            return (String[]) list.toArray(new String[list.size()]);
    }
    
}
