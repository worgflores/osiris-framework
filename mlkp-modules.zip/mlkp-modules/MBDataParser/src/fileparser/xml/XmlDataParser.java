
package fileparser.xml;

import com.rameses.common.xml.XmlNode;
import com.rameses.common.xml.XmlParser;
import java.io.InputStream;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;

public class XmlDataParser {
    
    private double principals;
    private int rowcounter;
    public XmlDataParser() {
        principals = 0.0;
    }
    
    public StringBuffer[] parse(InputStream is) throws Exception {
        StringBuffer buff = new StringBuffer();
        
        StringBuffer errorbuff = new StringBuffer();
        StringBuffer correctbuff = new StringBuffer();
        StringBuffer[] buffs = new StringBuffer[]{correctbuff, errorbuff};
        
        XmlParser parser = new XmlParser();
        XmlNode rootnode = parser.parse(is);
        Iterator rownodes = rootnode.getNodes("Worksheet/Table/Row");
        //uninclude header
        rowcounter = 0;
        rownodes.next();
        while (rownodes.hasNext()) {
            rowcounter += 1;
            XmlNode rownode = (XmlNode) rownodes.next();
            StringBuffer data = convertToNewSpecs(rownode, rowcounter);
            if (data.length() < 450) {
                errorbuff.append("Row # "+rowcounter+"\n");
            } else {
                buff.append(data+"\n");
            }
        }
        
        correctbuff.append(getHeader());
        correctbuff.append(buff);
        
        return buffs;
    }
    
    private StringBuffer getHeader() {
        StringBuffer sb = new StringBuffer();
        
        Date d = new Date();
        Calendar c = Calendar.getInstance();
        c.setTime(d);
        String yyyy = "" + c.get(Calendar.YEAR);
        String mm = "" + c.get(Calendar.MONTH);
        if (mm.length() == 1) {
            mm = "0" + mm;
        }
        String dd = "" + c.get(Calendar.DATE);
        if (dd.length() == 1) {
            dd = "0" + dd;
        }
        String dtsent = yyyy + "-" + mm + "-" + dd;
        sb.append(dtsent);
        
        String branchid = "MTRBNK";
        sb.append(branchid);
        
        String userid = "MTRBNKU1";
        for (int j = userid.length(); j < 20; j++) {
            userid = userid + " ";
        }
        sb.append(userid);
        
        String terminalid = "MTRBNKT1";
        for (int j = terminalid.length(); j < 10; j++) {
            terminalid = terminalid + " ";
        }
        sb.append(terminalid);
        
        String secretkey = "TB09!DMX$G";
        sb.append(secretkey);
        
        String totalcount = "" + rowcounter;
        for (int j = totalcount.length(); j < 5; j++) {
            totalcount = "0" + totalcount;
        }
        sb.append(totalcount);
        
        String signature = "";
        if (principals < 100.0) {
            signature = "0";
        }else {
            signature = "" + (long)(principals/100);
        }
        for (int j = signature.length(); j < 6; j++) {
            signature = "0" + signature;
        }
        sb.append(signature);
        
        sb.append("\n");
        
        return sb;
    }
    
    private StringBuffer convertToNewSpecs(XmlNode node, int rowcounter) {
        StringBuffer sb = new StringBuffer();
        
        String itemno = "" + rowcounter;
        for (int j = itemno.length(); j < 5; j++) {
            itemno = "0" + itemno;
        }
        sb.append(itemno);
        
        int cellcounter = 0;
        Iterator cellnodes = node.getNodes("Cell");
        
        String dtfiled = getDataAt(cellnodes, 27);
        dtfiled = dtfiled + "                               ";
        dtfiled = dtfiled.substring(4,8)+"-"+dtfiled.substring(2,4)+"-"+dtfiled.substring(0,2) + " 00:00:00";
        sb.append(dtfiled);
        
        cellnodes = node.getNodes("Cell");
        String ccrefno = getDataAt(cellnodes, 1);
        for (int j = ccrefno.length(); j < 20; j++) {
            ccrefno = ccrefno + " ";
        }
        sb.append(ccrefno);
        
        cellnodes = node.getNodes("Cell");
        String principal = getDataAt(cellnodes, 13);
        principal = principal + "000";
        principal = principal.substring(0, principal.indexOf(".") + 3).trim();
        principals = principals + Double.parseDouble(principal);
        for (int j = principal.length(); j < 12; j++) {
            principal = "0"+principal;
        }
        sb.append(principal);
        
        cellnodes = node.getNodes("Cell");
        String currencyid = getDataAt(cellnodes, 16);
        sb.append(currencyid);
        
        String sourceoffund = "                    ";
        sb.append(sourceoffund);
        
        String relationtoreceiver = "                    ";
        sb.append(relationtoreceiver);
        
        String purpose = "                              ";
        sb.append(purpose);
        
        cellnodes = node.getNodes("Cell");
        String receivername = getDataAt(cellnodes, 3);
        String[] names = receivername.split(",",2);
        String receiverlname = "";
        String receiverfname = "";
        String receivermname = "";
        if (names.length == 1) {
            return sb;
        } else {
            receiverlname = names[0].trim();
            receiverfname = names[1].trim();
        }
        if (receiverlname.length() > 20) {
            receiverfname = receiverlname.substring(20);
            receiverlname = receiverlname.substring(0,20);
        }
        if (receiverfname.length() > 20) {
            receivermname = receiverfname.substring(20);
            receiverfname = receiverfname.substring(0,20);
        }
        for (int j = receiverlname.length(); j < 20; j++) {
            receiverlname = receiverlname + " ";
        }
        for (int j = receiverfname.length(); j < 20; j++) {
            receiverfname = receiverfname + " ";
        }
        for (int j = receivermname.length(); j < 20; j++) {
            receivermname = receivermname + " ";
        }
        sb.append(receiverlname);
        sb.append(receiverfname);
        sb.append(receivermname);
        
        String receivergender = "3";
        sb.append(receivergender);
        
        String receiverbirthdate = "          ";
        sb.append(receiverbirthdate);
        
        cellnodes = node.getNodes("Cell");
        String receiverstreet = getDataAt(cellnodes, 4);
        if (receiverstreet.trim().length() == 0) {
            receiverstreet = ".";
        }
        for (int j = receiverstreet.length(); j < 50; j++) {
            receiverstreet = receiverstreet + " ";
        }
        sb.append(receiverstreet);
        
        cellnodes = node.getNodes("Cell");
        String receiverprovince = getDataAt(cellnodes, 5);
        if (receiverprovince.trim().length() == 0) {
            receiverprovince = ".";
        }
        for (int j = receiverprovince.length(); j < 50; j++) {
            receiverprovince = receiverprovince + " ";
        }
        sb.append(receiverprovince);
        
        String receivercountry = ".";
        for (int j = receivercountry.length(); j < 50; j++) {
            receivercountry = receivercountry + " ";
        }
        sb.append(receivercountry);
        
        cellnodes = node.getNodes("Cell");
        String receiverphone = getDataAt(cellnodes, 6);
        if (receiverphone.length() > 20) {
            receiverphone = receiverphone.substring(0, 20);
        }
        sb.append(receiverphone);
        
        cellnodes = node.getNodes("Cell");
        String msg1 = getDataAt(cellnodes, 19);
        cellnodes = node.getNodes("Cell");
        String msg2 = getDataAt(cellnodes, 20);
        cellnodes = node.getNodes("Cell");
        String msg3 = getDataAt(cellnodes, 21);
        String msg = msg1 + "  " + msg2 + "  " + msg3;
        for (int j = msg.length(); j < 100; j++) {
            msg = msg + " ";
        }
        if (msg.length() > 100) {
            msg = msg.substring(0, 99);
        }
        sb.append(msg);
        
        return sb;
    }
    
    private String getDataAt(Iterator cellnodes, int index) {
        int ctr = 1;
        Iterator itr = cellnodes;
        while (itr.hasNext()) {
            XmlNode cellnode = (XmlNode) itr.next();
            if (cellnode.containsAttribute("ss:Index")) {
                ctr = Integer.parseInt(cellnode.getAttribute("ss:Index"));
            }
            if (ctr == index) {
                XmlNode datanode = cellnode.getNode("Data");
                if (datanode != null) {
                    return datanode.getValue();
                }
                else
                    break;
            }
            ctr += 1;
        }
        return "";
    }
    
    
}
