
package fileparser;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.SystemColor;
import javax.swing.JFrame;

public class Main {
    
    public static void main(String[] args) throws Exception 
    {
        JFrame frame = new JFrame("METROBANK Data Parser");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setDefaultLookAndFeelDecorated(false);
        frame.setLayout(new BorderLayout());
        
        frame.getContentPane().add(new MBDataParserUI());
        
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        
//        InputStream is = Main.class.getResourceAsStream("MBSpec.txt");
//        DataParser parser = new DataParser();
//        
//        FileWriter fw = new FileWriter(new File("src/fileparser/Test.txt"));
//        BufferedWriter bw = new BufferedWriter(fw);
//        bw.write(parser.parse(is).toString());
//        bw.close();
    }
    
}
