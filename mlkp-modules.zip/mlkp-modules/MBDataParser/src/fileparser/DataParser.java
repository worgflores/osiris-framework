
package fileparser;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Calendar;
import java.util.Date;

public class DataParser {
    
    private double principals;
    private int counter;
    public DataParser() {
        principals = 0.0;
    }
    
    public StringBuffer[] parse(InputStream in) throws Exception {
        StringBuffer buff = new StringBuffer();
        StringBuffer errorbuff = new StringBuffer();
        StringBuffer correctbuff = new StringBuffer();
        StringBuffer[] buffs = new StringBuffer[]{correctbuff, errorbuff};
        BufferedReader reader = null;
        String text = null;
        counter = 0;
        try {
            reader = new BufferedReader(new InputStreamReader(in));
            while ((text = reader.readLine()) != null) {
                if (text.length() == 0) continue;
                
                counter += 1;
                StringBuffer sb = convertToNewSpecs(text, counter);
                if (sb.length() != 469) {
                    errorbuff.append(text);
                    errorbuff.append("\n");
                    counter -= 1;
                } else {
                    buff.append(sb);
                    buff.append("\n");
                }
            }
            
            correctbuff.append(getHeader());
            correctbuff.append(buff);
            
            return buffs;
        } catch(Exception ex) {
            throw ex;
        } finally {
            try { reader.close(); }catch(Exception ign){;}
        }
    }
    
    private StringBuffer getHeader() {
        StringBuffer sb = new StringBuffer();
        
        Date d = new Date();
        Calendar c = Calendar.getInstance();
        c.setTime(d);
        String yyyy = "" + c.get(Calendar.YEAR);
        String mm = "" + c.get(Calendar.MONTH);
        if (mm.length() == 1) {
            mm = "0" + mm;
        }
        String dd = "" + c.get(Calendar.DATE);
        if (dd.length() == 1) {
            dd = "0" + dd;
        }
        String dtsent = yyyy + "-" + mm + "-" + dd;
        sb.append(dtsent);
        
        String branchid = "MTRBNK";
        sb.append(branchid);
        
        String userid = "MTRBNKU1";
        for (int j = userid.length(); j < 20; j++) {
            userid = userid + " ";
        }
        sb.append(userid);
        
        String terminalid = "MTRBNKT1";
        for (int j = terminalid.length(); j < 10; j++) {
            terminalid = terminalid + " ";
        }
        sb.append(terminalid);
        
        String secretkey = "TB09!DMX$G";
        sb.append(secretkey);
        
        String totalcount = "" + counter;
        for (int j = totalcount.length(); j < 5; j++) {
            totalcount = "0" + totalcount;
        }
        sb.append(totalcount);
        
        String signature = "";
        if (principals < 100.0) {
            signature = "0";
        }else {
            signature = "" + (long)(principals/100);
        }
        for (int j = signature.length(); j < 6; j++) {
            signature = "0" + signature;
        }
        sb.append(signature);
        
        sb.append("\n");
        
        return sb;
    }
    
    private StringBuffer convertToNewSpecs(String text, int index) throws Exception 
    {
        System.out.println("indexno=" + index);
        System.out.println("  " + text);
        StringBuffer sb = new StringBuffer();
        
        String itemno = "" + index;
        for (int j = itemno.length(); j < 5; j++) {
            itemno = "0" + itemno;
        }
        sb.append(itemno);
        
        String dtfiled = text.substring(459, 467);
        dtfiled = dtfiled.substring(4,8)+"-"+dtfiled.substring(2,4)+"-"+dtfiled.substring(0,2) + " 00:00:00";
        sb.append(dtfiled);
        
        String ccrefno = text.substring(0, 15);
        for (int j = ccrefno.trim().length(); j < 20; j++) {
            ccrefno = ccrefno + " ";
        }
        sb.append(ccrefno);
        
        String principal = text.substring(271, 290);
        principal = principal.substring(0, principal.indexOf(".") + 3).trim();
        principals = principals + Double.parseDouble(principal);
        for (int j = principal.trim().length(); j < 12; j++) {
            principal = "0"+principal;
        }
        sb.append(principal);
        
        String currencyid = text.substring(294, 297);
        sb.append(currencyid);
        
        String sourceoffund = "                    ";
        sb.append(sourceoffund);
        
        String relationtoreceiver = "                    ";
        sb.append(relationtoreceiver);
        
        String purpose = "                              ";
        sb.append(purpose);
        
        String receivername = text.substring(45, 85).trim();
        String[] names = receivername.split(",",2);
        String receiverlname = "";
        String receiverfname = "";
        String receivermname = "";
        if (names.length == 1) {
            return sb;
        } else {
            receiverlname = names[0].trim();
            receiverfname = names[1].trim();
        }
        if (receiverlname.length() > 20) {
            receiverfname = receiverlname.substring(20);
            receiverlname = receiverlname.substring(0,20);
        }
        if (receiverfname.length() > 20) {
            receivermname = receiverfname.substring(20);
            receiverfname = receiverfname.substring(0,20);
        }
        for (int j = receiverlname.trim().length(); j < 20; j++) {
            receiverlname = receiverlname + " ";
        }
        for (int j = receiverfname.trim().length(); j < 20; j++) {
            receiverfname = receiverfname + " ";
        }
        for (int j = receivermname.trim().length(); j < 20; j++) {
            receivermname = receivermname + " ";
        }
        sb.append(receiverlname);
        sb.append(receiverfname);
        sb.append(receivermname);
        
        String receivergender = "3";
        sb.append(receivergender);
        
        String receiverbirthdate = "          ";
        sb.append(receiverbirthdate);
        
        String receiverstreet = text.substring(85,125).trim();
        if (receiverstreet.trim().length() == 0) {
            receiverstreet = ".";
        }
        for (int j = receiverstreet.length(); j < 50; j++) {
            receiverstreet = receiverstreet + " ";
        }
        sb.append(receiverstreet);
        
        String receiverprovince = text.substring(125,165).trim();
        if (receiverprovince.trim().length() == 0) {
            receiverprovince = ".";
        }
        for (int j = receiverprovince.trim().length(); j < 50; j++) {
            receiverprovince = receiverprovince + " ";
        }
        sb.append(receiverprovince);
        
        String receivercountry = ".";
        for (int j = receivercountry.trim().length(); j < 50; j++) {
            receivercountry = receivercountry + " ";
        }
        sb.append(receivercountry);
        
        String receiverphone = text.substring(165, 205);
        receiverphone = receiverphone.substring(0, 20);
        sb.append(receiverphone);
        
        String msg = text.substring(299, 339).trim() + "  " + text.substring(339, 379).trim() + "  " + text.substring(379, 419).trim();
        for (int j = msg.trim().length(); j < 100; j++) {
            msg = msg + " ";
        }
        if (msg.length() > 100) {
            msg = msg.substring(0, 99);
        }
        sb.append(msg);
        
        return sb;
    }
    
}
