package test;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import rameses.osiris.client.app.App;
import rameses.osiris.common.interfaces.IDataModel;
import rameses.osiris.common.interfaces.IDataSetModel;
import rameses.osiris.common.service.Request;
import rameses.osiris.common.service.Response;

public class RuleTest 
{
    public static void main(String[] args) throws Exception 
    {
        System.setProperty("app.host", "http://192.168.3.220:8080/mlhuillier/action");        
        
        RuleTest r = new RuleTest();
        //r.dump(r.execQueryList("mldb", "show variables"));
        System.out.println("");
        r.dump(r.execQueryList("mldb", "show full processlist"));
    }
    
    public RuleTest() {
    }
    
    public IDataSetModel execQueryList(String dsname, String sql) throws Exception
    {
        Request req = new Request();
        req.addParameter("DSNAME", "java:" + dsname);
        req.addParameter("QUERY", "2");
        req.addParameter("SQLSTMT", sql);
        Response res = App.getServiceManager().invoke("system.exec", req);
        return (IDataSetModel) res.getValue("list");
    }
    
    public String execQuery(String dsname, String sql) throws Exception
    {
        Request req = new Request();
        req.addParameter("DSNAME", "java:" + dsname);
        req.addParameter("QUERY", "1");
        req.addParameter("SQLSTMT", sql);
        Response res = App.getServiceManager().invoke("system.exec", req);
        return res.getValue("xmldata")+"";
    }    
    
    public void dump(IDataSetModel list) throws Exception
    {
        int len = list.size();
        for (int i=0; i<len; i++)
        {
            IDataModel doc = list.getItem(i);
            Iterator itr = doc.getFields();
            Map data = new HashMap();
            
            while (itr.hasNext())
            {
                String key = itr.next().toString();
                data.put(key, doc.getValue(key));
            }
            
            int lineno = i+1;
            System.out.println(lineno + ") " + data);
        }
    }
    
}
