package test;

import groovy.ui.Console;

public class GroovyConsoleTest 
{
    public static void main(String[] args) throws Exception 
    {
        Console c = new Console(); 
        c.run(); 
        
    }
}
