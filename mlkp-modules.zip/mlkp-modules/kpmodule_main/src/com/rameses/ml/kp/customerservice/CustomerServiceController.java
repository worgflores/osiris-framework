package com.rameses.ml.kp.customerservice;

import com.rameses.osiris.client.AbstractFormController;
import java.awt.Dimension;
import java.io.InputStream;

public class CustomerServiceController extends AbstractFormController
{
    
    public CustomerServiceController() 
    {
    }

    protected Class getDefaultPageClass() { return CustomerServicePage.class; }

    protected InputStream getCodeBaseAsStream() { 
        return getClass().getResourceAsStream("CustomerServiceController.xml");
    }

    public String getPreferredID() { return "customerservice.frm"; }

    public String getTitle() { return "Customer Service (Build 31.0)"; }
    
    public Dimension getPreferredSize() {
        return new Dimension(798, 515);
    }

}
