package com.rameses.ml.kp.sms;

import com.rameses.osiris.client.component.ComboEntry;

public class SMSPage extends com.rameses.osiris.client.Page
{
    
    public SMSPage()
{
        initComponents();
    }
    
    // <editor-fold defaultstate="collapsed" desc=" Generated Code ">//GEN-BEGIN:initComponents
    private void initComponents() {
        xLabel1 = new com.rameses.osiris.client.component.XLabel();
        xPanel1 = new com.rameses.osiris.client.component.XPanel();
        xButton2 = new com.rameses.osiris.client.component.XButton();
        xGlue1 = new com.rameses.osiris.client.component.spacer.XGlue();
        xButton1 = new com.rameses.osiris.client.component.XButton();
        xStrut1 = new com.rameses.osiris.client.component.spacer.XStrut();
        xButton3 = new com.rameses.osiris.client.component.XButton();
        xPanel2 = new com.rameses.osiris.client.component.XPanel();
        xLabel2 = new com.rameses.osiris.client.component.XLabel();
        xTextField1 = new com.rameses.osiris.client.component.XTextField();
        xLabel3 = new com.rameses.osiris.client.component.XLabel();
        xTextArea1 = new com.rameses.osiris.client.component.XTextArea();
        xLabel4 = new com.rameses.osiris.client.component.XLabel();
        xTextField2 = new com.rameses.osiris.client.component.XTextField();
        xCheck1 = new com.rameses.osiris.client.component.XCheck();
        xCheck2 = new com.rameses.osiris.client.component.XCheck();
        xLabel5 = new com.rameses.osiris.client.component.XLabel();
        xTextField3 = new com.rameses.osiris.client.component.XTextField();
        xLabel6 = new com.rameses.osiris.client.component.XLabel();
        xTextField4 = new com.rameses.osiris.client.component.XTextField();

        setLayout(new java.awt.BorderLayout());

        setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        setOpaque(false);
        setPreferredSize(new java.awt.Dimension(572, 401));
        xLabel1.setBackground(new java.awt.Color(0, 0, 153));
        xLabel1.setForeground(new java.awt.Color(255, 255, 255));
        xLabel1.setOpaque(true);
        xLabel1.setPadding(new java.awt.Insets(10, 10, 10, 10));
        xLabel1.setText("<html><font size=\"5\">SMS Broadcast</font></html>");
        add(xLabel1, java.awt.BorderLayout.NORTH);

        xPanel1.setLayout(new javax.swing.BoxLayout(xPanel1, javax.swing.BoxLayout.X_AXIS));

        xPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        xPanel1.setOpaque(true);
        xPanel1.setPadding(new java.awt.Insets(10, 10, 10, 10));
        xButton2.setAlt('u');
        xButton2.setOnclick("showBuildContacts");
        xButton2.setText("Build Contacts");
        xPanel1.add(xButton2);

        xPanel1.add(xGlue1);

        xButton1.setAlt('s');
        xButton1.setDefaultFocusInWindow(true);
        xButton1.setOnclick("doSend");
        xButton1.setText(" Send ");
        xPanel1.add(xButton1);

        xStrut1.setLength(5);
        xPanel1.add(xStrut1);

        xButton3.setOnclick("doClose");
        xButton3.setText("Cancel");
        xPanel1.add(xButton3);

        add(xPanel1, java.awt.BorderLayout.SOUTH);

        xPanel2.setLayout(null);

        xPanel2.setBackground(new java.awt.Color(255, 255, 255));
        xPanel2.setOpaque(true);
        xLabel2.setText("Subject :");
        xPanel2.add(xLabel2);
        xLabel2.setBounds(18, 51, 66, 14);

        xTextField1.setModelName("sms");
        xTextField1.setName("subject");
        xPanel2.add(xTextField1);
        xTextField1.setBounds(120, 48, 405, 19);

        xLabel3.setText("<html>Message <font color=\"red\">*</font> :</html>");
        xPanel2.add(xLabel3);
        xLabel3.setBounds(18, 75, 81, 14);

        xTextArea1.setModelName("sms");
        xTextArea1.setName("message");
        xTextArea1.setTextcase("none");
        xPanel2.add(xTextArea1);
        xTextArea1.setBounds(120, 75, 405, 135);

        xLabel4.setText("Footer :");
        xPanel2.add(xLabel4);
        xLabel4.setBounds(18, 219, 66, 14);

        xTextField2.setModelName("sms");
        xTextField2.setName("footer");
        xPanel2.add(xTextField2);
        xTextField2.setBounds(120, 216, 405, 19);

        xCheck1.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        xCheck1.setModelName("sms");
        xCheck1.setName("incsubject");
        xCheck1.setText(" Include Subject");
        xPanel2.add(xCheck1);
        xCheck1.setBounds(120, 252, 135, 15);

        xCheck2.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        xCheck2.setModelName("sms");
        xCheck2.setName("incfooter");
        xCheck2.setText(" Include Footer");
        xPanel2.add(xCheck2);
        xCheck2.setBounds(120, 270, 135, 15);

        xLabel5.setText("<html>Table Name <font color=\"red\">*</font> :</html>");
        xPanel2.add(xLabel5);
        xLabel5.setBounds(18, 24, 96, 14);

        xTextField3.setDefaultFocus(true);
        xTextField3.setModelName("sms");
        xTextField3.setName("tablename");
        xTextField3.setTextcase("none");
        xPanel2.add(xTextField3);
        xTextField3.setBounds(120, 24, 405, 19);

        xLabel6.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        xLabel6.setText("<html>Limit <font color=\"red\">*</font> :</html>");
        xPanel2.add(xLabel6);
        xLabel6.setBounds(402, 252, 57, 14);

        xTextField4.setModelName("sms");
        xTextField4.setName("limit");
        xPanel2.add(xTextField4);
        xTextField4.setBounds(465, 249, 60, 19);

        add(xPanel2, java.awt.BorderLayout.CENTER);

    }// </editor-fold>//GEN-END:initComponents
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private com.rameses.osiris.client.component.XButton xButton1;
    private com.rameses.osiris.client.component.XButton xButton2;
    private com.rameses.osiris.client.component.XButton xButton3;
    private com.rameses.osiris.client.component.XCheck xCheck1;
    private com.rameses.osiris.client.component.XCheck xCheck2;
    private com.rameses.osiris.client.component.spacer.XGlue xGlue1;
    private com.rameses.osiris.client.component.XLabel xLabel1;
    private com.rameses.osiris.client.component.XLabel xLabel2;
    private com.rameses.osiris.client.component.XLabel xLabel3;
    private com.rameses.osiris.client.component.XLabel xLabel4;
    private com.rameses.osiris.client.component.XLabel xLabel5;
    private com.rameses.osiris.client.component.XLabel xLabel6;
    private com.rameses.osiris.client.component.XPanel xPanel1;
    private com.rameses.osiris.client.component.XPanel xPanel2;
    private com.rameses.osiris.client.component.spacer.XStrut xStrut1;
    private com.rameses.osiris.client.component.XTextArea xTextArea1;
    private com.rameses.osiris.client.component.XTextField xTextField1;
    private com.rameses.osiris.client.component.XTextField xTextField2;
    private com.rameses.osiris.client.component.XTextField xTextField3;
    private com.rameses.osiris.client.component.XTextField xTextField4;
    // End of variables declaration//GEN-END:variables
    
}
