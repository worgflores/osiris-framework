package com.rameses.ml.kp.customerservice;

import com.rameses.osiris.client.component.ComboEntry;

public class CustomerServicePage extends com.rameses.osiris.client.Page
{
    
    public CustomerServicePage()
{
        initComponents();
    }
    
    // <editor-fold defaultstate="collapsed" desc=" Generated Code ">//GEN-BEGIN:initComponents
    private void initComponents() {
        xPanel1 = new com.rameses.osiris.client.component.XPanel();
        xLabel1 = new com.rameses.osiris.client.component.XLabel();
        xPanel3 = new com.rameses.osiris.client.component.XPanel();
        xPanel4 = new com.rameses.osiris.client.component.XPanel();
        xLabel2 = new com.rameses.osiris.client.component.XLabel();
        xTextField1 = new com.rameses.osiris.client.component.XTextField();
        xLabel3 = new com.rameses.osiris.client.component.XLabel();
        xCombo1 = new com.rameses.osiris.client.component.XCombo();
        xLabel4 = new com.rameses.osiris.client.component.XLabel();
        xTextField2 = new com.rameses.osiris.client.component.XTextField();
        xLabel5 = new com.rameses.osiris.client.component.XLabel();
        xTextField3 = new com.rameses.osiris.client.component.XTextField();
        xLabel6 = new com.rameses.osiris.client.component.XLabel();
        xTextField4 = new com.rameses.osiris.client.component.XTextField();
        xLabel7 = new com.rameses.osiris.client.component.XLabel();
        xButton1 = new com.rameses.osiris.client.component.XButton();
        xPanel2 = new com.rameses.osiris.client.component.XPanel();
        xTable1 = new com.rameses.osiris.client.component.XTable();
        xPanel5 = new com.rameses.osiris.client.component.XPanel();
        xButton2 = new com.rameses.osiris.client.component.XButton();

        setLayout(new java.awt.BorderLayout());

        setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        setPreferredSize(new java.awt.Dimension(798, 515));
        xPanel1.setLayout(new java.awt.BorderLayout());

        xPanel1.setOpaque(true);
        xPanel1.setPreferredSize(new java.awt.Dimension(798, 202));
        xLabel1.setBackground(new java.awt.Color(0, 0, 153));
        xLabel1.setForeground(new java.awt.Color(255, 255, 255));
        xLabel1.setOpaque(true);
        xLabel1.setPadding(new java.awt.Insets(10, 10, 10, 10));
        xLabel1.setText("<html><font size=\"5\">Customer Service</font></html>");
        xPanel1.add(xLabel1, java.awt.BorderLayout.NORTH);

        xPanel3.setLayout(new java.awt.BorderLayout());

        xPanel3.setPadding(new java.awt.Insets(5, 5, 5, 5));
        xPanel4.setLayout(null);

        xPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder(" Search Criteria "));
        xPanel4.setPreferredSize(new java.awt.Dimension(792, 164));
        xLabel2.setText("<html><u>K</u>PTN :</html>");
        xPanel4.add(xLabel2);
        xLabel2.setBounds(24, 45, 72, 15);

        xTextField1.setFocusAccelerator('k');
        xTextField1.setDefaultFocus(true);
        xTextField1.setFont(new java.awt.Font("Dialog", 1, 14));
        xTextField1.setForeground(new java.awt.Color(102, 0, 51));
        xTextField1.setModelName("bykptn");
        xTextField1.setName("kptn");
        xPanel4.add(xTextField1);
        xTextField1.setBounds(102, 42, 170, 20);

        xLabel3.setText("<html>Status :</html>");
        xPanel4.add(xLabel3);
        xLabel3.setBounds(280, 40, 50, 20);

        xCombo1.setEntries(new ComboEntry[]
            {
                new ComboEntry("0", "Unclaimed"),
                new ComboEntry("1", "Claimed"),
                new ComboEntry("2", "Cancelled"),
                new ComboEntry("5", "Return To Sender")
            });
            xCombo1.setName("status");
            xPanel4.add(xCombo1);
            xCombo1.setBounds(330, 40, 120, 22);

            xLabel4.setText("<html><u>C</u>C Ref No. :</html>");
            xPanel4.add(xLabel4);
            xLabel4.setBounds(24, 69, 70, 14);

            xTextField2.setFocusAccelerator('c');
            xTextField2.setFont(new java.awt.Font("Dialog", 1, 14));
            xTextField2.setForeground(new java.awt.Color(102, 0, 51));
            xTextField2.setModelName("byccrefno");
            xTextField2.setName("ccrefno");
            xPanel4.add(xTextField2);
            xTextField2.setBounds(102, 66, 170, 20);

            xLabel5.setText("<html><u>R</u>eceiver :</html>");
            xPanel4.add(xLabel5);
            xLabel5.setBounds(24, 93, 66, 15);

            xTextField3.setFocusAccelerator('r');
            xTextField3.setFont(new java.awt.Font("Dialog", 1, 14));
            xTextField3.setForeground(new java.awt.Color(102, 0, 51));
            xTextField3.setModelName("byreceiver");
            xTextField3.setName("receiverlastname");
            xPanel4.add(xTextField3);
            xTextField3.setBounds(102, 90, 170, 20);

            xLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
            xLabel6.setText("<html>(<i>Last Name</i>)</html>");
            xPanel4.add(xLabel6);
            xLabel6.setBounds(111, 111, 150, 18);

            xTextField4.setFont(new java.awt.Font("Dialog", 1, 14));
            xTextField4.setForeground(new java.awt.Color(102, 0, 51));
            xTextField4.setModelName("byreceiver");
            xTextField4.setName("receiverfirstname");
            xPanel4.add(xTextField4);
            xTextField4.setBounds(276, 90, 177, 20);

            xLabel7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
            xLabel7.setText("<html>(<i>First Name</i>)</html>");
            xPanel4.add(xLabel7);
            xLabel7.setBounds(285, 111, 153, 18);

            xButton1.setAlt('h');
            xButton1.setDefaultFocusInWindow(true);
            xButton1.setOnclick("getResults");
            xButton1.setText("Search");
            xPanel4.add(xButton1);
            xButton1.setBounds(462, 87, 80, 28);

            xPanel3.add(xPanel4, java.awt.BorderLayout.CENTER);

            xPanel1.add(xPanel3, java.awt.BorderLayout.CENTER);

            add(xPanel1, java.awt.BorderLayout.NORTH);

            xPanel2.setLayout(new java.awt.BorderLayout());

            xPanel2.setOpaque(true);
            xPanel2.setPadding(new java.awt.Insets(0, 7, 5, 7));
            xPanel2.setPreferredSize(new java.awt.Dimension(798, 293));
            xTable1.setAutoresize(false);
            xTable1.setColumnAsXml("<column caption=\"Txn Date\" name=\"dtfiled\" width=\"120\"/>\n<column caption=\"KPTN\" name=\"kptn\" width=\"120\"/>\n<column caption=\"CC Ref. No.\" name=\"ccrefno\" width=\"120\"/>\n<column caption=\"Control\" name=\"controlno\" width=\"150\"/>\n<column caption=\"Sender Name\" name=\"sendername\" width=\"150\"/>\n<column caption=\"Receiver Name\" name=\"receivername\" width=\"150\"/>\n<column caption=\"Sendout Currency\" name=\"sendoutcurrencyid\" width=\"100\" align=\"center\"/>\n<column caption=\"Principal\" name=\"principal\" width=\"100\" type=\"currency\" align=\"right\"/>\n<column caption=\"Pout Date\" name=\"dtclaimed\" width=\"100\"/>\n<column caption=\"Pout Branch\" name=\"poutbranchid\" width=\"80\"/>\n<column caption=\"Pout Control\" name=\"payoutcontrol\" width=\"100\"/>\n<column caption=\"Pout Currency\" name=\"payoutcurrencyid\" width=\"100\" align=\"center\" />\n<column caption=\"Amout Paid\" name=\"amtpaid\" width=\"150\" type=\"currency\" align=\"right\"  />\n<column caption=\"Sending Branch\" name=\"branchid\" width=\"100\"/>\n<column caption=\"Sending Operator\" name=\"operator\" width=\"100\"/>\n<column caption=\"Status\" name=\"status\" width=\"100\"/>\n");
            xTable1.setModelName("datalist");
            xTable1.setRowsperpage(-1);
            xPanel2.add(xTable1, java.awt.BorderLayout.CENTER);

            xPanel5.setLayout(new javax.swing.BoxLayout(xPanel5, javax.swing.BoxLayout.X_AXIS));

            xPanel5.setOpaque(true);
            xPanel5.setPadding(new java.awt.Insets(3, 5, 5, 5));
            xButton2.setAlt('v');
            xButton2.setOnclick("showTxnLog");
            xButton2.setText("View Transaction Log");
            xPanel5.add(xButton2);

            xPanel2.add(xPanel5, java.awt.BorderLayout.SOUTH);

            add(xPanel2, java.awt.BorderLayout.CENTER);

        }// </editor-fold>//GEN-END:initComponents
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private com.rameses.osiris.client.component.XButton xButton1;
    private com.rameses.osiris.client.component.XButton xButton2;
    private com.rameses.osiris.client.component.XCombo xCombo1;
    private com.rameses.osiris.client.component.XLabel xLabel1;
    private com.rameses.osiris.client.component.XLabel xLabel2;
    private com.rameses.osiris.client.component.XLabel xLabel3;
    private com.rameses.osiris.client.component.XLabel xLabel4;
    private com.rameses.osiris.client.component.XLabel xLabel5;
    private com.rameses.osiris.client.component.XLabel xLabel6;
    private com.rameses.osiris.client.component.XLabel xLabel7;
    private com.rameses.osiris.client.component.XPanel xPanel1;
    private com.rameses.osiris.client.component.XPanel xPanel2;
    private com.rameses.osiris.client.component.XPanel xPanel3;
    private com.rameses.osiris.client.component.XPanel xPanel4;
    private com.rameses.osiris.client.component.XPanel xPanel5;
    private com.rameses.osiris.client.component.XTable xTable1;
    private com.rameses.osiris.client.component.XTextField xTextField1;
    private com.rameses.osiris.client.component.XTextField xTextField2;
    private com.rameses.osiris.client.component.XTextField xTextField3;
    private com.rameses.osiris.client.component.XTextField xTextField4;
    // End of variables declaration//GEN-END:variables
    
}
