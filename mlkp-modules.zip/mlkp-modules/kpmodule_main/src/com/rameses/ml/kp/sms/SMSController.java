package com.rameses.ml.kp.sms;

import com.rameses.osiris.client.AbstractFormController;
import java.awt.Dimension;
import java.io.InputStream;

public class SMSController extends AbstractFormController
{
    
    public SMSController() 
    {
        addPage("buildContactOption", SMSBuildContactOption.class);
    }

    protected Class getDefaultPageClass() { return SMSPage.class; }

    protected InputStream getCodeBaseAsStream() { 
        return getClass().getResourceAsStream("SMSController.xml");
    }

    public String getPreferredID() { return "sms.frm"; }

    public String getTitle() { return "SMS"; }
    
    public Dimension getPreferredSize() {
        return new Dimension(572, 431);
    }

}
