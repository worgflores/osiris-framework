package com.rameses.ml.kp.sms;

import com.rameses.osiris.client.component.ComboEntry;

public class SMSBuildContactOption extends com.rameses.osiris.client.Page
{
    
    public SMSBuildContactOption()
{
        initComponents();
    }
    
    // <editor-fold defaultstate="collapsed" desc=" Generated Code ">//GEN-BEGIN:initComponents
    private void initComponents() {
        xLabel1 = new com.rameses.osiris.client.component.XLabel();
        xPanel1 = new com.rameses.osiris.client.component.XPanel();
        xGlue1 = new com.rameses.osiris.client.component.spacer.XGlue();
        xButton2 = new com.rameses.osiris.client.component.XButton();
        xStrut2 = new com.rameses.osiris.client.component.spacer.XStrut();
        xButton1 = new com.rameses.osiris.client.component.XButton();
        xStrut1 = new com.rameses.osiris.client.component.spacer.XStrut();
        xButton3 = new com.rameses.osiris.client.component.XButton();
        xPanel2 = new com.rameses.osiris.client.component.XPanel();
        xLabel2 = new com.rameses.osiris.client.component.XLabel();
        xLabel3 = new com.rameses.osiris.client.component.XLabel();
        xCombo1 = new com.rameses.osiris.client.component.XCombo();
        xTextField1 = new com.rameses.osiris.client.component.XTextField();
        xLabel4 = new com.rameses.osiris.client.component.XLabel();
        xLabel5 = new com.rameses.osiris.client.component.XLabel();
        xLabel6 = new com.rameses.osiris.client.component.XLabel();
        xTextField2 = new com.rameses.osiris.client.component.XTextField();

        setLayout(new java.awt.BorderLayout());

        setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        setOpaque(false);
        setPreferredSize(new java.awt.Dimension(572, 401));
        xLabel1.setBackground(new java.awt.Color(0, 0, 153));
        xLabel1.setForeground(new java.awt.Color(255, 255, 255));
        xLabel1.setOpaque(true);
        xLabel1.setPadding(new java.awt.Insets(10, 10, 10, 10));
        xLabel1.setText("<html><font size=\"5\">Build Contacts</font></html>");
        add(xLabel1, java.awt.BorderLayout.NORTH);

        xPanel1.setLayout(new javax.swing.BoxLayout(xPanel1, javax.swing.BoxLayout.X_AXIS));

        xPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        xPanel1.setOpaque(true);
        xPanel1.setPadding(new java.awt.Insets(10, 10, 10, 10));
        xPanel1.add(xGlue1);

        xButton2.setAlt('b');
        xButton2.setDefaultFocusInWindow(true);
        xButton2.setOnclick("gotoPage('default')");
        xButton2.setText("  Back  ");
        xPanel1.add(xButton2);

        xStrut2.setLength(5);
        xPanel1.add(xStrut2);

        xButton1.setAlt('u');
        xButton1.setDefaultFocusInWindow(true);
        xButton1.setOnclick("doBuild");
        xButton1.setText("  Build  ");
        xPanel1.add(xButton1);

        xPanel1.add(xStrut1);

        xButton3.setAlt('c');
        xButton3.setOnclick("doClose");
        xButton3.setText("Cancel");
        xPanel1.add(xButton3);

        add(xPanel1, java.awt.BorderLayout.SOUTH);

        xPanel2.setLayout(null);

        xPanel2.setBackground(new java.awt.Color(255, 255, 255));
        xPanel2.setOpaque(true);
        xLabel2.setFont(new java.awt.Font("Tahoma", 1, 11));
        xLabel2.setText("Please provide the needed parameter(s)");
        xPanel2.add(xLabel2);
        xLabel2.setBounds(27, 21, 276, 24);

        xLabel3.setText("Date :");
        xPanel2.add(xLabel3);
        xLabel3.setBounds(51, 105, 48, 14);

        xCombo1.setModelName("contact");
        xCombo1.setEntries(new ComboEntry[]
            {
                new ComboEntry("01", "January"),
                new ComboEntry("02", "February"),
                new ComboEntry("03", "March"),
                new ComboEntry("04", "April"),
                new ComboEntry("05", "May"),
                new ComboEntry("06", "June"),
                new ComboEntry("07", "July"),
                new ComboEntry("08", "August"),
                new ComboEntry("09", "September"),
                new ComboEntry("10", "October"),
                new ComboEntry("11", "November"),
                new ComboEntry("12", "December")
            });
            xCombo1.setName("month");
            xPanel2.add(xCombo1);
            xCombo1.setBounds(135, 102, 132, 22);

            xTextField1.setModelName("contact");
            xTextField1.setName("year");
            xTextField1.setTextcase("none");
            xPanel2.add(xTextField1);
            xTextField1.setBounds(270, 102, 60, 21);

            xLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
            xLabel4.setFont(new java.awt.Font("Tahoma", 3, 11));
            xLabel4.setForeground(new java.awt.Color(153, 51, 0));
            xLabel4.setText("<html><b>( Month )</b></html>");
            xPanel2.add(xLabel4);
            xLabel4.setBounds(138, 129, 126, 13);

            xLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
            xLabel5.setFont(new java.awt.Font("Tahoma", 3, 11));
            xLabel5.setForeground(new java.awt.Color(153, 51, 0));
            xLabel5.setText("<html><b>( Year )</b></html>");
            xPanel2.add(xLabel5);
            xLabel5.setBounds(273, 129, 57, 13);

            xLabel6.setText("Table Name :");
            xPanel2.add(xLabel6);
            xLabel6.setBounds(51, 72, 72, 14);

            xTextField2.setDefaultFocus(true);
            xTextField2.setModelName("contact");
            xTextField2.setName("tablename");
            xTextField2.setTextcase("lower");
            xPanel2.add(xTextField2);
            xTextField2.setBounds(135, 69, 210, 21);

            add(xPanel2, java.awt.BorderLayout.CENTER);

        }// </editor-fold>//GEN-END:initComponents
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private com.rameses.osiris.client.component.XButton xButton1;
    private com.rameses.osiris.client.component.XButton xButton2;
    private com.rameses.osiris.client.component.XButton xButton3;
    private com.rameses.osiris.client.component.XCombo xCombo1;
    private com.rameses.osiris.client.component.spacer.XGlue xGlue1;
    private com.rameses.osiris.client.component.XLabel xLabel1;
    private com.rameses.osiris.client.component.XLabel xLabel2;
    private com.rameses.osiris.client.component.XLabel xLabel3;
    private com.rameses.osiris.client.component.XLabel xLabel4;
    private com.rameses.osiris.client.component.XLabel xLabel5;
    private com.rameses.osiris.client.component.XLabel xLabel6;
    private com.rameses.osiris.client.component.XPanel xPanel1;
    private com.rameses.osiris.client.component.XPanel xPanel2;
    private com.rameses.osiris.client.component.spacer.XStrut xStrut1;
    private com.rameses.osiris.client.component.spacer.XStrut xStrut2;
    private com.rameses.osiris.client.component.XTextField xTextField1;
    private com.rameses.osiris.client.component.XTextField xTextField2;
    // End of variables declaration//GEN-END:variables
    
}
