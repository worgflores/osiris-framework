package com.rameses.ml.chinatrust;

import com.rameses.osiris.client.AbstractFormController;
import java.awt.Dimension;
import java.io.InputStream;

public class CashCardController extends AbstractFormController
{
    
    public CashCardController() 
    {
    }

    protected Class getDefaultPageClass() { return CashCardPage.class; }

    protected InputStream getCodeBaseAsStream() 
    {
        Class clz = CashCardController.class;
        return clz.getResourceAsStream(clz.getSimpleName() + ".xml");
    }

    public String getPreferredID() { return "partnerfund.frm"; }

    public Dimension getPreferredSize() {
        return new Dimension(483, 373);
    }
    
}
