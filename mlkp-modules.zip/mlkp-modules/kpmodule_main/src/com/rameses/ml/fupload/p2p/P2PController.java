package com.rameses.ml.fupload.p2p;

import com.rameses.osiris.client.AbstractFormController;

public class P2PController //extends AbstractFormController
{
    
    public P2PController() {
    }
    
}
