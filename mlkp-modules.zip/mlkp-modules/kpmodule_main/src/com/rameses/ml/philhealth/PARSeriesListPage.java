package com.rameses.ml.philhealth;

import com.rameses.osiris.client.Page;

public class PARSeriesListPage extends Page 
{
    
    public PARSeriesListPage() {
        initComponents();
    }
    
    // <editor-fold defaultstate="collapsed" desc=" Generated Code ">//GEN-BEGIN:initComponents
    private void initComponents() {
        xPanel1 = new com.rameses.osiris.client.component.XPanel();
        xTitleHeader1 = new com.rameses.osiris.client.component.template.XTitleHeader();
        xPanel2 = new com.rameses.osiris.client.component.XPanel();
        xLabel1 = new com.rameses.osiris.client.component.XLabel();
        xPanel3 = new com.rameses.osiris.client.component.XPanel();
        xPanel6 = new com.rameses.osiris.client.component.XPanel();
        xButton5 = new com.rameses.osiris.client.component.XButton();
        xButton6 = new com.rameses.osiris.client.component.XButton();
        xTextField1 = new com.rameses.osiris.client.component.XTextField();
        xTable1 = new com.rameses.osiris.client.component.XTable();
        xPanel5 = new com.rameses.osiris.client.component.XPanel();
        xButton2 = new com.rameses.osiris.client.component.XButton();
        xButton3 = new com.rameses.osiris.client.component.XButton();
        xButton4 = new com.rameses.osiris.client.component.XButton();

        setLayout(new java.awt.BorderLayout());

        setBackground(new java.awt.Color(255, 255, 255));
        xPanel1.setLayout(new java.awt.BorderLayout());

        xPanel1.setPreferredSize(new java.awt.Dimension(487, 125));
        xTitleHeader1.setText("Manage PAR Series");
        xPanel1.add(xTitleHeader1, java.awt.BorderLayout.NORTH);

        xPanel2.setLayout(new java.awt.BorderLayout());

        xPanel2.setBackground(new java.awt.Color(219, 229, 255));
        xPanel2.setOpaque(true);
        xPanel2.setPreferredSize(new java.awt.Dimension(413, 89));
        xLabel1.setForeground(new java.awt.Color(9, 45, 117));
        xLabel1.setPadding(new java.awt.Insets(10, 10, 10, 10));
        xLabel1.setPreferredSize(new java.awt.Dimension(487, 48));
        xLabel1.setText("<html>To view the detail information of an item, just select the item and press <b>Ctrl-Enter</b>. <br>Or simply by double-clicking an item.</html>");
        xPanel2.add(xLabel1, java.awt.BorderLayout.NORTH);

        xPanel3.setLayout(new java.awt.BorderLayout());

        xPanel3.setPreferredSize(new java.awt.Dimension(100, 40));
        xPanel6.setLayout(null);

        xPanel6.setPreferredSize(new java.awt.Dimension(180, 50));
        xButton5.setAlt('n');
        xButton5.setOnclick("doCreate");
        xButton5.setText("New");
        xPanel6.add(xButton5);
        xButton5.setBounds(9, 9, 69, 23);

        xButton6.setAlt('v');
        xButton6.setOnclick("doView");
        xButton6.setText("View");
        xPanel6.add(xButton6);
        xButton6.setBounds(80, 9, 72, 23);

        xTextField1.setName("dummy");
        xPanel6.add(xTextField1);
        xTextField1.setBounds(-10, -10, 10, 10);

        xPanel3.add(xPanel6, java.awt.BorderLayout.WEST);

        xPanel2.add(xPanel3, java.awt.BorderLayout.SOUTH);

        xPanel1.add(xPanel2, java.awt.BorderLayout.SOUTH);

        add(xPanel1, java.awt.BorderLayout.NORTH);

        xTable1.setAutoresize(false);
        xTable1.setColumnAsXml("<column name=\"dtfiled\" caption=\"Date Filed\" width=\"120\"/>\n<column name=\"strprefix\" caption=\"Prefix\" width=\"80\"/>\n<column name=\"intstartseries\" caption=\"Start Series\" width=\"120\"/>\n<column name=\"intendseries\" caption=\"End Series\" width=\"120\"/>\n<column name=\"intnextseries\" caption=\"Next Series\" width=\"120\"/>\n\n\n");
        xTable1.setModelName("list");
        add(xTable1, java.awt.BorderLayout.CENTER);

        xPanel5.setLayout(null);

        xPanel5.setOpaque(true);
        xPanel5.setPreferredSize(new java.awt.Dimension(100, 50));
        xButton2.setAlt('1');
        xButton2.setOnclick("doNavFirst");
        xButton2.setText("1-First");
        xPanel5.add(xButton2);
        xButton2.setBounds(9, 12, 66, 23);

        xButton3.setAlt('2');
        xButton3.setOnclick("doNavPrev");
        xButton3.setText("2-Previous");
        xPanel5.add(xButton3);
        xButton3.setBounds(78, 12, 83, 23);

        xButton4.setAlt('3');
        xButton4.setOnclick("doNavNext");
        xButton4.setText("3-Next");
        xPanel5.add(xButton4);
        xButton4.setBounds(165, 12, 72, 23);

        add(xPanel5, java.awt.BorderLayout.SOUTH);

    }// </editor-fold>//GEN-END:initComponents
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private com.rameses.osiris.client.component.XButton xButton2;
    private com.rameses.osiris.client.component.XButton xButton3;
    private com.rameses.osiris.client.component.XButton xButton4;
    private com.rameses.osiris.client.component.XButton xButton5;
    private com.rameses.osiris.client.component.XButton xButton6;
    private com.rameses.osiris.client.component.XLabel xLabel1;
    private com.rameses.osiris.client.component.XPanel xPanel1;
    private com.rameses.osiris.client.component.XPanel xPanel2;
    private com.rameses.osiris.client.component.XPanel xPanel3;
    private com.rameses.osiris.client.component.XPanel xPanel5;
    private com.rameses.osiris.client.component.XPanel xPanel6;
    private com.rameses.osiris.client.component.XTable xTable1;
    private com.rameses.osiris.client.component.XTextField xTextField1;
    private com.rameses.osiris.client.component.template.XTitleHeader xTitleHeader1;
    // End of variables declaration//GEN-END:variables
    
}
