package com.rameses.ml.philhealth;

import com.rameses.osiris.client.AbstractFormController;
import java.awt.Dimension;
import java.io.InputStream;

public class AdminDailyReportController extends AbstractFormController
{
    
    public AdminDailyReportController() 
    {
        addPage("preview", AdminDailyReportPreviewPage.class);
    }

    protected Class getDefaultPageClass() {
        return AdminDailyReportPage.class;
    }

    protected InputStream getCodeBaseAsStream() 
    {
        Class clazz = getClass();
        return clazz.getResourceAsStream(clazz.getSimpleName() + ".jc");
    }

    public String getPreferredID() { return "philhealthadminreport.frm"; }

    public String getTitle() { return "Philhealth Daily Report"; }

    public boolean isCacheable() { return false; }

    public boolean isResizable() { return true; }
    
    public Dimension getPreferredSize() {
        return new Dimension(761, 516);
    }
    
}
