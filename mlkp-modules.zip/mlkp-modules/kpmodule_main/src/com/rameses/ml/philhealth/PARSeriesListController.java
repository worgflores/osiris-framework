package com.rameses.ml.philhealth;

import com.rameses.osiris.client.AbstractFormController;
import java.awt.Dimension;
import java.io.InputStream;

public class PARSeriesListController extends AbstractFormController
{
    
    public PARSeriesListController() 
    {
    }

    protected Class getDefaultPageClass() {
        return PARSeriesListPage.class;
    }

    protected InputStream getCodeBaseAsStream() 
    {
        Class clazz = getClass();
        return clazz.getResourceAsStream(clazz.getSimpleName() + ".jc");
    }

    public String getPreferredID() { return "philhealthparserieslist.frm"; }

    public String getTitle() { return "Philhealth PAR Series"; }

    public boolean isCacheable() { return false; }

    public boolean isResizable() { return true; }
    
    public Dimension getPreferredSize() {
        return new Dimension(761, 516);
    }
    
}
