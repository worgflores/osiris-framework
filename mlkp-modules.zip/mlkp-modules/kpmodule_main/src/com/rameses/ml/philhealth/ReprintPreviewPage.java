package com.rameses.ml.philhealth;

public class ReprintPreviewPage extends com.rameses.osiris.client.Page
{
    
    public ReprintPreviewPage()
{
        initComponents();
    }
    
    // <editor-fold defaultstate="collapsed" desc=" Generated Code ">//GEN-BEGIN:initComponents
    private void initComponents() {
        xTitleHeader1 = new com.rameses.osiris.client.component.template.XTitleHeader();
        xPanel1 = new com.rameses.osiris.client.component.XPanel();
        xGlue1 = new com.rameses.osiris.client.component.spacer.XGlue();
        xButton3 = new com.rameses.osiris.client.component.XButton();
        xStrut2 = new com.rameses.osiris.client.component.spacer.XStrut();
        xButton1 = new com.rameses.osiris.client.component.XButton();
        xStrut1 = new com.rameses.osiris.client.component.spacer.XStrut();
        xButton2 = new com.rameses.osiris.client.component.XButton();
        xPanel2 = new com.rameses.osiris.client.component.XPanel();
        xTextField1 = new com.rameses.osiris.client.component.XTextField();
        xLabelPrint1 = new com.rameses.osiris.client.component.XLabelPrint();
        xLabelPrint3 = new com.rameses.osiris.client.component.XLabelPrint();
        xLabelPrint4 = new com.rameses.osiris.client.component.XLabelPrint();
        xLabelPrint5 = new com.rameses.osiris.client.component.XLabelPrint();
        xLabelPrint6 = new com.rameses.osiris.client.component.XLabelPrint();
        xLabelPrint7 = new com.rameses.osiris.client.component.XLabelPrint();
        xLabelPrint8 = new com.rameses.osiris.client.component.XLabelPrint();
        xLabelPrint9 = new com.rameses.osiris.client.component.XLabelPrint();
        xLabelPrint10 = new com.rameses.osiris.client.component.XLabelPrint();
        xLabelPrint11 = new com.rameses.osiris.client.component.XLabelPrint();
        xLabelPrint12 = new com.rameses.osiris.client.component.XLabelPrint();
        xLabelPrint13 = new com.rameses.osiris.client.component.XLabelPrint();
        xLabelPrint14 = new com.rameses.osiris.client.component.XLabelPrint();
        xLabelPrint15 = new com.rameses.osiris.client.component.XLabelPrint();
        xLabelPrint16 = new com.rameses.osiris.client.component.XLabelPrint();
        xLabelPrint18 = new com.rameses.osiris.client.component.XLabelPrint();
        xLabelPrint19 = new com.rameses.osiris.client.component.XLabelPrint();
        xLabelPrint20 = new com.rameses.osiris.client.component.XLabelPrint();
        xLabelPrint21 = new com.rameses.osiris.client.component.XLabelPrint();
        xLabelPrint22 = new com.rameses.osiris.client.component.XLabelPrint();

        setLayout(new java.awt.BorderLayout());

        setBackground(new java.awt.Color(255, 255, 255));
        setPreferredSize(new java.awt.Dimension(584, 479));
        xTitleHeader1.setText("Philhealth Reprint Transaction");
        add(xTitleHeader1, java.awt.BorderLayout.NORTH);

        xPanel1.setLayout(new javax.swing.BoxLayout(xPanel1, javax.swing.BoxLayout.X_AXIS));

        xPanel1.setOpaque(true);
        xPanel1.setPadding(new java.awt.Insets(7, 7, 7, 10));
        xPanel1.add(xGlue1);

        xButton3.setIconResource("shared/images/16/back.png");
        xButton3.setAlt('b');
        xButton3.setOnclick("gotoPage('default')");
        xButton3.setText("Back");
        xPanel1.add(xButton3);

        xStrut2.setLength(5);
        xPanel1.add(xStrut2);

        xButton1.setIconResource("shared/images/16/document.png");
        xButton1.setAlt('p');
        xButton1.setOnclick("doPrint");
        xButton1.setText("Print");
        xPanel1.add(xButton1);

        xStrut1.setLength(5);
        xPanel1.add(xStrut1);

        xButton2.setIconResource("shared/images/16/close.png");
        xButton2.setAlt('c');
        xButton2.setOnclick("doClose");
        xButton2.setText("Cancel");
        xPanel1.add(xButton2);

        add(xPanel1, java.awt.BorderLayout.SOUTH);

        xPanel2.setLayout(null);

        xTextField1.setName("dummy");
        xPanel2.add(xTextField1);
        xTextField1.setBounds(-10, -10, 10, 10);

        xLabelPrint1.setFont(new java.awt.Font("courier,plain,11", 1, 15));
        xLabelPrint1.setText("{payment.par_no}");
        xPanel2.add(xLabelPrint1);
        xLabelPrint1.setBounds(305, 90, 141, 20);

        xLabelPrint3.setFont(new java.awt.Font("Dialog", 0, 11));
        xLabelPrint3.setText("PIN/PEN :");
        xPanel2.add(xLabelPrint3);
        xLabelPrint3.setBounds(51, 123, 100, 20);

        xLabelPrint4.setFont(new java.awt.Font("Dialog", 0, 11));
        xLabelPrint4.setText("Member Name :");
        xPanel2.add(xLabelPrint4);
        xLabelPrint4.setBounds(51, 140, 100, 20);

        xLabelPrint5.setFont(new java.awt.Font("Dialog", 0, 11));
        xLabelPrint5.setText("Member Type :");
        xPanel2.add(xLabelPrint5);
        xLabelPrint5.setBounds(51, 157, 100, 20);

        xLabelPrint6.setFont(new java.awt.Font("Dialog", 0, 11));
        xLabelPrint6.setText("Applicable Period :");
        xPanel2.add(xLabelPrint6);
        xLabelPrint6.setBounds(51, 174, 100, 20);

        xLabelPrint7.setFont(new java.awt.Font("Dialog", 0, 11));
        xLabelPrint7.setText("Amount :");
        xPanel2.add(xLabelPrint7);
        xLabelPrint7.setBounds(51, 192, 100, 20);

        xLabelPrint8.setFont(new java.awt.Font("Dialog", 0, 11));
        xLabelPrint8.setText("Validation Date :");
        xPanel2.add(xLabelPrint8);
        xLabelPrint8.setBounds(51, 210, 100, 20);

        xLabelPrint9.setFont(new java.awt.Font("Dialog", 0, 11));
        xLabelPrint9.setText("Remarks :");
        xPanel2.add(xLabelPrint9);
        xLabelPrint9.setBounds(51, 228, 100, 20);

        xLabelPrint10.setFont(new java.awt.Font("Dialog", 0, 11));
        xLabelPrint10.setText("{payment.memberid}");
        xPanel2.add(xLabelPrint10);
        xLabelPrint10.setBounds(150, 123, 400, 20);

        xLabelPrint11.setFont(new java.awt.Font("Dialog", 0, 11));
        xLabelPrint11.setText("{payment.membername}");
        xPanel2.add(xLabelPrint11);
        xLabelPrint11.setBounds(150, 140, 400, 20);

        xLabelPrint12.setFont(new java.awt.Font("Dialog", 0, 11));
        xLabelPrint12.setText("{payment.membertype}");
        xPanel2.add(xLabelPrint12);
        xLabelPrint12.setBounds(150, 157, 400, 20);

        xLabelPrint13.setFont(new java.awt.Font("Dialog", 0, 11));
        xLabelPrint13.setText("{payment.applicableperiod}");
        xPanel2.add(xLabelPrint13);
        xLabelPrint13.setBounds(150, 174, 400, 20);

        xLabelPrint14.setFont(new java.awt.Font("Dialog", 0, 11));
        xLabelPrint14.setText("{payment.amount}");
        xPanel2.add(xLabelPrint14);
        xLabelPrint14.setBounds(150, 192, 400, 20);

        xLabelPrint15.setFont(new java.awt.Font("Dialog", 0, 11));
        xLabelPrint15.setText("{payment.fmtdtpaid}");
        xPanel2.add(xLabelPrint15);
        xLabelPrint15.setBounds(150, 210, 400, 20);

        xLabelPrint16.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        xLabelPrint16.setFont(new java.awt.Font("Dialog", 0, 11));
        xLabelPrint16.setText("<p>{payment.details}</p>");
        xPanel2.add(xLabelPrint16);
        xLabelPrint16.setBounds(150, 230, 400, 50);

        xLabelPrint18.setFont(new java.awt.Font("Dialog", 0, 11));
        xLabelPrint18.setText("____________________");
        xPanel2.add(xLabelPrint18);
        xLabelPrint18.setBounds(50, 282, 130, 15);

        xLabelPrint19.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        xLabelPrint19.setFont(new java.awt.Font("Dialog", 0, 14));
        xLabelPrint19.setText("<b>PHILHEALTH AGENT'S RECEIPT (REPRINT)</b>");
        xPanel2.add(xLabelPrint19);
        xLabelPrint19.setBounds(48, 50, 375, 20);

        xLabelPrint20.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        xLabelPrint20.setFont(new java.awt.Font("Dialog", 0, 11));
        xLabelPrint20.setText("Customer's Signature");
        xPanel2.add(xLabelPrint20);
        xLabelPrint20.setBounds(50, 296, 116, 18);

        xLabelPrint21.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        xLabelPrint21.setFont(new java.awt.Font("Dialog", 0, 11));
        xLabelPrint21.setText("____________________");
        xPanel2.add(xLabelPrint21);
        xLabelPrint21.setBounds(286, 282, 136, 15);

        xLabelPrint22.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        xLabelPrint22.setFont(new java.awt.Font("Dialog", 0, 11));
        xLabelPrint22.setText("Operator's Signature");
        xPanel2.add(xLabelPrint22);
        xLabelPrint22.setBounds(302, 296, 120, 18);

        add(xPanel2, java.awt.BorderLayout.CENTER);

    }// </editor-fold>//GEN-END:initComponents
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private com.rameses.osiris.client.component.XButton xButton1;
    private com.rameses.osiris.client.component.XButton xButton2;
    private com.rameses.osiris.client.component.XButton xButton3;
    private com.rameses.osiris.client.component.spacer.XGlue xGlue1;
    private com.rameses.osiris.client.component.XLabelPrint xLabelPrint1;
    private com.rameses.osiris.client.component.XLabelPrint xLabelPrint10;
    private com.rameses.osiris.client.component.XLabelPrint xLabelPrint11;
    private com.rameses.osiris.client.component.XLabelPrint xLabelPrint12;
    private com.rameses.osiris.client.component.XLabelPrint xLabelPrint13;
    private com.rameses.osiris.client.component.XLabelPrint xLabelPrint14;
    private com.rameses.osiris.client.component.XLabelPrint xLabelPrint15;
    private com.rameses.osiris.client.component.XLabelPrint xLabelPrint16;
    private com.rameses.osiris.client.component.XLabelPrint xLabelPrint18;
    private com.rameses.osiris.client.component.XLabelPrint xLabelPrint19;
    private com.rameses.osiris.client.component.XLabelPrint xLabelPrint20;
    private com.rameses.osiris.client.component.XLabelPrint xLabelPrint21;
    private com.rameses.osiris.client.component.XLabelPrint xLabelPrint22;
    private com.rameses.osiris.client.component.XLabelPrint xLabelPrint3;
    private com.rameses.osiris.client.component.XLabelPrint xLabelPrint4;
    private com.rameses.osiris.client.component.XLabelPrint xLabelPrint5;
    private com.rameses.osiris.client.component.XLabelPrint xLabelPrint6;
    private com.rameses.osiris.client.component.XLabelPrint xLabelPrint7;
    private com.rameses.osiris.client.component.XLabelPrint xLabelPrint8;
    private com.rameses.osiris.client.component.XLabelPrint xLabelPrint9;
    private com.rameses.osiris.client.component.XPanel xPanel1;
    private com.rameses.osiris.client.component.XPanel xPanel2;
    private com.rameses.osiris.client.component.spacer.XStrut xStrut1;
    private com.rameses.osiris.client.component.spacer.XStrut xStrut2;
    private com.rameses.osiris.client.component.XTextField xTextField1;
    private com.rameses.osiris.client.component.template.XTitleHeader xTitleHeader1;
    // End of variables declaration//GEN-END:variables
    
}
