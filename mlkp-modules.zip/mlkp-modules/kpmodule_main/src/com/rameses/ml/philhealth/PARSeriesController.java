package com.rameses.ml.philhealth;

import com.rameses.osiris.client.AbstractFormController;
import java.awt.Dimension;
import java.io.InputStream;

public class PARSeriesController extends AbstractFormController
{
    
    public PARSeriesController() {
        addPage("readonly", PARSeriesReadonlyPage.class);
    }

    protected Class getDefaultPageClass() {
        return PARSeriesPage.class;
    }

    protected InputStream getCodeBaseAsStream() 
    {
        Class clz = PARSeriesController.class;
        return clz.getResourceAsStream(clz.getSimpleName() + ".jc");
    }

    public String getPreferredID() { return "philhealthparseries.frm"; }

    public String getTitle() { return "Philhealth PAR Series"; }

    public boolean isCacheable() { return false; }

    public boolean isResizable() { return true; }
    
    public Dimension getPreferredSize() {
        return new Dimension(483, 373);
    }
    
}
