package com.rameses.ml.philhealth;

import com.rameses.osiris.client.AbstractFormController;
import java.awt.Dimension;
import java.io.InputStream;

public class ReprintController extends AbstractFormController
{
    
    public ReprintController() 
    {
        addPage("printPage", ReprintPreviewPage.class);
    } 

    protected Class getDefaultPageClass() { 
        return ReprintMainPage.class;
    }

    protected InputStream getCodeBaseAsStream() 
    {
        Class clazz = getClass();
        return clazz.getResourceAsStream(clazz.getSimpleName() + ".jc");
    }

    public String getPreferredID() { return "philhealthreprint.frm"; }

    public String getTitle() { return "Philhealth Reprint"; }

    public boolean isCacheable() { return false; }

    public Dimension getPreferredSize() {
        return new Dimension(584, 479);
    }
    
}
