package com.rameses.ml.philhealth;

import com.rameses.osiris.client.Page;

public class PARSeriesReadonlyPage extends Page 
{
    
    public PARSeriesReadonlyPage() {
        initComponents();
    }
    
    // <editor-fold defaultstate="collapsed" desc=" Generated Code ">//GEN-BEGIN:initComponents
    private void initComponents() {
        xPanel1 = new com.rameses.osiris.client.component.XPanel();
        xLabel1 = new com.rameses.osiris.client.component.XLabel();
        xTextField1 = new com.rameses.osiris.client.component.XTextField();
        xLabel2 = new com.rameses.osiris.client.component.XLabel();
        xTextField2 = new com.rameses.osiris.client.component.XTextField();
        xLabel3 = new com.rameses.osiris.client.component.XLabel();
        xTextField3 = new com.rameses.osiris.client.component.XTextField();
        xTextField4 = new com.rameses.osiris.client.component.XTextField();
        xLabel4 = new com.rameses.osiris.client.component.XLabel();
        xTextField5 = new com.rameses.osiris.client.component.XTextField();
        xLabel5 = new com.rameses.osiris.client.component.XLabel();
        xTextField6 = new com.rameses.osiris.client.component.XTextField();
        xTextField7 = new com.rameses.osiris.client.component.XTextField();
        xPanel2 = new com.rameses.osiris.client.component.XPanel();
        xGlue1 = new com.rameses.osiris.client.component.spacer.XGlue();
        xStrut1 = new com.rameses.osiris.client.component.spacer.XStrut();
        xButton3 = new com.rameses.osiris.client.component.XButton();
        xTitleHeader1 = new com.rameses.osiris.client.component.template.XTitleHeader();

        setLayout(new java.awt.BorderLayout());

        setBackground(new java.awt.Color(255, 255, 255));
        setPreferredSize(new java.awt.Dimension(483, 373));
        xPanel1.setLayout(null);

        xLabel1.setText("Prefix :");
        xPanel1.add(xLabel1);
        xLabel1.setBounds(33, 57, 84, 14);

        xTextField1.setEnabled(false);
        xTextField1.setFont(new java.awt.Font("Tahoma", 0, 13));
        xTextField1.setModelName("data");
        xTextField1.setName("strprefix");
        xPanel1.add(xTextField1);
        xTextField1.setBounds(123, 54, 165, 20);

        xLabel2.setText("End Series : ");
        xPanel1.add(xLabel2);
        xLabel2.setBounds(33, 111, 84, 14);

        xTextField2.setEnabled(false);
        xTextField2.setFont(new java.awt.Font("Courier New", 0, 14));
        xTextField2.setModelName("data");
        xTextField2.setName("intendseries");
        xPanel1.add(xTextField2);
        xTextField2.setBounds(123, 108, 165, 21);

        xLabel3.setText("Start Series :");
        xPanel1.add(xLabel3);
        xLabel3.setBounds(33, 84, 84, 14);

        xTextField3.setEnabled(false);
        xTextField3.setFont(new java.awt.Font("Courier New", 0, 14));
        xTextField3.setModelName("data");
        xTextField3.setName("intstartseries");
        xPanel1.add(xTextField3);
        xTextField3.setBounds(123, 81, 165, 22);

        xTextField4.setName("dummy");
        xTextField4.setPreferredSize(new java.awt.Dimension(10, 10));
        xPanel1.add(xTextField4);
        xTextField4.setBounds(-10, -10, 10, 10);

        xLabel4.setText("Date Filed :");
        xPanel1.add(xLabel4);
        xLabel4.setBounds(33, 30, 84, 14);

        xTextField5.setEnabled(false);
        xTextField5.setFont(new java.awt.Font("Tahoma", 0, 13));
        xTextField5.setModelName("data");
        xTextField5.setName("dtfiled");
        xPanel1.add(xTextField5);
        xTextField5.setBounds(123, 27, 165, 20);

        xLabel5.setText("Next Series :");
        xPanel1.add(xLabel5);
        xLabel5.setBounds(33, 138, 84, 14);

        xTextField6.setEnabled(false);
        xTextField6.setFont(new java.awt.Font("Courier New", 0, 14));
        xTextField6.setModelName("data");
        xTextField6.setName("intnextseries");
        xPanel1.add(xTextField6);
        xTextField6.setBounds(123, 135, 165, 21);

        xTextField7.setName("dummy");
        xPanel1.add(xTextField7);
        xTextField7.setBounds(-10, -10, 10, 10);

        add(xPanel1, java.awt.BorderLayout.CENTER);

        xPanel2.setLayout(new javax.swing.BoxLayout(xPanel2, javax.swing.BoxLayout.X_AXIS));

        xPanel2.setOpaque(true);
        xPanel2.setPadding(new java.awt.Insets(7, 7, 7, 10));
        xPanel2.setPreferredSize(new java.awt.Dimension(100, 50));
        org.jdesktop.layout.GroupLayout xGlue1Layout = new org.jdesktop.layout.GroupLayout(xGlue1);
        xGlue1.setLayout(xGlue1Layout);
        xGlue1Layout.setHorizontalGroup(
            xGlue1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(0, 377, Short.MAX_VALUE)
        );
        xGlue1Layout.setVerticalGroup(
            xGlue1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(0, 0, Short.MAX_VALUE)
        );
        xPanel2.add(xGlue1);

        xStrut1.setLength(10);
        org.jdesktop.layout.GroupLayout xStrut1Layout = new org.jdesktop.layout.GroupLayout(xStrut1);
        xStrut1.setLayout(xStrut1Layout);
        xStrut1Layout.setHorizontalGroup(
            xStrut1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(0, 10, Short.MAX_VALUE)
        );
        xStrut1Layout.setVerticalGroup(
            xStrut1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(0, 36, Short.MAX_VALUE)
        );
        xPanel2.add(xStrut1);

        xButton3.setIconResource("shared/images/16/close.png");
        xButton3.setAlt('c');
        xButton3.setOnclick("close");
        xButton3.setText("Close");
        xPanel2.add(xButton3);

        add(xPanel2, java.awt.BorderLayout.SOUTH);

        xTitleHeader1.setText("PAR Series");
        add(xTitleHeader1, java.awt.BorderLayout.NORTH);

    }// </editor-fold>//GEN-END:initComponents
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private com.rameses.osiris.client.component.XButton xButton3;
    private com.rameses.osiris.client.component.spacer.XGlue xGlue1;
    private com.rameses.osiris.client.component.XLabel xLabel1;
    private com.rameses.osiris.client.component.XLabel xLabel2;
    private com.rameses.osiris.client.component.XLabel xLabel3;
    private com.rameses.osiris.client.component.XLabel xLabel4;
    private com.rameses.osiris.client.component.XLabel xLabel5;
    private com.rameses.osiris.client.component.XPanel xPanel1;
    private com.rameses.osiris.client.component.XPanel xPanel2;
    private com.rameses.osiris.client.component.spacer.XStrut xStrut1;
    private com.rameses.osiris.client.component.XTextField xTextField1;
    private com.rameses.osiris.client.component.XTextField xTextField2;
    private com.rameses.osiris.client.component.XTextField xTextField3;
    private com.rameses.osiris.client.component.XTextField xTextField4;
    private com.rameses.osiris.client.component.XTextField xTextField5;
    private com.rameses.osiris.client.component.XTextField xTextField6;
    private com.rameses.osiris.client.component.XTextField xTextField7;
    private com.rameses.osiris.client.component.template.XTitleHeader xTitleHeader1;
    // End of variables declaration//GEN-END:variables
    
}
