package com.rameses.ml.philhealth;

public class ReprintMainPage extends com.rameses.osiris.client.Page
{
    
    public ReprintMainPage()
{
        initComponents();
    }
    
    // <editor-fold defaultstate="collapsed" desc=" Generated Code ">//GEN-BEGIN:initComponents
    private void initComponents() {
        xTitleHeader1 = new com.rameses.osiris.client.component.template.XTitleHeader();
        xPanel1 = new com.rameses.osiris.client.component.XPanel();
        xGlue1 = new com.rameses.osiris.client.component.spacer.XGlue();
        xButton1 = new com.rameses.osiris.client.component.XButton();
        xStrut1 = new com.rameses.osiris.client.component.spacer.XStrut();
        xButton2 = new com.rameses.osiris.client.component.XButton();
        xPanel2 = new com.rameses.osiris.client.component.XPanel();
        xLabel1 = new com.rameses.osiris.client.component.XLabel();
        xLabel2 = new com.rameses.osiris.client.component.XLabel();
        xTextField1 = new com.rameses.osiris.client.component.XTextField();
        xTextField2 = new com.rameses.osiris.client.component.XTextField();

        setLayout(new java.awt.BorderLayout());

        setBackground(new java.awt.Color(255, 255, 255));
        setPreferredSize(new java.awt.Dimension(584, 479));
        xTitleHeader1.setText("Philhealth Reprint Transaction");
        add(xTitleHeader1, java.awt.BorderLayout.NORTH);

        xPanel1.setLayout(new javax.swing.BoxLayout(xPanel1, javax.swing.BoxLayout.X_AXIS));

        xPanel1.setOpaque(true);
        xPanel1.setPadding(new java.awt.Insets(7, 7, 7, 10));
        xPanel1.add(xGlue1);

        xButton1.setIconResource("shared/images/16/next.png");
        xButton1.setAlt('n');
        xButton1.setDefaultFocusInWindow(true);
        xButton1.setOnclick("doValidateEntry");
        xButton1.setText("Next");
        xPanel1.add(xButton1);

        xStrut1.setLength(5);
        xPanel1.add(xStrut1);

        xButton2.setIconResource("shared/images/16/close.png");
        xButton2.setAlt('c');
        xButton2.setOnclick("doClose");
        xButton2.setText("Cancel");
        xPanel1.add(xButton2);

        add(xPanel1, java.awt.BorderLayout.SOUTH);

        xPanel2.setLayout(null);

        xLabel1.setText("<html>PAR Number <font color=\"red\">* </font>:</html>");
        xPanel2.add(xLabel1);
        xLabel1.setBounds(36, 36, 99, 21);

        xLabel2.setText("<html>Reason <font color=\"red\">* </font>:</html>");
        xPanel2.add(xLabel2);
        xLabel2.setBounds(36, 63, 99, 21);

        xTextField1.setFont(new java.awt.Font("Dialog", 1, 16));
        xTextField1.setForeground(new java.awt.Color(153, 0, 0));
        xTextField1.setName("parno");
        xPanel2.add(xTextField1);
        xTextField1.setBounds(141, 36, 174, 20);

        xTextField2.setName("reason");
        xPanel2.add(xTextField2);
        xTextField2.setBounds(141, 63, 336, 20);

        add(xPanel2, java.awt.BorderLayout.CENTER);

    }// </editor-fold>//GEN-END:initComponents
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private com.rameses.osiris.client.component.XButton xButton1;
    private com.rameses.osiris.client.component.XButton xButton2;
    private com.rameses.osiris.client.component.spacer.XGlue xGlue1;
    private com.rameses.osiris.client.component.XLabel xLabel1;
    private com.rameses.osiris.client.component.XLabel xLabel2;
    private com.rameses.osiris.client.component.XPanel xPanel1;
    private com.rameses.osiris.client.component.XPanel xPanel2;
    private com.rameses.osiris.client.component.spacer.XStrut xStrut1;
    private com.rameses.osiris.client.component.XTextField xTextField1;
    private com.rameses.osiris.client.component.XTextField xTextField2;
    private com.rameses.osiris.client.component.template.XTitleHeader xTitleHeader1;
    // End of variables declaration//GEN-END:variables
    
}
