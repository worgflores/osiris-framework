package com.rameses.ml.cardholder;

import com.rameses.osiris.client.AbstractFormController;
import java.awt.Dimension;
import java.io.InputStream;
import rameses.osiris.common.data.DataUtil;

public class ChangeCardNumberController extends AbstractFormController
{
    
    public ChangeCardNumberController() 
    {
        addPage("detail", DetailPage.class);
    }

    protected Class getDefaultPageClass() { return DefaultPage.class; }

    protected InputStream getCodeBaseAsStream() { 
        return getClass().getResourceAsStream("ChangeCardNumberController.xml");
    }

    public String getPreferredID() { return "changeMLCardNumber.frm"; }

    public String getTitle() { return "Change MLCard Number"; }
    
    public Dimension getPreferredSize() {
        return new Dimension(590, 480);
    }
}
