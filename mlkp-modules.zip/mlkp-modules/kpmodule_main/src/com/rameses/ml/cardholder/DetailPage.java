package com.rameses.ml.cardholder;

import com.rameses.osiris.client.component.ComboEntry;

public class DetailPage extends com.rameses.osiris.client.Page
{
    
    public DetailPage()
{
        initComponents();
    }
    
    // <editor-fold defaultstate="collapsed" desc=" Generated Code ">//GEN-BEGIN:initComponents
    private void initComponents() {
        xLabel1 = new com.rameses.osiris.client.component.XLabel();
        xPanel1 = new com.rameses.osiris.client.component.XPanel();
        xPanel3 = new com.rameses.osiris.client.component.XPanel();
        xLabel2 = new com.rameses.osiris.client.component.XLabel();
        xLabel011 = new com.rameses.osiris.client.component.template.XLabel01();
        xLabel3 = new com.rameses.osiris.client.component.XLabel();
        xLabel12 = new com.rameses.osiris.client.component.template.XLabel01();
        xLabel13 = new com.rameses.osiris.client.component.template.XLabel01();
        xLabel14 = new com.rameses.osiris.client.component.template.XLabel01();
        xLabel4 = new com.rameses.osiris.client.component.XLabel();
        xLabel15 = new com.rameses.osiris.client.component.template.XLabel01();
        xLabel5 = new com.rameses.osiris.client.component.XLabel();
        xLabel16 = new com.rameses.osiris.client.component.template.XLabel01();
        xLabel6 = new com.rameses.osiris.client.component.XLabel();
        xLabel7 = new com.rameses.osiris.client.component.XLabel();
        xLabel8 = new com.rameses.osiris.client.component.XLabel();
        xLabel17 = new com.rameses.osiris.client.component.template.XLabel01();
        xLabel18 = new com.rameses.osiris.client.component.template.XLabel01();
        xLabel9 = new com.rameses.osiris.client.component.XLabel();
        xLabel10 = new com.rameses.osiris.client.component.XLabel();
        xLabel11 = new com.rameses.osiris.client.component.XLabel();
        xLabel19 = new com.rameses.osiris.client.component.XLabel();
        xCombo1 = new com.rameses.osiris.client.component.XCombo();
        xLabel20 = new com.rameses.osiris.client.component.XLabel();
        xLabel21 = new com.rameses.osiris.client.component.template.XLabel01();
        xPanel4 = new com.rameses.osiris.client.component.XPanel();
        xLabel22 = new com.rameses.osiris.client.component.XLabel();
        xTextField1 = new com.rameses.osiris.client.component.XTextField();
        xPanel2 = new com.rameses.osiris.client.component.XPanel();
        xGlue1 = new com.rameses.osiris.client.component.spacer.XGlue();
        xButton3 = new com.rameses.osiris.client.component.XButton();
        xStrut2 = new com.rameses.osiris.client.component.spacer.XStrut();
        xButton1 = new com.rameses.osiris.client.component.XButton();
        xStrut1 = new com.rameses.osiris.client.component.spacer.XStrut();
        xButton2 = new com.rameses.osiris.client.component.XButton();

        setLayout(new java.awt.BorderLayout());

        setBackground(new java.awt.Color(255, 255, 255));
        setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        setPreferredSize(new java.awt.Dimension(590, 468));
        xLabel1.setBackground(new java.awt.Color(0, 0, 153));
        xLabel1.setForeground(new java.awt.Color(255, 255, 255));
        xLabel1.setOpaque(true);
        xLabel1.setPadding(new java.awt.Insets(10, 10, 10, 10));
        xLabel1.setText("<html><font size=\"5\">Change MLCard Number</font></html>");
        add(xLabel1, java.awt.BorderLayout.NORTH);

        xPanel1.setLayout(null);

        xPanel3.setLayout(null);

        xPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(" Customer Information "));
        xLabel2.setText("ML Card No. :");
        xPanel3.add(xLabel2);
        xLabel2.setBounds(27, 33, 75, 18);

        xLabel011.setFont(new java.awt.Font("Courier New", 1, 18));
        xLabel011.setForeground(new java.awt.Color(204, 51, 0));
        xLabel011.setModelName("mlcardholder");
        xLabel011.setName("cardid");
        xLabel011.setText("00-000-000");
        xPanel3.add(xLabel011);
        xLabel011.setBounds(111, 33, 138, 19);

        xLabel3.setText("Name :");
        xPanel3.add(xLabel3);
        xLabel3.setBounds(27, 54, 75, 18);

        xLabel12.setModelName("mlcardholder");
        xLabel12.setName("lastname");
        xLabel12.setText("lastname");
        xPanel3.add(xLabel12);
        xLabel12.setBounds(111, 54, 138, 19);

        xLabel13.setModelName("mlcardholder");
        xLabel13.setName("firstname");
        xLabel13.setText("firstname");
        xPanel3.add(xLabel13);
        xLabel13.setBounds(252, 54, 138, 19);

        xLabel14.setModelName("mlcardholder");
        xLabel14.setName("middlename");
        xLabel14.setText("middlename");
        xPanel3.add(xLabel14);
        xLabel14.setBounds(393, 54, 138, 19);

        xLabel4.setText("Address :");
        xPanel3.add(xLabel4);
        xLabel4.setBounds(27, 105, 75, 18);

        xLabel15.setModelName("mlcardholder");
        xLabel15.setName("fulladdress");
        xLabel15.setText("fulladdress");
        xPanel3.add(xLabel15);
        xLabel15.setBounds(111, 105, 420, 19);

        xLabel5.setText("ID Details :");
        xPanel3.add(xLabel5);
        xLabel5.setBounds(27, 126, 75, 18);

        xLabel16.setModelName("mlcardholder");
        xLabel16.setName("idtype");
        xLabel16.setText("idtype");
        xPanel3.add(xLabel16);
        xLabel16.setBounds(111, 126, 138, 19);

        xLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        xLabel6.setText("( Last Name )");
        xPanel3.add(xLabel6);
        xLabel6.setBounds(111, 72, 138, 21);

        xLabel7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        xLabel7.setText("( First Name )");
        xPanel3.add(xLabel7);
        xLabel7.setBounds(252, 72, 138, 21);

        xLabel8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        xLabel8.setText("( Middle Name )");
        xPanel3.add(xLabel8);
        xLabel8.setBounds(393, 72, 138, 21);

        xLabel17.setModelName("mlcardholder");
        xLabel17.setName("idno");
        xLabel17.setText("idno");
        xPanel3.add(xLabel17);
        xLabel17.setBounds(252, 126, 162, 19);

        xLabel18.setModelName("mlcardholder");
        xLabel18.setName("idexpiry");
        xLabel18.setText("idexpiry");
        xPanel3.add(xLabel18);
        xLabel18.setBounds(417, 126, 114, 19);

        xLabel9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        xLabel9.setText("( Company / ID Type )");
        xPanel3.add(xLabel9);
        xLabel9.setBounds(111, 144, 138, 18);

        xLabel10.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        xLabel10.setText("( ID Number )");
        xPanel3.add(xLabel10);
        xLabel10.setBounds(252, 144, 159, 18);

        xLabel11.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        xLabel11.setText("( Expiry Date )");
        xPanel3.add(xLabel11);
        xLabel11.setBounds(417, 144, 114, 18);

        xLabel19.setText("Civil Status :");
        xPanel3.add(xLabel19);
        xLabel19.setBounds(27, 177, 75, 18);

        xCombo1.setModelName("mlcardholder");
        xCombo1.setEnabled(false);
        xCombo1.setEntries(new ComboEntry[]
            {
                new ComboEntry("MARRIED", "Married", true),
                new ComboEntry("SEPARATED", "Separated"),
                new ComboEntry("SINGLE", "Single"),
                new ComboEntry("WIDOWER", "Widow/er")
            });
            xCombo1.setName("civilstatus");
            xPanel3.add(xCombo1);
            xCombo1.setBounds(111, 177, 138, 22);

            xLabel20.setText("Birth Date :");
            xPanel3.add(xLabel20);
            xLabel20.setBounds(27, 204, 75, 18);

            xLabel21.setModelName("mlcardholder");
            xLabel21.setName("birthdate");
            xLabel21.setText("birthdate");
            xPanel3.add(xLabel21);
            xLabel21.setBounds(111, 204, 138, 19);

            xPanel1.add(xPanel3);
            xPanel3.setBounds(15, 15, 555, 252);

            xPanel4.setLayout(null);

            xPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder(" New Card Number Information "));
            xLabel22.setText("<html>ML Card No. <font color=\"red\">*</font> :</html>");
            xPanel4.add(xLabel22);
            xLabel22.setBounds(27, 36, 117, 18);

            xTextField1.setFont(new java.awt.Font("Courier New", 1, 18));
            xTextField1.setForeground(new java.awt.Color(51, 0, 153));
            xTextField1.setName("newcardid");
            xPanel4.add(xTextField1);
            xTextField1.setBounds(156, 30, 192, 33);

            xPanel1.add(xPanel4);
            xPanel4.setBounds(18, 270, 549, 84);

            add(xPanel1, java.awt.BorderLayout.CENTER);

            xPanel2.setLayout(new javax.swing.BoxLayout(xPanel2, javax.swing.BoxLayout.X_AXIS));

            xPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());
            xPanel2.setOpaque(true);
            xPanel2.setPadding(new java.awt.Insets(7, 5, 5, 10));
            xPanel2.add(xGlue1);

            xButton3.setIconResource("shared/images/16/back.png");
            xButton3.setAlt('b');
            xButton3.setDefaultFocusInWindow(true);
            xButton3.setOnclick("gotoPage('default')");
            xButton3.setText("Back");
            xPanel2.add(xButton3);

            xStrut2.setLength(5);
            xPanel2.add(xStrut2);

            xButton1.setIconResource("shared/images/16/save.png");
            xButton1.setAlt('n');
            xButton1.setDefaultFocusInWindow(true);
            xButton1.setOnclick("doUpdate");
            xButton1.setText("Update");
            xPanel2.add(xButton1);

            xPanel2.add(xStrut1);

            xButton2.setIconResource("shared/images/16/close.png");
            xButton2.setAlt('c');
            xButton2.setOnclick("doClose");
            xButton2.setText("Cancel");
            xPanel2.add(xButton2);

            add(xPanel2, java.awt.BorderLayout.SOUTH);

        }// </editor-fold>//GEN-END:initComponents
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private com.rameses.osiris.client.component.XButton xButton1;
    private com.rameses.osiris.client.component.XButton xButton2;
    private com.rameses.osiris.client.component.XButton xButton3;
    private com.rameses.osiris.client.component.XCombo xCombo1;
    private com.rameses.osiris.client.component.spacer.XGlue xGlue1;
    private com.rameses.osiris.client.component.template.XLabel01 xLabel011;
    private com.rameses.osiris.client.component.XLabel xLabel1;
    private com.rameses.osiris.client.component.XLabel xLabel10;
    private com.rameses.osiris.client.component.XLabel xLabel11;
    private com.rameses.osiris.client.component.template.XLabel01 xLabel12;
    private com.rameses.osiris.client.component.template.XLabel01 xLabel13;
    private com.rameses.osiris.client.component.template.XLabel01 xLabel14;
    private com.rameses.osiris.client.component.template.XLabel01 xLabel15;
    private com.rameses.osiris.client.component.template.XLabel01 xLabel16;
    private com.rameses.osiris.client.component.template.XLabel01 xLabel17;
    private com.rameses.osiris.client.component.template.XLabel01 xLabel18;
    private com.rameses.osiris.client.component.XLabel xLabel19;
    private com.rameses.osiris.client.component.XLabel xLabel2;
    private com.rameses.osiris.client.component.XLabel xLabel20;
    private com.rameses.osiris.client.component.template.XLabel01 xLabel21;
    private com.rameses.osiris.client.component.XLabel xLabel22;
    private com.rameses.osiris.client.component.XLabel xLabel3;
    private com.rameses.osiris.client.component.XLabel xLabel4;
    private com.rameses.osiris.client.component.XLabel xLabel5;
    private com.rameses.osiris.client.component.XLabel xLabel6;
    private com.rameses.osiris.client.component.XLabel xLabel7;
    private com.rameses.osiris.client.component.XLabel xLabel8;
    private com.rameses.osiris.client.component.XLabel xLabel9;
    private com.rameses.osiris.client.component.XPanel xPanel1;
    private com.rameses.osiris.client.component.XPanel xPanel2;
    private com.rameses.osiris.client.component.XPanel xPanel3;
    private com.rameses.osiris.client.component.XPanel xPanel4;
    private com.rameses.osiris.client.component.spacer.XStrut xStrut1;
    private com.rameses.osiris.client.component.spacer.XStrut xStrut2;
    private com.rameses.osiris.client.component.XTextField xTextField1;
    // End of variables declaration//GEN-END:variables
    
}
