package com.rameses.ml.uniteller;

import com.rameses.osiris.client.AbstractFormController;
import java.awt.Dimension;
import java.io.InputStream;

public class DetailReportController extends AbstractFormController
{
    
    public DetailReportController() 
    {
        addPage("preview", DailyReportPreviewPage.class);
    }

    protected Class getDefaultPageClass() {
        return DetailReportControllerPage.class;
    }

    protected InputStream getCodeBaseAsStream() 
    {
        Class clazz = getClass();
        return clazz.getResourceAsStream(clazz.getSimpleName() + ".jc");
    }

    public String getPreferredID() { return "uniteller.detailreport.frm"; }

    public String getTitle() { return "UniTeller Detail Report"; }

    public boolean isCacheable() { return false; }

    public boolean isResizable() { return true; }
    
    public Dimension getPreferredSize() {
        return new Dimension(800, 600);
    }
    
}
