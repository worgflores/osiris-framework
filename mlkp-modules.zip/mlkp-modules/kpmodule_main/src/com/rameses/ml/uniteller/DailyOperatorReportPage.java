package com.rameses.ml.uniteller;

public class DailyOperatorReportPage extends com.rameses.osiris.client.Page
{
    
    public DailyOperatorReportPage()
{
        initComponents();
    }
    
    // <editor-fold defaultstate="collapsed" desc=" Generated Code ">//GEN-BEGIN:initComponents
    private void initComponents() {
        xLabel1 = new com.rameses.osiris.client.component.XLabel();
        xPanel1 = new com.rameses.osiris.client.component.XPanel();
        xLabel2 = new com.rameses.osiris.client.component.XLabel();
        xLabel3 = new com.rameses.osiris.client.component.XLabel();
        xLabel4 = new com.rameses.osiris.client.component.XLabel();
        xTextField1 = new com.rameses.osiris.client.component.XTextField();
        xLabel5 = new com.rameses.osiris.client.component.XLabel();
        xButton1 = new com.rameses.osiris.client.component.XButton();
        xButton2 = new com.rameses.osiris.client.component.XButton();

        setLayout(new java.awt.BorderLayout());

        setBackground(new java.awt.Color(255, 255, 255));
        setPreferredSize(new java.awt.Dimension(761, 516));
        xLabel1.setBackground(new java.awt.Color(111, 104, 104));
        xLabel1.setForeground(new java.awt.Color(255, 255, 255));
        xLabel1.setOpaque(true);
        xLabel1.setPadding(new java.awt.Insets(5, 5, 5, 5));
        xLabel1.setText("<html><b>Copyright 2004. MLhuillier Philippines Inc. All rights reserved. Powered by <font color=\"yellow\"><u>Rameses Systems Inc.</u></font></b></html>");
        add(xLabel1, java.awt.BorderLayout.SOUTH);

        xPanel1.setLayout(null);

        xLabel2.setText("<html><font size=\"5\">UniTeller Daily Operator Report</font></html>");
        xPanel1.add(xLabel2);
        xLabel2.setBounds(18, 18, 272, 33);

        xLabel3.setText("<html>Specify from the provided parameters below to narrow down your search.</html>");
        xPanel1.add(xLabel3);
        xLabel3.setBounds(48, 60, 459, 24);

        xLabel4.setText("<html><b>Date :</b></html>");
        xPanel1.add(xLabel4);
        xLabel4.setBounds(81, 102, 51, 21);

        xTextField1.setFormat("####-##-##");
        xTextField1.setName("txndate");
        xTextField1.setType("mask");
        xPanel1.add(xTextField1);
        xTextField1.setBounds(138, 102, 129, 20);

        xLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        xLabel5.setText("<html>( YYYY-MM-DD )</html>");
        xPanel1.add(xLabel5);
        xLabel5.setBounds(138, 120, 129, 18);

        xButton1.setIconResource("shared/images/16/document.png");
        xButton1.setAlt('v');
        xButton1.setOnclick("doPreview");
        xButton1.setText("Preview");
        xPanel1.add(xButton1);
        xButton1.setBounds(138, 165, 102, 33);

        xButton2.setIconResource("shared/images/16/close.png");
        xButton2.setAlt('c');
        xButton2.setOnclick("doClose");
        xButton2.setText("Cancel");
        xPanel1.add(xButton2);
        xButton2.setBounds(246, 165, 102, 33);

        add(xPanel1, java.awt.BorderLayout.CENTER);

    }// </editor-fold>//GEN-END:initComponents
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private com.rameses.osiris.client.component.XButton xButton1;
    private com.rameses.osiris.client.component.XButton xButton2;
    private com.rameses.osiris.client.component.XLabel xLabel1;
    private com.rameses.osiris.client.component.XLabel xLabel2;
    private com.rameses.osiris.client.component.XLabel xLabel3;
    private com.rameses.osiris.client.component.XLabel xLabel4;
    private com.rameses.osiris.client.component.XLabel xLabel5;
    private com.rameses.osiris.client.component.XPanel xPanel1;
    private com.rameses.osiris.client.component.XTextField xTextField1;
    // End of variables declaration//GEN-END:variables
    
}
