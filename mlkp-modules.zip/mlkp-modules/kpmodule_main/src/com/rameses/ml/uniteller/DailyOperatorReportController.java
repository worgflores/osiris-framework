package com.rameses.ml.uniteller;

import com.rameses.osiris.client.AbstractFormController;
import java.awt.Dimension;
import java.io.InputStream;

public class DailyOperatorReportController extends AbstractFormController
{
    
    public DailyOperatorReportController() 
    {
        addPage("preview", DailyReportPreviewPage.class);
    }

    protected Class getDefaultPageClass() {
        return DailyOperatorReportPage.class;
    }

    protected InputStream getCodeBaseAsStream() 
    {
        Class clazz = getClass();
        return clazz.getResourceAsStream(clazz.getSimpleName() + ".jc");
    }

    public String getPreferredID() { return "uniteller.dailyOperatorReport.frm"; }

    public String getTitle() { return "UniTeller Daily Operator Report"; }

    public boolean isCacheable() { return false; }

    public boolean isResizable() { return true; }
    
    public Dimension getPreferredSize() {
        return new Dimension(800, 600);
    }
    
}
