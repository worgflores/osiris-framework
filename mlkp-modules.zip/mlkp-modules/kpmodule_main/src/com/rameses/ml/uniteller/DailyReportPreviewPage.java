package com.rameses.ml.uniteller;

public class DailyReportPreviewPage extends com.rameses.osiris.client.Page
{
    
    public DailyReportPreviewPage()
{
        initComponents();
    }
    
    // <editor-fold defaultstate="collapsed" desc=" Generated Code ">//GEN-BEGIN:initComponents
    private void initComponents() {
        xLabel1 = new com.rameses.osiris.client.component.XLabel();
        xPanel2 = new com.rameses.osiris.client.component.XPanel();
        xButton1 = new com.rameses.osiris.client.component.XButton();
        xButton2 = new com.rameses.osiris.client.component.XButton();
        xTextField1 = new com.rameses.osiris.client.component.XTextField();
        xTextArea1 = new com.rameses.osiris.client.component.XTextArea();

        setLayout(new java.awt.BorderLayout());

        setBackground(new java.awt.Color(255, 255, 255));
        setPreferredSize(new java.awt.Dimension(645, 467));
        xLabel1.setBackground(new java.awt.Color(111, 104, 104));
        xLabel1.setForeground(new java.awt.Color(255, 255, 255));
        xLabel1.setOpaque(true);
        xLabel1.setPadding(new java.awt.Insets(5, 5, 5, 5));
        xLabel1.setText("<html><b>Copyright 2004. MLhuillier Philippines Inc. All rights reserved. Powered by <font color=\"yellow\"><u>Rameses Systems Inc.</u></font></b></html>");
        add(xLabel1, java.awt.BorderLayout.SOUTH);

        xPanel2.setLayout(null);

        xPanel2.setOpaque(true);
        xPanel2.setPreferredSize(new java.awt.Dimension(645, 43));
        xButton1.setIconResource("shared/images/16/back.png");
        xButton1.setAlt('b');
        xButton1.setOnclick("gotoPage('default')");
        xButton1.setText("Back");
        xPanel2.add(xButton1);
        xButton1.setBounds(6, 6, 81, 30);

        xButton2.setIconResource("shared/images/print.png");
        xButton2.setAlt('p');
        xButton2.setOnclick("doPrint");
        xButton2.setText("Print");
        xPanel2.add(xButton2);
        xButton2.setBounds(90, 6, 93, 30);

        xTextField1.setName("dummy");
        xPanel2.add(xTextField1);
        xTextField1.setBounds(-10, -10, 10, 10);

        add(xPanel2, java.awt.BorderLayout.NORTH);

        xTextArea1.setEnabled(false);
        xTextArea1.setTextFont(new java.awt.Font("DialogInput", 0, 11));
        xTextArea1.setName("REPORT");
        add(xTextArea1, java.awt.BorderLayout.CENTER);

    }// </editor-fold>//GEN-END:initComponents
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private com.rameses.osiris.client.component.XButton xButton1;
    private com.rameses.osiris.client.component.XButton xButton2;
    private com.rameses.osiris.client.component.XLabel xLabel1;
    private com.rameses.osiris.client.component.XPanel xPanel2;
    private com.rameses.osiris.client.component.XTextArea xTextArea1;
    private com.rameses.osiris.client.component.XTextField xTextField1;
    // End of variables declaration//GEN-END:variables
    
}
