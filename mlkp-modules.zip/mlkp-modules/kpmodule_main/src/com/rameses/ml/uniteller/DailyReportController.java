package com.rameses.ml.uniteller;

import com.rameses.osiris.client.AbstractFormController;
import java.awt.Dimension;
import java.io.InputStream;

public class DailyReportController extends AbstractFormController
{
    
    public DailyReportController() 
    {
        addPage("preview", DailyReportPreviewPage.class);
    }

    protected Class getDefaultPageClass() {
        return DailyReportPage.class;
    }

    protected InputStream getCodeBaseAsStream() 
    {
        Class clazz = getClass();
        return clazz.getResourceAsStream(clazz.getSimpleName() + ".jc");
    }

    public String getPreferredID() { return "uniteller.dailyReport.frm"; }

    public String getTitle() { return "UniTeller Daily Report"; }

    public boolean isCacheable() { return false; }

    public boolean isResizable() { return true; }
    
    public Dimension getPreferredSize() {
        return new Dimension(800, 600);
    }
    
}
