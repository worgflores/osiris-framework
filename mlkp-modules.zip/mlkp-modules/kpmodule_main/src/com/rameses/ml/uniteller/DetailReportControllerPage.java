package com.rameses.ml.uniteller;

public class DetailReportControllerPage extends com.rameses.osiris.client.Page
{
    
    public DetailReportControllerPage()
{
        initComponents();
    }
    
    // <editor-fold defaultstate="collapsed" desc=" Generated Code ">//GEN-BEGIN:initComponents
    private void initComponents() {
        xLabel1 = new com.rameses.osiris.client.component.XLabel();
        xPanel1 = new com.rameses.osiris.client.component.XPanel();
        xLabel2 = new com.rameses.osiris.client.component.XLabel();
        xLabel3 = new com.rameses.osiris.client.component.XLabel();
        xButton1 = new com.rameses.osiris.client.component.XButton();
        xLabel6 = new com.rameses.osiris.client.component.XLabel();
        xOption1 = new com.rameses.osiris.client.component.XOption();
        xOption2 = new com.rameses.osiris.client.component.XOption();
        xOption3 = new com.rameses.osiris.client.component.XOption();
        xOption4 = new com.rameses.osiris.client.component.XOption();
        xOption5 = new com.rameses.osiris.client.component.XOption();
        xLabel7 = new com.rameses.osiris.client.component.XLabel();
        xOption6 = new com.rameses.osiris.client.component.XOption();
        xTextField2 = new com.rameses.osiris.client.component.XTextField();
        xCombo1 = new com.rameses.osiris.client.component.XCombo();
        xCombo2 = new com.rameses.osiris.client.component.XCombo();
        xCombo3 = new com.rameses.osiris.client.component.XCombo();
        xCombo4 = new com.rameses.osiris.client.component.XCombo();

        setLayout(new java.awt.BorderLayout());

        setBackground(new java.awt.Color(255, 255, 255));
        setPreferredSize(new java.awt.Dimension(761, 516));
        xLabel1.setBackground(new java.awt.Color(111, 104, 104));
        xLabel1.setForeground(new java.awt.Color(255, 255, 255));
        xLabel1.setOpaque(true);
        xLabel1.setPadding(new java.awt.Insets(5, 5, 5, 5));
        xLabel1.setText("<html><b>Copyright 2004. MLhuillier Philippines Inc. All rights reserved. Powered by <font color=\"yellow\"><u>Rameses Systems Inc.</u></font></b></html>");
        add(xLabel1, java.awt.BorderLayout.SOUTH);

        xPanel1.setLayout(null);

        xLabel2.setText("<html><font size=\"5\">UniTeller Detail Reports</font></html>");
        xPanel1.add(xLabel2);
        xLabel2.setBounds(18, 18, 228, 33);

        xLabel3.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        xLabel3.setText("<html>Welcome to <b><i>UniTeller Detail Reports</i></b>. This facility enables you to make reports for UniTeller transactions. Specify from the provided parameters below to narrow down your search. If you have any problems regarding this facility, please contact your administrator.</html>");
        xPanel1.add(xLabel3);
        xLabel3.setBounds(46, 60, 604, 52);

        xButton1.setIconResource("shared/images/16/document.png");
        xButton1.setAlt('v');
        xButton1.setOnclick("doPreview");
        xButton1.setText("Preview");
        xPanel1.add(xButton1);
        xButton1.setBounds(210, 368, 102, 33);

        xLabel6.setBackground(new java.awt.Color(0, 51, 153));
        xLabel6.setForeground(new java.awt.Color(255, 255, 255));
        xLabel6.setOpaque(true);
        xLabel6.setPadding(new java.awt.Insets(5, 10, 5, 5));
        xLabel6.setText("<html><b>LOCATION</b></html>");
        xPanel1.add(xLabel6);
        xLabel6.setBounds(46, 122, 580, 20);

        xOption1.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        xOption1.setName("location");
        xOption1.setOnclick("changeGroup");
        xOption1.setText("All");
        xOption1.setValue("ALL");
        xPanel1.add(xOption1);
        xOption1.setBounds(70, 156, 70, 15);

        xOption2.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        xOption2.setName("location");
        xOption2.setOnclick("changeGroup");
        xOption2.setText("Branch");
        xOption2.setValue("BRANCH");
        xPanel1.add(xOption2);
        xOption2.setBounds(70, 178, 72, 15);

        xOption3.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        xOption3.setName("location");
        xOption3.setOnclick("changeGroup");
        xOption3.setText("Area");
        xOption3.setValue("AREA");
        xPanel1.add(xOption3);
        xOption3.setBounds(70, 200, 72, 15);

        xOption4.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        xOption4.setName("location");
        xOption4.setOnclick("changeGroup");
        xOption4.setText("Region");
        xOption4.setValue("REGION");
        xPanel1.add(xOption4);
        xOption4.setBounds(70, 222, 72, 15);

        xOption5.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        xOption5.setName("location");
        xOption5.setOnclick("changeGroup");
        xOption5.setText("Loop");
        xOption5.setValue("LOOPGROUP");
        xPanel1.add(xOption5);
        xOption5.setBounds(70, 244, 72, 15);

        xLabel7.setBackground(new java.awt.Color(0, 51, 153));
        xLabel7.setForeground(new java.awt.Color(255, 255, 255));
        xLabel7.setOpaque(true);
        xLabel7.setPadding(new java.awt.Insets(5, 10, 5, 5));
        xLabel7.setText("<html><b>PERIOD</b></html>");
        xPanel1.add(xLabel7);
        xLabel7.setBounds(46, 274, 580, 20);

        xOption6.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        xOption6.setName("period");
        xOption6.setText("Daily    (yyyy-mm-dd)");
        xOption6.setValue("DAILY");
        xPanel1.add(xOption6);
        xOption6.setBounds(70, 308, 134, 15);

        xTextField2.setFormat("####-##-##");
        xTextField2.setName("dailystartdate");
        xTextField2.setType("mask");
        xPanel1.add(xTextField2);
        xTextField2.setBounds(210, 306, 120, 20);

        xCombo1.setEnabled(false);
        xCombo1.setName("grpbranch");
        xCombo1.setSrc("branch");
        xCombo1.setSrckey("objid");
        xCombo1.setSrcvalue("objid");
        xPanel1.add(xCombo1);
        xCombo1.setBounds(210, 174, 120, 20);

        xCombo2.setEnabled(false);
        xCombo2.setName("grparea");
        xCombo2.setSrc("area");
        xCombo2.setSrckey("objid");
        xCombo2.setSrcvalue("title");
        xPanel1.add(xCombo2);
        xCombo2.setBounds(210, 196, 300, 20);

        xCombo3.setEnabled(false);
        xCombo3.setName("grpregion");
        xCombo3.setSrc("region");
        xCombo3.setSrckey("objid");
        xCombo3.setSrcvalue("title");
        xPanel1.add(xCombo3);
        xCombo3.setBounds(210, 218, 300, 20);

        xCombo4.setEnabled(false);
        xCombo4.setName("grploop");
        xCombo4.setSrc("loopgroup");
        xCombo4.setSrckey("objid");
        xCombo4.setSrcvalue("objid");
        xPanel1.add(xCombo4);
        xCombo4.setBounds(210, 240, 120, 20);

        add(xPanel1, java.awt.BorderLayout.CENTER);

    }// </editor-fold>//GEN-END:initComponents
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private com.rameses.osiris.client.component.XButton xButton1;
    private com.rameses.osiris.client.component.XCombo xCombo1;
    private com.rameses.osiris.client.component.XCombo xCombo2;
    private com.rameses.osiris.client.component.XCombo xCombo3;
    private com.rameses.osiris.client.component.XCombo xCombo4;
    private com.rameses.osiris.client.component.XLabel xLabel1;
    private com.rameses.osiris.client.component.XLabel xLabel2;
    private com.rameses.osiris.client.component.XLabel xLabel3;
    private com.rameses.osiris.client.component.XLabel xLabel6;
    private com.rameses.osiris.client.component.XLabel xLabel7;
    private com.rameses.osiris.client.component.XOption xOption1;
    private com.rameses.osiris.client.component.XOption xOption2;
    private com.rameses.osiris.client.component.XOption xOption3;
    private com.rameses.osiris.client.component.XOption xOption4;
    private com.rameses.osiris.client.component.XOption xOption5;
    private com.rameses.osiris.client.component.XOption xOption6;
    private com.rameses.osiris.client.component.XPanel xPanel1;
    private com.rameses.osiris.client.component.XTextField xTextField2;
    // End of variables declaration//GEN-END:variables
    
}
