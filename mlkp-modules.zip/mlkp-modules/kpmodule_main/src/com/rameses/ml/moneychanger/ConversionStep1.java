package com.rameses.ml.moneychanger;

import com.rameses.osiris.client.component.ComboEntry;

public class ConversionStep1 extends com.rameses.osiris.client.Page
{
    
    /** Creates new form ConversionStep1 */
    public ConversionStep1()
{
        initComponents();
    }
    
    // <editor-fold defaultstate="collapsed" desc=" Generated Code ">//GEN-BEGIN:initComponents
    private void initComponents() {
        xTitleHeader1 = new com.rameses.osiris.client.component.template.XTitleHeader();
        xPanel1 = new com.rameses.osiris.client.component.XPanel();
        xLabel1 = new com.rameses.osiris.client.component.XLabel();
        xTextField1 = new com.rameses.osiris.client.component.XTextField();
        xCombo1 = new com.rameses.osiris.client.component.XCombo();
        xLabel2 = new com.rameses.osiris.client.component.XLabel();
        xCombo2 = new com.rameses.osiris.client.component.XCombo();
        xButton1 = new com.rameses.osiris.client.component.XButton();
        xLabel3 = new com.rameses.osiris.client.component.XLabel();

        setLayout(new java.awt.BorderLayout());

        setPreferredSize(new java.awt.Dimension(572, 243));
        xTitleHeader1.setText("Money Changer");
        add(xTitleHeader1, java.awt.BorderLayout.NORTH);

        xPanel1.setLayout(null);

        xLabel1.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        xLabel1.setPadding(new java.awt.Insets(0, 0, 0, 10));
        xLabel1.setText("<html><font size=\"3\"><b>From Currency:</b></font><html>");
        xPanel1.add(xLabel1);
        xLabel1.setBounds(36, 60, 110, 22);

        xTextField1.setFont(new java.awt.Font("Courier New", 1, 18));
        xTextField1.setModelName("data");
        xTextField1.setName("amount");
        xTextField1.setType("currency");
        xPanel1.add(xTextField1);
        xTextField1.setBounds(150, 32, 128, 24);

        xCombo1.setModelName("data");
        xCombo1.setEntries(new ComboEntry[]
            {
                new ComboEntry("USD", "USD"),
                new ComboEntry("PHP", "PHP")
            });
            xCombo1.setFont(new java.awt.Font("Tahoma", 1, 12));
            xCombo1.setName("currency");
            xPanel1.add(xCombo1);
            xCombo1.setBounds(150, 60, 128, 24);

            xLabel2.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
            xLabel2.setPadding(new java.awt.Insets(0, 0, 0, 10));
            xLabel2.setText("<html><font size=\"3\"><b>To Currency:</b></font><html>");
            xPanel1.add(xLabel2);
            xLabel2.setBounds(36, 88, 110, 22);

            xCombo2.setModelName("data");
            xCombo2.setEntries(new ComboEntry[]
                {
                    new ComboEntry("USD", "USD"),
                    new ComboEntry("PHP", "PHP")
                });
                xCombo2.setFont(new java.awt.Font("Tahoma", 1, 12));
                xCombo2.setName("targetcurrency");
                xPanel1.add(xCombo2);
                xCombo2.setBounds(150, 88, 128, 24);

                xButton1.setDefaultFocusInWindow(true);
                xButton1.setOnclick("doConvert");
                xButton1.setText("Convert");
                xPanel1.add(xButton1);
                xButton1.setBounds(150, 138, 92, 28);

                xLabel3.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
                xLabel3.setPadding(new java.awt.Insets(0, 0, 0, 10));
                xLabel3.setText("<html><font size=\"3\"><b>Amount:</b></font><html>");
                xPanel1.add(xLabel3);
                xLabel3.setBounds(36, 32, 110, 22);

                add(xPanel1, java.awt.BorderLayout.CENTER);

            }// </editor-fold>//GEN-END:initComponents
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private com.rameses.osiris.client.component.XButton xButton1;
    private com.rameses.osiris.client.component.XCombo xCombo1;
    private com.rameses.osiris.client.component.XCombo xCombo2;
    private com.rameses.osiris.client.component.XLabel xLabel1;
    private com.rameses.osiris.client.component.XLabel xLabel2;
    private com.rameses.osiris.client.component.XLabel xLabel3;
    private com.rameses.osiris.client.component.XPanel xPanel1;
    private com.rameses.osiris.client.component.XTextField xTextField1;
    private com.rameses.osiris.client.component.template.XTitleHeader xTitleHeader1;
    // End of variables declaration//GEN-END:variables
    
}
