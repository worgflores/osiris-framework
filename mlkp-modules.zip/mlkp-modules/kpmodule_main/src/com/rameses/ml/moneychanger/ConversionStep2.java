package com.rameses.ml.moneychanger;

import com.rameses.osiris.client.component.ComboEntry;

public class ConversionStep2 extends com.rameses.osiris.client.Page
{
    
    /** Creates new form ConversionStep1 */
    public ConversionStep2()
{
        initComponents();
    }
    
    // <editor-fold defaultstate="collapsed" desc=" Generated Code ">//GEN-BEGIN:initComponents
    private void initComponents() {
        xTitleHeader1 = new com.rameses.osiris.client.component.template.XTitleHeader();
        xPanel1 = new com.rameses.osiris.client.component.XPanel();
        xButton1 = new com.rameses.osiris.client.component.XButton();
        xLabel3 = new com.rameses.osiris.client.component.XLabel();
        xLabel4 = new com.rameses.osiris.client.component.XLabel();
        xLabel011 = new com.rameses.osiris.client.component.template.XLabel01();
        xLabel12 = new com.rameses.osiris.client.component.template.XLabel01();
        xLabel13 = new com.rameses.osiris.client.component.template.XLabel01();
        xLabel14 = new com.rameses.osiris.client.component.template.XLabel01();
        xButton2 = new com.rameses.osiris.client.component.XButton();
        xLabel5 = new com.rameses.osiris.client.component.XLabel();
        xLabel15 = new com.rameses.osiris.client.component.template.XLabel01();

        setLayout(new java.awt.BorderLayout());

        setPreferredSize(new java.awt.Dimension(572, 243));
        xTitleHeader1.setText("Money Changer");
        add(xTitleHeader1, java.awt.BorderLayout.NORTH);

        xPanel1.setLayout(null);

        xButton1.setAlt('m');
        xButton1.setDefaultFocusInWindow(true);
        xButton1.setOnclick("doModify");
        xButton1.setText("Modify");
        xPanel1.add(xButton1);
        xButton1.setBounds(152, 112, 82, 28);

        xLabel3.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        xLabel3.setPadding(new java.awt.Insets(0, 0, 0, 10));
        xLabel3.setText("<html><font size=\"3\"><b>Source Amount:</b></font><html>");
        xPanel1.add(xLabel3);
        xLabel3.setBounds(22, 32, 124, 22);

        xLabel4.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        xLabel4.setPadding(new java.awt.Insets(0, 0, 0, 10));
        xLabel4.setText("<html><font size=\"3\"><b>Target Amount:</b></font><html>");
        xPanel1.add(xLabel4);
        xLabel4.setBounds(22, 62, 124, 22);

        xLabel011.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        xLabel011.setFont(new java.awt.Font("Tahoma", 1, 18));
        xLabel011.setModelName("data");
        xLabel011.setName("currency");
        xLabel011.setText("PHP");
        xPanel1.add(xLabel011);
        xLabel011.setBounds(152, 32, 48, 26);

        xLabel12.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        xLabel12.setFont(new java.awt.Font("Tahoma", 1, 18));
        xLabel12.setModelName("data");
        xLabel12.setName("targetcurrency");
        xLabel12.setText("PHP");
        xPanel1.add(xLabel12);
        xLabel12.setBounds(152, 60, 48, 26);

        xLabel13.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        xLabel13.setFont(new java.awt.Font("Tahoma", 0, 22));
        xLabel13.setModelName("data");
        xLabel13.setName("sourceamount");
        xLabel13.setText("50,000.0000");
        xPanel1.add(xLabel13);
        xLabel13.setBounds(202, 32, 154, 26);

        xLabel14.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        xLabel14.setFont(new java.awt.Font("Tahoma", 0, 22));
        xLabel14.setForeground(new java.awt.Color(204, 0, 0));
        xLabel14.setModelName("data");
        xLabel14.setName("targetamount");
        xLabel14.setText("50,000.0000");
        xPanel1.add(xLabel14);
        xLabel14.setBounds(202, 60, 154, 26);

        xButton2.setAlt('c');
        xButton2.setOnclick("doClose");
        xButton2.setText("Close");
        xPanel1.add(xButton2);
        xButton2.setBounds(238, 112, 82, 28);

        xLabel5.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        xLabel5.setPadding(new java.awt.Insets(0, 0, 0, 10));
        xLabel5.setText("<html><font size=\"5\"><b>RATE OF THE DAY</b></font><html>");
        xPanel1.add(xLabel5);
        xLabel5.setBounds(374, 8, 184, 24);

        xLabel15.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        xLabel15.setFont(new java.awt.Font("Tahoma", 0, 36));
        xLabel15.setForeground(new java.awt.Color(204, 0, 0));
        xLabel15.setModelName("data");
        xLabel15.setName("targetrate");
        xLabel15.setText("48.25");
        xPanel1.add(xLabel15);
        xLabel15.setBounds(374, 32, 156, 54);

        add(xPanel1, java.awt.BorderLayout.CENTER);

    }// </editor-fold>//GEN-END:initComponents
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private com.rameses.osiris.client.component.XButton xButton1;
    private com.rameses.osiris.client.component.XButton xButton2;
    private com.rameses.osiris.client.component.template.XLabel01 xLabel011;
    private com.rameses.osiris.client.component.template.XLabel01 xLabel12;
    private com.rameses.osiris.client.component.template.XLabel01 xLabel13;
    private com.rameses.osiris.client.component.template.XLabel01 xLabel14;
    private com.rameses.osiris.client.component.template.XLabel01 xLabel15;
    private com.rameses.osiris.client.component.XLabel xLabel3;
    private com.rameses.osiris.client.component.XLabel xLabel4;
    private com.rameses.osiris.client.component.XLabel xLabel5;
    private com.rameses.osiris.client.component.XPanel xPanel1;
    private com.rameses.osiris.client.component.template.XTitleHeader xTitleHeader1;
    // End of variables declaration//GEN-END:variables
    
}
