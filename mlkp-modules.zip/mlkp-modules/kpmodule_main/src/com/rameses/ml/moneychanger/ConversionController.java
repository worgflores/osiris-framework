package com.rameses.ml.moneychanger;

import com.rameses.osiris.client.AbstractFormController;
import java.awt.Dimension;

public class ConversionController extends AbstractFormController
{
    
    public ConversionController() {
        addPage("results", ConversionStep2.class);
    }

    protected Class getDefaultPageClass() { return ConversionStep1.class; }

    public String getPreferredID() { return "moneychanger.frm"; }

    public Dimension getPreferredSize() {
        return new Dimension(572, 280);
    }
    
}

