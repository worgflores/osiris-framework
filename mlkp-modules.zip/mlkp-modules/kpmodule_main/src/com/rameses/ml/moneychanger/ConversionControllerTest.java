package com.rameses.ml.moneychanger;

import com.rameses.osiris.client.FormLauncher;
import java.util.Hashtable;
import java.util.Map;
import javax.swing.UIManager;
import rameses.osiris.client.app.App;

public class ConversionControllerTest 
{
    
    public static void main(String[] args) 
    {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch(Exception ign) {;}
        
        try
        {
            doLogin();
            ConversionController c = new ConversionController();
            FormLauncher.newInstance().launch(c);
        }
        catch(Exception ex) {
            ex.printStackTrace();
        }
        finally {
            System.exit(0);
        }
    }
    
    static void doLogin() throws Exception
    {
        System.setProperty("app.host", "http://localhost:8080/mlhuillier/action"); 
        
        Map props = new Hashtable();
        props.put("TERMINALID", "UAKPDSXC");
        App.getSecurityManager().login("KPUSER", "1234", props);
    } 
    
    private ConversionControllerTest() {
    }
 
    
}
