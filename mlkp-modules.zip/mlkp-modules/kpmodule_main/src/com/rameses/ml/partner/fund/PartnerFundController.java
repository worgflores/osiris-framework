package com.rameses.ml.partner.fund;

import com.rameses.osiris.client.AbstractFormController;
import java.awt.Dimension;
import java.io.InputStream;

public class PartnerFundController extends AbstractFormController
{
    
    public PartnerFundController() 
    {
        addPage("browsePartner", PartnerFundBrowsePage.class);
        addPage("readonly", PartnerFundReadOnlyPage.class);
        addPage("loadAmount", PartnerFundLoadAmountPage.class);
    }

    protected Class getDefaultPageClass() {
        return PartnerFundControllerPage.class;
    }

    protected InputStream getCodeBaseAsStream() 
    {
        Class clz = PartnerFundController.class;
        return clz.getResourceAsStream(clz.getSimpleName() + ".xml");
    }

    public String getPreferredID() {
        return "partnerfund.frm";
    }

    public Dimension getPreferredSize() {
        return new Dimension(483, 373);
    }
    
}
