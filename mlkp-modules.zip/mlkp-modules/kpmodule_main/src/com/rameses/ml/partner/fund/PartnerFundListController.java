package com.rameses.ml.partner.fund;

import com.rameses.osiris.client.AbstractFormController;
import java.awt.Dimension;
import java.io.InputStream;

public class PartnerFundListController extends AbstractFormController
{
    
    public PartnerFundListController() {
    }

    protected Class getDefaultPageClass() {
        return PartnerFundListPage.class;
    }

    protected InputStream getCodeBaseAsStream() 
    {
        Class clz = getClass();
        return clz.getResourceAsStream(clz.getSimpleName() + ".xml");
    }

    public String getPreferredID() {
        return "partnerfundlist.frm";
    }

    public Dimension getPreferredSize() {
        return new Dimension(800, 517);
    }
    
}
