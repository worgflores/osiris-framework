package com.rameses.ml.partner.fund;

import com.rameses.osiris.client.Page;

public class PartnerFundBrowsePage extends Page 
{
    
    public PartnerFundBrowsePage() {
        initComponents();
    }
    
    // <editor-fold defaultstate="collapsed" desc=" Generated Code ">//GEN-BEGIN:initComponents
    private void initComponents() {
        xPanel1 = new com.rameses.osiris.client.component.XPanel();
        xLabel1 = new com.rameses.osiris.client.component.XLabel();
        xTextField1 = new com.rameses.osiris.client.component.XTextField();
        xButton1 = new com.rameses.osiris.client.component.XButton();
        xTextField4 = new com.rameses.osiris.client.component.XTextField();
        xTable1 = new com.rameses.osiris.client.component.XTable();
        xPanel2 = new com.rameses.osiris.client.component.XPanel();
        xGlue1 = new com.rameses.osiris.client.component.spacer.XGlue();
        xButton2 = new com.rameses.osiris.client.component.XButton();
        xStrut1 = new com.rameses.osiris.client.component.spacer.XStrut();
        xButton3 = new com.rameses.osiris.client.component.XButton();
        xTitleHeader1 = new com.rameses.osiris.client.component.template.XTitleHeader();

        setLayout(new java.awt.BorderLayout());

        setBackground(new java.awt.Color(255, 255, 255));
        setPreferredSize(new java.awt.Dimension(483, 373));
        xPanel1.setLayout(null);

        xLabel1.setText("<html><b>Search</b></html>");
        xPanel1.add(xLabel1);
        xLabel1.setBounds(237, 18, 57, 14);

        xTextField1.setModelName("filter");
        xTextField1.setName("searchvalue");
        xPanel1.add(xTextField1);
        xTextField1.setBounds(294, 15, 120, 20);

        xButton1.setAlt('g');
        xButton1.setOnclick("doSearchPartner");
        xButton1.setText("Go");
        xPanel1.add(xButton1);
        xButton1.setBounds(417, 13, 51, 23);

        xTextField4.setName("dummy");
        xTextField4.setPreferredSize(new java.awt.Dimension(10, 10));
        xPanel1.add(xTextField4);
        xTextField4.setBounds(-10, -10, 10, 10);

        xTable1.setAutoresize(false);
        xTable1.setColumnAsXml("<column name=\"stracctid\" caption=\"Code\"/>\n<column name=\"stracctname\" caption=\"Description\" width=\"300\"/>");
        xTable1.setModelName("list");
        xPanel1.add(xTable1);
        xTable1.setBounds(15, 48, 453, 219);

        add(xPanel1, java.awt.BorderLayout.CENTER);

        xPanel2.setLayout(new javax.swing.BoxLayout(xPanel2, javax.swing.BoxLayout.X_AXIS));

        xPanel2.setOpaque(true);
        xPanel2.setPadding(new java.awt.Insets(5, 7, 7, 10));
        xPanel2.setPreferredSize(new java.awt.Dimension(100, 50));
        org.jdesktop.layout.GroupLayout xGlue1Layout = new org.jdesktop.layout.GroupLayout(xGlue1);
        xGlue1.setLayout(xGlue1Layout);
        xGlue1Layout.setHorizontalGroup(
            xGlue1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(0, 332, Short.MAX_VALUE)
        );
        xGlue1Layout.setVerticalGroup(
            xGlue1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(0, 0, Short.MAX_VALUE)
        );
        xPanel2.add(xGlue1);

        xButton2.setAlt('k');
        xButton2.setOnclick("doSelectPartner");
        xButton2.setText("  OK  ");
        xPanel2.add(xButton2);

        xStrut1.setLength(10);
        org.jdesktop.layout.GroupLayout xStrut1Layout = new org.jdesktop.layout.GroupLayout(xStrut1);
        xStrut1.setLayout(xStrut1Layout);
        xStrut1Layout.setHorizontalGroup(
            xStrut1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(0, 10, Short.MAX_VALUE)
        );
        xStrut1Layout.setVerticalGroup(
            xStrut1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(0, 38, Short.MAX_VALUE)
        );
        xPanel2.add(xStrut1);

        xButton3.setAlt('c');
        xButton3.setOnclick("gotoPage('default')");
        xButton3.setText("Cancel");
        xPanel2.add(xButton3);

        add(xPanel2, java.awt.BorderLayout.SOUTH);

        xTitleHeader1.setText("Search Partners");
        add(xTitleHeader1, java.awt.BorderLayout.NORTH);

    }// </editor-fold>//GEN-END:initComponents
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private com.rameses.osiris.client.component.XButton xButton1;
    private com.rameses.osiris.client.component.XButton xButton2;
    private com.rameses.osiris.client.component.XButton xButton3;
    private com.rameses.osiris.client.component.spacer.XGlue xGlue1;
    private com.rameses.osiris.client.component.XLabel xLabel1;
    private com.rameses.osiris.client.component.XPanel xPanel1;
    private com.rameses.osiris.client.component.XPanel xPanel2;
    private com.rameses.osiris.client.component.spacer.XStrut xStrut1;
    private com.rameses.osiris.client.component.XTable xTable1;
    private com.rameses.osiris.client.component.XTextField xTextField1;
    private com.rameses.osiris.client.component.XTextField xTextField4;
    private com.rameses.osiris.client.component.template.XTitleHeader xTitleHeader1;
    // End of variables declaration//GEN-END:variables
    
}
