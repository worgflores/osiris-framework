package com.rameses.ml.partner.fund;

import com.rameses.osiris.client.Page;
import com.rameses.osiris.client.component.ComboEntry;

public class PartnerFundReadOnlyPage extends Page 
{
    
    public PartnerFundReadOnlyPage() {
        initComponents();
    }
    
    // <editor-fold defaultstate="collapsed" desc=" Generated Code ">//GEN-BEGIN:initComponents
    private void initComponents() {
        xPanel1 = new com.rameses.osiris.client.component.XPanel();
        xLabel1 = new com.rameses.osiris.client.component.XLabel();
        xTextField1 = new com.rameses.osiris.client.component.XTextField();
        xLabel2 = new com.rameses.osiris.client.component.XLabel();
        xTextField2 = new com.rameses.osiris.client.component.XTextField();
        xLabel3 = new com.rameses.osiris.client.component.XLabel();
        xTextField3 = new com.rameses.osiris.client.component.XTextField();
        xTextField4 = new com.rameses.osiris.client.component.XTextField();
        xLabel4 = new com.rameses.osiris.client.component.XLabel();
        xTextField5 = new com.rameses.osiris.client.component.XTextField();
        xLabel5 = new com.rameses.osiris.client.component.XLabel();
        xCombo1 = new com.rameses.osiris.client.component.XCombo();
        xPanel2 = new com.rameses.osiris.client.component.XPanel();
        xButton3 = new com.rameses.osiris.client.component.XButton();
        xGlue1 = new com.rameses.osiris.client.component.spacer.XGlue();
        xStrut1 = new com.rameses.osiris.client.component.spacer.XStrut();
        xButton4 = new com.rameses.osiris.client.component.XButton();
        xTitleHeader1 = new com.rameses.osiris.client.component.template.XTitleHeader();

        setLayout(new java.awt.BorderLayout());

        setBackground(new java.awt.Color(255, 255, 255));
        setPreferredSize(new java.awt.Dimension(483, 373));
        xPanel1.setLayout(null);

        xLabel1.setText("<html>Partner ID :</html>");
        xPanel1.add(xLabel1);
        xLabel1.setBounds(27, 30, 75, 14);

        xTextField1.setEnabled(false);
        xTextField1.setModelName("data");
        xTextField1.setName("stracctid");
        xPanel1.add(xTextField1);
        xTextField1.setBounds(117, 27, 165, 20);

        xLabel2.setText("<html>Amount :</html>");
        xPanel1.add(xLabel2);
        xLabel2.setBounds(27, 108, 69, 14);

        xTextField2.setEnabled(false);
        xTextField2.setFont(new java.awt.Font("Courier New", 1, 16));
        xTextField2.setModelName("data");
        xTextField2.setName("curamount");
        xTextField2.setType("currency");
        xPanel1.add(xTextField2);
        xTextField2.setBounds(117, 105, 165, 21);

        xLabel3.setText("Partner Name :");
        xPanel1.add(xLabel3);
        xLabel3.setBounds(27, 54, 81, 14);

        xTextField3.setEnabled(false);
        xTextField3.setModelName("data");
        xTextField3.setName("stracctname");
        xPanel1.add(xTextField3);
        xTextField3.setBounds(117, 54, 315, 19);

        xTextField4.setName("dummy");
        xTextField4.setPreferredSize(new java.awt.Dimension(10, 10));
        xPanel1.add(xTextField4);
        xTextField4.setBounds(-10, -10, 10, 10);

        xLabel4.setText("<html>Balance :</html>");
        xPanel1.add(xLabel4);
        xLabel4.setBounds(27, 135, 69, 14);

        xTextField5.setEnabled(false);
        xTextField5.setFont(new java.awt.Font("Courier New", 1, 16));
        xTextField5.setModelName("data");
        xTextField5.setName("curbalance");
        xTextField5.setType("currency");
        xPanel1.add(xTextField5);
        xTextField5.setBounds(117, 132, 165, 21);

        xLabel5.setText("Currency :");
        xPanel1.add(xLabel5);
        xLabel5.setBounds(27, 81, 69, 14);

        xCombo1.setModelName("data");
        xCombo1.setEnabled(false);
        xCombo1.setEntries(new ComboEntry[]
            {
                new ComboEntry("PHP", "PHP"),
                new ComboEntry("USD", "USD")
            });
            xCombo1.setName("strcurrencyid");
            xPanel1.add(xCombo1);
            xCombo1.setBounds(117, 78, 165, 22);

            add(xPanel1, java.awt.BorderLayout.CENTER);

            xPanel2.setLayout(new javax.swing.BoxLayout(xPanel2, javax.swing.BoxLayout.X_AXIS));

            xPanel2.setOpaque(true);
            xPanel2.setPadding(new java.awt.Insets(5, 7, 7, 10));
            xPanel2.setPreferredSize(new java.awt.Dimension(100, 50));
            xButton3.setIconResource("");
            xButton3.setAlt('l');
            xButton3.setOnclick("doLoadAmount");
            xButton3.setText("Load Amount");
            xPanel2.add(xButton3);

            org.jdesktop.layout.GroupLayout xGlue1Layout = new org.jdesktop.layout.GroupLayout(xGlue1);
            xGlue1.setLayout(xGlue1Layout);
            xGlue1Layout.setHorizontalGroup(
                xGlue1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                .add(0, 278, Short.MAX_VALUE)
            );
            xGlue1Layout.setVerticalGroup(
                xGlue1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                .add(0, 0, Short.MAX_VALUE)
            );
            xPanel2.add(xGlue1);

            xStrut1.setLength(10);
            org.jdesktop.layout.GroupLayout xStrut1Layout = new org.jdesktop.layout.GroupLayout(xStrut1);
            xStrut1.setLayout(xStrut1Layout);
            xStrut1Layout.setHorizontalGroup(
                xStrut1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                .add(0, 10, Short.MAX_VALUE)
            );
            xStrut1Layout.setVerticalGroup(
                xStrut1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                .add(0, 38, Short.MAX_VALUE)
            );
            xPanel2.add(xStrut1);

            xButton4.setIconResource("shared/images/16/close.png");
            xButton4.setAlt('c');
            xButton4.setOnclick("doClose");
            xButton4.setText("Close");
            xPanel2.add(xButton4);

            add(xPanel2, java.awt.BorderLayout.SOUTH);

            xTitleHeader1.setText("Partner Fund");
            add(xTitleHeader1, java.awt.BorderLayout.NORTH);

        }// </editor-fold>//GEN-END:initComponents
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private com.rameses.osiris.client.component.XButton xButton3;
    private com.rameses.osiris.client.component.XButton xButton4;
    private com.rameses.osiris.client.component.XCombo xCombo1;
    private com.rameses.osiris.client.component.spacer.XGlue xGlue1;
    private com.rameses.osiris.client.component.XLabel xLabel1;
    private com.rameses.osiris.client.component.XLabel xLabel2;
    private com.rameses.osiris.client.component.XLabel xLabel3;
    private com.rameses.osiris.client.component.XLabel xLabel4;
    private com.rameses.osiris.client.component.XLabel xLabel5;
    private com.rameses.osiris.client.component.XPanel xPanel1;
    private com.rameses.osiris.client.component.XPanel xPanel2;
    private com.rameses.osiris.client.component.spacer.XStrut xStrut1;
    private com.rameses.osiris.client.component.XTextField xTextField1;
    private com.rameses.osiris.client.component.XTextField xTextField2;
    private com.rameses.osiris.client.component.XTextField xTextField3;
    private com.rameses.osiris.client.component.XTextField xTextField4;
    private com.rameses.osiris.client.component.XTextField xTextField5;
    private com.rameses.osiris.client.component.template.XTitleHeader xTitleHeader1;
    // End of variables declaration//GEN-END:variables
    
}
