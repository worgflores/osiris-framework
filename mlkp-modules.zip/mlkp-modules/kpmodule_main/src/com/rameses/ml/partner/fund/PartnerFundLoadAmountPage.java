package com.rameses.ml.partner.fund;

import com.rameses.osiris.client.Page;
import com.rameses.osiris.client.component.ComboEntry;

public class PartnerFundLoadAmountPage extends Page 
{
    
    public PartnerFundLoadAmountPage() {
        initComponents();
    }
    
    // <editor-fold defaultstate="collapsed" desc=" Generated Code ">//GEN-BEGIN:initComponents
    private void initComponents() {
        xPanel1 = new com.rameses.osiris.client.component.XPanel();
        xLabel2 = new com.rameses.osiris.client.component.XLabel();
        xTextField2 = new com.rameses.osiris.client.component.XTextField();
        xTextField4 = new com.rameses.osiris.client.component.XTextField();
        xCombo1 = new com.rameses.osiris.client.component.XCombo();
        xPanel2 = new com.rameses.osiris.client.component.XPanel();
        xGlue1 = new com.rameses.osiris.client.component.spacer.XGlue();
        xButton4 = new com.rameses.osiris.client.component.XButton();
        xStrut1 = new com.rameses.osiris.client.component.spacer.XStrut();
        xButton5 = new com.rameses.osiris.client.component.XButton();
        xTitleHeader1 = new com.rameses.osiris.client.component.template.XTitleHeader();

        setLayout(new java.awt.BorderLayout());

        setBackground(new java.awt.Color(255, 255, 255));
        setPreferredSize(new java.awt.Dimension(483, 373));
        xPanel1.setLayout(null);

        xLabel2.setFont(new java.awt.Font("Tahoma", 0, 14));
        xLabel2.setText("<html><b>Amount </b> <font color=\"red\">*</font> :</html>");
        xPanel1.add(xLabel2);
        xLabel2.setBounds(27, 51, 87, 24);

        xTextField2.setFont(new java.awt.Font("Courier New", 1, 20));
        xTextField2.setName("curamount");
        xTextField2.setType("currency");
        xPanel1.add(xTextField2);
        xTextField2.setBounds(117, 51, 165, 24);

        xTextField4.setName("dummy");
        xTextField4.setPreferredSize(new java.awt.Dimension(10, 10));
        xPanel1.add(xTextField4);
        xTextField4.setBounds(-10, -10, 10, 10);

        xCombo1.setModelName("data");
        xCombo1.setEnabled(false);
        xCombo1.setEntries(new ComboEntry[]
            {
                new ComboEntry("PHP", "PHP"),
                new ComboEntry("USD", "USD")
            });
            xCombo1.setFont(new java.awt.Font("Courier New", 0, 18));
            xCombo1.setName("strcurrencyid");
            xPanel1.add(xCombo1);
            xCombo1.setBounds(285, 51, 72, 24);

            add(xPanel1, java.awt.BorderLayout.CENTER);

            xPanel2.setLayout(new javax.swing.BoxLayout(xPanel2, javax.swing.BoxLayout.X_AXIS));

            xPanel2.setOpaque(true);
            xPanel2.setPadding(new java.awt.Insets(5, 7, 7, 10));
            xPanel2.setPreferredSize(new java.awt.Dimension(100, 50));
            org.jdesktop.layout.GroupLayout xGlue1Layout = new org.jdesktop.layout.GroupLayout(xGlue1);
            xGlue1.setLayout(xGlue1Layout);
            xGlue1Layout.setHorizontalGroup(
                xGlue1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                .add(0, 294, Short.MAX_VALUE)
            );
            xGlue1Layout.setVerticalGroup(
                xGlue1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                .add(0, 0, Short.MAX_VALUE)
            );
            xPanel2.add(xGlue1);

            xButton4.setIconResource("shared/images/16/save.png");
            xButton4.setAlt('s');
            xButton4.setDefaultFocusInWindow(true);
            xButton4.setOnclick("doSaveLoadAmount");
            xButton4.setText("Save");
            xPanel2.add(xButton4);

            xStrut1.setLength(10);
            org.jdesktop.layout.GroupLayout xStrut1Layout = new org.jdesktop.layout.GroupLayout(xStrut1);
            xStrut1.setLayout(xStrut1Layout);
            xStrut1Layout.setHorizontalGroup(
                xStrut1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                .add(0, 10, Short.MAX_VALUE)
            );
            xStrut1Layout.setVerticalGroup(
                xStrut1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                .add(0, 38, Short.MAX_VALUE)
            );
            xPanel2.add(xStrut1);

            xButton5.setIconResource("shared/images/16/close.png");
            xButton5.setAlt('c');
            xButton5.setOnclick("doCancelLoadAmount");
            xButton5.setText("Cancel");
            xPanel2.add(xButton5);

            add(xPanel2, java.awt.BorderLayout.SOUTH);

            xTitleHeader1.setText("Partner Fund - Load Amount");
            add(xTitleHeader1, java.awt.BorderLayout.NORTH);

        }// </editor-fold>//GEN-END:initComponents
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private com.rameses.osiris.client.component.XButton xButton4;
    private com.rameses.osiris.client.component.XButton xButton5;
    private com.rameses.osiris.client.component.XCombo xCombo1;
    private com.rameses.osiris.client.component.spacer.XGlue xGlue1;
    private com.rameses.osiris.client.component.XLabel xLabel2;
    private com.rameses.osiris.client.component.XPanel xPanel1;
    private com.rameses.osiris.client.component.XPanel xPanel2;
    private com.rameses.osiris.client.component.spacer.XStrut xStrut1;
    private com.rameses.osiris.client.component.XTextField xTextField2;
    private com.rameses.osiris.client.component.XTextField xTextField4;
    private com.rameses.osiris.client.component.template.XTitleHeader xTitleHeader1;
    // End of variables declaration//GEN-END:variables
    
}
