package com.rameses.ml.kyc;

import com.rameses.osiris.client.AbstractFormController;
import java.awt.Dimension;
import java.io.InputStream;

public class KYCController extends AbstractFormController
{
    
    public KYCController() 
    {
        addPage("fillremoteinfo", FillRemoteInfoPage.class);
        addPage("purposeoption", PurposeOptionPage.class);
        addPage("search", SearchPage.class);
        addPage("kyclist", KYCListPage.class);
        addPage("new", NewPage.class);
        addPage("newkycfromlist", NewPage.class);
        addPage("info", InfoPage.class);
        addPage("edit", EditPage.class);
        addPage("photogallery", PhotoGalleryPage.class);
    }

    protected Class getDefaultPageClass() {
        return DefaultPage.class;
    }

    protected InputStream getCodeBaseAsStream() {
        return getClass().getResourceAsStream("KYCController.jc");
    }

    public String getPreferredID() {
        return "kyc.frm";
    }

    public Dimension getPreferredSize() {
        return new Dimension(654, 490);
    }

    public boolean isDocument() {
        return true;
    }

    public String getDocumentName() {
        return "kyc";
    }

    public boolean isCacheable() {
        return false;
    }
    
}
