package com.rameses.ml.kyc;

public class KYCListPage extends com.rameses.osiris.client.Page
{
    
    /** Creates new form DefaultPage */
    public KYCListPage()
{
        initComponents();
    }
    
    // <editor-fold defaultstate="collapsed" desc=" Generated Code ">//GEN-BEGIN:initComponents
    private void initComponents() {
        xTitleHeader1 = new com.rameses.osiris.client.component.template.XTitleHeader();
        xPanel1 = new com.rameses.osiris.client.component.XPanel();
        xLabel1 = new com.rameses.osiris.client.component.XLabel();
        xTable1 = new com.rameses.osiris.client.component.XTable();
        xPanel3 = new com.rameses.osiris.client.component.XPanel();
        xButton4 = new com.rameses.osiris.client.component.XButton();
        xGlue1 = new com.rameses.osiris.client.component.spacer.XGlue();
        xButton3 = new com.rameses.osiris.client.component.XButton();
        xStrut2 = new com.rameses.osiris.client.component.spacer.XStrut();
        xButton1 = new com.rameses.osiris.client.component.XButton();
        xStrut1 = new com.rameses.osiris.client.component.spacer.XStrut();
        xButton2 = new com.rameses.osiris.client.component.XButton();

        setLayout(new java.awt.BorderLayout());

        setBackground(new java.awt.Color(255, 255, 255));
        setPreferredSize(new java.awt.Dimension(529, 409));
        xTitleHeader1.setText("Know-Your-Customer");
        add(xTitleHeader1, java.awt.BorderLayout.NORTH);

        xPanel1.setLayout(null);

        xLabel1.setBackground(new java.awt.Color(92, 133, 153));
        xLabel1.setFont(new java.awt.Font("Tahoma", 1, 12));
        xLabel1.setForeground(new java.awt.Color(255, 255, 255));
        xLabel1.setOpaque(true);
        xLabel1.setPadding(new java.awt.Insets(2, 5, 2, 2));
        xLabel1.setText("Customer List");
        xPanel1.add(xLabel1);
        xLabel1.setBounds(18, 21, 615, 21);

        xTable1.setColumnAsXml("<column name=\"lastname\" caption=\"Last Name\"/>\n<column name=\"firstname\" caption=\"First Name\"/>\n<column name=\"middlename\" caption=\"Middle Name\"/>\n<column name=\"birthdate\" caption=\"Birth Date\"/>");
        xTable1.setModelName("kyc");
        xTable1.setRowsperpage(15);
        xPanel1.add(xTable1);
        xTable1.setBounds(18, 42, 615, 294);

        add(xPanel1, java.awt.BorderLayout.CENTER);

        xPanel3.setLayout(new javax.swing.BoxLayout(xPanel3, javax.swing.BoxLayout.X_AXIS));

        xPanel3.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        xPanel3.setOpaque(true);
        xPanel3.setPadding(new java.awt.Insets(7, 5, 5, 10));
        xButton4.setIconResource("shared/images/16/document.png");
        xButton4.setAlt('n');
        xButton4.setOnclick("gotoPage('newkycfromlist')");
        xButton4.setText("New");
        xPanel3.add(xButton4);

        xPanel3.add(xGlue1);

        xButton3.setIconResource("shared/images/16/back.png");
        xButton3.setAlt('b');
        xButton3.setDefaultFocusInWindow(true);
        xButton3.setOnclick("gotoPage('default')");
        xButton3.setText("Back");
        xPanel3.add(xButton3);

        xStrut2.setLength(5);
        xPanel3.add(xStrut2);

        xButton1.setIconResource("shared/images/16/document.png");
        xButton1.setAlt('v');
        xButton1.setDefaultFocusInWindow(true);
        xButton1.setOnclick("viewKYCFromList");
        xButton1.setText("View");
        xPanel3.add(xButton1);

        xPanel3.add(xStrut1);

        xButton2.setIconResource("shared/images/16/close.png");
        xButton2.setAlt('c');
        xButton2.setOnclick("doClose");
        xButton2.setText("Cancel");
        xPanel3.add(xButton2);

        add(xPanel3, java.awt.BorderLayout.SOUTH);

    }// </editor-fold>//GEN-END:initComponents
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private com.rameses.osiris.client.component.XButton xButton1;
    private com.rameses.osiris.client.component.XButton xButton2;
    private com.rameses.osiris.client.component.XButton xButton3;
    private com.rameses.osiris.client.component.XButton xButton4;
    private com.rameses.osiris.client.component.spacer.XGlue xGlue1;
    private com.rameses.osiris.client.component.XLabel xLabel1;
    private com.rameses.osiris.client.component.XPanel xPanel1;
    private com.rameses.osiris.client.component.XPanel xPanel3;
    private com.rameses.osiris.client.component.spacer.XStrut xStrut1;
    private com.rameses.osiris.client.component.spacer.XStrut xStrut2;
    private com.rameses.osiris.client.component.XTable xTable1;
    private com.rameses.osiris.client.component.template.XTitleHeader xTitleHeader1;
    // End of variables declaration//GEN-END:variables
    
}
