package com.rameses.ml.kyc;

public class DefaultPage extends com.rameses.osiris.client.Page
{
    
    /** Creates new form DefaultPage */
    public DefaultPage()
{
        initComponents();
    }
    
    // <editor-fold defaultstate="collapsed" desc=" Generated Code ">//GEN-BEGIN:initComponents
    private void initComponents() {
        xTitleHeader1 = new com.rameses.osiris.client.component.template.XTitleHeader();
        xPanel1 = new com.rameses.osiris.client.component.XPanel();
        xLabel1 = new com.rameses.osiris.client.component.XLabel();
        xOption1 = new com.rameses.osiris.client.component.XOption();
        xOption2 = new com.rameses.osiris.client.component.XOption();
        xTextField1 = new com.rameses.osiris.client.component.XTextField();
        xPanel3 = new com.rameses.osiris.client.component.XPanel();
        xGlue1 = new com.rameses.osiris.client.component.spacer.XGlue();
        xButton1 = new com.rameses.osiris.client.component.XButton();
        xStrut1 = new com.rameses.osiris.client.component.spacer.XStrut();
        xButton2 = new com.rameses.osiris.client.component.XButton();

        setLayout(new java.awt.BorderLayout());

        setBackground(new java.awt.Color(255, 255, 255));
        setPreferredSize(new java.awt.Dimension(529, 409));
        xTitleHeader1.setText("Know-Your-Customer");
        add(xTitleHeader1, java.awt.BorderLayout.NORTH);

        xPanel1.setLayout(null);

        xLabel1.setText("<html><b>Is this a remote transaction?</b></html>");
        xPanel1.add(xLabel1);
        xLabel1.setBounds(27, 33, 222, 18);

        xOption1.setSelected(true);
        xOption1.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        xOption1.setName("remote");
        xOption1.setText(" Yes ");
        xOption1.setValue("1");
        xPanel1.add(xOption1);
        xOption1.setBounds(51, 69, 99, 15);

        xOption2.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        xOption2.setName("remote");
        xOption2.setText(" No");
        xOption2.setValue("0");
        xPanel1.add(xOption2);
        xOption2.setBounds(51, 93, 102, 15);

        xTextField1.setName("dummy");
        xPanel1.add(xTextField1);
        xTextField1.setBounds(-20, 1, 11, 19);

        add(xPanel1, java.awt.BorderLayout.CENTER);

        xPanel3.setLayout(new javax.swing.BoxLayout(xPanel3, javax.swing.BoxLayout.X_AXIS));

        xPanel3.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        xPanel3.setOpaque(true);
        xPanel3.setPadding(new java.awt.Insets(7, 5, 5, 10));
        xPanel3.add(xGlue1);

        xButton1.setIconResource("shared/images/16/next.png");
        xButton1.setAlt('n');
        xButton1.setDefaultFocusInWindow(true);
        xButton1.setOnclick("doCheckRemote");
        xButton1.setText("Next");
        xPanel3.add(xButton1);

        xPanel3.add(xStrut1);

        xButton2.setIconResource("shared/images/16/close.png");
        xButton2.setAlt('c');
        xButton2.setOnclick("doClose");
        xButton2.setText("Cancel");
        xPanel3.add(xButton2);

        add(xPanel3, java.awt.BorderLayout.SOUTH);

    }// </editor-fold>//GEN-END:initComponents
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private com.rameses.osiris.client.component.XButton xButton1;
    private com.rameses.osiris.client.component.XButton xButton2;
    private com.rameses.osiris.client.component.spacer.XGlue xGlue1;
    private com.rameses.osiris.client.component.XLabel xLabel1;
    private com.rameses.osiris.client.component.XOption xOption1;
    private com.rameses.osiris.client.component.XOption xOption2;
    private com.rameses.osiris.client.component.XPanel xPanel1;
    private com.rameses.osiris.client.component.XPanel xPanel3;
    private com.rameses.osiris.client.component.spacer.XStrut xStrut1;
    private com.rameses.osiris.client.component.XTextField xTextField1;
    private com.rameses.osiris.client.component.template.XTitleHeader xTitleHeader1;
    // End of variables declaration//GEN-END:variables
    
}
