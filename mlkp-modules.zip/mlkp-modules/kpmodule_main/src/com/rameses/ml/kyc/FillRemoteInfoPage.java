package com.rameses.ml.kyc;

import com.rameses.osiris.client.component.ComboEntry;

public class FillRemoteInfoPage extends com.rameses.osiris.client.Page
{
    
    /** Creates new form DefaultPage */
    public FillRemoteInfoPage()
{
        initComponents();
    }
    
    // <editor-fold defaultstate="collapsed" desc=" Generated Code ">//GEN-BEGIN:initComponents
    private void initComponents() {
        xTitleHeader1 = new com.rameses.osiris.client.component.template.XTitleHeader();
        xPanel1 = new com.rameses.osiris.client.component.XPanel();
        xLabel1 = new com.rameses.osiris.client.component.XLabel();
        xLabel2 = new com.rameses.osiris.client.component.XLabel();
        xLabel3 = new com.rameses.osiris.client.component.XLabel();
        xLabel4 = new com.rameses.osiris.client.component.XLabel();
        xLabel5 = new com.rameses.osiris.client.component.XLabel();
        xTextField1 = new com.rameses.osiris.client.component.XTextField();
        xTextField2 = new com.rameses.osiris.client.component.XTextField();
        xTextField3 = new com.rameses.osiris.client.component.XTextField();
        xCombo1 = new com.rameses.osiris.client.component.XCombo();
        xPanel3 = new com.rameses.osiris.client.component.XPanel();
        xGlue1 = new com.rameses.osiris.client.component.spacer.XGlue();
        xButton3 = new com.rameses.osiris.client.component.XButton();
        xStrut2 = new com.rameses.osiris.client.component.spacer.XStrut();
        xButton1 = new com.rameses.osiris.client.component.XButton();
        xStrut1 = new com.rameses.osiris.client.component.spacer.XStrut();
        xButton2 = new com.rameses.osiris.client.component.XButton();

        setLayout(new java.awt.BorderLayout());

        setBackground(new java.awt.Color(255, 255, 255));
        setPreferredSize(new java.awt.Dimension(529, 409));
        xTitleHeader1.setText("Know-Your-Customer");
        add(xTitleHeader1, java.awt.BorderLayout.NORTH);

        xPanel1.setLayout(null);

        xLabel1.setText("<html><b>Please provide the remote information below:</b></html>");
        xPanel1.add(xLabel1);
        xLabel1.setBounds(27, 33, 300, 18);

        xLabel2.setText("<html>Branch <font color=\"red\">*</font> :</html>");
        xPanel1.add(xLabel2);
        xLabel2.setBounds(63, 72, 63, 14);

        xLabel3.setText("<html>Operator <font color=\"red\">*</font> :</html>");
        xPanel1.add(xLabel3);
        xLabel3.setBounds(63, 96, 63, 14);

        xLabel4.setText("<html>Terminal Key <font color=\"red\">*</font> :</html>");
        xPanel1.add(xLabel4);
        xLabel4.setBounds(63, 120, 93, 14);

        xLabel5.setText("<html>Reason <font color=\"red\">*</font> :</html>");
        xPanel1.add(xLabel5);
        xLabel5.setBounds(63, 144, 78, 14);

        xTextField1.setModelName("kyc");
        xTextField1.setName("branchid");
        xPanel1.add(xTextField1);
        xTextField1.setBounds(162, 69, 171, 19);

        xTextField2.setModelName("kyc");
        xTextField2.setName("userid");
        xPanel1.add(xTextField2);
        xTextField2.setBounds(162, 93, 171, 19);

        xTextField3.setModelName("kyc");
        xTextField3.setName("terminalid");
        xPanel1.add(xTextField3);
        xTextField3.setBounds(162, 117, 171, 19);

        xCombo1.setModelName("kyc");
        xCombo1.setEntries(new ComboEntry[]
            {
                new ComboEntry("0", "Offline Branch"),
                new ComboEntry("1", "VPN Connection Down"),
                new ComboEntry("2", "Program Error"),
                new ComboEntry("3", "Others")
            });
            xCombo1.setName("asstreason");
            xPanel1.add(xCombo1);
            xCombo1.setBounds(162, 141, 171, 22);

            add(xPanel1, java.awt.BorderLayout.CENTER);

            xPanel3.setLayout(new javax.swing.BoxLayout(xPanel3, javax.swing.BoxLayout.X_AXIS));

            xPanel3.setBorder(javax.swing.BorderFactory.createEtchedBorder());
            xPanel3.setOpaque(true);
            xPanel3.setPadding(new java.awt.Insets(7, 5, 5, 10));
            xPanel3.add(xGlue1);

            xButton3.setIconResource("shared/images/16/back.png");
            xButton3.setAlt('b');
            xButton3.setOnclick("gotoPage('default')");
            xButton3.setText("Back");
            xPanel3.add(xButton3);

            xStrut2.setLength(5);
            xPanel3.add(xStrut2);

            xButton1.setIconResource("shared/images/16/next.png");
            xButton1.setAlt('n');
            xButton1.setDefaultFocusInWindow(true);
            xButton1.setOnclick("doValidateRemoteInfo");
            xButton1.setText("Next");
            xPanel3.add(xButton1);

            xPanel3.add(xStrut1);

            xButton2.setIconResource("shared/images/16/close.png");
            xButton2.setAlt('c');
            xButton2.setOnclick("doClose");
            xButton2.setText("Cancel");
            xPanel3.add(xButton2);

            add(xPanel3, java.awt.BorderLayout.SOUTH);

        }// </editor-fold>//GEN-END:initComponents
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private com.rameses.osiris.client.component.XButton xButton1;
    private com.rameses.osiris.client.component.XButton xButton2;
    private com.rameses.osiris.client.component.XButton xButton3;
    private com.rameses.osiris.client.component.XCombo xCombo1;
    private com.rameses.osiris.client.component.spacer.XGlue xGlue1;
    private com.rameses.osiris.client.component.XLabel xLabel1;
    private com.rameses.osiris.client.component.XLabel xLabel2;
    private com.rameses.osiris.client.component.XLabel xLabel3;
    private com.rameses.osiris.client.component.XLabel xLabel4;
    private com.rameses.osiris.client.component.XLabel xLabel5;
    private com.rameses.osiris.client.component.XPanel xPanel1;
    private com.rameses.osiris.client.component.XPanel xPanel3;
    private com.rameses.osiris.client.component.spacer.XStrut xStrut1;
    private com.rameses.osiris.client.component.spacer.XStrut xStrut2;
    private com.rameses.osiris.client.component.XTextField xTextField1;
    private com.rameses.osiris.client.component.XTextField xTextField2;
    private com.rameses.osiris.client.component.XTextField xTextField3;
    private com.rameses.osiris.client.component.template.XTitleHeader xTitleHeader1;
    // End of variables declaration//GEN-END:variables
    
}
