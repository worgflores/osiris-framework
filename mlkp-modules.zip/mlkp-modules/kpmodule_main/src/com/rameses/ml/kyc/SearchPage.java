package com.rameses.ml.kyc;

public class SearchPage extends com.rameses.osiris.client.Page
{
    
    /** Creates new form DefaultPage */
    public SearchPage()
{
        initComponents();
    }
    
    // <editor-fold defaultstate="collapsed" desc=" Generated Code ">//GEN-BEGIN:initComponents
    private void initComponents() {
        xTitleHeader1 = new com.rameses.osiris.client.component.template.XTitleHeader();
        xPanel1 = new com.rameses.osiris.client.component.XPanel();
        xPanel2 = new com.rameses.osiris.client.component.XPanel();
        xLabel1 = new com.rameses.osiris.client.component.XLabel();
        xTextField1 = new com.rameses.osiris.client.component.XTextField();
        xPanel4 = new com.rameses.osiris.client.component.XPanel();
        xLabel2 = new com.rameses.osiris.client.component.XLabel();
        xLabel3 = new com.rameses.osiris.client.component.XLabel();
        xLabel4 = new com.rameses.osiris.client.component.XLabel();
        xTextField2 = new com.rameses.osiris.client.component.XTextField();
        xTextField3 = new com.rameses.osiris.client.component.XTextField();
        xTextField4 = new com.rameses.osiris.client.component.XTextField();
        xPanel3 = new com.rameses.osiris.client.component.XPanel();
        xGlue1 = new com.rameses.osiris.client.component.spacer.XGlue();
        xButton3 = new com.rameses.osiris.client.component.XButton();
        xStrut2 = new com.rameses.osiris.client.component.spacer.XStrut();
        xButton1 = new com.rameses.osiris.client.component.XButton();
        xStrut1 = new com.rameses.osiris.client.component.spacer.XStrut();
        xButton2 = new com.rameses.osiris.client.component.XButton();

        setLayout(new java.awt.BorderLayout());

        setBackground(new java.awt.Color(255, 255, 255));
        setPreferredSize(new java.awt.Dimension(529, 409));
        xTitleHeader1.setText("Know-Your-Customer");
        add(xTitleHeader1, java.awt.BorderLayout.NORTH);

        xPanel1.setLayout(null);

        xPanel2.setLayout(null);

        xPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(" Search By KYC Number "));
        xLabel1.setText("KYC No. :");
        xPanel2.add(xLabel1);
        xLabel1.setBounds(27, 39, 63, 14);

        xTextField1.setDefaultFocus(true);
        xTextField1.setName("kycid");
        xPanel2.add(xTextField1);
        xTextField1.setBounds(117, 36, 201, 19);

        xPanel1.add(xPanel2);
        xPanel2.setBounds(18, 18, 615, 87);

        xPanel4.setLayout(null);

        xPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder(" Search By Customer Name "));
        xLabel2.setText("Last Name :");
        xPanel4.add(xLabel2);
        xLabel2.setBounds(27, 39, 72, 14);

        xLabel3.setText("First Name :");
        xPanel4.add(xLabel3);
        xLabel3.setBounds(27, 63, 72, 14);

        xLabel4.setText("Birth Date :");
        xPanel4.add(xLabel4);
        xLabel4.setBounds(27, 87, 72, 14);

        xTextField2.setName("lastname");
        xPanel4.add(xTextField2);
        xTextField2.setBounds(117, 36, 201, 19);

        xTextField3.setName("firstname");
        xPanel4.add(xTextField3);
        xTextField3.setBounds(117, 60, 201, 19);

        xTextField4.setFormat("####-##-##");
        xTextField4.setName("birthdate");
        xTextField4.setType("mask");
        xPanel4.add(xTextField4);
        xTextField4.setBounds(117, 84, 201, 19);

        xPanel1.add(xPanel4);
        xPanel4.setBounds(18, 111, 615, 135);

        add(xPanel1, java.awt.BorderLayout.CENTER);

        xPanel3.setLayout(new javax.swing.BoxLayout(xPanel3, javax.swing.BoxLayout.X_AXIS));

        xPanel3.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        xPanel3.setOpaque(true);
        xPanel3.setPadding(new java.awt.Insets(7, 5, 5, 10));
        xPanel3.add(xGlue1);

        xButton3.setIconResource("shared/images/16/back.png");
        xButton3.setAlt('b');
        xButton3.setOnclick("gotoPage('purposeoption')");
        xButton3.setText("Back");
        xPanel3.add(xButton3);

        xStrut2.setLength(5);
        xPanel3.add(xStrut2);

        xButton1.setIconResource("shared/images/16/next.png");
        xButton1.setAlt('n');
        xButton1.setDefaultFocusInWindow(true);
        xButton1.setOnclick("searchKYC");
        xButton1.setText("Next");
        xPanel3.add(xButton1);

        xPanel3.add(xStrut1);

        xButton2.setIconResource("shared/images/16/close.png");
        xButton2.setAlt('c');
        xButton2.setOnclick("doClose");
        xButton2.setText("Cancel");
        xPanel3.add(xButton2);

        add(xPanel3, java.awt.BorderLayout.SOUTH);

    }// </editor-fold>//GEN-END:initComponents
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private com.rameses.osiris.client.component.XButton xButton1;
    private com.rameses.osiris.client.component.XButton xButton2;
    private com.rameses.osiris.client.component.XButton xButton3;
    private com.rameses.osiris.client.component.spacer.XGlue xGlue1;
    private com.rameses.osiris.client.component.XLabel xLabel1;
    private com.rameses.osiris.client.component.XLabel xLabel2;
    private com.rameses.osiris.client.component.XLabel xLabel3;
    private com.rameses.osiris.client.component.XLabel xLabel4;
    private com.rameses.osiris.client.component.XPanel xPanel1;
    private com.rameses.osiris.client.component.XPanel xPanel2;
    private com.rameses.osiris.client.component.XPanel xPanel3;
    private com.rameses.osiris.client.component.XPanel xPanel4;
    private com.rameses.osiris.client.component.spacer.XStrut xStrut1;
    private com.rameses.osiris.client.component.spacer.XStrut xStrut2;
    private com.rameses.osiris.client.component.XTextField xTextField1;
    private com.rameses.osiris.client.component.XTextField xTextField2;
    private com.rameses.osiris.client.component.XTextField xTextField3;
    private com.rameses.osiris.client.component.XTextField xTextField4;
    private com.rameses.osiris.client.component.template.XTitleHeader xTitleHeader1;
    // End of variables declaration//GEN-END:variables
    
}
