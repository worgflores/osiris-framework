package com.rameses.ml.kyc;

import com.rameses.osiris.client.component.ComboEntry;

public class NewPage extends com.rameses.osiris.client.Page
{
    
    /** Creates new form DefaultPage */
    public NewPage()
{
        initComponents();
    }
    
    // <editor-fold defaultstate="collapsed" desc=" Generated Code ">//GEN-BEGIN:initComponents
    private void initComponents() {
        xTitleHeader1 = new com.rameses.osiris.client.component.template.XTitleHeader();
        xPanel1 = new com.rameses.osiris.client.component.XPanel();
        xLabel1 = new com.rameses.osiris.client.component.XLabel();
        xPanel2 = new com.rameses.osiris.client.component.XPanel();
        xLabel2 = new com.rameses.osiris.client.component.XLabel();
        xLabel011 = new com.rameses.osiris.client.component.template.XLabel01();
        xLabel3 = new com.rameses.osiris.client.component.XLabel();
        xLabel12 = new com.rameses.osiris.client.component.template.XLabel01();
        xLabel4 = new com.rameses.osiris.client.component.XLabel();
        xTextField1 = new com.rameses.osiris.client.component.XTextField();
        xLabel5 = new com.rameses.osiris.client.component.XLabel();
        xLabel13 = new com.rameses.osiris.client.component.template.XLabel01();
        xLabel6 = new com.rameses.osiris.client.component.XLabel();
        xLabel7 = new com.rameses.osiris.client.component.XLabel();
        xLabel8 = new com.rameses.osiris.client.component.XLabel();
        xCombo1 = new com.rameses.osiris.client.component.XCombo();
        xTextField2 = new com.rameses.osiris.client.component.XTextField();
        xTextField3 = new com.rameses.osiris.client.component.XTextField();
        xPanel3 = new com.rameses.osiris.client.component.XPanel();
        xGlue1 = new com.rameses.osiris.client.component.spacer.XGlue();
        xButton3 = new com.rameses.osiris.client.component.XButton();
        xStrut2 = new com.rameses.osiris.client.component.spacer.XStrut();
        xButton1 = new com.rameses.osiris.client.component.XButton();
        xStrut1 = new com.rameses.osiris.client.component.spacer.XStrut();
        xButton2 = new com.rameses.osiris.client.component.XButton();

        setLayout(new java.awt.BorderLayout());

        setBackground(new java.awt.Color(255, 255, 255));
        setPreferredSize(new java.awt.Dimension(529, 409));
        xTitleHeader1.setText("Know-Your-Customer");
        add(xTitleHeader1, java.awt.BorderLayout.NORTH);

        xPanel1.setLayout(null);

        xLabel1.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        xLabel1.setFont(new java.awt.Font("Tahoma", 1, 12));
        xLabel1.setForeground(new java.awt.Color(230, 0, 0));
        xLabel1.setText("<html>Customer is not existing on the database. Please verify if the entries are correct. </html>");
        xPanel1.add(xLabel1);
        xLabel1.setBounds(21, 18, 483, 45);

        xPanel2.setLayout(null);

        xPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(" Customer Information "));
        xLabel2.setText("Last Name : ");
        xPanel2.add(xLabel2);
        xLabel2.setBounds(27, 33, 66, 14);

        xLabel011.setName("lastname");
        xLabel011.setText("lastname");
        xPanel2.add(xLabel011);
        xLabel011.setBounds(132, 30, 160, 19);

        xLabel3.setText("First Name :");
        xPanel2.add(xLabel3);
        xLabel3.setBounds(27, 54, 66, 14);

        xLabel12.setName("firstname");
        xLabel12.setText("firstname");
        xPanel2.add(xLabel12);
        xLabel12.setBounds(132, 51, 160, 19);

        xLabel4.setText("<html>Middle Name <font color=\"red\">*</font> :</html>");
        xPanel2.add(xLabel4);
        xLabel4.setBounds(27, 75, 90, 18);

        xTextField1.setDefaultFocus(true);
        xTextField1.setName("middlename");
        xPanel2.add(xTextField1);
        xTextField1.setBounds(132, 75, 159, 19);

        xLabel5.setText("Birth Date : ");
        xPanel2.add(xLabel5);
        xLabel5.setBounds(27, 102, 66, 14);

        xLabel13.setName("birthdate");
        xLabel13.setText("birthdate");
        xPanel2.add(xLabel13);
        xLabel13.setBounds(132, 99, 160, 19);

        xLabel6.setText("<html>ID Type <font color=\"red\">*</font> :</html>");
        xPanel2.add(xLabel6);
        xLabel6.setBounds(27, 144, 93, 14);

        xLabel7.setText("<html>ID Number <font color=\"red\">*</font> :</html>");
        xPanel2.add(xLabel7);
        xLabel7.setBounds(27, 165, 93, 14);

        xLabel8.setText("<html>Expiry Date <font color=\"red\">*</font> :</html>");
        xPanel2.add(xLabel8);
        xLabel8.setBounds(27, 186, 93, 14);

        xCombo1.setEntries(new ComboEntry[]
            {
                new ComboEntry("CREDITID", "CREDIT CARD ID"),
                new ComboEntry("DRIVERLIC", "DRIVER'S LICENSE"),
                new ComboEntry("EMPID", "EMPLOYMENT ID"),
                new ComboEntry("GOVTID", "OTHER GOVERNMENT ISSUED ID"),
                new ComboEntry("GSIS", "GSIS"),
                new ComboEntry("NBIC", "NBI CLEARANCE"),
                new ComboEntry("PASSPORT", "PASSPORT"),
                new ComboEntry("PC", "POLICE CLEARANCE"),
                new ComboEntry("POSTAL", "POSTAL ID"),
                new ComboEntry("PRC", "PRC"),
                new ComboEntry("SCHOOLID", "SCHOOL ID"),
                new ComboEntry("SENIORID", "SENIOR CITIZEN ID"),
                new ComboEntry("SSS", "SSS"),
                new ComboEntry("TIN", "TAX IDENTIFICATION ID"),
                new ComboEntry("VOTERID", "NEW VOTER'S ID"),
                new ComboEntry("OTHER", "OTHERS"),
                new ComboEntry("", "")
            }
        );
        xCombo1.setName("idtype");
        xPanel2.add(xCombo1);
        xCombo1.setBounds(132, 138, 231, 22);

        xTextField2.setName("idno");
        xPanel2.add(xTextField2);
        xTextField2.setBounds(132, 162, 231, 19);

        xTextField3.setFormat("####-##-##");
        xTextField3.setName("idexpiry");
        xTextField3.setType("mask");
        xPanel2.add(xTextField3);
        xTextField3.setBounds(132, 183, 159, 19);

        xPanel1.add(xPanel2);
        xPanel2.setBounds(18, 57, 609, 285);

        add(xPanel1, java.awt.BorderLayout.CENTER);

        xPanel3.setLayout(new javax.swing.BoxLayout(xPanel3, javax.swing.BoxLayout.X_AXIS));

        xPanel3.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        xPanel3.setOpaque(true);
        xPanel3.setPadding(new java.awt.Insets(7, 5, 5, 10));
        xPanel3.add(xGlue1);

        xButton3.setIconResource("shared/images/16/back.png");
        xButton3.setAlt('b');
        xButton3.setOnclick("gotoSearchPageCancel");
        xButton3.setText("Back");
        xPanel3.add(xButton3);

        xStrut2.setLength(5);
        xPanel3.add(xStrut2);

        xButton1.setIconResource("shared/images/16/save.png");
        xButton1.setAlt('n');
        xButton1.setDefaultFocusInWindow(true);
        xButton1.setOnclick("saveKYC");
        xButton1.setText("Save");
        xPanel3.add(xButton1);

        xPanel3.add(xStrut1);

        xButton2.setIconResource("shared/images/16/close.png");
        xButton2.setAlt('c');
        xButton2.setOnclick("doClose");
        xButton2.setText("Cancel");
        xPanel3.add(xButton2);

        add(xPanel3, java.awt.BorderLayout.SOUTH);

    }// </editor-fold>//GEN-END:initComponents
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private com.rameses.osiris.client.component.XButton xButton1;
    private com.rameses.osiris.client.component.XButton xButton2;
    private com.rameses.osiris.client.component.XButton xButton3;
    private com.rameses.osiris.client.component.XCombo xCombo1;
    private com.rameses.osiris.client.component.spacer.XGlue xGlue1;
    private com.rameses.osiris.client.component.template.XLabel01 xLabel011;
    private com.rameses.osiris.client.component.XLabel xLabel1;
    private com.rameses.osiris.client.component.template.XLabel01 xLabel12;
    private com.rameses.osiris.client.component.template.XLabel01 xLabel13;
    private com.rameses.osiris.client.component.XLabel xLabel2;
    private com.rameses.osiris.client.component.XLabel xLabel3;
    private com.rameses.osiris.client.component.XLabel xLabel4;
    private com.rameses.osiris.client.component.XLabel xLabel5;
    private com.rameses.osiris.client.component.XLabel xLabel6;
    private com.rameses.osiris.client.component.XLabel xLabel7;
    private com.rameses.osiris.client.component.XLabel xLabel8;
    private com.rameses.osiris.client.component.XPanel xPanel1;
    private com.rameses.osiris.client.component.XPanel xPanel2;
    private com.rameses.osiris.client.component.XPanel xPanel3;
    private com.rameses.osiris.client.component.spacer.XStrut xStrut1;
    private com.rameses.osiris.client.component.spacer.XStrut xStrut2;
    private com.rameses.osiris.client.component.XTextField xTextField1;
    private com.rameses.osiris.client.component.XTextField xTextField2;
    private com.rameses.osiris.client.component.XTextField xTextField3;
    private com.rameses.osiris.client.component.template.XTitleHeader xTitleHeader1;
    // End of variables declaration//GEN-END:variables
    
}
