package com.rameses.ml.kyc;

import com.rameses.osiris.client.component.ComboEntry;

public class EditPage extends com.rameses.osiris.client.Page
{
    
    /** Creates new form DefaultPage */
    public EditPage()
{
        initComponents();
    }
    
    // <editor-fold defaultstate="collapsed" desc=" Generated Code ">//GEN-BEGIN:initComponents
    private void initComponents() {
        xPanel1 = new com.rameses.osiris.client.component.XPanel();
        xPanel2 = new com.rameses.osiris.client.component.XPanel();
        xLabel2 = new com.rameses.osiris.client.component.XLabel();
        xLabel011 = new com.rameses.osiris.client.component.template.XLabel01();
        xLabel3 = new com.rameses.osiris.client.component.XLabel();
        xLabel12 = new com.rameses.osiris.client.component.template.XLabel01();
        xLabel4 = new com.rameses.osiris.client.component.XLabel();
        xLabel13 = new com.rameses.osiris.client.component.template.XLabel01();
        xLabel5 = new com.rameses.osiris.client.component.XLabel();
        xLabel14 = new com.rameses.osiris.client.component.template.XLabel01();
        xPanel4 = new com.rameses.osiris.client.component.XPanel();
        xLabel6 = new com.rameses.osiris.client.component.XLabel();
        xLabel7 = new com.rameses.osiris.client.component.XLabel();
        xLabel15 = new com.rameses.osiris.client.component.template.XLabel01();
        xLabel16 = new com.rameses.osiris.client.component.template.XLabel01();
        xLabel17 = new com.rameses.osiris.client.component.template.XLabel01();
        xLabel18 = new com.rameses.osiris.client.component.template.XLabel01();
        xLabel11 = new com.rameses.osiris.client.component.XLabel();
        xLabel22 = new com.rameses.osiris.client.component.XLabel();
        xLabel23 = new com.rameses.osiris.client.component.XLabel();
        xPanel5 = new com.rameses.osiris.client.component.XPanel();
        xLabel8 = new com.rameses.osiris.client.component.XLabel();
        xCombo1 = new com.rameses.osiris.client.component.XCombo();
        xLabel9 = new com.rameses.osiris.client.component.XLabel();
        xLabel10 = new com.rameses.osiris.client.component.XLabel();
        xTextField2 = new com.rameses.osiris.client.component.XTextField();
        xTextField3 = new com.rameses.osiris.client.component.XTextField();
        xTextField1 = new com.rameses.osiris.client.component.XTextField();
        xPanel3 = new com.rameses.osiris.client.component.XPanel();
        xTitleHeader1 = new com.rameses.osiris.client.component.template.XTitleHeader();
        xToolbar1 = new com.rameses.osiris.client.component.XToolbar();
        xButton6 = new com.rameses.osiris.client.component.XButton();
        xButton2 = new com.rameses.osiris.client.component.XButton();

        setLayout(new java.awt.BorderLayout());

        setBackground(new java.awt.Color(255, 255, 255));
        setPreferredSize(new java.awt.Dimension(654, 450));
        xPanel1.setLayout(null);

        xPanel2.setLayout(null);

        xPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(" General Information "));
        xLabel2.setFont(new java.awt.Font("Tahoma", 1, 11));
        xLabel2.setText("KYC No. :");
        xPanel2.add(xLabel2);
        xLabel2.setBounds(27, 27, 66, 14);

        xLabel011.setFont(new java.awt.Font("Courier New", 1, 16));
        xLabel011.setForeground(new java.awt.Color(204, 0, 51));
        xLabel011.setModelName("kyc");
        xLabel011.setName("kycid");
        xLabel011.setText("0000000001");
        xPanel2.add(xLabel011);
        xLabel011.setBounds(132, 24, 150, 19);

        xLabel3.setText("Date Filed : ");
        xPanel2.add(xLabel3);
        xLabel3.setBounds(27, 48, 66, 14);

        xLabel12.setModelName("kyc");
        xLabel12.setName("dtfiled");
        xLabel12.setText("2008-01-01 00:00:00");
        xPanel2.add(xLabel12);
        xLabel12.setBounds(132, 45, 150, 19);

        xLabel4.setText("Registering Branch : ");
        xPanel2.add(xLabel4);
        xLabel4.setBounds(324, 27, 111, 14);

        xLabel13.setModelName("kyc");
        xLabel13.setName("branchid");
        xLabel13.setText("branchid");
        xPanel2.add(xLabel13);
        xLabel13.setBounds(438, 24, 150, 19);

        xLabel5.setText("Attending FLA :");
        xPanel2.add(xLabel5);
        xLabel5.setBounds(324, 48, 111, 14);

        xLabel14.setModelName("kyc");
        xLabel14.setName("userid");
        xLabel14.setText("userid");
        xPanel2.add(xLabel14);
        xLabel14.setBounds(438, 45, 150, 19);

        xPanel1.add(xPanel2);
        xPanel2.setBounds(15, 12, 621, 84);

        xPanel4.setLayout(null);

        xPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder(" Customer Information "));
        xLabel6.setText("Name :");
        xPanel4.add(xLabel6);
        xLabel6.setBounds(27, 30, 84, 14);

        xLabel7.setText("Birth Date :");
        xPanel4.add(xLabel7);
        xLabel7.setBounds(27, 72, 66, 14);

        xLabel15.setModelName("kyc");
        xLabel15.setName("lastname");
        xLabel15.setText("lastname");
        xPanel4.add(xLabel15);
        xLabel15.setBounds(132, 27, 150, 19);

        xLabel16.setModelName("kyc");
        xLabel16.setName("firstname");
        xLabel16.setText("firstname");
        xPanel4.add(xLabel16);
        xLabel16.setBounds(285, 27, 150, 19);

        xLabel17.setModelName("kyc");
        xLabel17.setName("middlename");
        xLabel17.setText("middlename");
        xPanel4.add(xLabel17);
        xLabel17.setBounds(438, 27, 150, 19);

        xLabel18.setModelName("kyc");
        xLabel18.setName("birthdate");
        xLabel18.setText("birthdate");
        xPanel4.add(xLabel18);
        xLabel18.setBounds(132, 69, 150, 19);

        xLabel11.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        xLabel11.setText("( Last Name )");
        xPanel4.add(xLabel11);
        xLabel11.setBounds(132, 45, 150, 14);

        xLabel22.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        xLabel22.setText("( First Name )");
        xPanel4.add(xLabel22);
        xLabel22.setBounds(285, 45, 150, 14);

        xLabel23.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        xLabel23.setText("( Middle Name )");
        xPanel4.add(xLabel23);
        xLabel23.setBounds(438, 45, 147, 14);

        xPanel1.add(xPanel4);
        xPanel4.setBounds(15, 96, 621, 105);

        xPanel5.setLayout(null);

        xPanel5.setBorder(javax.swing.BorderFactory.createTitledBorder(" Card ID Information "));
        xLabel8.setText("ID Type :");
        xPanel5.add(xLabel8);
        xLabel8.setBounds(27, 27, 66, 14);

        xCombo1.setDefaultFocus(true);
        xCombo1.setEntries(new ComboEntry[]
            {
                new ComboEntry("CREDITID", "CREDIT CARD ID"),
                new ComboEntry("DRIVERLIC", "DRIVER'S LICENSE"),
                new ComboEntry("EMPID", "EMPLOYMENT ID"),
                new ComboEntry("GOVTID", "OTHER GOVERNMENT ISSUED ID"),
                new ComboEntry("GSIS", "GSIS"),
                new ComboEntry("NBIC", "NBI CLEARANCE"),
                new ComboEntry("PASSPORT", "PASSPORT"),
                new ComboEntry("PC", "POLICE CLEARANCE"),
                new ComboEntry("POSTAL", "POSTAL ID"),
                new ComboEntry("PRC", "PRC"),
                new ComboEntry("SCHOOLID", "SCHOOL ID"),
                new ComboEntry("SENIORID", "SENIOR CITIZEN ID"),
                new ComboEntry("SSS", "SSS"),
                new ComboEntry("TIN", "TAX IDENTIFICATION ID"),
                new ComboEntry("VOTERID", "NEW VOTER'S ID"),
                new ComboEntry("OTHER", "OTHERS"),
                new ComboEntry("", "")
            }
        );
        xCombo1.setName("idtype_");
        xPanel5.add(xCombo1);
        xCombo1.setBounds(132, 24, 234, 22);

        xLabel9.setText("ID Number : ");
        xPanel5.add(xLabel9);
        xLabel9.setBounds(27, 51, 81, 14);

        xLabel10.setText("Expiry Date :");
        xPanel5.add(xLabel10);
        xLabel10.setBounds(27, 72, 81, 14);

        xTextField2.setName("idno_");
        xPanel5.add(xTextField2);
        xTextField2.setBounds(132, 48, 234, 19);

        xTextField3.setFormat("####-##-##");
        xTextField3.setName("idexpiry_");
        xTextField3.setType("mask");
        xPanel5.add(xTextField3);
        xTextField3.setBounds(132, 69, 147, 19);

        xPanel1.add(xPanel5);
        xPanel5.setBounds(15, 201, 621, 114);

        xTextField1.setName("dummy");
        xPanel1.add(xTextField1);
        xTextField1.setBounds(-20, 1, 11, 19);

        add(xPanel1, java.awt.BorderLayout.CENTER);

        xPanel3.setLayout(new java.awt.BorderLayout());

        xTitleHeader1.setText("Know-Your-Customer (Edit)");
        xPanel3.add(xTitleHeader1, java.awt.BorderLayout.SOUTH);

        xButton6.setIconResource("shared/images/16/save.png");
        xButton6.setAlt('s');
        xButton6.setOnclick("doUpdateIDInformation");
        xButton6.setText("Save   ");
        xToolbar1.add(xButton6);

        xButton2.setIconResource("shared/images/16/close.png");
        xButton2.setAlt('c');
        xButton2.setOnclick("doCancelEdit");
        xButton2.setText("Cancel");
        xToolbar1.add(xButton2);

        xPanel3.add(xToolbar1, java.awt.BorderLayout.NORTH);

        add(xPanel3, java.awt.BorderLayout.NORTH);

    }// </editor-fold>//GEN-END:initComponents
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private com.rameses.osiris.client.component.XButton xButton2;
    private com.rameses.osiris.client.component.XButton xButton6;
    private com.rameses.osiris.client.component.XCombo xCombo1;
    private com.rameses.osiris.client.component.template.XLabel01 xLabel011;
    private com.rameses.osiris.client.component.XLabel xLabel10;
    private com.rameses.osiris.client.component.XLabel xLabel11;
    private com.rameses.osiris.client.component.template.XLabel01 xLabel12;
    private com.rameses.osiris.client.component.template.XLabel01 xLabel13;
    private com.rameses.osiris.client.component.template.XLabel01 xLabel14;
    private com.rameses.osiris.client.component.template.XLabel01 xLabel15;
    private com.rameses.osiris.client.component.template.XLabel01 xLabel16;
    private com.rameses.osiris.client.component.template.XLabel01 xLabel17;
    private com.rameses.osiris.client.component.template.XLabel01 xLabel18;
    private com.rameses.osiris.client.component.XLabel xLabel2;
    private com.rameses.osiris.client.component.XLabel xLabel22;
    private com.rameses.osiris.client.component.XLabel xLabel23;
    private com.rameses.osiris.client.component.XLabel xLabel3;
    private com.rameses.osiris.client.component.XLabel xLabel4;
    private com.rameses.osiris.client.component.XLabel xLabel5;
    private com.rameses.osiris.client.component.XLabel xLabel6;
    private com.rameses.osiris.client.component.XLabel xLabel7;
    private com.rameses.osiris.client.component.XLabel xLabel8;
    private com.rameses.osiris.client.component.XLabel xLabel9;
    private com.rameses.osiris.client.component.XPanel xPanel1;
    private com.rameses.osiris.client.component.XPanel xPanel2;
    private com.rameses.osiris.client.component.XPanel xPanel3;
    private com.rameses.osiris.client.component.XPanel xPanel4;
    private com.rameses.osiris.client.component.XPanel xPanel5;
    private com.rameses.osiris.client.component.XTextField xTextField1;
    private com.rameses.osiris.client.component.XTextField xTextField2;
    private com.rameses.osiris.client.component.XTextField xTextField3;
    private com.rameses.osiris.client.component.template.XTitleHeader xTitleHeader1;
    private com.rameses.osiris.client.component.XToolbar xToolbar1;
    // End of variables declaration//GEN-END:variables
    
}
