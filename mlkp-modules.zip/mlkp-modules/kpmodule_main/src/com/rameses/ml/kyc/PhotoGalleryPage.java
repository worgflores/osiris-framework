package com.rameses.ml.kyc;

import com.rameses.osiris.client.component.ComboEntry;

public class PhotoGalleryPage extends com.rameses.osiris.client.Page
{
    
    /** Creates new form DefaultPage */
    public PhotoGalleryPage()
{
        initComponents();
    }
    
    // <editor-fold defaultstate="collapsed" desc=" Generated Code ">//GEN-BEGIN:initComponents
    private void initComponents() {
        xPanel1 = new com.rameses.osiris.client.component.XPanel();
        xButton3 = new com.rameses.osiris.client.component.XButton();
        xPanel2 = new com.rameses.osiris.client.component.XPanel();
        xLabel3 = new com.rameses.osiris.client.component.XLabel();
        xTextField1 = new com.rameses.osiris.client.component.XTextField();
        xLabel1 = new com.rameses.osiris.client.component.XLabel();
        xButton4 = new com.rameses.osiris.client.component.XButton();
        xButton5 = new com.rameses.osiris.client.component.XButton();
        xButton6 = new com.rameses.osiris.client.component.XButton();
        xButton7 = new com.rameses.osiris.client.component.XButton();
        xLabel2 = new com.rameses.osiris.client.component.XLabel();
        xButton8 = new com.rameses.osiris.client.component.XButton();
        xButton9 = new com.rameses.osiris.client.component.XButton();
        xButton10 = new com.rameses.osiris.client.component.XButton();
        xButton11 = new com.rameses.osiris.client.component.XButton();
        xButton12 = new com.rameses.osiris.client.component.XButton();
        xLabel4 = new com.rameses.osiris.client.component.XLabel();
        xButton13 = new com.rameses.osiris.client.component.XButton();
        xPanel3 = new com.rameses.osiris.client.component.XPanel();
        xTitleHeader1 = new com.rameses.osiris.client.component.template.XTitleHeader();
        xToolbar1 = new com.rameses.osiris.client.component.XToolbar();
        xButton1 = new com.rameses.osiris.client.component.XButton();
        xButton2 = new com.rameses.osiris.client.component.XButton();

        setLayout(new java.awt.BorderLayout());

        setBackground(new java.awt.Color(255, 255, 255));
        setPreferredSize(new java.awt.Dimension(654, 450));
        xPanel1.setLayout(null);

        xPanel1.setOpaque(true);
        xButton3.setOnclick("viewKYCForm");
        xButton3.setText("KYC Form");
        xPanel1.add(xButton3);
        xButton3.setBounds(12, 33, 114, 27);

        xPanel2.setLayout(null);

        xPanel2.setBackground(new java.awt.Color(255, 255, 255));
        xPanel2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        xPanel2.setOpaque(true);
        xLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        xLabel3.setName("photourl");
        xLabel3.setText("photo preview");
        xPanel2.add(xLabel3);
        xLabel3.setBounds(6, 6, 495, 321);

        xPanel1.add(xPanel2);
        xPanel2.setBounds(132, 6, 510, 336);

        xTextField1.setName("dummy");
        xPanel1.add(xTextField1);
        xTextField1.setBounds(-20, 237, 11, 19);

        xLabel1.setBackground(new java.awt.Color(92, 133, 153));
        xLabel1.setFont(new java.awt.Font("Tahoma", 1, 12));
        xLabel1.setForeground(new java.awt.Color(255, 255, 255));
        xLabel1.setOpaque(true);
        xLabel1.setPadding(new java.awt.Insets(2, 5, 2, 2));
        xLabel1.setText("  Preview Photo");
        xPanel1.add(xLabel1);
        xLabel1.setBounds(0, 6, 132, 24);

        xButton4.setOnclick("viewID1");
        xButton4.setText("ID #1");
        xPanel1.add(xButton4);
        xButton4.setBounds(12, 60, 114, 27);

        xButton5.setOnclick("viewID2");
        xButton5.setText("ID #2");
        xPanel1.add(xButton5);
        xButton5.setBounds(12, 87, 114, 27);

        xButton6.setOnclick("viewID3");
        xButton6.setText("ID #3");
        xPanel1.add(xButton6);
        xButton6.setBounds(12, 114, 114, 27);

        xButton7.setOnclick("viewID4");
        xButton7.setText("ID #4");
        xPanel1.add(xButton7);
        xButton7.setBounds(12, 141, 114, 27);

        xLabel2.setBackground(new java.awt.Color(92, 133, 153));
        xLabel2.setFont(new java.awt.Font("Tahoma", 1, 12));
        xLabel2.setForeground(new java.awt.Color(255, 255, 255));
        xLabel2.setOpaque(true);
        xLabel2.setPadding(new java.awt.Insets(2, 5, 2, 2));
        xLabel2.setText("  Upload Photo");
        xPanel1.add(xLabel2);
        xLabel2.setBounds(0, 180, 132, 24);

        xButton8.setOnclick("uploadKYCForm");
        xButton8.setText("KYC Form");
        xPanel1.add(xButton8);
        xButton8.setBounds(12, 207, 114, 27);

        xButton9.setOnclick("uploadID1");
        xButton9.setText("ID #1");
        xPanel1.add(xButton9);
        xButton9.setBounds(12, 234, 114, 27);

        xButton10.setOnclick("uploadID2");
        xButton10.setText("ID #2");
        xPanel1.add(xButton10);
        xButton10.setBounds(12, 261, 114, 27);

        xButton11.setOnclick("uploadID3");
        xButton11.setText("ID #3");
        xPanel1.add(xButton11);
        xButton11.setBounds(12, 288, 114, 27);

        xButton12.setOnclick("uploadID4");
        xButton12.setText("ID #4");
        xPanel1.add(xButton12);
        xButton12.setBounds(12, 315, 114, 27);

        xLabel4.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        xLabel4.setFont(new java.awt.Font("Tahoma", 1, 12));
        xLabel4.setForeground(java.awt.Color.red);
        xLabel4.setName("photomsg");
        xLabel4.setText("This photo needs update...");
        xPanel1.add(xLabel4);
        xLabel4.setBounds(265, 345, 375, 21);

        xButton13.setAlt('v');
        xButton13.setName("btnPreviewPhoto");
        xButton13.setOnclick("doPreviewPhoto");
        xButton13.setText("Preview Actual Photo");
        xPanel1.add(xButton13);
        xButton13.setBounds(135, 345, 141, 27);

        add(xPanel1, java.awt.BorderLayout.CENTER);

        xPanel3.setLayout(new java.awt.BorderLayout());

        xTitleHeader1.setName("customername");
        xTitleHeader1.setText("Photo Gallery : (Customer Name)");
        xPanel3.add(xTitleHeader1, java.awt.BorderLayout.SOUTH);

        xButton1.setIconResource("shared/images/16/back.png");
        xButton1.setAlt('b');
        xButton1.setOnclick("gotoPage('info')");
        xButton1.setText("Back");
        xToolbar1.add(xButton1);

        xButton2.setIconResource("shared/images/16/close.png");
        xButton2.setAlt('c');
        xButton2.setOnclick("doClose");
        xButton2.setText("Close");
        xToolbar1.add(xButton2);

        xPanel3.add(xToolbar1, java.awt.BorderLayout.NORTH);

        add(xPanel3, java.awt.BorderLayout.NORTH);

    }// </editor-fold>//GEN-END:initComponents
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private com.rameses.osiris.client.component.XButton xButton1;
    private com.rameses.osiris.client.component.XButton xButton10;
    private com.rameses.osiris.client.component.XButton xButton11;
    private com.rameses.osiris.client.component.XButton xButton12;
    private com.rameses.osiris.client.component.XButton xButton13;
    private com.rameses.osiris.client.component.XButton xButton2;
    private com.rameses.osiris.client.component.XButton xButton3;
    private com.rameses.osiris.client.component.XButton xButton4;
    private com.rameses.osiris.client.component.XButton xButton5;
    private com.rameses.osiris.client.component.XButton xButton6;
    private com.rameses.osiris.client.component.XButton xButton7;
    private com.rameses.osiris.client.component.XButton xButton8;
    private com.rameses.osiris.client.component.XButton xButton9;
    private com.rameses.osiris.client.component.XLabel xLabel1;
    private com.rameses.osiris.client.component.XLabel xLabel2;
    private com.rameses.osiris.client.component.XLabel xLabel3;
    private com.rameses.osiris.client.component.XLabel xLabel4;
    private com.rameses.osiris.client.component.XPanel xPanel1;
    private com.rameses.osiris.client.component.XPanel xPanel2;
    private com.rameses.osiris.client.component.XPanel xPanel3;
    private com.rameses.osiris.client.component.XTextField xTextField1;
    private com.rameses.osiris.client.component.template.XTitleHeader xTitleHeader1;
    private com.rameses.osiris.client.component.XToolbar xToolbar1;
    // End of variables declaration//GEN-END:variables
    
}
