package speedremit;

import java.util.Iterator;
import junit.framework.*;
import rameses.osiris.client.app.App;
import rameses.osiris.common.interfaces.IDataSetModel;
import rameses.osiris.common.service.Request;
import rameses.osiris.common.service.Response;

public class RuleTest extends TestCase {
    
    public RuleTest(String testName) {
        super(testName);
    }
    
    protected void setUp() throws Exception {
        System.setProperty("app.host", "http://192.168.3.173:8080/mlhuillier/action");
    }
    
    protected void tearDown() throws Exception {
    }
    
    public void testSearch() throws Exception 
    {
        Request req = new Request();
        //req.addParameter("CCREFNO", "ARY3561684038");
        //req.addParameter("CCREFNO", "ARY3590927725");
        //req.addParameter("CCREFNO", "ARY3597782382");
        //req.addParameter("CCREFNO", "ARY3550777181");
        
        Response res = invoke("SPDRMT.test.searchInXml", req);
        System.out.println(res.getValues());
    }

    
    private Response invoke(String command, Request req) throws Exception {
        return App.getServiceManager().invoke(command, req);
    }
}
