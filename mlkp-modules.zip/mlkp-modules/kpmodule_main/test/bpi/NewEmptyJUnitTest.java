package bpi;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import junit.framework.*;
import rameses.osiris.client.app.App;
import rameses.osiris.common.service.Request;
import rameses.osiris.common.service.Response;

public class NewEmptyJUnitTest extends TestCase 
{
    private String HOST = "http://192.168.3.247:8080/mlhuillier/action";
    
    public NewEmptyJUnitTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
    }

    protected void tearDown() throws Exception {
    }
    
    public void test0000() throws Exception 
    {
        String content = getContent(new FileInputStream(new File("bpitxn.txt")));
        Pattern pattern = Pattern.compile("[0-9]{11,11}_[0-9]{10,10}");
        Matcher matcher = pattern.matcher(content);
        StringBuffer sb = new StringBuffer(); 
        
        while (matcher.find())
        {
            String refno = matcher.group(); 
            Map data = execSingleQuery(" select " + 
                                       "    refno, arno, state, date_format(txndate,'%m/%d/%Y') as txndate, " + 
                                       "    date_format(txndate,'%r') as txntime, fdbkcode,  fdbkdesc " + 
                                       " from mlpartner.bpifileupload where refno='"+refno+"' ", "java:mldb"); 
            if (data == null || data.isEmpty()) 
            {
                System.out.println(refno + " not found");
                continue;
            }
            
            String arno = data.get("arno").toString(); 
            String state = data.get("state").toString();
            String txndate = data.get("txndate").toString(); 
            String txntime = data.get("txntime").toString(); 
            String fdbkcode = data.get("fdbkcode").toString(); 
            String fdbkdesc = data.get("fdbkdesc").toString(); 
            //sb.append(refno + "," + arno + "," + state + "," + txndate + "," + txntime + "," + fdbkcode + "," + fdbkdesc + "\n");
            
            if (!"2".equals(state))
                System.out.println(refno + " status is not claimed (" + fdbkcode + ", " + fdbkdesc + ")");
        }
        
        /*
        FileWriter writer = null; 
        try
        {
            writer = new FileWriter(new File("MLHBPI" + new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date()) + ".csv"));
            writer.write(sb.toString());
        }
        catch(Exception ex) {
            throw ex; 
        }
        finally {
            try { writer.close(); }catch(Exception ing){;} 
        }
         */
    }

    private String getContent(InputStream is) throws Exception 
    {
        try
        {
            StringBuffer sb = new StringBuffer(); 
            int read = -1;
            while ((read=is.read()) != -1) {
                sb.append((char) read); 
            }
            return sb.toString(); 
        }
        catch(Exception ex) {
            throw ex;
        }
        finally {
            try { is.close(); }catch(Exception ign){;}
        }        
    }
    
    private Map execSingleQuery(String stmt, String dsname) throws Exception 
    { 
        List list = execQuery(stmt, dsname); 
        if (list != null && list.size() > 0)
            return (Map) list.get(0);
        else
            return null; 
    }         
    
    private List execQuery(String stmt, String dsname) throws Exception 
    { 
        if (stmt == null || stmt.trim().length() == 0) throw new Exception("'stmt' parameter is required");
        if (dsname == null || dsname.trim().length() == 0) throw new Exception("'dsname' parameter is required");
        
        System.getProperties().put("app.host", HOST); 
        
        Request req = new Request(); 
        req.addParameter("DSNAME", dsname); 
        req.addParameter("SQLSTMT", stmt); 
        
        Response res = App.getServiceManager().invoke("system.db.list", req); 
        if ("0".equals(res.getValue("statuscode"))) 
            throw new Exception(res.getValue("statusmsg")+"");
        
        return (List) res.getValue("list"); 
    } 
    
    private Response invoke(String service, Request req) throws Exception 
    { 
        System.getProperties().put("app.host", HOST);
        return App.getServiceManager().invoke(service, req);
    }
    
    private void dump(List list) throws Exception
    {
        System.out.println("");
        
        long counter = 1;
        Iterator itr = list.iterator();
        while (itr.hasNext())
        {
            System.out.println(counter + ") " + itr.next());
            counter += 1;
        }
        System.out.println("");
    }
    
}
