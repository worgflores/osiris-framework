package phandy;

import java.io.File;
import java.io.FileInputStream;
import junit.framework.*;

public class FileTest extends TestCase 
{
    
    public FileTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
    }

    protected void tearDown() throws Exception {
    }
    
    public void test0000() throws Exception 
    {
        FileInputStream fis = null;
        try
        {
            File f = new File("C:/sample1234.txt");     
            fis = new FileInputStream(f); 

            StringBuffer sb = new StringBuffer(); 
            int read = -1;
            while ((read=fis.read()) != -1) 
            {
                System.out.println(read + " -> " + (char) read);
                sb.append((char) read); 
            }
            System.out.println(sb);
        }
        catch(Exception ex) {
            throw ex; 
        }
        finally {
            try { fis.close(); }catch(Exception ing){;} 
        }
        
    }
}
