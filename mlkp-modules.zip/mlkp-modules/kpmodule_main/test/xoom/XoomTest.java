package xoom;

import java.awt.Color;
import java.awt.Font;
import javax.swing.JDialog;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import junit.framework.*;
import rameses.osiris.client.app.App;
import rameses.osiris.common.service.Request;
import rameses.osiris.common.service.Response;

public class XoomTest extends TestCase 
{
    
    public XoomTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
        System.setProperty("app.host", "http://192.168.3.173:8080/mlhuillier/action");
    }

    protected void tearDown() throws Exception {
    }
    
    private Response invoke(String command, Request req) throws Exception {
        return App.getServiceManager().invoke(command, req);
    }    
    
    public void XtestSearchTransaction() throws Exception 
    { 
        Request req = new Request();
        req.addParameter("CCREFNO", "X061851816253126");
        req.addParameter("BRANCHID", "RECLA");
        req.addParameter("USERID", "KPUSER");
        
        Response res = invoke("XOOM.test.searchTransaction", req); 
        System.out.println(res.getValues()); 
    }     

    public void xtestCalculateCharge() throws Exception 
    { 
        Request req = new Request();
        req.addParameter("AMOUNT", "100.00");
        req.addParameter("CURRENCY", "PHP");
        
        Response res = invoke("XOOM.calculateCharge", req); 
        System.out.println(res.getValues()); 
    } 
    
    public void XtestFetchDataHandler() throws Exception 
    { 
        Request req = new Request();
        req.addParameter("CCREFNO", "X061857574039464");
        req.addParameter("BRANCHID", "MAIN1");
        req.addParameter("USERID", "KPUSER");
        
        Response res = invoke("1fetchDataHandler.XOOM", req); 
        System.out.println(res.getValues()); 
    }     
    
    public void xtestHello() throws Exception 
    {
        Request req = new Request();
        req.addParameter("DATE", "2009-07-10");
        req.addParameter("BRANCHID", "ILIGA1");
        req.addParameter("USERID", "SYSTEM");
        
        Response res = App.getServiceManager().invoke("xoom.branchdailyreport", req);
        
        JTextArea txtarea = new JTextArea();
        txtarea.setFont(Font.decode("courier-plain-11"));
        txtarea.setEditable(false);
        txtarea.setDisabledTextColor(Color.BLACK);
        txtarea.setText(res.getValue("REPORT")+"");
        
        JDialog d = new JDialog();
        d.setModal(true);
        d.setTitle("Xoom Daily Report");
        d.setSize(1024, 768);
        d.setContentPane(new JScrollPane(txtarea));
        d.setVisible(true); 
    }


}
