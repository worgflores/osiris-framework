package partnerfund;

import javax.swing.UIManager;
import junit.framework.TestCase;
import rameses.osiris.client.app.App;
import rameses.osiris.common.service.Request;
import rameses.osiris.common.service.Response;

public class PartnerFundTest extends TestCase
{
    public PartnerFundTest(String name) {
        super(name);
    }
        
    protected void setUp() throws Exception 
    {
        UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        System.setProperty("app.host","http://192.168.3.247:8080/mlhuillier/action");
        
        //System.setProperty("app.res.system","mlkp.Resource");
        //System.setProperty("app.res.shared","shared.Resource");
        //System.setProperty("app.res.svr","rameses.osiris.client.app.ScreenResource2");
        //System.setProperty("screen.host","http://192.168.3.246:8080/mlhuillier/screen");        
    }
    
    protected void tearDown() throws Exception {}
    
    public void testAvailability() throws Exception 
    {
        Request req = new Request();
        req.addParameter("BRANCHID", "LONDON");
        req.addParameter("CURRENCYID", "USD");
        req.addParameter("PRINCIPAL", "400.00");
        req.addParameter("CHARGE", "3.00");
        Response res = App.getServiceManager().invoke("prefund.test.checkAvailability", req);
        System.out.println(res.getValues());
//        System.out.println("CRD40e7bed:12d8356f202:46d0".hashCode());
//        System.out.println("CRD7bcbdb2e:12c87a95909:-6995".hashCode());
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
