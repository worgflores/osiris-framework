package mwci;

import junit.framework.*;

public class MWCITest extends TestCase 
{
    
    public MWCITest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
    }

    protected void tearDown() throws Exception {
    }
    
    // TODO add test methods here. The name must begin with 'test'. For example:
    // public void testHello() {}

    public void test00000() throws Exception 
    {
        
    }
}
