package nybp;

import java.util.Iterator;
import junit.framework.*;
import rameses.osiris.client.app.App;
import rameses.osiris.common.interfaces.IDataSetModel;
import rameses.osiris.common.service.Request;
import rameses.osiris.common.service.Response;

public class NYBPTest extends TestCase 
{
    
    public NYBPTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
        System.setProperty("app.host", "http://192.168.3.173:8080/mlhuillier/action");
    }

    protected void tearDown() throws Exception {
    }
    
    public void testShowRemittanceDetail() throws Exception
    {
        Request req = new Request();
        req.addParameter("CCREFNO", "33NY102234122");
        
        Response res = invoke("NYBP.test.showRemittanceDetail", req); 
        System.out.println(res.getValues()); 
    }

    public void xtestInquireTagAsCompleted() throws Exception
    {
        Request req = new Request();
        //req.addParameter("CCREFNO", "33AE005032756");
        //req.addParameter("TRACENO", "IRIGA311938711214");

        req.addParameter("CCREFNO", "33NY102205873");
        req.addParameter("TRACENO", "GULOD11620407065");
        
        Response res = invoke("NYBP.test.inquireTagAsCompleted", req); 
        System.out.println(res.getValues()); 
    }
    
    private Response invoke(String command, Request req) throws Exception
    {
        return App.getServiceManager().invoke(command, req);
    }
}
