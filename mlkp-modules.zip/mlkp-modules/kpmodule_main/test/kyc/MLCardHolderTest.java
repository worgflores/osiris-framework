package kyc;

import javax.swing.UIManager;
import junit.framework.TestCase;
import rameses.osiris.client.app.App;
import rameses.osiris.common.service.Request;
import rameses.osiris.common.service.Response;

public class MLCardHolderTest extends TestCase
{
    public MLCardHolderTest(String name) {
        super(name);
    }
        
    protected void setUp() throws Exception 
    {
        UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        System.setProperty("app.host","http://192.168.3.247:8080/mlhuillier/action");
        
        //System.setProperty("app.res.system","mlkp.Resource");
        //System.setProperty("app.res.shared","shared.Resource");
        //System.setProperty("app.res.svr","rameses.osiris.client.app.ScreenResource2");
        //System.setProperty("screen.host","http://192.168.3.246:8080/mlhuillier/screen");        
    }
    
    protected void tearDown() throws Exception {}
    
    public void testAvailability() throws Exception 
    {
        Request req = new Request();
        req.addParameter("MLCARDNO", "02-063-768");
        Response res = App.getServiceManager().invoke("mlcard.syncMLCardFromKYC", req);
        System.out.println(res.getValues());
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
