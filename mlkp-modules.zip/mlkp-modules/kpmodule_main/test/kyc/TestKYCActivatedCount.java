package kyc;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import junit.framework.*;
import rameses.osiris.client.app.App;
import rameses.osiris.common.interfaces.IDataModel;
import rameses.osiris.common.interfaces.IDataSetModel;
import rameses.osiris.common.service.Request;
import rameses.osiris.common.service.Response;

public class TestKYCActivatedCount extends TestCase 
{
    private String HOST = "http://192.168.3.247:8080/mlhuillier/action";
    
    public TestKYCActivatedCount(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception 
    {
    } 

    protected void tearDown() throws Exception {} 
    
    public void test00000() throws Exception 
    {
        Date dtfrom = java.sql.Date.valueOf("2005-01-01"); 
        Date dtto = java.sql.Date.valueOf("2010-11-30"); 
        
        String tablename = "rptkyc" + new SimpleDateFormat("yyyyMMddHHmm").format(new Date());
        boolean inited = false; 
        
        SimpleDateFormat YMD = new SimpleDateFormat("yyyy-MM-dd"); 
        Calendar cal = new GregorianCalendar(); 
        cal.setTime(dtto); 
        while (true)
        {
            Date dt = cal.getTime(); 
            if (dt.before(dtfrom)) break; 
            
            String sdate    = YMD.format(dt);
            String fromdate = sdate + " 00:00:00"; 
            String enddate  = sdate + " 23:59:59"; 
            StringBuffer sb = new StringBuffer(); 
            
            if (inited)
                sb.append(" INSERT INTO mltmp." + tablename + " "); 
            else
                sb.append(" CREATE TABLE mltmp." + tablename + " ");
            
            sb.append(" select r.parentid as loopgroup, r.strcode as regioncode, bt.branchid, sum(bt.cardcount) as intcount   ");
            sb.append(" from (  ");
            sb.append(" 		select  ");
            sb.append(" 			ifnull(bt.branchfiled,c.branch) as branchid,  ");
            sb.append(" 			case when c.activated=0 then -1 else bt.cardcount end as cardcount  ");
            sb.append(" 		from ( ");
            sb.append(" 				select  ");
            sb.append(" 					cardno, custid, branchfiled,  ");
            sb.append(" 					case when state=1 then 1 else -1 end as cardcount  ");
            sb.append(" 				from mlkyc.customercard  ");
            sb.append(" 				where dtfiled between '"+fromdate+"' and '"+enddate+"' ");
            sb.append(" 			) bt  ");
            sb.append(" 			inner join mlkyc.customercard cd on bt.cardno=cd.cardno  ");
            sb.append(" 			inner join mlkyc.customer c on bt.custid=c.custno   ");
            sb.append(" 	 )bt  ");
            sb.append(" 	inner join mlkp.tblbranch b on bt.branchid=b.objid  ");
            sb.append(" 	inner join mlkp.tblarea a on b.parentid=a.objid  ");
            sb.append(" 	inner join mlkp.tblregion r on a.parentid=r.objid  ");
            sb.append(" group by loopgroup, regioncode, branchid "); 
            
            System.out.println("processing " + sdate + "...");
            execUpdate206(sb.toString()); 
            
            inited = true; 
            cal.add(Calendar.DATE, -1); 
        } 
        System.out.println("finished.");
    } 
    
    private Object execQuery(String stmt) throws Exception { 
        return execQuery(stmt, false); 
    } 
    
    private Object execQuery(String stmt, boolean dataset) throws Exception 
    { 
        if (stmt.trim().length() == 0) throw new Exception("'stmt' parameter is required");
        
        System.getProperties().put("app.host", HOST); 
        
        Request req = new Request(); 
        req.addParameter("DSNAME", "java:mldb"); 
        req.addParameter("QUERY", (dataset ? "2" : "1")); 
        req.addParameter("SQLSTMT", stmt); 
        
        Response res = App.getServiceManager().invoke("system.exec", req); 
        Object o = res.getValue("xmldata"); 
        if (dataset) o = res.getValue("list"); 
        
        //System.out.println(o);
        return o;
    } 
    
    private Object execQuery206(String stmt, boolean dataset) throws Exception 
    { 
        if (stmt.trim().length() == 0) throw new Exception("'stmt' parameter is required");        
        
        System.getProperties().put("app.host", HOST);
        
        Request req = new Request();
        req.addParameter("DSNAME", "java:mlauditordb");
        req.addParameter("QUERY", (dataset ? "2" : "1"));
        req.addParameter("SQLSTMT", stmt);
        
        Response res = App.getServiceManager().invoke("system.exec", req);
        Object o = res.getValue("xmldata");
        if (dataset) o = res.getValue("list");
        
        //System.out.println(o);
        return o;
    } 

    private void execUpdate(String stmt) throws Exception 
    { 
        if (stmt.trim().length() == 0) throw new Exception("'stmt' parameter is required");
        
        System.getProperties().put("app.host", HOST);
        
        Request req = new Request();
        req.addParameter("DSNAME", "java:mldb");
        req.addParameter("QUERY", "0");
        req.addParameter("SQLSTMT", stmt);
        
        App.getServiceManager().invoke("system.exec", req);
    }

    private void execUpdate206(String stmt) throws Exception 
    { 
        if (stmt.trim().length() == 0) throw new Exception("'stmt' parameter is required");
        
        System.getProperties().put("app.host", HOST);
        
        Request req = new Request();
        req.addParameter("DSNAME", "java:mlauditordb");
        req.addParameter("SQLSTMT", stmt);
        
        Response res = App.getServiceManager().invoke("system.db.update", req);
        if ("0".equals(res.getValue("statuscode"))) 
        {
            System.out.println("[ERROR] " + res.getValue("statusmsg"));
            throw new Exception(res.getValue("statusmsg")+"");
        } 
    } 
    
    private Map convert(IDataModel doc) throws Exception
    {
        Map data = new HashMap();
        Iterator fields = doc.getFields();
        while (fields.hasNext())
        {
            String key = fields.next().toString();
            Object val = doc.getValue(key);
            data.put(key, val);
        }
        return data;
    }
    
    private Response invoke(String service, Request req) throws Exception 
    { 
        System.getProperties().put("app.host", HOST);
        return App.getServiceManager().invoke(service, req);
    }
    
    private void list(IDataSetModel idsm, String name) throws Exception
    {
        if (name != null) System.out.println("["+name+"]");
        
        for (int i=0; i<idsm.size(); i++)
        {
            IDataModel doc = idsm.getItem(i);
            Iterator itr = doc.getFields();
            StringBuffer sb = new StringBuffer();
            while (itr.hasNext())
            {
                String key = itr.next().toString();
                Object val = doc.getValue(key);
                if (sb.length() > 0) sb.append(", ");
                
                sb.append(key + "=" + val);
            }
            System.out.println(i + ") " + sb);
        }
        
        if (name != null) System.out.println("");
    }
    
}
