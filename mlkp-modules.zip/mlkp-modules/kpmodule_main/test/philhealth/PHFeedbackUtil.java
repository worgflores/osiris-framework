package philhealth;

import java.io.File;
import java.io.FileWriter;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PHFeedbackUtil 
{
    private String FEEDBACK_FILE_DIR = "/apps/mlphilhealthfiles.jar/META-INF";
	
    public void writeToFile(Object template, String collectionPeriod) throws Exception
    {
        FileWriter writer = null;
        try
        {
            String path = System.getProperty("jboss.server.home.dir") + 
                          FEEDBACK_FILE_DIR + "/N" + collectionPeriod + ".txt";
            
            File file = new File(path);
            writer = new FileWriter(file);
            writer.write(template.toString());
        }
        catch(Exception ex) {
            throw ex;
        }
        finally {
            try { writer.close(); }catch(Exception ign) {;}
        }
    }
    
    public boolean removeFile(String filename) throws Exception
    {
        File file = new File(System.getProperty("jboss.server.home.dir") + FEEDBACK_FILE_DIR + "/" + filename); 
        return file.delete();
    }
    
    public List getFeedbackFiles() throws Exception
    {
        List list = new ArrayList();
        File dir = new File(System.getProperty("jboss.server.home.dir") + FEEDBACK_FILE_DIR);
        if (dir.exists())
        {
            Calendar cal = new GregorianCalendar();
            File[] files = dir.listFiles();
            for (int i=0; i<files.length; i++)
            {
                if (files[i].isDirectory()) continue;
                
                String sn = files[i].getName();
                if (sn.endsWith(".txt") && sn.startsWith("N"))
                {
                    cal.setTimeInMillis(files[i].lastModified());
                    
                    Map data = new HashMap();
                    data.put("name", sn);
                    data.put("dtmodified", cal.getTime());
                    list.add(data);
                }
            }
        }
        return list;
    }
    
    public StringBuffer generate(List list, String collectionPeriod) throws Exception
    {
	String date = "";
	String branch = "";
	BigDecimal total = new BigDecimal(0.0);
        DecimalFormat decFormat = new DecimalFormat("0.00");
        SimpleDateFormat MDY = new SimpleDateFormat("MMddyyyy");
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        
	StringBuffer sb = new StringBuffer();
	sb.append("HEADER\n");
	sb.append(padRight("MLH", 6) + "\n");
	sb.append(collectionPeriod + "\n");
        
	for (int i=0; i < list.size(); i++)
	{
            Map data = (Map) list.get(i);
            String branch0 = "ML" + data.get("branchid").toString();
            if (!branch.equals(branch0))
            {
                date = "";
                branch = branch0;
                sb.append("BRANCH" +  padRight(branch0, 9) + "\n");
            }
            
            String date0 = MDY.format(sdf.parse(data.get("dtpaid").toString())); 
            if (!date.equals(date0))
            {
                date = date0;
                sb.append("DATE" + date0 + "\n");
            }
            sb.append(padRight(data.get("memno"), 14));
            sb.append(padRight(data.get("memname"), 60));
            
            String memtype = convertMemberType(data.get("memtype"));
            sb.append(padRight(memtype, 1));

            if ("V".equals(memtype)) 
            { 
                String[] arr = data.get("fromperiod").toString().split("-");  
                int month = (Integer.parseInt(arr[1]) * 3) - 2; 

                String smonth = month + "";
                if (month < 10) smonth = "0" + month;

                sb.append(smonth + arr[0]);

                arr = data.get("toperiod").toString().split("-");  
                month = (Integer.parseInt(arr[1]) * 3); 

                smonth = month + "";
                if (month < 10) smonth = "0" + month;

                sb.append("-" + smonth + arr[0]);
            } 
            else 
            { 
                String[] arr = data.get("fromperiod").toString().split("-");  
                sb.append(arr[1] + arr[0]);

                arr = data.get("toperiod").toString().split("-");  
                sb.append("-" + arr[1] + arr[0]);
            } 

            sb.append(padRight(data.get("par_no"), 15));
            
            double amt = Double.parseDouble(data.get("amount").toString());
            String samt = decFormat.format(amt).replaceAll("\\.", "");
            sb.append(padLeft(samt, 12, "0"));
            sb.append(";;\n");
            
            total = total.add(new BigDecimal(amt));
	}
	
        String stotal = decFormat.format(total).replaceAll("\\.", "");
	sb.append("TOTAL" + padLeft(stotal, 15, "0"));
        return sb;
    }

    private String convertMemberType(Object o)
    {
        String c = o.toString();
        if (c.equalsIgnoreCase("Voluntary")) 
            return "V"; 
        else if (c.equalsIgnoreCase("OFW")) 
            return "F"; 
        else if (c.length() > 0) 
            return c.substring(0,1).toUpperCase();
        else 
            return ""; 
    } 
    
    private String padRight(Object value, int length) {
        return padRight(value, length, " ");
    }
    
    private String padRight(Object value, int length, String pad)
    {
        StringBuffer sb = new StringBuffer();
        if (value != null) sb.append(value.toString());

        int size = length - sb.length();
        for (int i=0; i<size; i++) sb.append(pad);
        
        return sb.toString();
    }
    
    private String padLeft(Object value, int length) {
        return padLeft(value, length, " ");
    }
    
    private String padLeft(Object value, int length, String pad)
    {
        StringBuffer sb = new StringBuffer();
        if (value != null) sb.append(value.toString());

        int size = length - sb.length();
        for (int i=0; i<size; i++) sb.insert(0, pad);
        
        return sb.toString();
    }
    
}
