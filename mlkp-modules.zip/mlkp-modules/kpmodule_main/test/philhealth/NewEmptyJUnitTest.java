package philhealth;

import com.rameses.ml.philhealth.AdminDailyReportController;
import com.rameses.ml.philhealth.DailyReportController;
import com.rameses.ml.philhealth.PARSeriesListController;
import com.rameses.ml.philhealth.ReprintController;
import com.rameses.osiris.client.FormGenerator;
import com.rameses.osiris.client.FormLauncher;
import java.util.Hashtable;
import java.util.Map;
import javax.swing.UIManager;
import junit.framework.*;
import rameses.osiris.client.app.App;
import rameses.osiris.common.service.Request;
import rameses.osiris.common.service.Response;

public class NewEmptyJUnitTest extends TestCase 
{
    
    public NewEmptyJUnitTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception 
    {
        UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        System.setProperty("app.host", "http://localhost:8080/mlhuillier/action"); 
    }

    protected void tearDown() throws Exception {
    }
    
    public void testLogin() throws Exception
    {
        Map props = new Hashtable();
        props.put("TERMINALID", "UAKPDSXC");
        App.getSecurityManager().login("KPUSER", "1234", props);
    }
    
    public void xtestReprint() throws Exception 
    {
        ReprintController c = new ReprintController();
        //FormLauncher.newInstance().launch(c);
        FormGenerator.getInstance().dump(c);
        System.exit(0);
    }     

    public void xtestPARSeriesList() throws Exception 
    {
        PARSeriesListController c = new PARSeriesListController();
        FormLauncher.newInstance().launch(c);
        //FormGenerator.getInstance().dump(new PARSeriesController());
        System.exit(0);
    } 
    
    public void xtestAdminDailyReport() throws Exception 
    {
        AdminDailyReportController c = new AdminDailyReportController();
        FormLauncher.newInstance().launch(c);
        //FormGenerator.getInstance().dump(c);
        System.exit(0);
    }     
    
    public void xtestDailyReport() throws Exception 
    {
        DailyReportController c = new DailyReportController();
        FormLauncher.newInstance().launch(c);
        //FormGenerator.getInstance().dump(c);
        System.exit(0);
    } 
    
    public void xtestDailyReportRule() throws Exception 
    {
        Request req = new Request(); 
        req.addParameter("BRANCHID", "MIS"); 
        req.addParameter("USERID", "KPUSER"); 
        req.addParameter("FROMDATE", "2009-01-08"); 
        
        Response res = App.getServiceManager().invoke("philhealth.dailyReport", req);
        System.out.println(res.getValue("REPORT"));
    } 

}
