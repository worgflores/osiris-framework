package philhealth;

import java.util.Hashtable;
import java.util.Map;
import javax.swing.UIManager;
import junit.framework.*;
import rameses.osiris.client.app.App;
import rameses.osiris.common.service.Request;
import rameses.osiris.common.service.Response;

public class TestMemberInfo extends TestCase 
{
    
    public TestMemberInfo(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception 
    {
        UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        System.setProperty("app.host", "http://192.168.3.220:8080/mlhuillier/action"); 
    }

    protected void tearDown() throws Exception {
    }
    
    public void xtestLogin() throws Exception
    {
        Map props = new Hashtable();
        props.put("TERMINALID", "UAKPDSXC");
        App.getSecurityManager().login("KPUSER", "1234", props);
    }
    
    public void testGetMemberInfo() throws Exception 
    {
        Request req = new Request();
        req.addParameter("BRANCHID", "MAIN1");
        req.addParameter("USERID", "KPUSER");
        req.addParameter("TERMINALID", "NB3NXB3D");
        req.addParameter("TYPE", "1");
        req.addParameter("ID_NO", "190000954768");
        
        Response res = App.getServiceManager().invoke("philhealth.getInfo", req);
        System.out.println(res.getValues());
    }     

}
