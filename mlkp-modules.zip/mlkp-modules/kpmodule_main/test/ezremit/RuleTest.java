package ezremit;

import junit.framework.*;
import rameses.osiris.client.app.App;
import rameses.osiris.common.service.Request;
import rameses.osiris.common.service.Response;

public class RuleTest extends TestCase {
    
    public RuleTest(String testName) {
        super(testName);
    }
    
    protected void setUp() throws Exception {
        System.setProperty("app.host", "http://192.168.3.173:8080/mlhuillier/action");
    }
    
    protected void tearDown() throws Exception {
    }

    public void xtestEzcashReceive() throws Exception 
    {
        Request req = new Request(); 
        //req.addParameter("CCREFNO", "DEXMSID434799");
        //req.addParameter("CCREFNO", "CECSALW203705");
        req.addParameter("CCREFNO", "EZ756103087366");
        
        Response res = invoke("EZREMIT.test.EzcashReceive", req);
        System.out.println(res.getValues()); 
    }
    
    public void xtestRepostPayoutTransaction() throws Exception 
    {
        Request req = new Request(); 
        req.addParameter("REFNO", "EZ952137917464");
        req.addParameter("BRANCHID", "SYSTEM");
        req.addParameter("USERID", "SYSTEM");
        req.addParameter("TERMINALID", "SYSTEM");
        
        Response res = invoke("EZREMIT.repostPayoutTransaction", req);
        System.out.println(res.getValues());        
    }
    
    public void xtestSearch() throws Exception 
    {
        Request req = new Request();
        req.addParameter("CCREFNO", "CECSALW2037051");
        
        Response res = invoke("EZREMIT.test.search", req);
        System.out.println(res.getValues());
    }
    
    public void xtestFetchDataHandler() throws Exception 
    {
        Request req = new Request();
        req.addParameter("CCREFNO", "EZ641951847150");
        req.addParameter("debug", "1");
        
        Response res = invoke("fetchDataHandler.EZREMIT", req);
        System.out.println(res.getValues());
    }    
    
    private Response invoke(String command, Request req) throws Exception {
        return App.getServiceManager().invoke(command, req);
    }
}
