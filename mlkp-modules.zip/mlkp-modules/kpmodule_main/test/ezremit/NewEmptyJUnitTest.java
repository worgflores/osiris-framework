package ezremit;

import junit.framework.*;

/**
 *
 * @author ML
 */
public class NewEmptyJUnitTest extends TestCase {
    
    public NewEmptyJUnitTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
    }

    protected void tearDown() throws Exception {
    }
    
    public void test() throws Exception
    {
        
    }
}
