package kp;

import junit.framework.*;
import rameses.osiris.client.app.App;
import rameses.osiris.common.service.Request;
import rameses.osiris.common.service.Response;

public class BranchActivityReportTest extends TestCase 
{
    
    public BranchActivityReportTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
        System.setProperty("app.host", "http://192.168.3.220:8080/mlhuillier/action");
        //System.setProperty("app.host", "http://192.168.3.246:8080/mlhuillier/action");
    }

    protected void tearDown() throws Exception {
    }

    public void xtestSendout() throws Exception
    {
        Request req = new Request();
        req.addParameter("FROMDATE", "2009-05-30");
        req.addParameter("TODATE", "2009-05-30");
        req.addParameter("PERIOD", "DAILY");
        req.addParameter("STATUS", "all");
        req.addParameter("BRANCHID", "SANGIT");
        req.addParameter("USERID", "SANTIAGO-V");
        previewReport("report.branchmgrSendout", req);
    }
    
    public void testPayout() throws Exception
    {
        Request req = new Request();
        req.addParameter("FROMDATE", "2009-05-30");
        req.addParameter("TODATE", "2009-05-30");
        req.addParameter("PERIOD", "DAILY");
        req.addParameter("STATUS", "all");
        req.addParameter("BRANCHID", "SANGIT");
        req.addParameter("USERID", "SANTIAGO-V");
        previewReport("report.branchmgrPayout", req);
    }
    
    private void previewReport(String action, Request req) throws Exception
    {
        Response res = App.getServiceManager().invoke(action, req);
        System.out.println(res.getValue("REPORT"));
    }    
    
}
