package kp;

import junit.framework.*;
import rameses.osiris.client.app.App;
import rameses.osiris.common.service.Request;
import rameses.osiris.common.service.Response;

public class OtherTestUnit extends TestCase 
{
    
    public OtherTestUnit(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
        System.setProperty("app.host", "http://192.168.3.220:8080/mlhuillier/action");
    }

    protected void tearDown() throws Exception {
    }
    
    public void test0() throws Exception
    {
        String sql = null;
        
        //String sql = " UPDATE mlkp.tblsendout SET curcharge="+charge+ " WHERE objid='"+objid+"'";
        //String sql = " select * from mlkp.tblsendout where strcontrolno='s-6tumaui-08-008359'  ";
        //String sqlUpdate = "update mlkp.tblcontrol set strprefix='S-11AVENID-09' where objid='CTRL-1df1a4e3:121094273d7:1885' ";
        
        //String sql = "INSERT IGNORE INTO mlkp_admin.sys_user_permission SELECT 'CABUGASON-G', 'philhealth.*' ";
        
        String bp     = " select strcompanyid, state, count(objid) as intcount  from mlcs.tblbillpayment " + 
                        " where dttxndate between '2009-05-20 00:00:00' and '2009-05-20 23:59:59' " + 
                        " group by strcompanyid, state ";
        
        String bpinv  = " select count(objid)  from mlcs.tblinvalidatedbillpayment " + 
                        " where dtmodified between '2009-05-20 00:00:00' and " + 
                                                 " '2009-05-20 23:59:59' ";
        
        String bpcs   = " select count(objid) from mlcs.tblcancelbillpayment " + 
                        " where dtcancelled between '2009-05-23 00:00:00' and " + 
                                                  " '2009-05-23 23:59:59' ";
        
        Request req = new Request();
        req.addParameter("QUERY", "1");
        req.addParameter("DSNAME", "java:mldb");
        req.addParameter("SQLSTMT", bp);
        
        Response res = App.getServiceManager().invoke("system.exec", req);
        System.out.println(res.getValue("xmldata"));
    }
    
    private void updateSendoutCharge(String objid, double charge) throws Exception
    {
        //String sql = " UPDATE mlkp.tblsendout SET curcharge="+charge+ " WHERE objid='"+objid+"'";
        String sql = " select * from mlkp.tblcontrol where strbranchid='avenid' and strformname='sendout' ";
        
        Request req = new Request();
        req.addParameter("QUERY", "1");
        req.addParameter("DSNAME", "java:mldb");
        req.addParameter("SQLSTMT", sql);
        Response res = App.getServiceManager().invoke("system.exec", req);
        System.out.println(res.getValues());
    }
    
}
