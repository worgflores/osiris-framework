/*
 * ChangeRequestTest.java
 * JUnit based test
 *
 * Created on April 2, 2012, 2:09 PM
 */

package kp;

import junit.framework.*;
import rameses.osiris.client.app.App;
import rameses.osiris.common.service.Request;
import rameses.osiris.common.service.Response;

/**
 *
 * @author ML
 */
public class ChangeRequestTest extends TestCase {
    
    public ChangeRequestTest(String testName) {
        super(testName);
    }
    
    protected void setUp() throws Exception {
        System.setProperty("app.host", "http://192.168.3.173:8080/mlhuillier/action");
    }
    
    protected void tearDown() throws Exception {
    }
    
    public void xxtest0001() throws Exception {
        Request req = new Request();
        req.addParameter("REQNO", "3414811");        
        
        Response res = invoke("changerequest.manualreject", req);
        System.out.println(res.getValues());
    }
    
    private Response invoke(String command, Request req) throws Exception {
        return App.getServiceManager().invoke(command, req);
    }
    
}
