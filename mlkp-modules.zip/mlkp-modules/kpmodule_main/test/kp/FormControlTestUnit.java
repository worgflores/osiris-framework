package kp;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import junit.framework.*;
import rameses.osiris.client.app.App;
import rameses.osiris.common.interfaces.IDataModel;
import rameses.osiris.common.interfaces.IDataSetModel;
import rameses.osiris.common.service.Request;
import rameses.osiris.common.service.Response;

public class FormControlTestUnit extends TestCase 
{
    
    public FormControlTestUnit(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
        System.setProperty("app.host", "http://192.168.3.220:8080/mlhuillier/action");
    }

    protected void tearDown() throws Exception {
    }
    
    public void test0() throws Exception
    {
        //getBranchFormControls("sendout", "florid");
        //getLastSendoutControl("S-2FLORID-07-0105%");
        //updateFormControlNextSeries("SNDCT-2c610385:114a6b5bee5:6e45", 19998);
        
        //getBranchFormControls("payout", "liloal");
        //getLastPayoutControl("P-0LILOAL-05-0963%");
        //updateFormControlNextSeries("PAYCT-67aad35c:1062916f283:1994", 96359);

        getBranchFormControls("unipayout", "sumul1");
        //getLastUNITellerControl("up1sumul12009%");
        //updateFormControlNextSeries("CTRL70985728:124b92d6785:-3799", 5);
        
        //getBranchFormControls("bill", "guindu");
        //getLastBPControl("B-2GUINDU-05-000%");
        //updateFormControlNextSeries("BDCT-5ff06cef:107ba92e812:28fe", 2);        
    }
    
    private IDataSetModel getBranchFormControls(String type, String branchid) throws Exception
    {
        String sql = " SELECT objid, strprefix, intnextseries, strterminalid " + 
                     " FROM mlkp.tblcontrol " + 
                     " WHERE strbranchid='"+branchid+"' AND strformname='"+type+"' ";
        Request req = new Request();
        req.addParameter("QUERY", "2");
        req.addParameter("DSNAME", "java:mldb");
        req.addParameter("SQLSTMT", sql);
        Response res = App.getServiceManager().invoke("system.exec", req);
        IDataSetModel list = (IDataSetModel) res.getValue("list");
        for (int i=0; i<list.size(); i++)
        {
            Map item = convertToMap(list.getItem(i));
            System.out.println(item);
        }
        return list;
    }
    
    private IDataSetModel getLastPayoutControl(String controlno) throws Exception
    {
        String sql = " SELECT dtclaimed, state, strcontrolno " + 
                     " FROM mlkp.tblpayout WHERE strcontrolno like '"+controlno+"' ORDER BY strcontrolno LIMIT 200 ";
        Request req = new Request();
        req.addParameter("QUERY", "2");
        req.addParameter("DSNAME", "java:mldb");
        req.addParameter("SQLSTMT", sql);
        Response res = App.getServiceManager().invoke("system.exec", req);
        IDataSetModel list = (IDataSetModel) res.getValue("list");
        for (int i=0; i<list.size(); i++)
        {
            Map item = convertToMap(list.getItem(i));
            System.out.println(item);
        }
        return list;
    } 
    
    private IDataSetModel getLastUNITellerControl(String controlno) throws Exception
    {
        String sql = " SELECT objid, dtclaimed, controlno " + 
                     " FROM uniteller.payout WHERE controlno like '"+controlno+"' ORDER BY controlno LIMIT 200 ";
        Request req = new Request();
        req.addParameter("QUERY", "2");
        req.addParameter("DSNAME", "java:mldb");
        req.addParameter("SQLSTMT", sql);
        Response res = App.getServiceManager().invoke("system.exec", req);
        IDataSetModel list = (IDataSetModel) res.getValue("list");
        for (int i=0; i<list.size(); i++)
        {
            Map item = convertToMap(list.getItem(i));
            System.out.println(item);
        }
        return list;
    }     
    
    private IDataSetModel getLastSendoutControl(String controlno) throws Exception
    {
        String sql = " SELECT dtfiled, state, strcontrolno " + 
                     " FROM mlkp.tblsendout WHERE strcontrolno like '"+controlno+"' order by strcontrolno LIMIT 200 ";
        Request req = new Request();
        req.addParameter("QUERY", "2");
        req.addParameter("DSNAME", "java:mldb");
        req.addParameter("SQLSTMT", sql);
        Response res = App.getServiceManager().invoke("system.exec", req);
        IDataSetModel list = (IDataSetModel) res.getValue("list");
        for (int i=0; i<list.size(); i++)
        {
            Map item = convertToMap(list.getItem(i));
            System.out.println(item);
        }
        return list;
    }     
    
    private IDataSetModel getLastBPControl(String controlno) throws Exception
    {
        String sql = " SELECT dttxndate, state, strcontrolno " + 
                     " FROM mlcs.tblbillpayment WHERE strcontrolno like '"+controlno+"' ORDER BY strcontrolno LIMIT 200 ";
        Request req = new Request();
        req.addParameter("QUERY", "2");
        req.addParameter("DSNAME", "java:mldb");
        req.addParameter("SQLSTMT", sql);
        Response res = App.getServiceManager().invoke("system.exec", req);
        IDataSetModel list = (IDataSetModel) res.getValue("list");
        for (int i=0; i<list.size(); i++)
        {
            Map item = convertToMap(list.getItem(i));
            System.out.println(item);
        }
        return list;
    } 
    
    private void updateFormControlNextSeries(String objid, int seriesno) throws Exception
    {
        Request req = new Request();
        req.addParameter("QUERY", "0");
        req.addParameter("DSNAME", "java:mldb");
        req.addParameter("SQLSTMT", "UPDATE mlkp.tblcontrol SET intnextseries="+seriesno+" WHERE objid='"+objid+"'"); 
        App.getServiceManager().invoke("system.exec", req);
    }     
    
    private Map convertToMap(IDataModel doc) throws Exception
    {
        Map data = new HashMap();
        Iterator itr = doc.getFields();
        while (itr.hasNext())
        {
            String key = itr.next().toString();
            data.put(key, doc.getValue(key));
        }
        return data;
    }
}
