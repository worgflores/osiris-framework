package kp;

import java.rmi.server.UID;
import junit.framework.*;
import rameses.osiris.client.app.App;
import rameses.osiris.common.service.Request;

public class ForexRateHistoryTest extends TestCase 
{
    
    public ForexRateHistoryTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
        System.setProperty("app.host", "http://192.168.3.220:8080/mlhuillier/action");
    }

    protected void tearDown() throws Exception {
    }
    
    public void test0() throws Exception
    {
        double soutrate = 49.20;
        //logExtra  ("2009-03-31 12:10:00", "USD", soutrate, 48.50);
        //logSpecial("2009-03-31 12:12:00", "USD", soutrate, 48.35);
        //logSTD    ("2009-03-31 12:14:00", "USD", soutrate, 48.20);
    }
    
    private void logExtra(String date, String currency, double soutrate, double poutrate) throws Exception
    {
        String objid = "FXR" + new UID();
        StringBuffer sb = new StringBuffer();
        sb.append(" INSERT INTO mlkp.tblforexratehistory ");
        sb.append(" SELECT '"+objid+"', '"+date+"', 'TACBOBO-AL', '"+currency+"', "+ soutrate + ", " + poutrate + ", 'EXTRA' ");
        
        Request req = new Request();
        req.addParameter("QUERY", "0");
        req.addParameter("DSNAME", "java:mldb");
        req.addParameter("SQLSTMT", sb.toString());
        App.getServiceManager().invoke("system.exec", req);        
    }
    
    private void logSpecial(String date, String currency, double soutrate, double poutrate) throws Exception
    {
        String objid = "FXR" + new UID();
        StringBuffer sb = new StringBuffer();
        sb.append(" INSERT INTO mlkp.tblforexratehistory ");
        sb.append(" SELECT '"+objid+"', '"+date+"', 'TACBOBO-AL', '"+currency+"', "+ soutrate + ", " + poutrate + ", 'SPECIAL' ");
        
        Request req = new Request();
        req.addParameter("QUERY", "0");
        req.addParameter("DSNAME", "java:mldb");
        req.addParameter("SQLSTMT", sb.toString());
        App.getServiceManager().invoke("system.exec", req);        
    }    
    
    private void logSTD(String date, String currency, double soutrate, double poutrate) throws Exception
    {
        String objid = "FXR" + new UID();
        StringBuffer sb = new StringBuffer();
        sb.append(" INSERT INTO mlkp.tblforexratehistory ");
        sb.append(" SELECT '"+objid+"', '"+date+"', 'TACBOBO-AL', '"+currency+"', "+ soutrate + "," + poutrate + ", 'STD' ");
        
        Request req = new Request();
        req.addParameter("QUERY", "0");
        req.addParameter("DSNAME", "java:mldb");
        req.addParameter("SQLSTMT", sb.toString());
        App.getServiceManager().invoke("system.exec", req);        
    }        
    
}
