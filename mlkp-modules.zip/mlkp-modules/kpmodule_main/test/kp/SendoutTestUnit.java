package kp;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import junit.framework.*;
import rameses.osiris.client.app.App;
import rameses.osiris.common.interfaces.IDataModel;
import rameses.osiris.common.interfaces.IDataSetModel;
import rameses.osiris.common.service.Request;
import rameses.osiris.common.service.Response;

public class SendoutTestUnit extends TestCase 
{
    
    public SendoutTestUnit(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
        System.setProperty("app.host", "http://192.168.3.220:8080/mlhuillier/action");
        //System.setProperty("app.host", "http://192.168.3.246:8080/mlhuillier/action");
    }

    protected void tearDown() throws Exception {
    }

    public void xtest00() throws Exception
    {
        String sql = " insert into mlkp_admin.sys_user_permission " +  
                     " select 'KPUSER', permissionkey from mlkp_admin.sys_user_permission where uid='GILSON'"; 
        
        Request req = new Request();
        req.addParameter("QUERY", "0");
        req.addParameter("DSNAME", "java:mldb");
        //req.addParameter("SQLSTMT", sql);
        
        Response res = App.getServiceManager().invoke("system.exec", req);
        System.out.println(res.getValues());
    }
    
    public void xtest0() throws Exception
    {
        //searchSendoutByKPTN("malaba-j63E%");
        //searchSendoutByControlNo("S-0CONSO2-05-049435");
    }
    
    private IDataSetModel searchRTSByRefNo(String refno) throws Exception
    {
        String sql = " SELECT * FROM mlkp.tblreturntosender " + 
                     " WHERE strrefno like '"+refno+"' LIMIT 10 ";
        Request req = new Request();
        req.addParameter("QUERY", "2");
        req.addParameter("DSNAME", "java:mldb");
        req.addParameter("SQLSTMT", sql);
        Response res = App.getServiceManager().invoke("system.exec", req);
        IDataSetModel list = (IDataSetModel) res.getValue("list");
        for (int i=0; i<list.size(); i++)
        {
            Map item = convertToMap(list.getItem(i));
            System.out.println(item);
        }
        return list;
    }    
    
    private IDataSetModel searchSendoutByControlNo(String controlno) throws Exception
    {
        String sql = " SELECT dtfiled, state, strcontrolno, strkptn " + 
                     " FROM mlkp.tblsendout " + 
                     " WHERE strcontrolno like '"+controlno+"' LIMIT 100 ";
        Request req = new Request();
        req.addParameter("QUERY", "2");
        req.addParameter("DSNAME", "java:mldb");
        req.addParameter("SQLSTMT", sql);
        Response res = App.getServiceManager().invoke("system.exec", req);
        IDataSetModel list = (IDataSetModel) res.getValue("list");
        for (int i=0; i<list.size(); i++)
        {
            Map item = convertToMap(list.getItem(i));
            System.out.println(item);
        }
        return list;
    }
    
    private IDataSetModel searchSendoutByKPTN(String kptn) throws Exception
    {
        String sql = " SELECT dtfiled, state, strcontrolno, strkptn " + 
                     " FROM mlkp.tblsendout " + 
                     " WHERE strkptn like '"+kptn+"' LIMIT 50 ";
        Request req = new Request();
        req.addParameter("QUERY", "2");
        req.addParameter("DSNAME", "java:mldb");
        req.addParameter("SQLSTMT", sql);
        Response res = App.getServiceManager().invoke("system.exec", req);
        IDataSetModel list = (IDataSetModel) res.getValue("list");
        for (int i=0; i<list.size(); i++)
        {
            Map item = convertToMap(list.getItem(i));
            System.out.println(item);
        }
        return list;
    }    
    
    private Map convertToMap(IDataModel doc) throws Exception
    {
        Map data = new HashMap();
        Iterator itr = doc.getFields();
        while (itr.hasNext())
        {
            String key = itr.next().toString();
            data.put(key, doc.getValue(key));
        }
        return data;
    }
        
}
