
def res = ws.calculateCharge(2.0, "USD", "ml.atm.ws.HomeTellerWSHelper");
print "charge=${res.charge}, currency=${res.currency}, respcode=${res.respcode}, respdesc=${res.respdesc}";
println "";
