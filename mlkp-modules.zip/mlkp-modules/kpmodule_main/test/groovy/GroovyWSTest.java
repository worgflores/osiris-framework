package groovy;

import groovy.ui.Console;
import junit.framework.*;

public class GroovyWSTest extends TestCase 
{
    
    public GroovyWSTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
    }

    protected void tearDown() throws Exception {
    }
    
    public void test0() throws Exception
    {
//        ClassLoader loader = Thread.currentThread().getContextClassLoader();
//        WSClient c = new WSClient("http://192.168.12.62:8080/myws/MyWebServiceImpl?wsdl", loader);
//        c.initialize();
//        
//        System.out.println(c);
        
        Console c = new Console(); 
        c.run(); 
    }
}
