package txtconnect;

import junit.framework.*;
import rameses.osiris.client.app.App;
import rameses.osiris.common.service.Request;
import rameses.osiris.common.service.Response;

public class RuleTest extends TestCase {
    
    public RuleTest(String testName) {
        super(testName);
    }
    
    protected void setUp() throws Exception {
        System.setProperty("app.host", "http://192.168.3.173:8080/mlhuillier/action");
    }
    
    protected void tearDown() throws Exception {
    }

    private Response invoke(String command, Request req) throws Exception {
        return App.getServiceManager().invoke(command, req);
    }
    
    public void xtestSendMessage() throws Exception 
    {
        Request req = new Request(); 
        req.addParameter("MOBILENO", "09059990533");
        
        Response res = invoke("txtconnect.test.sendMessage", req);
        System.out.println(res.getValues()); 
    }
    
    
}
