package mcprosun;

import java.util.Iterator;
import junit.framework.*;
import rameses.osiris.client.app.App;
import rameses.osiris.common.interfaces.IDataSetModel;
import rameses.osiris.common.service.Request;
import rameses.osiris.common.service.Response;

public class SMSTest extends TestCase 
{
    
    public SMSTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
        System.setProperty("app.host", "http://192.168.3.173:8080/mlhuillier/action");
    }

    protected void tearDown() throws Exception {
    }

    private Response invoke(String command, Request req) throws Exception {
        return App.getServiceManager().invoke(command, req);
    }
    
    public void xtestLogin() throws Exception
    {
        Request req = new Request();
        Response res = invoke("SUNSMSService.test.login", req); 
        System.out.println("[login] " + res.getValues()); 
    }

    public void xtestSendMessage() throws Exception
    {
        Request req = new Request();
        req.addParameter("SESSIONID", "2e49ea51-974b-4314-adc1-9c29356c3ea1");
        req.addParameter("MOBILENO", "09059990533");
        req.addParameter("MESSAGE", "This is a test from MCPro-SUN. Please do not reply.");
        
        Response res = invoke("SUNSMSService.test.send", req); 
        System.out.println("[send] " + res.getValues()); 
    }
}
