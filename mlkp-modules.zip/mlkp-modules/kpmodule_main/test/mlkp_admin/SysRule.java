package mlkp_admin;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import junit.framework.*;
import rameses.osiris.client.app.App;
import rameses.osiris.common.service.Request;
import rameses.osiris.common.service.Response;

public class SysRule extends TestCase 
{
    private String HOST = "http://192.168.3.247:8080/mlhuillier/action";
    private DBConfig dbconfig = new DBConfig();
    private SQLDB sqldb = new SQLDB();
    
    public SysRule(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception 
    {
        System.setProperty("app.host", HOST); 
    }

    protected void tearDown() throws Exception {
    }
    
    public void xtestMain() throws Exception 
    {
        List list = execQuery("select rulename from mlkp_admin.sys_rule order by rulename", "java:searchdb");
        while (!list.isEmpty())
        {
            String name = ((Map) list.remove(0)).get("rulename").toString(); 
            
            Map data = (Map) execQuery("select * from mlkp_admin.sys_rule where rulename='"+name+"'", "java:searchdb").get(0);
        }
        
        Request req = new Request(); 
        req.addParameter("sourceTable", "tblkptnlog_bak1"); 
        req.addParameter("targetTable", "tblkptnlog"); 
        req.addParameter("kptn",   "madrij1774475145"); 
        
        System.out.println(invoke("kptnlog.rebuildKPTN", req)); 
    }
    
    public void xtestRebuild() throws Exception 
    {
        SimpleDateFormat YMDH = new SimpleDateFormat("yyyy-MM-dd HH:mm"); 
        Date dtfrom = java.sql.Date.valueOf("2011-03-01"); 
        Date dtto   = java.sql.Date.valueOf("2011-06-01"); 
        Calendar cal = Calendar.getInstance();
        cal.setTime(dtto); 
        while (true) 
        {
            Date dt = cal.getTime();
            if (dt.before(dtfrom)) break; 
            
            String sdate = YMDH.format(dt); 
            System.out.println("kptnlog.processing " + sdate + "...");
            
            Request req = new Request(); 
            req.addParameter("sourceTable", "tblkptnlog_bak1"); 
            req.addParameter("targetTable", "tblkptnlog"); 
            req.addParameter("startdate",   sdate+":00"); 
            req.addParameter("enddate",     sdate+":59"); 

            try
            {
                Map res = invoke("kptnlog.rebuild", req); 
                System.out.println("   " + res); 

                if ("1".equals(res.get("respcode"))) 
                    cal.add(Calendar.MINUTE, -10); 
            } 
            catch(Exception ex) { 
                System.out.println("   [ERROR] " + ex.getMessage()); 
            } 
        } 
    } 
    
    private List execQuery(String stmt, String dsname) throws Exception 
    { 
        if (stmt == null || stmt.trim().length() == 0) throw new Exception("'stmt' parameter is required");
        
        Request req = new Request(); 
        req.addParameter("DSNAME", dsname); 
        req.addParameter("SQLSTMT", stmt); 
        
        Response res = App.getServiceManager().invoke("system.db.list", req); 
        if ("0".equals(res.getValue("statuscode"))) 
        {
            System.out.println("[ERROR] " + res.getValue("statusmsg"));
            throw new Exception(res.getValue("statusmsg")+"");
        } 
        return (List) res.getValue("list");         
    }     
    
    private void execUpdate(String stmt, String dsname) throws Exception 
    { 
        if (stmt == null || stmt.trim().length() == 0) throw new Exception("'stmt' parameter is required");
        
        Request req = new Request();
        req.addParameter("DSNAME", dsname);
        req.addParameter("SQLSTMT", stmt);
        
        Response res = App.getServiceManager().invoke("system.db.update", req);
        if ("0".equals(res.getValue("statuscode"))) 
        {
            System.out.println("[ERROR] " + res.getValue("statusmsg"));
            throw new Exception(res.getValue("statusmsg")+"");
        }         
    }    
    
    private Map invoke(String rulename, Request req) throws Exception 
    {
        Response res = App.getServiceManager().invoke(rulename, req); 
        return res.getValues(); 
    }

}
