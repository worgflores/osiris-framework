package mlkp_admin;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

public class DBConfig 
{
    private Properties properties;
    
    public DBConfig() 
    {
        properties = new Properties();
        
        InputStream inp = null; 
        try
        {
            File file = new File(System.getProperty("dbconfig.dir", System.getProperty("user.dir")) + File.separator + "dbconfig.properties"); 
            if (file.exists())
            {
                inp = new FileInputStream(file); 
                properties.load(inp); 
            }
        } 
        catch(Exception ex) { 
            throw new IllegalStateException("Unable to load connection properties", ex);
        } 
        finally {
            try { inp.close(); }catch(Exception ing){;} 
        }
    }
    
    public Connection createSourceConnection() throws Exception
    {
        return createConnection(properties.getProperty("src.db.host"),
                                properties.getProperty("src.db.user"),
                                properties.getProperty("src.db.password"));
    }
    
    public Connection createTargetConnection() throws Exception
    {
        return createConnection(properties.getProperty("target.db.host"),
                                properties.getProperty("target.db.user"),
                                properties.getProperty("target.db.password"));
    }    
    
    public Connection createConnection(String name) throws Exception
    {
        String host = properties.getProperty(name + ".db.host");
        String user = properties.getProperty(name + ".db.user");
        String pwd = properties.getProperty(name + ".db.password");
        return createConnection(host, user, pwd);
    }
    
    public Connection createConnection(String host, String user, String pwd) throws Exception
    {
        Class.forName("com.mysql.jdbc.Driver");
        return DriverManager.getConnection(host, user, pwd);
    }
    
}
