package mlkp_admin;

import java.util.List;
import junit.framework.*;
import rameses.osiris.client.app.App;
import rameses.osiris.common.service.Request;
import rameses.osiris.common.service.Response;

public class ForexRateHistoryTest extends TestCase {
    
    public ForexRateHistoryTest(String testName) {
        super(testName);
    }
    
    protected void setUp() throws Exception {
        System.setProperty("app.host", "http://192.168.3.173:8080/mlhuillier/action");
    }
    
    protected void tearDown() throws Exception {}

    private Response invoke(String command, Request req) throws Exception {
        return App.getServiceManager().invoke(command, req);
    }
    
    public void testMain() throws Exception 
    { 
        Request req = new Request(); 
        req.addParameter("TXNDATE", "2011-11-03");
        req.addParameter("CURRENCYID", "USD");
        
        Response res = invoke("forexratehistory.daily.test", req); 
        List list = (List) res.getValue("data"); 
        
	req.addParameter("$RPT_RESULTS", list);	
	res = invoke("forexratehistory.buildreport.test", req);
        System.out.println(res.getValues());
    } 
    
}
