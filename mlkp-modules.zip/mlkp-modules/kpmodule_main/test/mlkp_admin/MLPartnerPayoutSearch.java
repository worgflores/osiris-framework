package mlkp_admin;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import junit.framework.*;
import rameses.osiris.client.app.App;
import rameses.osiris.common.interfaces.IDataModel;
import rameses.osiris.common.interfaces.IDataSetModel;
import rameses.osiris.common.service.Request;
import rameses.osiris.common.service.Response;

public class MLPartnerPayoutSearch extends TestCase 
{
    private String HOST = "http://192.168.3.153:8080/mlhuillier/action";
    
    public MLPartnerPayoutSearch(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception { 
        System.setProperty("app.host", HOST); 
    } 

    protected void tearDown() throws Exception {}
    
    public void xtestByCCREFNO() throws Exception 
    {
        Request req = new Request(); 
        req.addParameter("CCREFNO", "DAYEX109990"); 

        Map res = invoke("MLPARTNER.payoutsearch.byCCREFNO", req);
        System.out.println(res);
           
       IDataSetModel list = (IDataSetModel) res.get("list"); 
       if (list == null) return; 

       for (int row=0; row<list.size(); row++) {
           System.out.println(row + ") " + convertToMap(list.getItem(row)));
       }
    }

    public void xtestByKPTN() throws Exception 
    {
        Request req = new Request(); 
        req.addParameter("KPTN", "FSD470936087448"); 

        Map res = invoke("MLPARTNER.payoutsearch.byKPTN", req);
        System.out.println(res);
           
       IDataSetModel list = (IDataSetModel) res.get("list"); 
       if (list == null) return; 

       for (int row=0; row<list.size(); row++) {
           System.out.println(row + ") " + convertToMap(list.getItem(row)));
       }
    }
    
    public void testByReceiverName() throws Exception 
    {
        Request req = new Request(); 
        req.addParameter("LASTNAME", "ENCARNACION"); 
        req.addParameter("FIRSTNAME", "BRYAN JOHN"); 

        Map res = invoke("MLPARTNER.payoutsearch.byReceiverName", req);
        System.out.println(res);
           
       IDataSetModel list = (IDataSetModel) res.get("list"); 
       if (list == null) return; 

       for (int row=0; row<list.size(); row++) {
           System.out.println(row + ") " + convertToMap(list.getItem(row)));
       }
    }
    
    private Map convertToMap(IDataModel doc) throws Exception 
    {
        Map map = new HashMap();
        if (doc == null) return map;
        
        Iterator fields = doc.getFields(); 
        while (fields.hasNext()) 
        {
            String fldname = fields.next().toString(); 
            try { map.put(fldname, doc.getValue(fldname)); }catch(Exception ign){;} 
        }
        return map; 
    } 
    
    
    private Map invoke(String rulename, Request req) throws Exception 
    {
        Response res = App.getServiceManager().invoke(rulename, req); 
        return res.getValues(); 
    }

}
