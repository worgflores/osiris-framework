package mlkp_admin;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Map;
import junit.framework.*;
import rameses.osiris.client.app.App;
import rameses.osiris.common.service.Request;
import rameses.osiris.common.service.Response;

public class KPTNLogDataRemover extends TestCase 
{
    private String HOST = "http://192.168.3.173:8080/mlhuillier/action";
    private DBConfig dbconfig = new DBConfig();
    private SQLDB sqldb = new SQLDB();
    
    public KPTNLogDataRemover(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception 
    {
        System.setProperty("app.host", HOST); 
    }

    protected void tearDown() throws Exception {
    }
    
    public void xtestRemove() throws Exception 
    {
        Request req = new Request(); 
        req.addParameter("startdate", "0000-00-00 00:00:00"); 
        req.addParameter("enddate",   "0000-00-00 00:00:00"); 

        Map res = invoke("kptnlog.removeByDate", req); 
        System.out.println("   " + res); 
    } 
    
    private Map invoke(String rulename, Request req) throws Exception 
    {
        Response res = App.getServiceManager().invoke(rulename, req); 
        return res.getValues(); 
    }

}
