package mlkp_admin;

import java.util.Map;
import junit.framework.*;
import rameses.osiris.client.app.App;
import rameses.osiris.common.service.Request;
import rameses.osiris.common.service.Response;

public class WebserviceLog extends TestCase 
{
    private String HOST = "http://192.168.3.173:8080/mlhuillier/action";
    private DBConfig dbconfig = new DBConfig();
    private SQLDB sqldb = new SQLDB();
    
    public WebserviceLog(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception 
    {
        System.setProperty("app.host", HOST); 
    }

    protected void tearDown() throws Exception {
    }
    
    public void xtestRenew() throws Exception 
    {
//        Request req = new Request();
//        req.addParameter("tblname", "tblwebservicelog_bak1"); 
//        
//        System.out.println(invoke("webservicelog.renew", req));
    }
    
    
    private Map invoke(String rulename, Request req) throws Exception 
    {
        Response res = App.getServiceManager().invoke(rulename, req); 
        return res.getValues(); 
    }

}
