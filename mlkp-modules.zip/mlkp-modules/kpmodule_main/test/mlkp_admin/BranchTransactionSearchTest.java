package mlkp_admin;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import junit.framework.*;
import rameses.osiris.client.app.App;
import rameses.osiris.common.data.FilterDataModel;
import rameses.osiris.common.interfaces.IDataModel;
import rameses.osiris.common.interfaces.IDataSetModel;
import rameses.osiris.common.service.Request;
import rameses.osiris.common.service.Response;

public class BranchTransactionSearchTest extends TestCase {
    
    public BranchTransactionSearchTest(String testName) {
        super(testName);
    }
    
    protected void setUp() throws Exception {
        System.setProperty("app.host", "http://192.168.3.247:8080/mlhuillier/action");
    }
    
    protected void tearDown() throws Exception {
    }
    
    public void xtestBranchTxnSearchUnclaimed() throws Exception 
    {
        Request req = new Request();
        req.addParameter("BRANCHID", "WWDSLM"); 
        req.addParameter("RECEIVERLNAME", "OCSON"); 
        req.addParameter("RECEIVERFNAME", "JENNIFER"); 
        
        Response res = invoke("branchtxnsearch.unclaimed.MLKP3", req);
        System.out.println(res.getValues());
        
        System.out.println("----------------------------------------");
        IDataSetModel list = (IDataSetModel) res.getValue("list");
        if (list != null) 
        { 
            for (int i=0; i<list.size(); i++) {
                System.out.println((i+1) + ") " + convertToMap(list.getItem(i)));
            }
        }         
    }

    public void xtestBranchTxnSearchclaimed() throws Exception 
    {
        Request req = new Request();
        req.addParameter("BRANCHID", "STABAR");
        req.addParameter("RECEIVERLNAME", "CONCEPCION"); 
        req.addParameter("RECEIVERFNAME", "NANCY"); 
        
        Response res = invoke("branchtxnsearch.claimed.MLKP3", req);
        System.out.println(res.getValues());
        
        System.out.println("----------------------------------------");
        IDataSetModel list = (IDataSetModel) res.getValue("list");
        if (list != null) 
        { 
            for (int i=0; i<list.size(); i++) { 
                System.out.println((i+1) + ") " + convertToMap(list.getItem(i))); 
            } 
        } 
    }
    
    public void xtestUnclaimedCustomerService() throws Exception 
    {
        IDataModel filter = new FilterDataModel("bykptn");
        filter.setValue("kptn", "MBVCVR1884458343");
        
        Request req = new Request();
        req.addParameter("FILTER", filter);
        
        Response res = invoke("MLPARTNER.unclaimedcustomerservice.test", req);
        System.out.println(res.getValues());
    } 
    
    public void xtestClearCache() throws Exception 
    {
        Request req = new Request();
        req.addParameter("RULENAME", "MLPARTNER.ws.sendout.inquire");
        
        Response res = invoke("sysrule.clearCache", req);
        System.out.println(res.getValues());
    }     
    
    public void testKPTNLogMgmtSearch() throws Exception 
    {
        Request req = new Request();
        req.addParameter("KPTN", "FSD290173841948");
        
        Response res = invoke("MLPARTNER.kptnlogmgmt.search", req);
        System.out.println(res.getValues());
    }         
    
    
    
    private Map convertToMap(IDataModel doc) 
    {
        Map map = new HashMap();
        if (doc == null) return map; 
        
        Iterator keys = doc.getFields();
        while (keys.hasNext()) 
        {
            String key = keys.next().toString();  
            try {
                map.put(key, doc.getValue(key)); 
            } catch(Exception e) {;} 
        }
        return map; 
    }
    
    private Response invoke(String command, Request req) throws Exception {
        return App.getServiceManager().invoke(command, req);
    }
}
