package mlkp_admin;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import junit.framework.*;
import rameses.osiris.client.app.App;
import rameses.osiris.common.interfaces.IDataModel;
import rameses.osiris.common.interfaces.IDataSetModel;
import rameses.osiris.common.service.Request;
import rameses.osiris.common.service.Response;

public class FetchDataByCCRefNoAsyncTest extends TestCase 
{
    private String HOST = "http://192.168.3.247:8080/mlhuillier/action";
    
    public FetchDataByCCRefNoAsyncTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception { 
        System.setProperty("app.host", HOST); 
    } 

    protected void tearDown() throws Exception {}
    
    public void testMain() throws Exception 
    {
        Request req = new Request(); 
        req.addParameter("CCREFNO", "33AE003789963"); 
        req.addParameter("SEARCHMODE", "BYCCREFNO"); 
        req.addParameter("BRANCHID", "RECLA"); 
        req.addParameter("async_search", "");
        
        
        for (int i=0; i<1; i++) 
        {
           Map res = invoke("fetchDataHandler.ZNYBAY", req);
           System.out.println(res);
           
           IDataSetModel list = (IDataSetModel) res.get("list"); 
           if (list == null) continue; 
           
           for (int row=0; row<list.size(); row++) {
               System.out.println(row + ") " + convertToMap(list.getItem(row)));
           }
        }
    }

    
    public void xtestThread() throws Exception 
    {
        List runnerlist = new ArrayList(); 
        String branchid = "RECLA"; 
        String ccrefno = "EF8080000092581";
        
        int size = 1;
        for (int i=0; i<size; i++) 
        { 
            MyRunnable runnable = new MyRunnable(); 
            runnable.runnerlist = runnerlist; 
            runnable.branchid = branchid;
            runnable.ccrefno = ccrefno;
            
            new Thread(runnable).start(); 
        } 
        
        while (true) 
        {
            if (runnerlist.size() == size) break;
            
            Thread.sleep(250); 
        }
    } 
    
    private class MyRunnable implements Runnable
    {
        List runnerlist; 
        String branchid;
        String ccrefno;
        
        public void run() 
        { 
            try 
            { 
                String identifier = toString();
                Request req = new Request(); 
                req.addParameter("SEARCHMODE", "BYCCREFNO");                 
                req.addParameter("BRANCHID", branchid); 
                req.addParameter("CCREFNO", ccrefno); 
                
                Map res = invoke("payoutsearch.fetchDataByCCRefNoAsync", req);
                System.out.println("["+identifier+"] " + res);

                IDataSetModel list = (IDataSetModel) res.get("list"); 
                if (list == null) return; 

                for (int row=0; row<list.size(); row++) {
                   System.out.println("["+identifier+"] " + row + ") " + convertToMap(list.getItem(row)));
                } 
            }
            catch(Exception ex) { 
                System.out.println("[ERROR] " + ex.getClass().getName() + ": " + ex.getMessage()); 
            } 
            finally {
                runnerlist.add(this); 
            }
        } 
    } 
    
    
    private Map convertToMap(IDataModel doc) throws Exception 
    {
        Map map = new HashMap();
        if (doc == null) return map;
        
        Iterator fields = doc.getFields(); 
        while (fields.hasNext()) 
        {
            String fldname = fields.next().toString(); 
            try { map.put(fldname, doc.getValue(fldname)); }catch(Exception ign){;} 
        }
        return map; 
    } 
    
    
    private Map invoke(String rulename, Request req) throws Exception 
    {
        Response res = App.getServiceManager().invoke(rulename, req); 
        return res.getValues(); 
    }

}
