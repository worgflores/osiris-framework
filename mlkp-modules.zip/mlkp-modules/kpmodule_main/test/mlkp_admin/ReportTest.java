package mlkp_admin;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import junit.framework.*;
import rameses.osiris.client.app.App;
import rameses.osiris.common.service.Request;
import rameses.osiris.common.service.Response;

public class ReportTest extends TestCase {
    
    public ReportTest(String testName) {
        super(testName);
    }
    
    protected void setUp() throws Exception {
        System.setProperty("app.host", "http://192.168.3.247:8080/mlhuillier/action");
    }
    
    protected void tearDown() throws Exception {}
    
    public void xtestMain() throws Exception 
    {
        String lname = "dela cruz";
        String fname = "juan";
        String name = lname + ", " + fname + "";
        String find = lname + ", " + fname;
        int idx = name.indexOf(find);
        System.out.println("idx=" + idx);
        System.out.println(name.substring(idx, find.length()));
        System.out.println(name.substring(idx+find.length()));
    }
    
    public void xtestFSDRequestForChange() throws Exception 
    {
        Request req = new Request(); 
        req.addParameter("PERIOD", "MONTHLY"); 
        req.addParameter("FROMDATE", "2011-07-01"); 
        req.addParameter("TODATE", "2011-07-09"); 
        req.addParameter("LOCATION", "BRANCH"); 
        req.addParameter("BRANCHID", "MIS"); 
        req.addParameter("USERID", "KPBRANCHUSER"); 
        req.addParameter("REPORTTYPE", "REQUEST_FOR_CHANGE");
        
        Response res = invoke("report.fsd", req);
        System.out.println(res.getValues());
    }        
    
    public void XtestBranchRequestForChange() throws Exception 
    {
        Request req = new Request();
        req.addParameter("USERID", "LANOT-G");
        req.addParameter("BRANCHID", "PDGIL2");
        req.addParameter("FROMDATE", "2011-07-09");
        req.addParameter("RFCSTATUS", "");
        
        Response res = invoke("report.dailyChangeRequest", req);
        System.out.println(res.getValues());
    }  
    
    public void xtestBranchOperatorRequestForChange() throws Exception 
    {
        Request req = new Request();
        req.addParameter("BRANCHID", "AYALA2");
        req.addParameter("USERID", "GALAN-M");
        req.addParameter("FROMDATE", "2011-07-08");
        
        Response res = invoke("report.dailyOperatorChangeRequest", req);
        System.out.println(res.getValues());
    }      
    
    public void xtestBIR() throws Exception 
    {
        //System.getProperties().put("app.host", "http://localhost:18080/mlhuillier/action");
        
        Request req = new Request();
        req.addParameter("USERID", "KPUSER");
        req.addParameter("BRANCHID", "CAPITL");
        req.addParameter("FROMDATE", "2011-07-08");

        Response res = invoke("report.branchBIRReport", req);        
        System.out.println(res.getValues());
    }
    
    public void xtest1() throws Exception 
    {
        ExecutorService executorService = Executors.newCachedThreadPool(); 
        List list = new ArrayList(); 
        list.add(executorService.submit(new Runnable(){
            public void run() { 
                System.out.println("processing task 1");
            }
        }));
        list.add(executorService.submit(new Runnable(){
            public void run() { 
                System.out.println("processing task 2");
            }
        }));
        
        Iterator itr = list.iterator(); 
        while (itr.hasNext()) 
        {
            Future f = (Future) itr.next(); 
        }
    }
    
    private Response invoke(String command, Request req) throws Exception {
        return App.getServiceManager().invoke(command, req);
    }
}
