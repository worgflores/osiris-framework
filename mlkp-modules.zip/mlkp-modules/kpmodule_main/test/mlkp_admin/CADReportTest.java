package mlkp_admin;

import junit.framework.*;
import rameses.osiris.client.app.App;
import rameses.osiris.common.interfaces.IDataSetModel;
import rameses.osiris.common.service.Request;
import rameses.osiris.common.service.Response;

public class CADReportTest extends TestCase {
    
    public CADReportTest(String testName) {
        super(testName);
    }
    
    protected void setUp() throws Exception {
        System.setProperty("app.host", "http://192.168.3.247:8080/mlhuillier/action");        
    }
    
    protected void tearDown() throws Exception {}

    private Response invoke(String command, Request req) throws Exception {
        return App.getServiceManager().invoke(command, req);
    }
    
    public void xtestAuditRTS() throws Exception 
    {
        Request req = new Request(); 
        req.addParameter("PERIOD", "RANGE"); 
        req.addParameter("BRANCHID", "CHNBNK");        
        req.addParameter("FROMDATE", "2011-05-31"); 
        req.addParameter("TODATE",   "2011-06-05"); 
        req.addParameter("USERID", "KPUSER"); 
        
        Response res = invoke("report.dw.fsdaudit.returntosender", req);
        System.out.println(res.getValues());
    } 

    public void xtestAuditSendoutValid() throws Exception 
    { 
        Request req = new Request(); 
        req.addParameter("PERIOD", "DAILY"); 
        req.addParameter("BRANCHID", "FSD45"); 
        req.addParameter("FROMDATE", "2011-07-09"); 
        req.addParameter("TODATE",   "2011-07-09"); 
        req.addParameter("USERID", "KPUSER"); 
        
        Response res = invoke("dwreport.fsdaudit.sendoutvalid", req); 
        System.out.println(res.getValues()); 
    } 
    
}
