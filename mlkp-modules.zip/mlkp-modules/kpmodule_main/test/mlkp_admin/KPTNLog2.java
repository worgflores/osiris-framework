package mlkp_admin;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Map;
import junit.framework.*;
import rameses.osiris.client.app.App;
import rameses.osiris.common.service.Request;
import rameses.osiris.common.service.Response;

public class KPTNLog2 extends TestCase 
{
    private String HOST = "http://192.168.3.173:8080/mlhuillier/action";
    private DBConfig dbconfig = new DBConfig();
    private SQLDB sqldb = new SQLDB();
    
    public KPTNLog2(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception 
    {
        System.setProperty("app.host", HOST); 
    }

    protected void tearDown() throws Exception {
    }
    
    public void testRebuild() throws Exception 
    {
        SimpleDateFormat YMDH = new SimpleDateFormat("yyyy-MM-dd HH:mm"); 
        Date dtfrom = java.sql.Date.valueOf("2011-04-01"); 
        Date dtto   = java.sql.Date.valueOf("2011-05-01"); 
        Calendar cal = Calendar.getInstance();
        cal.setTime(dtto); 
        while (true) 
        {
            Date dt = cal.getTime();
            if (dt.before(dtfrom)) break; 
            
            String sdate = YMDH.format(dt); 
            System.out.println("kptnlog.processing " + sdate + "...");
            
            Request req = new Request(); 
            req.addParameter("sourceTable", "tblkptnlog_bak1"); 
            req.addParameter("targetTable", "tblkptnlog"); 
            req.addParameter("startdate",   sdate+":00"); 
            req.addParameter("enddate",     sdate+":59"); 

            try
            {
                Map res = invoke("kptnlog.rebuild", req); 
                System.out.println("   " + res); 

                if ("1".equals(res.get("respcode"))) 
                    cal.add(Calendar.MINUTE, -10); 
            } 
            catch(Exception ex) { 
                System.out.println("   [ERROR] " + ex.getMessage()); 
            } 
        } 
    } 
    
    private Map invoke(String rulename, Request req) throws Exception 
    {
        Response res = App.getServiceManager().invoke(rulename, req); 
        return res.getValues(); 
    }

}
