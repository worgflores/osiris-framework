package mlkp_admin;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import junit.framework.*;
import rameses.osiris.client.app.App;
import rameses.osiris.common.interfaces.IDataSetModel;
import rameses.osiris.common.service.Request;
import rameses.osiris.common.service.Response;

public class PayoutSearchTest extends TestCase {
    
    public PayoutSearchTest(String testName) {
        super(testName);
    }
    
    protected void setUp() throws Exception {
        //System.setProperty("app.host", "http://192.168.3.247:8080/mlhuillier/action");
    }
    
    protected void tearDown() throws Exception {
    }
    
    public void testFetchDataByKPTNAsync() throws Exception 
    {
        String ccrefno = "EF8080000092581"; 
//        fetchDataHandler("192.168.3.220", "fetchDataHandler.MLKP3", ccrefno);
//        fetchDataHandler("192.168.3.220", "fetchDataHandler.ABSCBN", ccrefno);
//        fetchDataHandler("192.168.3.220", "fetchDataHandler.AUNITELLER", ccrefno);
//        fetchDataHandler("192.168.3.220", "fetchDataHandler.IMEREM", ccrefno);
//        fetchDataHandler("192.168.3.220", "fetchDataHandler.MLGLOBAL", ccrefno);
//        fetchDataHandler("192.168.3.220", "fetchDataHandler.MTRANS", ccrefno);
//        fetchDataHandler("192.168.3.220", "fetchDataHandler.ZASIAUB", ccrefno);
//        fetchDataHandler("192.168.3.220", "fetchDataHandler.ZNYBAY", ccrefno);
        
//        searchByCCRefNo("192.168.3.220", ccrefno);
//        searchByCCRefNo("192.168.3.247", ccrefno);
//        searchByCCRefNo("192.168.3.173", ccrefno);
        
        searchUniteller("192.168.3.220", "5138890431", false); 
        searchAsyncTest("192.168.3.220", "5138890431"); 
    }
    
    private void searchByCCRefNo(String host, String ccrefno) throws Exception
    {
        System.getProperties().put("app.host", "http://"+host+":8080/mlhuillier/action"); 
        
        Request req = new Request();
        req.addParameter("async_search", "true");
        req.addParameter("CCREFNO", ccrefno);
        
        System.out.println("searching from " + System.getProperty("app.host") + "...");
        Response res = invoke("payoutsearch.fetchDataByCCRefNoAsync", req);
        System.out.println(res.getValues());
        System.out.println("----------------------------------------");
        IDataSetModel list = (IDataSetModel) res.getValue("list");
        if (list != null) 
        { 
            System.out.println(" list-size: " + list.size());
            Iterator fields = list.getFields(); 
            while (fields.hasNext()) 
            {
                String key = fields.next().toString();  
                Object val = list.getValue(key);  
                System.out.println(key + "=" + val);
            }
        }    
    }
    
    private void fetchDataHandler(String host, String rulename, String ccrefno) throws Exception 
    {
        System.getProperties().put("app.host", "http://"+host+":8080/mlhuillier/action"); 
        
        Request req = new Request();
        req.addParameter("async_search", "true");
        req.addParameter("CCREFNO", ccrefno);
        
        System.out.println("searching from " + System.getProperty("app.host") + "...");
        Response res = invoke(rulename, req);
        System.out.println(res.getValues());
        System.out.println("----------------------------------------");
        IDataSetModel list = (IDataSetModel) res.getValue("list");
        if (list != null) 
        { 
            System.out.println(" list-size: " + list.size());
            Iterator fields = list.getFields(); 
            while (fields.hasNext()) 
            {
                String key = fields.next().toString();  
                Object val = list.getValue(key);  
                System.out.println(key + "=" + val);
            }
        }            
    } 
    
    private void searchUniteller(String host, String ccrefno, boolean async) throws Exception 
    {
        System.getProperties().put("app.host", "http://"+host+":8080/mlhuillier/action"); 
        
        Request req = new Request();
        req.addParameter("CCREFNO", ccrefno);
        req.addParameter("BRANCHID", "RECLA");
        
        Response res = null;
        if (async)
        {
            req.addParameter("async_search", "true");
            res = invoke("payoutsearch.fetchDataByCCRefNo", req);
        }
        else 
            res = invoke("fetchDataHandler.AUNITELLER", req);

        System.out.println(res.getValues());
        System.out.println("----------------------------------------");
        IDataSetModel list = (IDataSetModel) res.getValue("list");
        if (list != null) 
        { 
            System.out.println(" list-size: " + list.size());
            Iterator fields = list.getFields(); 
            while (fields.hasNext()) 
            {
                String key = fields.next().toString();  
                Object val = list.getValue(key);  
                System.out.println(key + "=" + val);
            }
        }            
    }    

    
    
    private void searchAsyncTest(String host, String ccrefno) throws Exception 
    {
        System.getProperties().put("app.host", "http://"+host+":8080/mlhuillier/action"); 
        
        Request req = new Request();
        req.addParameter("CCREFNO", ccrefno);
        req.addParameter("BRANCHID", "RECLA");
        
        Response res = invoke("payoutsearch.test.fetchDataByCCRefNoAsync", req);
        System.out.println(res.getValues());
        System.out.println("----------------------------------------");
        IDataSetModel list = (IDataSetModel) res.getValue("list");
        if (list != null) 
        { 
            System.out.println(" list-size: " + list.size());
            Iterator fields = list.getFields(); 
            while (fields.hasNext()) 
            {
                String key = fields.next().toString();  
                Object val = list.getValue(key);  
                System.out.println(key + "=" + val);
            }
        }      
        
    }        
    
    public void xtest1() throws Exception 
    {
        ExecutorService executorService = Executors.newCachedThreadPool(); 
        List list = new ArrayList(); 
        list.add(executorService.submit(new Runnable(){
            public void run() { 
                System.out.println("processing task 1");
            }
        }));
        list.add(executorService.submit(new Runnable(){
            public void run() { 
                System.out.println("processing task 2");
            }
        }));
        
        Iterator itr = list.iterator(); 
        while (itr.hasNext()) 
        {
            Future f = (Future) itr.next(); 
        }
    }
    
    
    private Response invoke(String command, Request req) throws Exception {
        return App.getServiceManager().invoke(command, req);
    }
}
