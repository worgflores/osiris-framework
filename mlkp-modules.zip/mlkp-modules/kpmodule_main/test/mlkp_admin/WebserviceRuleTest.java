package mlkp_admin;

import java.net.URL;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import junit.framework.*;
import rameses.osiris.client.app.App;
import rameses.osiris.common.interfaces.IDataModel;
import rameses.osiris.common.interfaces.IDataSetModel;
import rameses.osiris.common.service.Request;
import rameses.osiris.common.service.Response;

public class WebserviceRuleTest extends TestCase {
    
    public WebserviceRuleTest(String testName) {
        super(testName);
    }
    
    protected void setUp() throws Exception {
        System.setProperty("app.host", "http://192.168.3.173:8080/mlhuillier/action");
    }
    
    protected void tearDown() throws Exception {}

    private Response invoke(String command, Request req) throws Exception {
        return App.getServiceManager().invoke(command, req);
    }
    
    public void XtestQryUnclaimList() throws Exception 
    {
        Request req = new Request();
        req.addParameter("KPTN1", "MBFRWA1884440781");
        req.addParameter("CCREFNO", "FPR0000422027MR");

        Response res = invoke("ws.qryunclaimlist", req);
        System.out.println(res.getValues());
    }        
    
    public void XtestQryCustomerServiceList() throws Exception 
    {
        Request req = new Request();
        req.addParameter("KPTN", "MTRTST1884399753");
        req.addParameter("TXNSTATUS", "1");

        Response res = invoke("ws.qrycustomerservicelist", req);
        System.out.println(res.getValues());
    } 
    
    public void xtestSendoutInquire() throws Exception 
    {
        Request req = new Request();
        req.addParameter("TRANSACTIONNO", "SIGUE1001505474");
        req.addParameter("BRANCHID", "sigue");

        Response res = invoke("ws.sendout.inquire", req);
        System.out.println(res.getValues());
        
        IDataSetModel list = (IDataSetModel) res.getValue("list");
        if (list != null) 
        {
            System.out.println("list-size=" + list.size());
            System.out.println(convertModelToMap(list.getItem(0)));
        }
    }        

    public void xtestCallCenterSearch() throws Exception 
    {
        Request req = new Request();
        req.addParameter("KPTN", "MBFRWA1884440004");
        req.addParameter("SEARCHMODE", "ByKPTN");

        Response res = invoke("MLPARTNER.callcenter.searchByKPTN.test", req);
        System.out.println(res.getValues());
        
        IDataSetModel list = (IDataSetModel) res.getValue("list");
        if (list != null) System.out.println("list-size=" + list.size());
    }        
    
    public void xtestResolveReferenceNo() throws Exception 
    {
        Request req = new Request();
        req.addParameter("REFERENCENO", "FSCJEC23012");
        req.addParameter("BRANCHID", "fsd19");

        Response res = invoke("ws.resolveReferenceNo", req);
        System.out.println(res.getValues());
    }   
    
    public void xtestChangeRequestInquiry() throws Exception 
    {
        Request req = new Request();
        req.addParameter("REQUESTNO", "3332379");

        Response res = invoke("ws.changerequest.inquire", req);
        System.out.println(res.getValues());
        
        IDataSetModel list = (IDataSetModel) res.getValue("list");
        if (list != null) System.out.println("list-size=" + list.size());
    }    
    
    public void XtestChangeRequestResolveTransactionNo() throws Exception 
    {
        Request req = new Request();
        req.addParameter("TRANSACTIONNO", "08-0202288");
        req.addParameter("BRANCHID", "MBWALY");

        Response res = invoke("ws.changerequest.resolveTransactionNo", req);
        System.out.println(res.getValues());
    }     
    
    public void xtestPayoutDaily() throws Exception 
    {
        Request req = new Request();
        req.addParameter("BRANCHID", "SIGUE");
        req.addParameter("TXNDATE", "2011-09-02");

        Response res = invoke("ws.payout.daily", req);
        System.out.println(res.getValues());
        
        IDataSetModel list = (IDataSetModel) res.getValue("list");
        for (int i=0; i<list.size(); i++) { 
            System.out.println(convertModelToMap(list.getItem(i))); 
        } 
    } 
    
    public void xtestDatasource() throws Exception 
    {
        Request req = new Request();
        
        Response res = invoke("JMXAPIService.DataSourceBinding", req);
        System.out.println(res.getValues());
    }
    
    public void testClearCache() throws Exception 
    {
        Request req = new Request();
        req.addParameter("RULENAME", "JMXAPIService.DataSourceBinding");
        
        Response res = invoke("sysrule.clearCache", req);
        System.out.println(res.getValues());
    } 
    
    private Map convertModelToMap(IDataModel doc) 
    {
        Map map = new HashMap();
        Iterator fields = doc.getFields();
        while (fields.hasNext()) 
        { 
            String fldname = fields.next().toString(); 
            Object fldvalue = null; 
            try 
            { 
                fldvalue = doc.getValue(fldname); 
                if (fldvalue == null || fldvalue.toString().length() == 0) fldvalue = null; 
            } catch(Exception ign) {;} 

            if (fldvalue != null) map.put(fldname, fldvalue); 
        } 
        return map; 
    }     
}
