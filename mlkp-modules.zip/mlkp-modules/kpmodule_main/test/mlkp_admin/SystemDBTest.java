package mlkp_admin;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import junit.framework.*;
import rameses.osiris.client.app.App;
import rameses.osiris.common.interfaces.IDataModel;
import rameses.osiris.common.service.Request;
import rameses.osiris.common.service.Response;

public class SystemDBTest extends TestCase {
    
    public SystemDBTest(String testName) {
        super(testName);
    }
    
    protected void setUp() throws Exception {
        System.setProperty("app.host", "http://192.168.3.173:8080/mlhuillier/action");
    }
    
    protected void tearDown() throws Exception {}

    private Response invoke(String command, Request req) throws Exception {
        return App.getServiceManager().invoke(command, req);
    }
    
    public void testMain() throws Exception 
    { 
        Request req = new Request();
        req.addParameter("DSNAME", "java:mldb3");
        req.addParameter("DBNAME", "wu");
        
        Response res = invoke("SystemDB.getTableStructure", req); 
        System.out.println(res.getValues());
    } 
    
    private Map convertModelToMap(IDataModel doc) 
    {
        Map map = new HashMap();
        Iterator fields = doc.getFields();
        while (fields.hasNext()) 
        { 
            String fldname = fields.next().toString(); 
            Object fldvalue = null; 
            try 
            { 
                fldvalue = doc.getValue(fldname); 
                if (fldvalue == null || fldvalue.toString().length() == 0) fldvalue = null; 
            } catch(Exception ign) {;} 

            if (fldvalue != null) map.put(fldname, fldvalue); 
        } 
        return map; 
    }     
}
