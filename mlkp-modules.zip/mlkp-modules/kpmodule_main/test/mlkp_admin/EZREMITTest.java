package mlkp_admin;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import junit.framework.*;
import rameses.osiris.client.app.App;
import rameses.osiris.common.service.Request;
import rameses.osiris.common.service.Response;

public class EZREMITTest extends TestCase 
{
    private String HOST = "http://192.168.3.247:8080/mlhuillier/action";
    private DBConfig dbconfig = new DBConfig();
    private SQLDB sqldb = new SQLDB();
    
    public EZREMITTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception 
    {
        System.setProperty("app.host", HOST); 
    }

    protected void tearDown() throws Exception {
    }
    
    public void testTransferSysReport() throws Exception 
    {
        Connection conn = null; 
        List list = new ArrayList(); 
        try 
        {
            conn = dbconfig.createConnection("jdbc:mysql://192.168.50.108/mlkp_admin", "root", "1234"); 
            list = sqldb.getList(conn, "select * from mlkp_admin.sys_report where reportname like '%ezr%' order by reportname", null); 
        }
        catch(Exception ex) { 
            throw ex; 
        } 
        finally {
            try { conn.close(); }catch(Exception ing){;}  
        }
        
        while (!list.isEmpty())
        {
            Map data = (Map) list.remove(0); 
            Request req = new Request(); 
            req.addParameter("data", data); 
            System.out.println(invoke("sysreport.add", req));
        } 
    } 

    public void testTransferSysScreen() throws Exception 
    {
        Connection conn = null; 
        List list = new ArrayList(); 
        try 
        {
            conn = dbconfig.createConnection("jdbc:mysql://192.168.50.108/mlkp_admin", "root", "1234"); 
            list = sqldb.getList(conn, "select * from mlkp_admin.sys_screen where scrname like '%ezr%' order by scrname", null); 
        }
        catch(Exception ex) { 
            throw ex; 
        } 
        finally {
            try { conn.close(); }catch(Exception ing){;}  
        }
        
        while (!list.isEmpty())
        {
            Map data = (Map) list.remove(0); 
            Request req = new Request(); 
            req.addParameter("data", data); 
            System.out.println(invoke("sysscreen.add", req));
        } 
    }     
    
    public void testTransferSysRule() throws Exception 
    {
        Connection conn = null; 
        List list = new ArrayList(); 
        try 
        {
            conn = dbconfig.createConnection("jdbc:mysql://192.168.50.108/mlkp_admin", "root", "1234"); 
            list = sqldb.getList(conn, "select * from mlkp_admin.sys_rule where rulename like '%ezr%'  order by rulename", null); 
        }
        catch(Exception ex) { 
            throw ex; 
        } 
        finally {
            try { conn.close(); }catch(Exception ing){;}  
        }
        
        while (!list.isEmpty())
        {
            Map data = (Map) list.remove(0); 
            Request req = new Request(); 
            req.addParameter("data", data); 
            System.out.println(invoke("sysrule.add", req));
        } 
    } 
        
    
    private Map invoke(String rulename, Request req) throws Exception 
    {
        Response res = App.getServiceManager().invoke(rulename, req); 
        return res.getValues(); 
    }

}
