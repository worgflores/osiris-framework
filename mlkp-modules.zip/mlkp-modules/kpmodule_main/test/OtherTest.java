import junit.framework.*;

public class OtherTest extends TestCase 
{
    
    public OtherTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
    }

    protected void tearDown() throws Exception {
    }
    
    public void test1() throws Exception
    {
        System.out.println((int) '<' + " : < ");
        System.out.println((int) '>' + " : > ");
        System.out.println((int) '[' + " : [ ");
        System.out.println((int) ']' + " : ] ");
        
        System.out.println((char) 60);
        System.out.println((char) 62);
        System.out.println((char) 91);
        System.out.println((char) 93);        
    }
}
