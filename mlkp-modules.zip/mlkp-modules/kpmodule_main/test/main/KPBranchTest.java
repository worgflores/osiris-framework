package main;

import java.util.Map;

import junit.framework.*;
import rameses.osiris.client.app.App;
import rameses.osiris.common.service.Request;
import rameses.osiris.common.service.Response;

public class KPBranchTest extends TestCase 
{
    
    public KPBranchTest(String testName) { 
        super(testName); 
    } 

    protected void setUp() throws Exception { 
        System.setProperty("app.host", "http://192.168.3.247:8080/mlhuillier/action"); 
    }

    protected void tearDown() throws Exception {} 
    
    public void test000001() throws Exception 
    {  
        Request req = new Request();
        req.addParameter("USERID", "DIFUNTORUM-N");
        req.addParameter("BRANCHID", "LIPA7");
        req.addParameter("FROMDATE", "2011-06-21");
        req.addParameter("REPORTNAME", "branch.BIRReport");

        Map res = invoke("report.branchBIRReport", req);
        System.out.println(res.get("REPORT"));   
    } 
    
    private Map invoke(String rulename, Request req) throws Exception 
    { 
        Response res = App.getServiceManager().invoke(rulename, req);
        return res.getValues(); 
    }    
}





