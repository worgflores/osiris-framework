package mlglobal;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import junit.framework.*;
import rameses.osiris.client.app.App;
import rameses.osiris.common.service.Request;
import rameses.osiris.common.service.Response;

public class RuleTest extends TestCase 
{
    private String HOST = "http://192.168.3.173:8080/mlhuillier/action";
    
    public RuleTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception 
    {
    } 

    protected void tearDown() throws Exception {} 

    public void xtestMain() throws Exception 
    {
        System.out.println(findTransaction("MLUSCHECKSTAT"));
        //System.out.println(checkStatus());
    }
    
    public void xtestService() throws Exception 
    {
        Request req = new Request(); 
        
        Response res = invoke("MLGLOBALServiceTest", req); 
        System.out.println(res.getValues());
    }
    
    private void saveManually(String ccrefno) throws Exception 
    {
        Request req = new Request(); 
        req.addParameter("REFNO", ccrefno);
        
        Response res = invoke("MLGLOBAL.saveManually", req); 
        System.out.println(res.getValues());
    }

    private Map findTransaction(String ccrefno) throws Exception
    {
        Request req = new Request(); 
        req.addParameter("CCREFNO", ccrefno); 
        
        Response res = invoke("MLGLOBAL.test.search", req); 
        return res.getValues(); 
    } 

    private Map openTransaction(String branchid, String userid, String ccrefno, String txnid) throws Exception
    {
        Request req = new Request(); 
        req.addParameter("BRANCHID", branchid); 
        req.addParameter("USERID", userid); 
        req.addParameter("CCREFNO", ccrefno); 
        req.addParameter("TXNID", txnid); 
        
        Response res = invoke("MLGLOBAL.test.openTransaction", req); 
        return res.getValues(); 
    } 

    private Map checkStatus() throws Exception
    {
        Response res = invoke("MLGLOBALServiceTool.checkStatus", new Request()); 
        return res.getValues(); 
    } 
    
    private Response invoke(String service, Request req) throws Exception 
    { 
        System.getProperties().put("app.host", HOST);
        return App.getServiceManager().invoke(service, req);
    }
    
    private void dump(List list) throws Exception
    {
        System.out.println("");
        
        long counter = 1;
        Iterator itr = list.iterator();
        while (itr.hasNext())
        {
            System.out.println(counter + ") " + itr.next());
            counter += 1;
        }
        System.out.println("");
    }
}
