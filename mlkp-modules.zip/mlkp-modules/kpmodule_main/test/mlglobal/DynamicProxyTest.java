package mlglobal;

import com.rameses.invoker.client.DynamicHttpInvoker;
import com.rameses.invoker.client.DynamicHttpInvoker.Action;
import junit.framework.*;

public class DynamicProxyTest extends TestCase 
{
    public DynamicProxyTest(String testName) { 
        super(testName);  
    } 

    protected void setUp() throws Exception 
    {
    } 

    protected void tearDown() throws Exception {} 
    
    public void test00001() throws Exception
    {
        DynamicHttpInvoker i = new DynamicHttpInvoker("192.168.12.62:8080", "mlglobal"); 
        Action a = i.create("DateService"); 
        System.out.println(a.invoke("getServerDate")); 
    }
    
}
