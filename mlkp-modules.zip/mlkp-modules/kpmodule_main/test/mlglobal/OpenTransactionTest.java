package mlglobal;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import junit.framework.*;
import rameses.osiris.client.app.App;
import rameses.osiris.common.service.Request;
import rameses.osiris.common.service.Response;

public class OpenTransactionTest extends TestCase 
{
    private String HOST = "http://192.168.3.247:8080/mlhuillier/action";
    
    public OpenTransactionTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception 
    {
    } 

    protected void tearDown() throws Exception {} 

    public void testMain() throws Exception 
    { 
        //System.out.println(findTransaction("MLUS1821262643")); 
        System.out.println(openTransaction("V & G", "PARAC-M", "MLUS1821262643", "SNDMLUSSO82a59d8:1309f5d9d26:-7ffe")); 
    } 
    
    private void saveManually() throws Exception 
    {
        Request req = new Request(); 
        req.addParameter("REFNO", "MLUS1870032729");
        
        Response res = invoke("MLGLOBAL.saveManually", req); 
        System.out.println(res.getValues());
    }

    private Map findTransaction(String ccrefno) throws Exception
    {
        Request req = new Request(); 
        req.addParameter("CCREFNO", ccrefno); 
        
        Response res = invoke("MLGLOBAL.test.findTransaction", req); 
        return res.getValues(); 
    } 

    private Map openTransaction(String branchid, String userid, String ccrefno, String txnid) throws Exception
    {
        Request req = new Request(); 
        req.addParameter("BRANCHID", branchid); 
        req.addParameter("USERID", userid); 
        req.addParameter("CCREFNO", ccrefno); 
        req.addParameter("TXNID", txnid); 
        
        Response res = invoke("MLGLOBAL.test.openTransaction", req); 
        return res.getValues(); 
    } 
        
    
    
    private Map execSingleQuery(String stmt) throws Exception { 
        return execSingleQuery(stmt, "java:mldb"); 
    }     
    
    private Map execSingleQuery(String stmt, String dsname) throws Exception 
    { 
        List list = execQuery(stmt, dsname); 
        if (list != null && list.size() > 0)
            return (Map) list.get(0);
        else
            return null; 
    }         
    
    private List execQuery(String stmt) throws Exception { 
        return execQuery(stmt, "java:mldb"); 
    } 
    
    private List execAuditQuery(String stmt) throws Exception {
        return execQuery(stmt, "java:mlauditordb"); 
    }
    
    private List execQuery(String stmt, String dsname) throws Exception 
    { 
        if (stmt == null || stmt.trim().length() == 0) throw new Exception("'stmt' parameter is required");
        if (dsname == null || dsname.trim().length() == 0) throw new Exception("'dsname' parameter is required");
        
        System.getProperties().put("app.host", HOST); 
        
        Request req = new Request(); 
        req.addParameter("DSNAME", dsname); 
        req.addParameter("SQLSTMT", stmt); 
        
        Response res = App.getServiceManager().invoke("system.db.list", req); 
        if ("0".equals(res.getValue("statuscode"))) 
        {
            System.out.println("[ERROR] " + res.getValue("statusmsg"));
            throw new Exception(res.getValue("statusmsg")+"");
        } 
        
        return (List) res.getValue("list"); 
    } 

    private void execUpdate(String stmt) throws Exception {
        execUpdate(stmt, "java:mldb");
    }
    
    private void execUpdate(String stmt, String dsname) throws Exception 
    { 
        if (stmt == null || stmt.trim().length() == 0) throw new Exception("'stmt' parameter is required");
        if (dsname == null || dsname.trim().length() == 0) throw new Exception("'dsname' parameter is required");
        
        System.getProperties().put("app.host", HOST);
        
        Request req = new Request();
        req.addParameter("DSNAME", dsname);
        req.addParameter("SQLSTMT", stmt);
        
        Response res = App.getServiceManager().invoke("system.db.update", req);
        if ("0".equals(res.getValue("statuscode"))) 
        {
            //System.out.println("[ERROR] " + res.getValue("statusmsg"));
            throw new Exception(res.getValue("statusmsg")+"");
        } 
    }

    
    private Response invoke(String service, Request req) throws Exception 
    { 
        System.getProperties().put("app.host", HOST);
        return App.getServiceManager().invoke(service, req);
    }
    
    private void dump(List list) throws Exception
    {
        System.out.println("");
        
        long counter = 1;
        Iterator itr = list.iterator();
        while (itr.hasNext())
        {
            System.out.println(counter + ") " + itr.next());
            counter += 1;
        }
        System.out.println("");
    }
}
