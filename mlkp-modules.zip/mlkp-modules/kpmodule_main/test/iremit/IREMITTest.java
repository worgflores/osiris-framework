package iremit;

import junit.framework.*;
import rameses.osiris.client.app.App;
import rameses.osiris.common.interfaces.IDataSetModel;
import rameses.osiris.common.service.Request;
import rameses.osiris.common.service.Response;

public class IREMITTest extends TestCase {
    
    public IREMITTest(String testName) {
        super(testName);
    }
    
    protected void setUp() throws Exception {
        System.setProperty("app.host", "http://192.168.3.247:8080/mlhuillier/action");
    }
    
    protected void tearDown() throws Exception {
    }
    
    public void testEZRemitSearch() throws Exception 
    {
        Request req = new Request();
        req.addParameter("CCREFNO", "ZAMLUHY247901");
        
        Response res = invoke("EZREMIT.test.search", req);
        System.out.println(res.getValues());
    }
    
    public void xtestWSGetDailySendouts() throws Exception 
    {
        Request req = new Request();
        req.addParameter("BRANCHID", "FSD45");
        req.addParameter("USERID", "KPUSER");
        req.addParameter("TXNDATE", "2011-07-26");
        
        Response res = invoke("ws.getDailySendouts2", req);
        System.out.println(res.getValues());
    }

    public void xtestWSQryUnclaim() throws Exception 
    {
        Request req = new Request();
        req.addParameter("BRANCHID", "FSD17");
        req.addParameter("1KPTN", "FSD171865302015");
        req.addParameter("1CCREFNO", "SPS1966325014TP");
        req.addParameter("LASTNAME", "Manipol");
        req.addParameter("FIRSTNAME", "Iluminada");
        
        Response res = invoke("ws.qryunclaimlist", req);
        System.out.println(res.getValues());
    }

    public void xtestWSQryCustomerService() throws Exception 
    {
        Request req = new Request();
        req.addParameter("BRANCHID", "FSD17");
        req.addParameter("1KPTN", "FSD171865095974");
        req.addParameter("1CCREFNO", "AUS20000329970"); 
        req.addParameter("LASTNAME", "ESCARTIN"); 
        req.addParameter("FIRSTNAME", "MARYJEAN"); 
        req.addParameter("TXNSTATUS", "1");
        
        Response res = invoke("MLPARTNER.ws.qrycustomerservicelist1", req);
        System.out.println(res.getValues());
    }
    
    public void xtestFetchDataByName() throws Exception 
    {
        Request req = new Request();
        req.addParameter("LASTNAME", "ero");
        req.addParameter("FIRSTNAME", "alicia");
        
        Response res = invoke("payoutsearch.fetchDataByName2", req);
        //Response res = invoke("fetchDataByName.MLPARTNER", req);
        System.out.println(res.getValues());
        
        IDataSetModel list = (IDataSetModel) res.getValue("list");
        if (list != null) System.out.println("list-size: " + list.size());
    }
    
    private Response invoke(String command, Request req) throws Exception {
        return App.getServiceManager().invoke(command, req);
    }
}
