package moneytransit;

import junit.framework.*;
import rameses.osiris.client.app.App;
import rameses.osiris.common.service.Request;
import rameses.osiris.common.service.Response;

public class NewEmptyJUnitTest extends TestCase 
{
    
    public NewEmptyJUnitTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
        System.setProperty("app.host", "http://192.168.3.247:8080/mlhuillier/action");
    }

    protected void tearDown() throws Exception {
    }
    
    public void testSearchTransaction() throws Exception 
    {
        Request req = new Request(); 
        req.addParameter("CCREFNO", "898603712");
        req.addParameter("BRANCHID", "RECLA");
        
        Response res = App.getServiceManager().invoke("MTRANS.test.searchTransaction", req); 
        System.out.println(res.getValues());
    }

    public void xtestFetchDataHandler() throws Exception 
    {
        Request req = new Request(); 
        req.addParameter("CCREFNO", "898603712");
        req.addParameter("BRANCHID", "RECLA");
        
        Response res = App.getServiceManager().invoke("fetchDataHandler.MTRANS", req); 
        System.out.println(res.getValues());
    }
    
}
