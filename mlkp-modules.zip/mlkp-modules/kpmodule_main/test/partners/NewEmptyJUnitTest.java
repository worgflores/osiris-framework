package partners;

import junit.framework.*;

public class NewEmptyJUnitTest extends TestCase {
    
    public NewEmptyJUnitTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
    }

    protected void tearDown() throws Exception {
    }
    
    public void xtest0() throws Exception
    {
        String branchid = "FSD48";
        String userid = "FSD48U1";
        String terminalid = "FSD48T1";
        String secretkey = "MLKPTEST";
        String signature = branchid + userid + terminalid + secretkey;
        System.out.println(CryptoUtil.createHash(signature));
        
        branchid = "MIS";
        userid = "KPUSER";
        terminalid = "VDC03LEC65";
        secretkey = "MLWS";
        
        String phoneno = "09208181192";
        signature = branchid + userid + terminalid + phoneno + secretkey;
        System.out.println(CryptoUtil.createHash(signature));        
    }
    
    public void test00001() throws Exception
    {
        String branchid = "MBFRWA";  
        String userid = "ONG-CA";  
        String terminalid = "23HL9X5PJN";  
        String secretkey = "MLWS";
        System.out.println("sign1=" + CryptoUtil.createHash(branchid + userid + terminalid + secretkey));
        
        String controlno = "MBFRWA10001";
        System.out.println("sign2=" + CryptoUtil.createHash(branchid + userid + terminalid + controlno + secretkey));
    }    
}
