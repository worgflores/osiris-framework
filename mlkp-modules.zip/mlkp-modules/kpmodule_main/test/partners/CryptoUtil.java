package partners;

import java.security.MessageDigest;

public final class CryptoUtil 
{
    public static String createHash(String text)
    {
        try
        {
            MessageDigest md = MessageDigest.getInstance("MD5");
            md.update(text.getBytes());
            return toHexString(md.digest());
        }
        catch(Exception ex) {
            throw new RuntimeException(ex.getMessage(), ex);
        }
    }
    

    public static String toHexString(byte[] hash) 
    {
        String hexDigit = "0123456789abcdef";
        StringBuffer sb = new StringBuffer(hash.length);
        for (int i=0; i< hash.length; i++) 
        {
            int b = hash[i] & 0xFF;
            sb.append(hexDigit.charAt(b >>> 4));
            sb.append(hexDigit.charAt(b & 0xF));
        }
        return sb.toString();
    }    
    
    private CryptoUtil() {}
    
    
}
