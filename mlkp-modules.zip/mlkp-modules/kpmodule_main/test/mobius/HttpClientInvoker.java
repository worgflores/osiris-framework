package mobius;

import java.net.URL;
import java.net.URLConnection;
import java.util.Iterator;
import java.util.Map;

public class HttpClientInvoker 
{
    
    public HttpClientInvoker() {
    }

    public Object invoke(String urlpath, Map params, String reqMethod) throws Exception 
    {
        URL url = new URL(urlpath); 
        URLConnection conn = url.openConnection(); 
        conn.setDoInput(true); 
        conn.setDoOutput(true);
        conn.setUseCaches(false); 
        
        if (params != null)
        {
            Iterator keys = params.keySet().iterator(); 
            while (keys.hasNext())
            {
                String key = keys.next().toString();
                Object val = params.get(key); 
                if (val == null) val = ""; 
                
                conn.setRequestProperty(key, val.toString()); 
            }
        }
        
        return null;
    }
    
}
