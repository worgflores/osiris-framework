package aub;

import java.util.Date;
import java.util.Iterator;
import junit.framework.*;
import rameses.osiris.client.app.App;
import rameses.osiris.common.interfaces.IDataSetModel;
import rameses.osiris.common.service.Request;
import rameses.osiris.common.service.Response;

public class AUBTest extends TestCase {
    
    public AUBTest(String testName) {
        super(testName);
    }
    
    protected void setUp() throws Exception {
        System.setProperty("app.host", "http://192.168.3.173:8080/mlhuillier/action");
    }
    
    protected void tearDown() throws Exception {
    }
    
    public void testShowRemittanceDetail() throws Exception 
    {
        Request req = new Request();
        req.addParameter("CCREFNO", "PES04X00000000069978");
        
        Response res = invoke("AUB.test.searchTransaction", req);
        System.out.println(res.getValues());
    }
    
    
    public void xtest0() throws Exception 
    {
        Request req = new Request();
        req.addParameter("CCREFNO", "CEA00X00000000003638");
        
        Response res = invoke("ASIAUB.findTransaction", req);
        System.out.println(res.getValues());
        System.out.println("--------------------------------- ");
        IDataSetModel list = (IDataSetModel) res.getValue("list");
        if (list != null)
        {
            Iterator fields = list.getFields();
            while (fields.hasNext())
            {
                String key = fields.next().toString(); 
                Object val = list.getValue(key); 
                System.out.println(key + "=" + val);
            }
        }
    }
    
    
    private Response invoke(String command, Request req) throws Exception {
        return App.getServiceManager().invoke(command, req);
    }
}
