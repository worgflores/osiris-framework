package mlreward;

import java.util.Iterator;
import junit.framework.*;
import rameses.osiris.client.app.App;
import rameses.osiris.common.interfaces.IDataModel;
import rameses.osiris.common.interfaces.IDataSetModel;
import rameses.osiris.common.service.Request;
import rameses.osiris.common.service.Response;

public class RuleTest extends TestCase 
{
    private String HOST = "http://192.168.3.173:8080/mlhuillier/action";
    
    public RuleTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception 
    {
    } 

    protected void tearDown() throws Exception {} 
        
    private Response invoke(String service, Request req) throws Exception 
    { 
        System.getProperties().put("app.host", HOST);
        return App.getServiceManager().invoke(service, req);
    }    
    
    public void testMain() throws Exception
    {
        Request req = new Request();		
        req.addParameter("CARDNO", "05-411-499");			
        req.addParameter("START", "0");
        req.addParameter("ROWSIZE", "10");
        
        Response res = invoke("rewardpoints.gettotalpoints", req);        
        System.out.println(res.getValues());
        
        dump((IDataSetModel) res.getValue("list")); 
    } 
    
    private void dump(IDataSetModel list) throws Exception 
    {
        if (list == null) return;
        
        for (int i=0; i<list.size(); i++) 
        {
            System.out.println("***** Row# " + (i+1) + " *****");
            IDataModel doc = list.getItem(i); 
            Iterator fields = list.getFields(); 
            while (fields.hasNext()) 
            {
                String fldname = fields.next().toString(); 
                System.out.println(fldname + "=" + doc.getValue(fldname));
            }
        }
    }
}
