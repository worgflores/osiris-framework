package auditreport;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import junit.framework.*;
import rameses.osiris.client.app.App;
import rameses.osiris.common.service.Request;
import rameses.osiris.common.service.Response;

public class MonthlySummaryByBranchTest extends TestCase 
{
    private String HOST = "http://192.168.3.220:8080/mlhuillier/action";
    
    public MonthlySummaryByBranchTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception 
    {
    } 

    protected void tearDown() throws Exception {} 
    
    public void testSendoutValid() throws Exception
    {
        Request req = new Request(); 
        req.addParameter("RPTTABLE", "rpttest" + new SimpleDateFormat("yyyyMMdd").format(new Date()));
        req.addParameter("TXNSTATUS", "STD_SENDOUT_VALID");
        req.addParameter("FROMDATE", "2011-04-01");
        req.addParameter("TODATE", "2011-04-01");
        req.addParameter("BRANCHID", "ALANGL");
        req.addParameter("USERID", "KPUSER");
        req.addParameter("BUILDREPORT", "0");
        
        Response res = invoke("auditreport.monthlyByBranch2", req); 
        System.out.println(res.getValues());
        
        req.addParameter("BUILDREPORT", "1");
        res = invoke("auditreport.monthlyByBranch2", req);
        System.out.println(res.getValue("REPORT"));
    }
    
    

    private Response invoke(String service, Request req) throws Exception 
    { 
        System.getProperties().put("app.host", HOST);
        return App.getServiceManager().invoke(service, req);
    }
    
    private void dump(List list) throws Exception
    {
        System.out.println("");
        
        long counter = 1;
        Iterator itr = list.iterator();
        while (itr.hasNext())
        {
            System.out.println(counter + ") " + itr.next());
            counter += 1;
        }
        System.out.println("");
    }
}
