package uniteller;

import junit.framework.*;
import rameses.osiris.client.app.App;
import rameses.osiris.common.service.Request;
import rameses.osiris.common.service.Response;

public class NewEmptyJUnitTest extends TestCase 
{
    
    public NewEmptyJUnitTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception 
    {
       // UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        System.setProperty("app.host", "http://192.168.3.173:8080/mlhuillier/action"); 
    } 

    protected void tearDown() throws Exception {
    }
    
    private Response invoke(String command, Request req) throws Exception {
        return App.getServiceManager().invoke(command, req);
    }
    
    public void xtestTagAsClaimed() throws Exception
    {
        Request req = new Request();
        req.addParameter("CCREFNO", "5237519942");
        
        Response res = invoke("uniteller.admin.tagAsClaimed", req);
        System.out.println(res.getValues());
    }         
}
