package abscbn;

import junit.framework.*;
import rameses.osiris.client.app.App;
import rameses.osiris.common.service.Request;
import rameses.osiris.common.service.Response;

public class RuleTest extends TestCase {
    
    public RuleTest(String testName) {
        super(testName);
    }
    
    protected void setUp() throws Exception {
        System.setProperty("app.host", "http://192.168.3.173:8080/mlhuillier/action");
    }
    
    protected void tearDown() throws Exception {
    }
    
    public void xtestMain() throws Exception 
    {
        //clearCache();
        System.currentTimeMillis();
    }
    
    public void testCheckIfComplete() throws Exception 
    {
        Request req = new Request();
        req.addParameter("CCREFNO", "FT12089779467139");
        
        Response res = invoke("ABSCBN.test.CheckIfComplete", req);
        System.out.println(res.getValues());        
    }
    
    public void xtestCheckTransactionStatus() throws Exception 
    {
        Request req = new Request();
        req.addParameter("REFNO", "FT12089779467139");
        
        Response res = invoke("ABSCBN.test.checktransactionstatus", req);
        System.out.println(res.getValues());        
        
    }
    
    public void xtestGetRemittance() throws Exception 
    {
        Request req = new Request();
        req.addParameter("CCREFNO", "FT11337453064886");
        
        Response res = invoke("ABSCBN.test.fetchData", req);
        System.out.println(res.getValues());
    }

    public void xtestFetchDataHandler() throws Exception 
    {
        Request req = new Request();
        req.addParameter("CCREFNO", "FT11188305200670");
        
        Response res = invoke("fetchDataHandler.ABSCBN", req);
        System.out.println(res.getValues());
    }
    
    private void xclearCache() throws Exception 
    {
        String[] rulenames = "ABSCBN.branchDailyReport,ABSCBN.calculateCharge,ABSCBN.calculateCharge.Scheme2,ABSCBN.cancelPayout,ABSCBN.cancelPayout_BAK1,ABSCBN.checktransaction.getInfo,ABSCBN.commitPayoutDraft,ABSCBN.creditPayoutFetchData,ABSCBN.creditPayoutSave,ABSCBN.creditPayoutSave_BAK1,ABSCBN.fetchPayoutDraft,ABSCBN.fetchPayoutInfo,ABSCBN.operatordailyreport,ABSCBN.reprint,ABSCBN.resolvePayoutDraft,ABSCBN.save,ABSCBN.saveImplv1,ABSCBN.saveImplv2,ABSCBN.savePayoutFromDraft,ABSCBN.save_BAK1,ABSCBN.save_BAK2,ABSCBN.test.checktransactionstatus,ABSCBN.test.fetchData,ABSCBN.test.getRemittance,ABSCBN.updateChargeValue,abscbnreport.detail,abscbnreport.detaildaily,abscbnreport.summary,abscbnreport.summarydaily,ABSCBNService,ABSCBNService.groovy,ABSCBNServiceAPI,ABSCBNServiceTool.checkStatus,ABSCBN_getFormInfo,afetchDataHandler.ABSCBN,asyncfetchDataHandler_ABSCBN,branchtransaction.payoutabscbn,fetchDataHandler.ABSCBN,report.abscbn.detail,report.abscbn.detaildaily".split(","); 
        for (int i=0; i<rulenames.length; i++)
        { 
            Request req = new Request();
            req.addParameter("RULENAME", rulenames[i]);

            Response res = invoke("sysrule.clearCache", req);
            System.out.println(rulenames[i] + "-> " + res.getValues());
        } 
    } 
    
    private Response invoke(String command, Request req) throws Exception {
        return App.getServiceManager().invoke(command, req);
    }
}
