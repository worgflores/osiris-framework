package util;

import java.security.MessageDigest;
import java.util.Hashtable;
import java.util.Map;
import junit.framework.*;
import rameses.osiris.client.app.App;
import rameses.osiris.common.data.DefaultDataModel;
import rameses.osiris.common.interfaces.IDataModel;
import rameses.osiris.common.service.Request;
import rameses.osiris.common.soap.CryptoUtil;

public class REMITTest extends TestCase 
{
    private String branchid = "REMITX";
    private String userid = "U1180513092024";
    private String terminalid = "T118051309";
    
    public REMITTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
        System.setProperty("app.host", "http://192.168.3.220:8080/mlhuillier/action");
    }

    protected void tearDown() throws Exception {
    }
    
    private String createSignature(String s) throws Exception
    {
        MessageDigest md = MessageDigest.getInstance("MD5");
        md.update(s.getBytes());
        return CryptoUtil.toHexString(md.digest());
    }
    
    public void test0() throws Exception
    {
        String kptn = "REMITX5XQ278H8";
        DefaultDataModel filter = new DefaultDataModel();
        filter.setName( "bykptn" );
        filter.setValue( "kptn", kptn);
        
        Request req = new Request();
        req.addParameter("REMARKS", "FOR PAYOUT" );
        req.addParameter("USERID", userid);
        req.addParameter("BRANCHID", branchid);
        req.addParameter("TERMINALID", terminalid);
        req.addParameter("MLKPVERSION","3.0");
        
        IDataModel doc = App.getDocumentManager().getData("sendout", req, filter);
        Map send = new Hashtable();
        send.put("sendoutid", doc.getValue("objid"));
        send.put("kptn", doc.getValue("kptn"));
        send.put("status", doc.getValue("status"));
        send.put("dtfiled", doc.getValue("dtfiled"));
        send.put("controlno", doc.getValue("controlno"));
        send.put("principal", doc.getValue("principal"));
        send.put("charge", doc.getValue("charge"));
        send.put("othercharge", doc.getValue("othercharge"));
        send.put("senderid", doc.getValue("senderid"));
        send.put("senderlname", doc.getValue("senderlastname"));
        send.put("senderfname", doc.getValue("senderfirstname"));
        send.put("sendermname", doc.getValue("sendermiddlename"));
        send.put("receiverlname", doc.getValue("receiverlastname"));
        send.put("receiverfname", doc.getValue("receiverfirstname"));
        send.put("receivermname", doc.getValue("receivermiddlename"));
        System.out.println(send);
    }

}
