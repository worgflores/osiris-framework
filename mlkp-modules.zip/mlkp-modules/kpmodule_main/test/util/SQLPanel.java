package util;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import rameses.osiris.client.app.App;
import rameses.osiris.common.service.Request;
import rameses.osiris.common.service.Response;

public class SQLPanel extends javax.swing.JPanel 
{
    private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); 
    private String host;
    private String dsname;
    
    public SQLPanel() {
        initComponents();
    }
    
    public String getHost() { return host; }
    public void setHost(String host) { this.host = host; }
    
    public String getDsname() { return dsname; }
    public void setDsname(String dsname) { this.dsname = dsname; }
    
    public void open()
    {
        final JDialog d = new JDialog();
        d.setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE); 
        d.addWindowListener(new WindowAdapter() 
        {
            public void windowClosing(WindowEvent e) 
            {
                d.dispose();
                System.exit(0); 
            } 
        }); 
        d.setModal(true);
        d.setTitle("SQLPanel ["+dsname+"]"); 
        d.setContentPane(this); 
        d.pack();
        d.setVisible(true);
    }
    
    private List execQuery(String stmt) throws Exception 
    { 
        if (stmt == null || stmt.trim().length() == 0) throw new Exception("'stmt' parameter is required");
        
        System.getProperties().put("app.host", host); 
        
        Request req = new Request(); 
        req.addParameter("DSNAME", dsname); 
        req.addParameter("SQLSTMT", stmt); 
        
        Response res = App.getServiceManager().invoke("system.db.list", req); 
        if ("0".equals(res.getValue("statuscode"))) 
        {
            System.out.println("[ERROR] " + res.getValue("statusmsg"));
            throw new Exception(res.getValue("statusmsg")+"");
        } 
        return (List) res.getValue("list");         
    } 
    
    private void execUpdate(String stmt) throws Exception 
    { 
        if (stmt == null || stmt.trim().length() == 0) throw new Exception("'stmt' parameter is required");
        
        System.getProperties().put("app.host", host);
        
        Request req = new Request();
        req.addParameter("DSNAME", dsname);
        req.addParameter("SQLSTMT", stmt);
        
        Response res = App.getServiceManager().invoke("system.db.update", req);
        if ("0".equals(res.getValue("statuscode"))) 
        {
            System.out.println("[ERROR] " + res.getValue("statusmsg"));
            throw new Exception(res.getValue("statusmsg")+"");
        }         
    }
    
    private StringBuffer list(List list) throws Exception
    {
        long counter = 1;
        StringBuffer out = new StringBuffer();
        Iterator items = list.iterator();
        while (items.hasNext())
        {
            Map data = (Map) items.next();
            Iterator flds = data.keySet().iterator();
            StringBuffer sb = new StringBuffer();
            while (flds.hasNext())
            {
                String key = flds.next().toString();
                Object val = data.get(key);
                if (sb.length() > 0) sb.append(", ");
                
                sb.append(key + "=" + val);
            }
            
            out.append(counter + ") " + sb + "\n");
            counter += 1;
        }
        return out;
    }

    // <editor-fold defaultstate="collapsed" desc=" Generated Code ">//GEN-BEGIN:initComponents
    private void initComponents() {
        jPanel1 = new javax.swing.JPanel();
        btnQuery = new javax.swing.JButton();
        btnUpdate = new javax.swing.JButton();
        jSplitPane1 = new javax.swing.JSplitPane();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtSQL = new javax.swing.JTextArea();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtOutput = new javax.swing.JTextArea();

        setLayout(new java.awt.BorderLayout());

        setPreferredSize(new java.awt.Dimension(800, 600));
        jPanel1.setLayout(new javax.swing.BoxLayout(jPanel1, javax.swing.BoxLayout.X_AXIS));

        jPanel1.setBorder(javax.swing.BorderFactory.createEmptyBorder(10, 10, 10, 10));
        btnQuery.setMnemonic('q');
        btnQuery.setText("Execute Query");
        btnQuery.setFocusable(false);
        btnQuery.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnQueryActionPerformed(evt);
            }
        });

        jPanel1.add(btnQuery);

        btnUpdate.setMnemonic('u');
        btnUpdate.setText("Execute Update");
        btnUpdate.setFocusable(false);
        btnUpdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdateActionPerformed(evt);
            }
        });

        jPanel1.add(btnUpdate);

        add(jPanel1, java.awt.BorderLayout.NORTH);

        jSplitPane1.setDividerLocation(400);
        jSplitPane1.setOrientation(javax.swing.JSplitPane.VERTICAL_SPLIT);
        txtSQL.setColumns(20);
        txtSQL.setRows(5);
        txtSQL.setTabSize(4);
        txtSQL.setBorder(javax.swing.BorderFactory.createEmptyBorder(5, 5, 1, 1));
        jScrollPane1.setViewportView(txtSQL);

        jSplitPane1.setTopComponent(jScrollPane1);

        txtOutput.setColumns(20);
        txtOutput.setEditable(false);
        txtOutput.setFont(new java.awt.Font("Courier", 0, 11));
        txtOutput.setRows(5);
        txtOutput.setTabSize(4);
        txtOutput.setText("Output");
        txtOutput.setBorder(javax.swing.BorderFactory.createEmptyBorder(5, 5, 1, 1));
        jScrollPane2.setViewportView(txtOutput);

        jSplitPane1.setRightComponent(jScrollPane2);

        add(jSplitPane1, java.awt.BorderLayout.CENTER);

    }// </editor-fold>//GEN-END:initComponents

    private void btnUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateActionPerformed

        try 
        {
            String sql = txtSQL.getSelectedText();
            if (sql == null || sql.trim().length() == 0)
                sql = txtSQL.getText(); 
            
            txtOutput.setText("Started " + sdf.format(new Date()) + "\n");
            execUpdate(sql);
            txtOutput.append("\nQuery completed successfully.");
        } 
        catch(Exception ex) 
        {
            txtOutput.append("\nError.. " + ex.getMessage());
            JOptionPane.showMessageDialog(this, ex.getMessage(), "ERROR", JOptionPane.ERROR_MESSAGE); 
        }
        
    }//GEN-LAST:event_btnUpdateActionPerformed

    private void btnQueryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnQueryActionPerformed

        try 
        {
            String sql = txtSQL.getSelectedText();
            if (sql == null || sql.trim().length() == 0)
                sql = txtSQL.getText(); 
            
            txtOutput.setText("Started " + sdf.format(new Date()) + "\n\n");
            List list = execQuery(sql);
            txtOutput.append(list(list).toString());
            txtOutput.append("\nQuery completed successfully.");
            
            try { txtOutput.select(0,0); }catch(Exception ign){;}  
        } 
        catch(Exception ex) 
        {
            txtOutput.append("\nError.. " + ex.getMessage());
            JOptionPane.showMessageDialog(this, ex.getMessage(), "ERROR", JOptionPane.ERROR_MESSAGE); 
        }
        
    }//GEN-LAST:event_btnQueryActionPerformed
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnQuery;
    private javax.swing.JButton btnUpdate;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JSplitPane jSplitPane1;
    private javax.swing.JTextArea txtOutput;
    private javax.swing.JTextArea txtSQL;
    // End of variables declaration//GEN-END:variables
    
}
