package util;

import java.io.InputStream;
import java.net.URL;
import java.rmi.server.UID;
import java.security.MessageDigest;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import junit.framework.*;
import rameses.osiris.client.app.App;
import rameses.osiris.common.data.DefaultDataModel;
import rameses.osiris.common.interfaces.IDataModel;
import rameses.osiris.common.service.Request;
import rameses.osiris.common.service.Response;
import rameses.osiris.common.soap.CryptoUtil;

public class NYBAYTest extends TestCase 
{
    private String sessionId = "ML" + new UID();
    private String username = "PMLLER";
    private String password = "PMLLER0902";
    private String pinno = "PMLLER20090902";
    
    public NYBAYTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception 
    {
        System.setProperty("app.host", "http://192.168.3.247:8080/mlhuillier/action");
    }

    protected void tearDown() throws Exception {
    }
    
    private String createSignature(String s) throws Exception
    {
        MessageDigest md = MessageDigest.getInstance("MD5");
        md.update(s.getBytes());
        return CryptoUtil.toHexString(md.digest());
    }
    

    public void xtestMain() throws Exception 
    {
        //MLMAIN1117051542
        Request req = new Request();
        req.addParameter("CCREFNO", "NYBP40135");
        
        Response res = App.getServiceManager().invoke("NYBP.test.showRemittanceDetail", req); 
        System.out.println(res.getValues());
        
        Map result = (Map) res.getValue("result");
        result.put("idtype", "TEST");
        result.put("idno", "TEST");
        result.put("idexpiry", "2011-12-31");
        result.put("branchid", "MAIN1");
        result.put("userid", "KPUSER");
        result.put("terminalid", "SYSTEM");
                
        IDataModel data = new DefaultDataModel();
        Iterator keys = result.keySet().iterator(); 
        while (keys.hasNext()) 
        {
            String key = keys.next().toString();
            try { 
                data.setValue(key, result.get(key));
            } catch(Exception ign){
                System.out.println("[ERROR] " + key + ": " + ign.getMessage());
            }
        }
        data.setName("data"); 
        
        req.addParameter("DATA", data);
        req.addParameter("BRANCHID", "MAIN1");
        req.addParameter("USERID", "KPUSER");
        req.addParameter("TERMINALID", "SYSTEM");
        
        res = App.getServiceManager().invoke("NYBP.saveImplv2", req); 
        System.out.println(res.getValues()); 
    } 
    
    public void xtestTagAsCompleted() throws Exception 
    { 
        String refno = "XXXX";
        String traceno = "XXXXXX";
        
        String s = sessionId + refno + traceno + pinno;
        String signature = createSignature(s);
        
        StringBuffer stmt = new StringBuffer();
        stmt.append("sessionId=" + sessionId);
        stmt.append("&username=" + username);
        stmt.append("&password=" + password);
        stmt.append("&refno=" + refno);
        stmt.append("&traceno=" + traceno);
        stmt.append("&signature=" + signature);        
        
        String result = invoke("TagAsCompleted", stmt.toString());
        System.out.println("[TagAsCompleted] " + result);
        
        String[] keys = new String[]
        {
            "sessionId","status","objid","refno","amount","currencyid",
            "receiverlname","receiverfname","receivermname","receiveraddress",
            "receiverphone", "receiptno" 
        }; 
        Map data = convert(result, keys); 
        System.out.println(data); 
    } 
    
    public void xtestInquireTagAsCompleted() throws Exception 
    {
        String refno = "SAAR36-658";
        String traceno = "TACLO3WPKWTDH5";

        String s = sessionId + username + refno + traceno + pinno;
        String signature = createSignature(s);
        
        StringBuffer stmt = new StringBuffer();
        stmt.append("sessionId=" + sessionId);
        stmt.append("&username=" + username);
        stmt.append("&password=" + password);
        stmt.append("&refno=" + refno);
        stmt.append("&traceno=" + traceno);
        stmt.append("&signature=" + signature);

        String result = invoke("InquireTagAsCompleted", stmt.toString());
        System.out.println("[InquireTagAsCompleted] " + result);
        
        String[] keys = new String[]
        {
            "sessionId","status","objid", "refno", 
            "amount","currencyid","receiverlname",
            "receiverfname","receivermname","receiveraddress", "receiverphone",
            "receiptno"
        };
        Map data = convert(result, keys);
        System.out.println(data);
        
        String status = data.get("status")+"";
        if ("0".equals(status)){}
        else if ("1".equals(status)) throw new Exception("Transaction connot be processed.");
        else if ("3".equals(status)) throw new Exception("Cannot be process due to other errors. ${result.refno}");
        else if ("4".equals(status)) throw new Exception("Incorrect username or password.");
        else if ("6".equals(status)) throw new Exception("Incorrect signature.");
        else throw new Exception("Unknown status "+status+" for transaction 'InquiretagAsCompleted'.");        
    }
    
    public void xtestShowRemittanceDetail() throws Exception 
    {
        String refno = "33ny100081831";
        
        String s = sessionId + refno + pinno;
        String signature = createSignature(s);

        StringBuffer stmt = new StringBuffer();
        stmt.append("sessionId=" + sessionId);
        stmt.append("&username=" + username);
        stmt.append("&password=" + password);
        stmt.append("&refno=" + refno);
        stmt.append("&signature=" + signature);

        String result = invoke("ShowRemittanceDetail", stmt.toString());
        System.out.println("[ShowRemittanceDetail]\n" + result);
        
        String[] keys = new String[]
        {
            "sessionId","status","objid", "amount","currencyid",
            "receiverlname", "receiverfname","receivermname","receiveraddress", 
            "receiverphone", "dtfiled", "senderlname", "senderfname", "sendermname",
            "senderaddress", "traceno" 
        };
        
//        "sessionId":"ML4cfae9bc:124bd2c40d3:-96", "status":"1", "objid":"33CI880005313", "amount":"10000.00",  "currencyid":"PHP", 
//        "receiverlname":"ASAREZ", "receiverfname":"MONICA", "receivermname":"", "receiveraddress":".PASIG CITY.METRO MANILA  ", 
//        "receiverphone":"09289318253", "dtfiled":"2009-10-30", "senderlname":"LEGASPI", "senderfname":"ALMA", "sendermname":"", "senderaddress":"USA c/o NYBP Philippines", "traceno":"MARAMAML0TKY69", ]

        
        Map data = convert(result, keys);
        String status = data.get("status")+"";
        if ("0".equals(status)) 
            data.put("statusmsg", "OK");
        else if ("4".equals(status)) 
            data.put("statusmsg", "Transaction does not exists");
        else if ("1".equals(status)) 
            data.put("statusmsg", "Transaction already claimed");
        else if ("3".equals(status)) 
            data.put("statusmsg", "Cannot be processed due to other errors. " + refno);
        else if ("5".equals(status)) 
            data.put("statusmsg", "Incorrect password or username.");
        else if ("6".equals(status)) 
            data.put("statusmsg", "Incorrect signature value");
        else if ("7".equals(status)) 
            data.put("statusmsg", "Use by other service. Pickup not intended for MLhuillier");
        else
            data.put("statusmsg", "Unknown status "+status+" for transaction 'ShowRemittanceDetail'.");
        
        System.out.println("");
        System.out.println(data);
        System.out.println("");
        //inquireTagAsCompleted(refno, data.get("traceno")+"");
    }

    private void inquireTagAsCompleted(String refno, String traceno) throws Exception 
    {
        String s = sessionId + username + refno + traceno + pinno;
        String signature = createSignature(s);
        
        StringBuffer stmt = new StringBuffer();
        stmt.append("sessionId=" + sessionId);
        stmt.append("&username=" + username);
        stmt.append("&password=" + password);
        stmt.append("&refno=" + refno);
        stmt.append("&traceno=" + traceno);
        stmt.append("&signature=" + signature);

        String result = invoke("InquireTagAsCompleted", stmt.toString());
        System.out.println("[InquireTagAsCompleted]\n" + result);
        
        String[] keys = new String[]
        {
            "sessionId","status","objid", "refno", 
            "amount","currencyid","receiverlname",
            "receiverfname","receivermname","receiveraddress", "receiverphone",
            "receiptno"
        };
        Map data = convert(result, keys);
        System.out.println(data);
        
        String status = data.get("status")+"";
        if ("0".equals(status)){}
        else if ("1".equals(status)) throw new Exception("Transaction connot be processed.");
        else if ("3".equals(status)) throw new Exception("Cannot be process due to other errors. ${result.refno}");
        else if ("4".equals(status)) throw new Exception("Incorrect username or password.");
        else if ("6".equals(status)) throw new Exception("Incorrect signature.");
        else throw new Exception("Unknown status "+status+" for transaction 'InquiretagAsCompleted'.");        
    }
    
    public void xtestDailyReport() throws Exception 
    { 
        System.setProperty("app.host", "http://192.168.3.220:8080/mlhuillier/action");
        
        Request req = new Request();
        req.addParameter("USERID", "SYSTEM");
        req.addParameter("BRANCHID", "%");
        req.addParameter("LOOP", "VISMIN");
        req.addParameter("PERIOD", "DAILY");
        req.addParameter("LOCATION", "LOOP");
        req.addParameter("FROMDATE", "2009-10-02");
        
        //Response res = App.getServiceManager().invoke("NYBAY.dailyReport", req);
        Response res = App.getServiceManager().invoke("report.nybaydetail", req);
        System.out.println(res.getValue("REPORT"));
    } 
    
    private String invoke(String name, String requestInfo)throws Exception 
    {
        InputStream is = null;

        try 
        {
            String path = "http://192.168.3.211:8080/wsproxy/redirect/https://www.nybp.info/PickupWebService/Service1.asmx/"+name+"?"+requestInfo;
            URL url = new URL(path);
            is = url.openStream();
            int i = -1;
            StringBuffer sb = new StringBuffer(); 
            while((i = is.read()) != -1 ){ 
                sb.append((char)i); 
            } 

            String txt = sb.toString();
            
            String s = "<"+name+"Return>";

            int idx0 = txt.indexOf(s);
            int idx1= txt.indexOf("</"+name+"Return>");

            String result = txt.substring(idx0+s.length(),idx1);
            return result;
        } 
        catch(Exception e) {
            throw e;
        } 
        finally {
            try { is.close(); }catch(Exception ign){;}
        }
    }
        
    private Map convert(String data, String[] keys) 
    {
        Map map = new HashMap();
        int startidx = 0;
        int idx = -1;
        int ctr = 0;
        while(true) 
        {
            if(ctr >= keys.length) break;
            
            idx = data.indexOf('|',startidx);
            if(idx < 0) break;

            map.put(keys[ctr], data.substring(startidx, idx));
            startidx = idx + 1;
            ctr ++;
        }

        if (ctr < keys.length && startidx > 0 && startidx < data.length())
            map.put(keys[ctr],data.substring(startidx));
        
        return map;
    }

}
