package util;

import java.security.MessageDigest;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import junit.framework.*;
import rameses.osiris.client.app.App;
import rameses.osiris.common.interfaces.IDataSetModel;
import rameses.osiris.common.service.Request;
import rameses.osiris.common.service.Response;
import rameses.osiris.common.soap.CryptoUtil;

public class UnitellerTest extends TestCase 
{
    
    public UnitellerTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
    }

    protected void tearDown() throws Exception {
    }
    
    private String createSignature(String s) throws Exception
    {
        MessageDigest md = MessageDigest.getInstance("MD5");
        md.update(s.getBytes());
        return CryptoUtil.toHexString(md.digest());
    }
    
    public void xtest0() throws Exception 
    { 
        System.setProperty("app.host", "http://192.168.3.220:8080/mlhuillier/action");
        
        Request req = new Request();
        req.addParameter("USERID", "SYSTEM");
        req.addParameter("BRANCHID", "RECLA");
        req.addParameter("CCREFNO", "59360550221");
        
        //Response res = App.getServiceManager().invoke("NYBAY.dailyReport", req);
        Response res = App.getServiceManager().invoke("uniteller.testSearch", req); 
        System.out.println(res.getValues());
        
        IDataSetModel dsm = (IDataSetModel) res.getValue("list");
        Iterator keys = dsm.getFields();
        while (keys.hasNext())
        {
            String key = keys.next().toString();
            Object val = dsm.getValue(key);
            System.out.println(key + "=" + val);
        }
    } 
    

}
