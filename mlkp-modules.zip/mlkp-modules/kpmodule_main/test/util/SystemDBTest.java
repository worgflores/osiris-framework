package util;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import junit.framework.*;
import rameses.osiris.client.app.App;
import rameses.osiris.common.service.Request;
import rameses.osiris.common.service.Response;

public class SystemDBTest extends TestCase 
{
    private String HOST = "http://192.168.3.247:8080/mlhuillier/action";
    
    public SystemDBTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {} 

    protected void tearDown() throws Exception {} 

    
    public void test0001_1() throws Exception 
    { 
        dump(execQuery("select * from mlpartner.nybaypayoutdraft where objid like '33ny100765415%' limit 10 ")); 
        //dump(execQuery("select * from mlkp.tblsendout where objid='SB-282204db:12ca1a3ff6f:4209' ")); 
        
    }
        
    public void xtest0001() throws Exception 
    { 
        
        //1) {globalrate=44.18000, curselling=44.93, txndate=2010-09-15 13:22:07.0, currency=USD, parentid=STD, curbuying=43.93, modifiedby=ml1, objid=FRX56002b0b:12abc93d371:-7fd9}
        //2) {globalrate=44.18000, curselling=44.93, txndate=2010-09-15 13:22:07.0, currency=USD, parentid=SPECIAL, curbuying=44.08, modifiedby=ml1, objid=FRX56002b0b:12abc93d371:-7fd8}
        //3) {globalrate=44.18000, curselling=44.93, txndate=2010-09-15 13:22:07.0, currency=USD, parentid=EXTRA, curbuying=44.08, modifiedby=ml1, objid=FRX56002b0b:12abc93d371:-7fd7}
        
        //FRX56002b0b:12abc93d371:-7fd9  FRX56002b0b:12abc93d371:-7fd8  FRX56002b0b:12abc93d371:-7fd7 
        //dump(execQuery("select * from mlkp.tblforexratehistory order by txndate desc limit 10")); 
        
        /*
        execUpdate(" insert into mlkp.tblforexratehistory (objid, parentid, txndate, globalrate, currency, curselling, curbuying, modifiedby) " + 
                   " select 'USDSTD20100915132207', parentid, '2010-09-15 12:59:01', globalrate, currency, curselling, curbuying, modifiedby " + 
                   " from mlkp.tblforexratehistory where objid='FRX56002b0b:12abc93d371:-7fd9' "); 
        
        execUpdate(" insert into mlkp.tblforexratehistory (objid, parentid, txndate, globalrate, currency, curselling, curbuying, modifiedby) " + 
                   " select 'USDSP20100915132207', parentid, '2010-09-15 12:59:01', globalrate, currency, curselling, curbuying, modifiedby " + 
                   " from mlkp.tblforexratehistory where objid='FRX56002b0b:12abc93d371:-7fd8' "); 
        
        execUpdate(" insert into mlkp.tblforexratehistory (objid, parentid, txndate, globalrate, currency, curselling, curbuying, modifiedby) " + 
                   " select 'USDEXT20100915132207', parentid, '2010-09-15 12:59:01', globalrate, currency, curselling, curbuying, modifiedby " + 
                   " from mlkp.tblforexratehistory where objid='FRX56002b0b:12abc93d371:-7fd7' "); 
        
        */
        
        
        
        
        
        
        
        
        
        
        
        
    }
    
    private Map getTransactionInfo(String refno) throws Exception 
    {
        return execSingleQuery(" select * from (select objid, strccrefno from mlkp.tblsendoutinfo where strccrefno='"+refno+"')bt " + 
                               "    inner join mlkp.tblsendout s on bt.objid=s.objid " + 
                               "    left join mlkp.tblsendoutinfo sif on bt.objid=sif.objid " + 
                               "    left join mlkp.tblsendoutor sor on bt.objid=sor.objid " +
                               "    left join mlkp.tblsendoutoption sop on bt.objid=sop.objid " +
                               "    left join mlkp.tblsendoutwalkinid sw on bt.objid=sw.objid ");
    }
    
    public void xtest0002() throws Exception
    {
        List list = null;
        
//        list = execQuery(" select bt.* from ( " + 
//                         " select objid, state, dtfiled, strkptn, strsenderlname, strsenderfname, strsendermname,  " + 
//                         "   strreceiverlname, strreceiverfname, strreceivermname, curprincipal from mlkp.tblsendout " + 
//                         " where strsenderlname like 'gaanan%' limit 100) bt order by dtfiled desc ");
        
//        list = execQuery(" select bt.* from ( " + 
//                         " select objid, state, dtfiled, strkptn, strsenderlname, strsenderfname, strsendermname,  " + 
//                         "   strreceiverlname, strreceiverfname, strreceivermname, curprincipal from mlkp.tblsendout " + 
//                         " where strsenderlname='braza' and strsenderfname='eduardo' limit 100) bt order by dtfiled desc ");
        
//        list = execQuery(
//                         " select  " + 
//                         "   s.state, s.dtfiled, s.strkptn, s.strsenderlname, s.strsenderfname, s.strsendermname, " + 
//                         "   s.strreceiverlname, s.strreceiverfname, s.strreceivermname, s.curprincipal " +                 
//                         " from ( " + 
//                         "        select objid, strbranchid from mlkp.tblsendout " + 
//                         "        where dtfiled between '2010-03-15 00:00:00' and '2010-03-15 23:59:59' " + 
//                         "        having strbranchid='binan1' " + 
//                         "      )bt " + 
//                         "   inner join mlkp.tblsendout s on bt.objid=s.objid " + 
//                         " order by s.dtfiled desc ");
        
//        list = execQuery(" select * from mlkp_admin.sys_user_permission where permissionkey like '%kyc%' "); 
//        dump(list);
        
        //execUpdate(" insert ignore into mlkp_admin.sys_user_permission (uid,permissionkey) values ('TURNO-G','KYC.(mgmt|edit)') ");
        
    }
    
    
    private Map execSingleQuery(String stmt) throws Exception { 
        return execSingleQuery(stmt, "java:mldb"); 
    }     
    
    private Map execSingleQuery(String stmt, String dsname) throws Exception 
    { 
        List list = execQuery(stmt, dsname); 
        if (list != null && list.size() > 0)
            return (Map) list.get(0);
        else
            return null; 
    }         
    
    private List execQuery(String stmt) throws Exception { 
        return execQuery(stmt, "java:mldb"); 
    } 
    
    private List execAuditQuery(String stmt) throws Exception {
        return execQuery(stmt, "java:mlauditordb"); 
    }
    
    private List execQuery(String stmt, String dsname) throws Exception 
    { 
        if (stmt == null || stmt.trim().length() == 0) throw new Exception("'stmt' parameter is required");
        if (dsname == null || dsname.trim().length() == 0) throw new Exception("'dsname' parameter is required");
        
        System.getProperties().put("app.host", HOST); 
        
        Request req = new Request(); 
        req.addParameter("DSNAME", dsname); 
        req.addParameter("SQLSTMT", stmt); 
        
        Response res = App.getServiceManager().invoke("system.db.list", req); 
        if ("0".equals(res.getValue("statuscode"))) 
        {
            System.out.println("[ERROR] " + res.getValue("statusmsg"));
            throw new Exception(res.getValue("statusmsg")+"");
        } 
        
        return (List) res.getValue("list"); 
    } 

    private void execUpdate(String stmt) throws Exception {
        execUpdate(stmt, "java:mldb");
    }
    
    private void execUpdate(String stmt, String dsname) throws Exception 
    { 
        if (stmt == null || stmt.trim().length() == 0) throw new Exception("'stmt' parameter is required");
        if (dsname == null || dsname.trim().length() == 0) throw new Exception("'dsname' parameter is required");
        
        System.getProperties().put("app.host", HOST);
        
        Request req = new Request();
        req.addParameter("DSNAME", dsname);
        req.addParameter("SQLSTMT", stmt);
        
        Response res = App.getServiceManager().invoke("system.db.update", req);
        if ("0".equals(res.getValue("statuscode"))) 
        {
            //System.out.println("[ERROR] " + res.getValue("statusmsg"));
            throw new Exception(res.getValue("statusmsg")+"");
        } 
    }

    
    private Response invoke(String service, Request req) throws Exception 
    { 
        System.getProperties().put("app.host", HOST);
        return App.getServiceManager().invoke(service, req);
    }
    
    private void dump(List list) throws Exception
    {
        System.out.println("");
        
        long counter = 1;
        Iterator itr = list.iterator();
        while (itr.hasNext())
        {
            System.out.println(counter + ") " + itr.next());
            counter += 1;
        }
        System.out.println("");
    }
    
}
