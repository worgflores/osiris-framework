package util;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import junit.framework.*;
import rameses.osiris.client.app.App;
import rameses.osiris.common.interfaces.IDataModel;
import rameses.osiris.common.interfaces.IDataSetModel;
import rameses.osiris.common.service.Request;
import rameses.osiris.common.service.Response;

public class NYBPChargeUpdater2 extends TestCase 
{
    private String HOST = "http://192.168.3.247:8080/mlhuillier/action";
    
    public NYBPChargeUpdater2(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
    }

    protected void tearDown() throws Exception {
    }
    
    public void test000() throws Exception 
    { 
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date dtfrom = java.sql.Date.valueOf("2010-01-18");
        Date dtto = java.sql.Date.valueOf("2010-01-31");
        Calendar cal = new GregorianCalendar();
        cal.setTime(dtfrom);
        while (true)
        {
            Date dt = cal.getTime();
            if (dt.after(dtto)) break;
            
            String sdate = sdf.format(dt);
            IDataSetModel list = getTransactionsByDate(sdate);
            int size = list.size();
            int counter = 0;
            
            System.out.println("updating... [date="+sdate+", size="+size+"]");
            while (true)
            {
                if (counter >= size) break;
                
                IDataModel doc = list.getItem(counter);
                String objid = doc.getValue("objid").toString();
                String currency = doc.getValue("currencyid").toString().toLowerCase();
                double amount = Double.parseDouble(doc.getValue("amount").toString());
                double charge = 0.0;
                
                if ("usd".equals(currency))
                {
                    if (amount < 800)
                        charge = 3;
                    else
                    {
                        int mod = (int) (amount % 800.0);
                        int cnt = (int) (amount / 800.0);
                        if (mod > 0) cnt += 1;
                        
                        charge = 3.0 * cnt;                        
                    }
                }
                else 
                {
                    if (amount <= 50000) 
                        charge = 125;
                    else
                    {
                        int mod = (int) (amount % 50000.0);
                        int cnt = (int) (amount / 50000.0);
                        if (mod > 0) cnt += 1;
                        
                        charge = 125.0 * cnt;
                    }
                }
                
                try
                {
                    execUpdate("update mlpartner.nybaypayouttxn set charge="+charge+" where objid='"+objid+"'");
                    Thread.sleep(100);
                }
                catch(Throwable t) {
                    System.out.println("   [ERROR: "+objid+"] " + t.getMessage());
                }
                
                counter += 1;
            }
            cal.add(Calendar.DATE, 1);
            System.gc();
        }
    }     

    private IDataSetModel getTransactionsByDate(String sdate) throws Exception
    {
        StringBuffer sb = new StringBuffer();       
//        sb.append(" select bt.*, ");
//        sb.append("    case ");
//        sb.append("       when bt.currencyid='PHP' then ");
//        sb.append("          case ");
//        sb.append("             when bt.amount between 0.01 and 50000.0 then 125.0 ");
//        sb.append("             when bt.amount between 50000.01 and 100000.0 then 150.0 else 0.0 ");
//        sb.append("          end ");
//        sb.append("       when bt.currencyid='USD' then ");
//        sb.append("          case ");
//        sb.append("             when bt.amount between 0.01 and 800.0 then 3.0 ");
//        sb.append("             when bt.amount between 800.01 and 1600.0 then 6.0 ");
//        sb.append("             when bt.amount between 1600.01 and 2000.0 then 9.0 else 0.0 ");
//        sb.append("          end ");
//        sb.append("       else 0.0 ");
//        sb.append("    end as charge ");
//        sb.append(" from ( ");
//        sb.append("          select objid, dtclaimed, kptn, currencyid, amount ");
//        sb.append("          from mlpartner.nybaypayouttxn ");
//        sb.append("          where dtclaimed between '"+sdate+" 00:00:00' and '"+sdate+" 23:59:59' "); 
//        sb.append("      )bt ");
//        sb.append(" order by dtclaimed ");
        
        sb.append(" select objid, currencyid, amount, charge from mlpartner.nybaypayouttxn ");
        sb.append(" where dtclaimed between '"+sdate+" 00:00:00' and '"+sdate+" 23:59:59' "); 
        sb.append(" having charge is null ");
        return execQuery(sb.toString());
    }
    
    private IDataSetModel execQuery(String stmt) throws Exception 
    { 
        System.getProperties().put("app.host", HOST);
        
        Request req = new Request();
        req.addParameter("DSNAME", "java:mldb");
        req.addParameter("QUERY", "2");
        req.addParameter("SQLSTMT", stmt);
        
        Response res = App.getServiceManager().invoke("system.exec", req);
        return (IDataSetModel) res.getValue("list");
    } 
    
    private void execUpdate(String stmt) throws Exception { 
        execUpdate(stmt, HOST);
    }
    
    private void execUpdate(String stmt, String host) throws Exception 
    { 
        System.getProperties().put("app.host", host);
        
        Request req = new Request();
        req.addParameter("DSNAME", "java:mldb");
        req.addParameter("QUERY", "0");
        req.addParameter("SQLSTMT", stmt);
        
        App.getServiceManager().invoke("system.exec", req);
    }    
    
    private Map convert(IDataModel doc) throws Exception
    {
        Map data = new HashMap();
        Iterator fields = doc.getFields();
        while (fields.hasNext())
        {
            String key = fields.next().toString();
            Object val = doc.getValue(key);
            data.put(key, val);
        }
        return data;
    }
    
    private Response invoke(String service, Request req) throws Exception 
    { 
        System.getProperties().put("app.host", HOST);
        return App.getServiceManager().invoke(service, req);
    }
    
    private void list(IDataSetModel idsm, String name) throws Exception
    {
        System.out.println("["+name+"]");
        for (int i=0; i<idsm.size(); i++)
        {
            IDataModel doc = idsm.getItem(i);
            Iterator itr = doc.getFields();
            StringBuffer sb = new StringBuffer();
            while (itr.hasNext())
            {
                String key = itr.next().toString();
                Object val = doc.getValue(key);
                if (sb.length() > 0) sb.append(", ");
                
                sb.append(key + "=" + val);
            }
            System.out.println(sb);
        }
        System.out.println("");
    }
    
}
