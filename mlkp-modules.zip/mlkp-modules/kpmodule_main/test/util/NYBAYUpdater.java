package util;

import java.io.InputStream;
import java.net.URL;
import java.rmi.server.UID;
import java.security.MessageDigest;
import junit.framework.*;
import rameses.osiris.common.soap.CryptoUtil;

public class NYBAYUpdater extends TestCase 
{
    private String username = "PMLLER";
    private String password = "PMLLER0902";
    private String pinno = "PMLLER20090902";
    
    public NYBAYUpdater(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
    }

    protected void tearDown() throws Exception {
    }
    
    public void test0() throws Exception
    {
        String refno = "MD00613434";
        String traceno = "LILOACNMT4TPYP";
        System.out.println(inquireTagAsCompleted(refno, traceno));

        System.out.println("");
        System.out.println(tagAsCompleted(refno, traceno));
        
        System.out.println("");
        System.out.println(getRemittanceDetail(refno));
    }
    
    private String createSignature(String s) throws Exception
    {
        MessageDigest md = MessageDigest.getInstance("MD5");
        md.update(s.getBytes());
        return CryptoUtil.toHexString(md.digest());
    }
    
    private String tagAsCompleted(String refno, String traceno) throws Exception 
    { 
        String sessionId = "ML" + new UID();
        String s = sessionId + refno + traceno + pinno;
        String signature = createSignature(s);
        
        StringBuffer stmt = new StringBuffer();
        stmt.append("sessionId=" + sessionId);
        stmt.append("&username=" + username);
        stmt.append("&password=" + password);
        stmt.append("&refno=" + refno);
        stmt.append("&traceno=" + traceno);
        stmt.append("&signature=" + signature);        
        
        return invoke("TagAsCompleted", stmt.toString());
    } 
    
    private String inquireTagAsCompleted(String refno, String traceno) throws Exception 
    {
        String sessionId = "ML" + new UID();
        String s = sessionId + username + refno + traceno + pinno;
        String signature = createSignature(s);
        
        StringBuffer stmt = new StringBuffer();
        stmt.append("sessionId=" + sessionId);
        stmt.append("&username=" + username);
        stmt.append("&password=" + password);
        stmt.append("&refno=" + refno);
        stmt.append("&traceno=" + traceno);
        stmt.append("&signature=" + signature);

        return invoke("InquireTagAsCompleted", stmt.toString());
    }    
    
    private String getRemittanceDetail(String refno) throws Exception 
    {
        String sessionId = "ML" + new UID();
        String s = sessionId + refno + pinno;
        String signature = createSignature(s);

        StringBuffer stmt = new StringBuffer();
        stmt.append("sessionId=" + sessionId);
        stmt.append("&username=" + username);
        stmt.append("&password=" + password);
        stmt.append("&refno=" + refno);
        stmt.append("&signature=" + signature);

        return invoke("ShowRemittanceDetail", stmt.toString());
    }
            

    private String invoke(String name, String requestInfo)throws Exception 
    {
        InputStream is = null;

        try 
        {
            String path = "http://192.168.3.211:8080/wsproxy/redirect/http://www.nybp.info/PickupWebService/Service1.asmx/"+name+"?"+requestInfo;
            URL url = new URL(path);
            is = url.openStream();
            int i = -1;
            StringBuffer sb = new StringBuffer(); 
            while((i = is.read()) != -1 ){ 
                sb.append((char)i); 
            } 

            String txt = sb.toString();
            
            String s = "<"+name+"Return>";

            int idx0 = txt.indexOf(s);
            int idx1= txt.indexOf("</"+name+"Return>");

            String result = txt.substring(idx0+s.length(),idx1);
            return result;
        } catch(Exception e) {
            throw e;
        } finally {
            is.close();
        }
    }
    
    
    /*
    insert into mlpartner.nybaypayouttxn 
    (
            objid, dtfiled, dtclaimed, kptn, branchid, userid, terminalid, sendingbranchid,  
            receiverlname, receiverfname, receivermname, receiveraddress,  
            receiverphone, currencyid, amount, charge, idtype, cardid, idexpiry  
    ) 
    values 
    (
            'SAAR52-474', '2009-10-28 00:00:00', '2009-10-29 10:45:00', 'MBLCAT5R2353ME', 'MBLCAT', 'DAVID-J', 'BSC3B5XU', 'NYBP', 
            'VERGARA', 'HER C', null,'PAMPANGA.MABALACAT.PAMBANGA', 
            null, 'PHP', '4046.00', 0.0, 'POSTALID', '7025181', '2013-09-01'  
    )      
    **/
}
