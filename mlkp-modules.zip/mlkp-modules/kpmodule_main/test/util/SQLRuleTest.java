package util;

import javax.swing.UIManager;
import junit.framework.*;

public class SQLRuleTest extends TestCase 
{
    private String HOST = "http://192.168.3.173:8080/mlhuillier/action";
    
    public SQLRuleTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
        UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
    }

    protected void tearDown() throws Exception {}
        
    public void xtest0000() throws Exception
    {
        SQLPanel p = new SQLPanel(); 
        p.setHost(HOST); 
        p.setDsname("java:mldb");
        p.open(); 
        
    }
}
