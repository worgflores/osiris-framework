package util;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import junit.framework.*;
import rameses.osiris.client.app.App;
import rameses.osiris.common.interfaces.IDataModel;
import rameses.osiris.common.interfaces.IDataSetModel;
import rameses.osiris.common.service.Request;
import rameses.osiris.common.service.Response;

public class BillPaymentTest extends TestCase 
{
    private String HOST = "http://192.168.3.220:8080/mlhuillier/action";
    
    public BillPaymentTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
        System.getProperties().put("app.host", HOST);
    }

    protected void tearDown() throws Exception {
    }

    public void xtestBranchDailyReport() throws Exception 
    { 
        Request req = new Request();
        req.addParameter("USERID", "ALIPIS-L");
        req.addParameter("BRANCHID", "LCASTE");
        req.addParameter("FROMDATE", "2009-09-22");
        req.addParameter("REPORTNAME", "branchmgr.billpayment");

        Response res = App.getServiceManager().invoke("report.dailyBillPayment", req);
        System.out.println(res.getValue("REPORT"));
    } 

    public void test000() throws Exception 
    { 
        //execUpdate("update mlcs.tblbillpayment set strpostid='PB-64392465:127c7033eb8:2213' where objid='BP-15839380:127d0d08e8a:1340' ");        
        
//        String sql = "select objid, dttxndate, state, strbranchid, strcontrolno, strpostid from mlcs.tblbillpayment where strcontrolno like 'bp-03roxas2-08-000074' limit 10 ";
//        IDataSetModel list = (IDataSetModel) execQuery(sql, true);
//        list(list, "billpayment");
    } 
    

    private Object execQuery(String stmt) throws Exception { 
        return execQuery(stmt, false);
    }
    
    private Object execQuery(String stmt, boolean dataset) throws Exception 
    { 
        System.getProperties().put("app.host", HOST);
        
        Request req = new Request();
        req.addParameter("DSNAME", "java:mldb");
        req.addParameter("QUERY", (dataset ? "2" : "1"));
        req.addParameter("SQLSTMT", stmt);
        
        Response res = App.getServiceManager().invoke("system.exec", req);
        Object o = res.getValue("xmldata");
        if (dataset) o = res.getValue("list");
        
        return o;
    } 
    
    private void execUpdate(String stmt) throws Exception 
    { 
        System.getProperties().put("app.host", HOST);
        
        Request req = new Request();
        req.addParameter("DSNAME", "java:mldb");
        req.addParameter("QUERY", "0");
        req.addParameter("SQLSTMT", stmt);
        
        App.getServiceManager().invoke("system.exec", req);
    }
    
    private Map convert(IDataModel doc) throws Exception
    {
        Map data = new HashMap();
        Iterator fields = doc.getFields();
        while (fields.hasNext())
        {
            String key = fields.next().toString();
            Object val = doc.getValue(key);
            data.put(key, val);
        }
        return data;
    }    
    
    private void list(IDataSetModel idsm, String name) throws Exception
    {
        System.out.println("["+name+"]");
        for (int i=0; i<idsm.size(); i++)
        {
            IDataModel doc = idsm.getItem(i);
            Iterator itr = doc.getFields();
            StringBuffer sb = new StringBuffer();
            while (itr.hasNext())
            {
                String key = itr.next().toString();
                Object val = doc.getValue(key);
                if (sb.length() > 0) sb.append(", ");
                
                sb.append(key + "=" + val);
            }
            System.out.println(sb);
        }
        System.out.println("");
    }
    
}
