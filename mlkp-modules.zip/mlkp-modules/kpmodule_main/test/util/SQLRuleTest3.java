package util;

import javax.swing.UIManager;
import junit.framework.*;

public class SQLRuleTest3 extends TestCase 
{
    private String HOST = "http://192.168.3.220:8080/mlhuillier/action";
    
    public SQLRuleTest3(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
        UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
    }

    protected void tearDown() throws Exception {}
        
    public void test0000() throws Exception
    {
        SQLPanel p = new SQLPanel(); 
        p.setHost(HOST); 
        //p.setDsname("java:mlsystem");
        p.setDsname("java:searchdb");
        p.open(); 
        
    }
}
