package util;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import junit.framework.*;
import rameses.osiris.client.app.App;
import rameses.osiris.common.interfaces.IDataModel;
import rameses.osiris.common.interfaces.IDataSetModel;
import rameses.osiris.common.service.Request;
import rameses.osiris.common.service.Response;

public class DisableCorporatePartnerReport extends TestCase 
{
    
    public DisableCorporatePartnerReport(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception 
    {
        System.setProperty("app.host","http://192.168.3.247:8080/mlhuillier/action");
    }

    protected void tearDown() throws Exception {
    }
    
    public void testSlaveStart() throws Exception
    {
        System.out.println("starting...");
        while (true)
        {
            try
            {
                System.out.println("checking time...");
                IDataSetModel list = (IDataSetModel) execQuery("select (now() >= '2010-02-24 22:00:00') as expired ", true);
                if (list.size() > 0)
                {
                    IDataModel doc = list.getItem(0);
                    String vall = doc.getValue("expired")+"";
                    if ("1".equals(vall)) 
                    {
                        execUpdate("update mlkp_admin.sys_user_permission set permissionkey='1corporatepartner.*' where permissionkey='corporatepartner.*'"); 
                        break; 
                    }
                }
                
                Thread.sleep(2000);
            }
            catch(Exception ex) {
                System.out.println("   [ERROR] " + ex.getMessage());
            }
        }
        System.out.println("done.");
    }
    
    private void slaveStart(String rulename) 
    {
        try {
            App.getServiceManager().invoke(rulename, new Request());
        } catch(Exception ex) {
            ex.printStackTrace();
        }
    }
    
    private Object execQuery(String stmt, boolean dataset) throws Exception 
    { 
        Request req = new Request();
        req.addParameter("DSNAME", "java:mldb");
        req.addParameter("QUERY", (dataset ? "2" : "1"));
        req.addParameter("SQLSTMT", stmt);
        
        Response res = App.getServiceManager().invoke("system.exec", req);
        Object o = res.getValue("xmldata");
        if (dataset) 
            return res.getValue("list");
        else
            return o;
    } 
    
    private void execUpdate(String stmt) throws Exception 
    { 
        Request req = new Request();
        req.addParameter("DSNAME", "java:mldb");
        req.addParameter("QUERY", "0");
        req.addParameter("SQLSTMT", stmt);
        App.getServiceManager().invoke("system.exec", req);
    }
    
    private Map convert(IDataModel doc) throws Exception
    {
        Map data = new HashMap();
        Iterator fields = doc.getFields();
        while (fields.hasNext())
        {
            String key = fields.next().toString();
            Object val = doc.getValue(key);
            data.put(key, val);
        }
        return data;
    }
    
    private Response invoke(String service, Request req) throws Exception 
    { 
        return App.getServiceManager().invoke(service, req);
    }
    
}
