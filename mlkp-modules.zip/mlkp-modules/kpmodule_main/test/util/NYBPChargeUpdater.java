package util;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import junit.framework.*;
import rameses.osiris.client.app.App;
import rameses.osiris.common.interfaces.IDataModel;
import rameses.osiris.common.interfaces.IDataSetModel;
import rameses.osiris.common.service.Request;
import rameses.osiris.common.service.Response;

public class NYBPChargeUpdater extends TestCase 
{
    private String HOST = "http://192.168.3.247:8080/mlhuillier/action";
    
    public NYBPChargeUpdater(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
    }

    protected void tearDown() throws Exception {
    }
    
    public void test001() throws Exception 
    { 
        Date startdate = java.sql.Date.valueOf("2010-02-26");
        Date enddate = java.sql.Date.valueOf("2010-02-26");
        
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Calendar cal = new GregorianCalendar();
        cal.setTime(startdate);
        
        while (true)
        {
            Date dt = cal.getTime();
            if (dt.after(enddate)) break;
            
            String sdate = sdf.format(dt);
            System.out.println("processing " + sdate + "...");
            IDataSetModel list = execQuery(" select objid, currencyid from mlpartner.nybaypayouttxn " + 
                                           " where dtclaimed between '"+sdate+" 00:00:00' and '"+sdate+" 23:59:59' " + 
                                           " having currencyid='PHP' ");
            for (int i=0; i<list.size(); i++)
            {
                IDataModel doc = list.getItem(i);
                String objid = doc.getValue("objid").toString();
                System.out.println(i + ") " + objid);
                
                StringBuffer sb = new StringBuffer();
                sb.append(" update mlpartner.nybaypayouttxn set ");
                sb.append("     charge=case ");
                sb.append("               when amount between 0.01 and 50000.0 then 120.0 ");
                sb.append("               when amount between 50000.01 and 100000.0 then 240.0 ");
                sb.append("               when amount between 100000.01 and 150000.0 then 360.0 ");
                sb.append("               when amount between 150000.01 and 200000.0 then 480.0 else 600.0 ");
                sb.append("            end ");
                sb.append(" where objid='"+objid+"' and currencyid='PHP' ");
                execUpdate(sb.toString());
                
                Thread.sleep(500);
            }
            cal.add(Calendar.DATE, 1);
        }
    }     
    
    public void test002() throws Exception 
    { 
        
    }         
    
    private IDataSetModel execQuery(String stmt) throws Exception 
    { 
        System.getProperties().put("app.host", HOST);
        
        Request req = new Request();
        req.addParameter("DSNAME", "java:mldb");
        req.addParameter("QUERY", "2");
        req.addParameter("SQLSTMT", stmt);
        
        Response res = App.getServiceManager().invoke("system.exec", req);
        return (IDataSetModel) res.getValue("list");
    } 
    
    private void execUpdate(String stmt) throws Exception 
    { 
        System.getProperties().put("app.host", HOST);
        
        Request req = new Request();
        req.addParameter("DSNAME", "java:mldb");
        req.addParameter("QUERY", "0");
        req.addParameter("SQLSTMT", stmt);
        
        App.getServiceManager().invoke("system.exec", req);
    }
    
    private Map convert(IDataModel doc) throws Exception
    {
        Map data = new HashMap();
        Iterator fields = doc.getFields();
        while (fields.hasNext())
        {
            String key = fields.next().toString();
            Object val = doc.getValue(key);
            data.put(key, val);
        }
        return data;
    }
    
    private Response invoke(String service, Request req) throws Exception 
    { 
        System.getProperties().put("app.host", HOST);
        return App.getServiceManager().invoke(service, req);
    }
    
    private void list(IDataSetModel idsm, String name) throws Exception
    {
        System.out.println("["+name+"]");
        for (int i=0; i<idsm.size(); i++)
        {
            IDataModel doc = idsm.getItem(i);
            Iterator itr = doc.getFields();
            StringBuffer sb = new StringBuffer();
            while (itr.hasNext())
            {
                String key = itr.next().toString();
                Object val = doc.getValue(key);
                if (sb.length() > 0) sb.append(", ");
                
                sb.append(key + "=" + val);
            }
            System.out.println(sb);
        }
        System.out.println("");
    }
    
    private void list(IDataSetModel idsm) throws Exception
    {
        for (int i=0; i<idsm.size(); i++)
        {
            IDataModel doc = idsm.getItem(i);
            Iterator itr = doc.getFields();
            StringBuffer sb = new StringBuffer();
            while (itr.hasNext())
            {
                String key = itr.next().toString();
                Object val = doc.getValue(key);
                if (sb.length() > 0) sb.append(", ");
                
                sb.append(key + "=" + val);
            }
            System.out.println(sb);
        }
    }    
    
}
