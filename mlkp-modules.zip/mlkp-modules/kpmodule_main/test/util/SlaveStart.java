package util;

import junit.framework.*;
import rameses.osiris.client.app.App;
import rameses.osiris.common.service.Request;

public class SlaveStart extends TestCase 
{
    
    public SlaveStart(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception 
    {
        System.setProperty("app.host", "http://192.168.3.247:8080/mlhuillier/action");
    }

    protected void tearDown() throws Exception {
    }
    
    public void testSlaveStart() throws Exception
    {
        System.out.println("testSlaveStart...");
        while (true)
        {
            //slaveStart("slaveStart");
            slaveStart("slaveStart2");
            //slaveStart("slaveStart3");
            Thread.sleep(5000);
        }
    }
    
    private void slaveStart(String rulename) 
    {
        try {
            App.getServiceManager().invoke(rulename, new Request());
        } catch(Exception ex) {
            ex.printStackTrace();
        }
    }
}
