package util;

import java.io.InputStream;
import java.net.URL;
import java.rmi.server.UID;
import java.security.MessageDigest;
import java.util.HashMap;
import java.util.Map;
import rameses.osiris.common.soap.CryptoUtil;

public class NYBAYWS 
{
    private String username = "PMLLER";
    private String password = "PMLLER0902";
    private String pinno = "PMLLER20090902";
    
    public NYBAYWS() {
    }
    
    public Map showRemittanceDetail(String refno) throws Exception 
    {
        String sessionId = "ML" + new UID();
        String s = sessionId + refno + pinno;
        String signature = createSignature(s);

        StringBuffer stmt = new StringBuffer();
        stmt.append("sessionId=" + sessionId);
        stmt.append("&username=" + username);
        stmt.append("&password=" + password);
        stmt.append("&refno=" + refno);
        stmt.append("&signature=" + signature);

        String result = invoke("ShowRemittanceDetail", stmt.toString());
        //System.out.println("[ShowRemittanceDetail] " + result);
        String[] arr = new String[]
        {
            "sessionId","status","objid",
            "amount","currencyid","receiverlname",
            "receiverfname","receivermname","receiveraddress", 
            "receiverphone", "dtfiled"
        };
        return convert(result, arr);        
    }
            
    private String createSignature(String s) throws Exception 
    {
        MessageDigest md = MessageDigest.getInstance("MD5");
        md.update(s.getBytes());
        return CryptoUtil.toHexString(md.digest());
    }
    
    private Map convert(String data, String[] keys) 
    {
        Map map = new HashMap();
        int startidx = 0;
        int idx = -1;
        int ctr = 0;
        while(true) 
        {
            if (ctr >= keys.length) break;
            
            idx = data.indexOf('|',startidx);
            if (idx < 0) break;

            map.put(keys[ctr],data.substring(startidx, idx));
            startidx = idx + 1;
            ctr ++;
        }

        if (ctr < keys.length && startidx > 0 && startidx < data.length())
            map.put(keys[ctr],data.substring(startidx));
        
        return map;
    }

    private String invoke(String name, String requestInfo)throws Exception 
    {
        InputStream is = null;

        try 
        {
            String path = "http://192.168.3.211:8080/wsproxy/redirect/http://www.nybp.info/PickupWebService/Service1.asmx/"+name+"?"+requestInfo;
            URL url = new URL(path);
            is = url.openStream();
            int i = -1;
            StringBuffer sb = new StringBuffer(); 
            while((i = is.read()) != -1 ){ 
                sb.append((char)i); 
            } 

            String txt = sb.toString();
            
            String s = "<"+name+"Return>";

            int idx0 = txt.indexOf(s);
            int idx1= txt.indexOf("</"+name+"Return>");

            String result = txt.substring(idx0+s.length(),idx1);
            return result;
        } catch(Exception e) {
            throw e;
        } finally {
            try { is.close(); }catch(Exception ign){;}
        }
    }
    
}
