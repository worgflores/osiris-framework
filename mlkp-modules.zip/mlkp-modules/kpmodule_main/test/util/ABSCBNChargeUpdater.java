package util;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import junit.framework.*;
import rameses.osiris.client.app.App;
import rameses.osiris.common.service.Request;
import rameses.osiris.common.service.Response;

public class ABSCBNChargeUpdater extends TestCase 
{
    private String HOST = "http://192.168.3.247:8080/mlhuillier/action";
    
    public ABSCBNChargeUpdater(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
    }

    protected void tearDown() throws Exception {
    }
    
    public void test002() throws Exception 
    { 
        for (int d=1; d<=31; d++)
        {
            String sd = d+"";
            if (d < 10) sd = "0"+d;
            
            String sdate = "2010-10-" + sd;
            System.out.println("processing " + sdate);
            doUpdateCharge(sdate);    
        }
        
        //doCleanDraft();
        
//        HOST = "http://192.168.3.246:8080/mlhuillier/action";
//        
//        Request req = new Request();
//        req.addParameter("CCREFNO", "FT10173941603591");
//        
//        Response res = invoke("ABSCBN.test.fetchData", req); 
//        System.out.println(res.getValues());
    }         
    
    private void doUpdateCharge(String sdate) throws Exception 
    { 
        java.sql.Date.valueOf(sdate);

        List list = execQuery(" select objid, charge from mlpartner.abscbnpayout where dtclaimed between '"+sdate+" 00:00:00' and '"+sdate+" 23:59:59' having charge=0 ");
        while (!list.isEmpty())
        {
            Map data = (Map) list.remove(0); 
            System.out.println(data);
            String objid = data.get("objid").toString();
            
            Request req = new Request();
            req.addParameter("REFNO", objid);
            
            invoke("ABSCBN.updateChargeValue", req);
        }
    } 
    
    private void doCleanDraft() throws Exception 
    { 
        List list = execQuery(" select objid from mlpartner.abscbnpayout limit 1000 ");
        while (!list.isEmpty())
        {
            Map data = (Map) list.remove(0); 
            String objid = data.get("objid").toString();
            
            System.out.println(" removing draft " + objid + "...");
            //execUpdate(" delete from mlpartner.abscbnpayoutdraft where objid='"+objid+"' ");
        } 
    } 
    
    private Map execSingleQuery(String stmt) throws Exception { 
        return execSingleQuery(stmt, "java:mldb"); 
    }     
    
    private Map execSingleQuery(String stmt, String dsname) throws Exception 
    { 
        List list = execQuery(stmt, dsname); 
        if (list != null && list.size() > 0)
            return (Map) list.get(0);
        else
            return null; 
    }         
    
    private List execQuery(String stmt) throws Exception { 
        return execQuery(stmt, "java:mldb"); 
    } 
    
    private List execQuery(String stmt, String dsname) throws Exception 
    { 
        if (stmt == null || stmt.trim().length() == 0) throw new Exception("'stmt' parameter is required");
        if (dsname == null || dsname.trim().length() == 0) throw new Exception("'dsname' parameter is required");
        
        System.getProperties().put("app.host", HOST); 
        
        Request req = new Request(); 
        req.addParameter("DSNAME", dsname); 
        req.addParameter("SQLSTMT", stmt); 
        
        Response res = App.getServiceManager().invoke("system.db.list", req); 
        if ("0".equals(res.getValue("statuscode"))) 
        {
            System.out.println("[ERROR] " + res.getValue("statusmsg"));
            throw new Exception(res.getValue("statusmsg")+"");
        } 
        
        return (List) res.getValue("list"); 
    } 

    private void execUpdate(String stmt) throws Exception {
        execUpdate(stmt, "java:mldb");
    }
    
    private void execUpdate(String stmt, String dsname) throws Exception 
    { 
        if (stmt == null || stmt.trim().length() == 0) throw new Exception("'stmt' parameter is required");
        if (dsname == null || dsname.trim().length() == 0) throw new Exception("'dsname' parameter is required");
        
        System.getProperties().put("app.host", HOST);
        
        Request req = new Request();
        req.addParameter("DSNAME", dsname);
        req.addParameter("SQLSTMT", stmt);
        
        Response res = App.getServiceManager().invoke("system.db.update", req);
        if ("0".equals(res.getValue("statuscode"))) 
        {
            System.out.println("[ERROR] " + res.getValue("statusmsg"));
            throw new Exception(res.getValue("statusmsg")+"");
        } 
    }

    
    private Response invoke(String service, Request req) throws Exception 
    { 
        System.getProperties().put("app.host", HOST);
        return App.getServiceManager().invoke(service, req);
    }
    
    private void dump(List list) throws Exception
    {
        System.out.println("");
        
        long counter = 1;
        Iterator itr = list.iterator();
        while (itr.hasNext())
        {
            System.out.println(counter + ") " + itr.next());
            counter += 1;
        }
        System.out.println("");
    }
    
}
