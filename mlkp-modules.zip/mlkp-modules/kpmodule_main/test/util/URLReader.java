package util;

import java.io.InputStream;
import java.net.URL;
import java.util.Timer;
import java.util.TimerTask;

public class URLReader
{
    /*
     *  URLReader urlr = new URLReader(url, 2000); 
     *  InputStream in = urlr.openStream();
     */
    
    private Object locked = new Object();
    private URL url;
    private int timeout = 5000; 
    private boolean done;
    private InputStream in;
    
    public URLReader(URL url) {
        this(url, 5000);
    }
    
    public URLReader(URL url, int timeout) 
    {
        this.url = url;
        this.timeout = timeout;
    }    
    
    public int getTimeout() { return timeout; }
    
    public InputStream openStream() throws Exception 
    {
        synchronized (locked)
        {
            boolean inited = false;
            done = false;
            while (true)
            {
                if (inited) continue;
                if (done) break; 
                
                Timer timer1 = new Timer(); 
                timer1.schedule(new TimerTask() 
                {
                    public void run() { run0(); }
                }, 500);
                
                Timer timer2 = new Timer();
                timer2.schedule(new TimerTask() 
                {
                    public void run() { run1(); }
                }, getTimeout());
                
                inited = true;
            }

            return null;
        }
    }

    private void run0() 
    {
        
    }
    
    private void run1() 
    {
        
    }    
}
