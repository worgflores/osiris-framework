package util;

import java.sql.ResultSet;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import junit.framework.*;
import rameses.osiris.client.app.App;
import rameses.osiris.common.interfaces.IDataModel;
import rameses.osiris.common.service.Request;
import rameses.osiris.common.service.Response;

public class SystemTest extends TestCase 
{
    private String HOST = "http://192.168.3.247:8080/mlhuillier/action";
    
    public SystemTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
        System.getProperties().put("app.host", HOST);
    }

    protected void tearDown() throws Exception {
    }
    
    public void test0() throws Exception
    {
        String creditbranch = "FSD48";
        String kptn = "FSD393WM773H7";
        double charge = 150.0;
        
        //changeSendoutCharge("SYSTEM", "SYSTEM", "SYSTEM", kptn, charge);
        //creditTransactionAndChangeCharge("SYSTEM", "SYSTEM", "SYSTEM", kptn, charge, creditbranch); 
        execQuery("select * from mlkp.tblkptnlog where kptn='"+kptn+"' order by txndate desc");
    }

    private void changeSendoutCharge(String userid, String branchid, String terminalid, String kptn, double charge) throws Exception 
    { 
        Request req = new Request();
        req.addParameter("USERID", userid);
        req.addParameter("BRANCHID", branchid);
        req.addParameter("TERMINALID", terminalid);
        req.addParameter("KPTN", kptn);
        req.addParameter("CHARGE", charge+"");

        Response res = App.getServiceManager().invoke("system.changeSendoutCharge", req);
        System.out.println(res.getValues());
    } 
    
    private void creditTransactionAndChangeCharge(String userid, String branchid, String terminalid, String kptn, double charge, String tobranchid) throws Exception 
    { 
        Request req = new Request();
        req.addParameter("USERID", userid);
        req.addParameter("BRANCHID", branchid);
        req.addParameter("TERMINALID", terminalid);
        req.addParameter("KPTN", kptn);
        req.addParameter("CHARGE", charge+"");
        req.addParameter("TOBRANCHID", tobranchid);

        Response res = App.getServiceManager().invoke("system.creditTransactionAndChangeCharge", req);
        System.out.println(res.getValues());
    } 
    
    private Object execQuery(String stmt) throws Exception { 
        return execQuery(stmt, false);
    }
    
    private Object execQuery(String stmt, boolean dataset) throws Exception 
    { 
        System.getProperties().put("app.host", HOST);
        
        Request req = new Request();
        req.addParameter("DSNAME", "java:mldb");
        req.addParameter("QUERY", (dataset ? "2" : "1"));
        req.addParameter("SQLSTMT", stmt);
        
        Response res = App.getServiceManager().invoke("system.exec", req);
        Object o = res.getValue("xmldata");
        if (dataset) o = res.getValue("list");
        
        System.out.println(o);
        return o;
    } 
    
    private void execUpdate(String stmt) throws Exception 
    { 
        System.getProperties().put("app.host", HOST);
        
        Request req = new Request();
        req.addParameter("DSNAME", "java:mldb");
        req.addParameter("QUERY", "0");
        req.addParameter("SQLSTMT", stmt);
        
        App.getServiceManager().invoke("system.exec", req);
    }
    
    private Map convert(IDataModel doc) throws Exception
    {
        Map data = new HashMap();
        Iterator fields = doc.getFields();
        while (fields.hasNext())
        {
            String key = fields.next().toString();
            Object val = doc.getValue(key);
            data.put(key, val);
        }
        return data;
    }    
}
