package util;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import junit.framework.*;
import rameses.osiris.client.app.App;
import rameses.osiris.common.interfaces.IDataModel;
import rameses.osiris.common.interfaces.IDataSetModel;
import rameses.osiris.common.service.Request;
import rameses.osiris.common.service.Response;

public class SendoutUtil extends TestCase 
{
    private String HOST = "http://192.168.3.247:8080/mlhuillier/action";
    
    public SendoutUtil(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
    }

    protected void tearDown() throws Exception {
    }
    
    public void test000() throws Exception 
    { 
        String kptn = "nagactnd4rx84j";
        IDataSetModel list = (IDataSetModel) execQuery("select * from mlkp.tblsendout where strkptn like '"+kptn+"%'", true);
        list(list, "sendout");        
        
//        list = (IDataSetModel) execQuery("select * from mlkp.tblsendoutreinstated where strkptn like '"+kptn+"%'", true);
//        list(list, "sendoutreinstated");

        list = (IDataSetModel) execQuery("select * from mlkp.qryunclaim where strkptn like '"+kptn+"%'", true);
        list(list, "qryunclaim");
    }     

    private Object execQuery(String stmt) throws Exception { 
        return execQuery(stmt, false);
    }
    
    private Object execQuery(String stmt, boolean dataset) throws Exception 
    { 
        System.getProperties().put("app.host", HOST);
        
        Request req = new Request();
        req.addParameter("DSNAME", "java:mldb");
        req.addParameter("QUERY", (dataset ? "2" : "1"));
        req.addParameter("SQLSTMT", stmt);
        
        Response res = App.getServiceManager().invoke("system.exec", req);
        Object o = res.getValue("xmldata");
        if (dataset) o = res.getValue("list");
        
        //System.out.println(o);
        return o;
    } 
    
    private void execUpdate(String stmt) throws Exception 
    { 
        System.getProperties().put("app.host", HOST);
        
        Request req = new Request();
        req.addParameter("DSNAME", "java:mldb");
        req.addParameter("QUERY", "0");
        req.addParameter("SQLSTMT", stmt);
        
        App.getServiceManager().invoke("system.exec", req);
    }
    
    private Map convert(IDataModel doc) throws Exception
    {
        Map data = new HashMap();
        Iterator fields = doc.getFields();
        while (fields.hasNext())
        {
            String key = fields.next().toString();
            Object val = doc.getValue(key);
            data.put(key, val);
        }
        return data;
    }
    
    private Response invoke(String service, Request req) throws Exception 
    { 
        System.getProperties().put("app.host", HOST);
        return App.getServiceManager().invoke(service, req);
    }
    
    private void showKPTN(String kptn) throws Exception
    {
        IDataSetModel list = (IDataSetModel) execQuery("SELECT * FROM mlkp.tblsendout WHERE strkptn like '"+kptn+"'", true);
        list(list, "showKPTN");
    }
    
    private void list(IDataSetModel idsm, String name) throws Exception
    {
        System.out.println("["+name+"]");
        for (int i=0; i<idsm.size(); i++)
        {
            IDataModel doc = idsm.getItem(i);
            Iterator itr = doc.getFields();
            StringBuffer sb = new StringBuffer();
            while (itr.hasNext())
            {
                String key = itr.next().toString();
                Object val = doc.getValue(key);
                if (sb.length() > 0) sb.append(", ");
                
                sb.append(key + "=" + val);
            }
            System.out.println(sb);
        }
        System.out.println("");
    }
    
}
