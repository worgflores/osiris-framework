package util;

import java.math.BigDecimal;
import junit.framework.*;
import rameses.osiris.client.app.App;
import rameses.osiris.common.service.Request;
import rameses.osiris.common.service.Response;

public class RuleReportTest extends TestCase 
{
    //private String HOST = "http://192.168.3.246:8080/mlhuillier/action";
    //private String HOST = "http://192.168.3.187/mlhuillier/action";
    private String HOST = "http://192.168.3.208/mlhuillier/action";
    
    
    public RuleReportTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
    }

    protected void tearDown() throws Exception {
        //"912,345,678.90";
    }
    
    public void test000() throws Exception 
    { 
        Request req = new Request();
        req.addParameter("USERID", "CABUGASON-G");
        //req.addParameter("BRANCHID", "FUENT1");
        req.addParameter("STATUS", "sendout");
        req.addParameter("FROMDATE", "2010-03-24");
        req.addParameter("PERIOD", "DAILY");
        
        Response res = invoke("report.dw.branchuser", req);
        System.out.println(res.getValue("REPORT"));
    } 
    
    public void xtestWSDailySendoutList() throws Exception 
    { 
        Request req = new Request();
        req.addParameter("USERID", "SYSTEM");
        req.addParameter("BRANCHID", "PNYEXT");
        req.addParameter("TXNDATE", "2009-10-24");

        Response res = invoke("ws.dailysendoutlist", req);
        System.out.println(res.getValue("xmldata"));
    }     

    public void xtest1() throws Exception 
    { 
        Request req = new Request();
        req.addParameter("USERID", "SYSTEM");
        req.addParameter("BRANCHID", "DUMAG2");
        req.addParameter("STATUS", "all");
        req.addParameter("FROMDATE", "2009-09-03");
        req.addParameter("REPORTNAME", "branchmgr.sendout");

        Response res = invoke("report.dailySendout", req);
        System.out.println(res.getValue("REPORT"));
    } 
        
    private Response invoke(String service, Request req) throws Exception 
    { 
        System.getProperties().put("app.host", HOST);
        return App.getServiceManager().invoke(service, req);
    }
    
}
