package util;

import junit.framework.*;
import rameses.osiris.client.app.App;
import rameses.osiris.common.service.Request;
import rameses.osiris.common.service.Response;

public class PayoutSearchTest extends TestCase {
    private String HOST = "http://192.168.3.247:8080/mlhuillier/action";
    
    public PayoutSearchTest(String testName) {
        super(testName);
    }
    
    protected void setUp() throws Exception {
    }
    
    protected void tearDown() throws Exception {}
    
    public void xtest0000() throws Exception {
        Request req = new Request();
        req.addParameter("SEARCHMODE", "BYCCREFNO");
        req.addParameter("CCREFNO", "");
        
        Response res = invoke("payoutsearch.test.getResults", req);
        System.out.println(res.getValues());
    }
    
    private Response invoke(String service, Request req) throws Exception {
        System.getProperties().put("app.host", HOST);
        return App.getServiceManager().invoke(service, req);
    }
    
}
