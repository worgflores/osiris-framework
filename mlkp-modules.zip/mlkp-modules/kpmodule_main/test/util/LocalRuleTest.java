package util;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import junit.framework.*;
import rameses.osiris.client.app.App;
import rameses.osiris.common.interfaces.IDataModel;
import rameses.osiris.common.interfaces.IDataSetModel;
import rameses.osiris.common.service.Request;
import rameses.osiris.common.service.Response;

public class LocalRuleTest extends TestCase 
{
    private String HOST = "http://192.168.3.246:8080/mlhuillier/action";
        
    public LocalRuleTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {}

    protected void tearDown() throws Exception {}
    
    public void xtestABSCBNFetchData() throws Exception 
    {
        Request req = new Request(); 
        req.addParameter("CCREFNO", "FT10191448318330"); 
        
        //Response res = invoke("ABSCBN.test.fetchData", req); 
        Response res = invoke("fetchDataHandler.ABSCBN", req); 
        System.out.println(res.getValues()); 
    }

    public void xtestABSCBNDailyReport() throws Exception 
    {
        Request req = new Request(); 
        req.addParameter("FROMDATE", "2010-03-29"); 
        req.addParameter("TODATE", "2010-03-29"); 
        req.addParameter("BRANCHID", "MIS"); 
        req.addParameter("USERID", "KPUSER"); 
        req.addParameter("LOCATION", "ALL"); 
        
        Response res = invoke("report.abscbn.detail", req); 
        System.out.println(res.getValue("REPORT")); 
    }
    
    public void test0000() throws Exception 
    {
        Request req = new Request(); 
        req.addParameter("REFNO", "97742485318");

        Response res = invoke("IMEService.test.pay", req); 
        System.out.println(res.getValues());
    }
    
    public void XtestRandomNumber() throws Exception 
    {
        Request req = new Request(); 
        
        while (true) 
        {
            Thread.sleep(150);
            try { invoke("test.generateRandomNumber", req); }catch(Exception ign){ System.out.println(ign.getMessage()); }
        }
    }
    
    private Object execQuery(String stmt) throws Exception { 
        return execQuery(stmt, false); 
    } 
    
    private Object execQuery(String stmt, boolean dataset) throws Exception 
    { 
        System.getProperties().put("app.host", HOST); 
        
        Request req = new Request(); 
        req.addParameter("DSNAME", "java:mldb"); 
        req.addParameter("QUERY", (dataset ? "2" : "1")); 
        req.addParameter("SQLSTMT", stmt); 
        
        Response res = App.getServiceManager().invoke("system.exec", req); 
        Object o = res.getValue("xmldata"); 
        if (dataset) o = res.getValue("list"); 
        
        //System.out.println(o);
        return o;
    } 
    
    private void execUpdate(String stmt) throws Exception 
    { 
        System.getProperties().put("app.host", HOST);
        
        Request req = new Request();
        req.addParameter("DSNAME", "java:mldb");
        req.addParameter("QUERY", "0");
        req.addParameter("SQLSTMT", stmt);
        
        App.getServiceManager().invoke("system.exec", req);
    }
    
    private Map convert(IDataModel doc) throws Exception
    {
        Map data = new HashMap();
        Iterator fields = doc.getFields();
        while (fields.hasNext())
        {
            String key = fields.next().toString();
            Object val = doc.getValue(key);
            data.put(key, val);
        }
        return data;
    }
    
    private Response invoke(String service, Request req) throws Exception 
    { 
        System.getProperties().put("app.host", HOST);
        return App.getServiceManager().invoke(service, req);
    }
    
    private void list(IDataSetModel idsm, String name) throws Exception
    {
        if (name != null) System.out.println("["+name+"]");
        
        for (int i=0; i<idsm.size(); i++)
        {
            IDataModel doc = idsm.getItem(i);
            Iterator itr = doc.getFields();
            StringBuffer sb = new StringBuffer();
            while (itr.hasNext())
            {
                String key = itr.next().toString();
                Object val = doc.getValue(key);
                if (sb.length() > 0) sb.append(", ");
                
                sb.append(key + "=" + val);
            }
            System.out.println(i + ") " + sb);
        }
        
        if (name != null) System.out.println("");
    }
    
}
