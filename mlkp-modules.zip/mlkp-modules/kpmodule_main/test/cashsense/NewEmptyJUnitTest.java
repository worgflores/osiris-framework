package cashsense;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import junit.framework.*;
import rameses.osiris.client.app.App;
import rameses.osiris.common.data.DefaultDataModel;
import rameses.osiris.common.interfaces.IDataModel;
import rameses.osiris.common.service.Request;
import rameses.osiris.common.service.Response;
import rameses.osiris.common.soap.CryptoUtil;

public class NewEmptyJUnitTest extends TestCase 
{
    private String HOST = "http://192.168.3.247:8080/mlhuillier/action";
    
    public NewEmptyJUnitTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
    }

    protected void tearDown() throws Exception {
    }
    
    public void test2() throws Exception 
    {
        IDataModel doc = new DefaultDataModel();
        doc.setName("billpayment");
        doc.setValue("amtpaid", "125.00");
        doc.setValue("acctno", "CS4ITR3JS");
        
        Request req = new Request();
        req.addParameter("billpayment", doc);
        
        Response res = invoke("CSHSNS.test.validateTransaction", req);
        System.out.println(res.getValues()); 
        
//        System.out.println("md5Hash: " + MD5Hash("CS4ITR3JS1250020101210", "20101210"));
//        System.out.println("createHash: " + createHash("CS4ITR3JS1250020101210"));
    }
    
    private String MD5Hash(String text, String salt) throws Exception 
    {
        javax.crypto.spec.SecretKeySpec skey = new javax.crypto.spec.SecretKeySpec(salt.getBytes(), "HmacMD5");
        javax.crypto.Mac mac = javax.crypto.Mac.getInstance("HmacMD5");
        mac.init(skey);

        byte[] bytes = mac.doFinal(text.getBytes()); 
        return CryptoUtil.toHexString(bytes); 
    } 
    
    public String createHash( String val ) 
    {
        try 
        {
            MessageDigest md = MessageDigest.getInstance("MD5");
            md.update( val.getBytes() );
            return toHexString( md.digest() );
        } 
        catch (NoSuchAlgorithmException ex) {
            throw new IllegalStateException( "CSHSNSService.createhash error. " + ex.getMessage() ); 
        }
    }    
    
    private String toHexString( byte[] b ) 
    {
        String hexDigit = "0123456789abcdef";
        StringBuffer sb = new StringBuffer( b.length );
        for(int i = 0; i<b.length; i++) 
        {
            int j = b[i] & 0xff;
            sb.append( hexDigit.charAt(j >>> 4) );
            sb.append( hexDigit.charAt(j & 0xf) );
        }
        return sb.toString();
    }    
    
    private Response invoke(String service, Request req) throws Exception 
    { 
        System.getProperties().put("app.host", HOST);
        return App.getServiceManager().invoke(service, req);
    }
    

}
