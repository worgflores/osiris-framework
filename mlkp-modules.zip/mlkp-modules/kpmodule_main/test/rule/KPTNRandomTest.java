package rule;

import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import junit.framework.*;

public class KPTNRandomTest extends TestCase 
{
    
    public KPTNRandomTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
    }

    protected void tearDown() throws Exception {
    }
    
    public void test000() throws Exception
    {
        System.out.println("KPTNRandomTest");     
        System.out.println(System.currentTimeMillis());
        System.out.println("");

        SecureRandom sr = new SecureRandom();
        
        List list = new ArrayList(); 
        long counter = 1; 
        while (true) 
        {
            //sr.setSeed(System.currentTimeMillis() + new Object().hashCode());
            sr.setSeed(System.currentTimeMillis());
            int num = sr.nextInt();
            if (num < 0) num = num * (-1);
            
            String s = num+"";  
            if (s.length() < 10)
            {
                StringBuffer sb = new StringBuffer(); 
                for (int i=0, len=10-s.length(); i<len; i++) sb.append("0");
                
                sb.append(s);
                s = sb.toString();
            }
            
            if (list.contains(s)) 
            {
                System.out.println("duplicate " + s + " at counter " + counter); 
                continue;
            }
            
            list.add(s); 
            counter += 1; 
        } 
    }
    
    private String generateRandomNumbers(int len) throws Exception
    {
        SimpleDateFormat YMDHMS = new SimpleDateFormat("yyyyMMddHHmmss"); 
        SimpleDateFormat sdf = new SimpleDateFormat("yy"); 
        String source = YMDHMS.format(new Date()) + "123456789098765432101234567890";
        
        StringBuffer sbuff = new StringBuffer();
        for(int i=0; i<len;i++) 
        {
            int idx = (int) (Math.random() * source.length() );
            sbuff.append( source.substring(idx, idx+1)); 
        }
        return sdf.format(new Date()) + sbuff.toString();
    }

}
