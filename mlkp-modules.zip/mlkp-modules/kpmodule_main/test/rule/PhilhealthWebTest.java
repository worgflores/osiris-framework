package rule;

import junit.framework.*;
import rameses.osiris.client.app.App;
import rameses.osiris.common.service.Request;
import rameses.osiris.common.service.Response;

public class PhilhealthWebTest extends TestCase 
{
    
    public PhilhealthWebTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
        System.setProperty("app.host", "http://192.168.3.220:8080/mlhuillier/action");
    }

    protected void tearDown() throws Exception {
    }
    
    public void test1() throws Exception
    {
        Request req = new Request();
        req.addParameter("TYPE", "1");
        req.addParameter("ID_NO", "190898938623");
        
        Response res = App.getServiceManager().invoke("philhealth.getMemberInfo2", req);
        System.out.println(res.getValues());
    }

}
