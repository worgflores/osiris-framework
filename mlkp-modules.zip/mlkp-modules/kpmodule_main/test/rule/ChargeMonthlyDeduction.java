package rule;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import junit.framework.*;
import rameses.osiris.client.app.App;
import rameses.osiris.common.service.Request;
import rameses.osiris.common.service.Response;

public class ChargeMonthlyDeduction extends TestCase 
{
    
    public ChargeMonthlyDeduction(String testName) { 
        super(testName); 
    } 

    protected void setUp() throws Exception { 
        System.setProperty("app.host", "http://192.168.3.173:8080/mlhuillier/action");
    }

    protected void tearDown() throws Exception {} 
    
    public void xtest000001() throws Exception 
    {  
        String kptn = "FSD391495149362"; 
        String billDate = "2012-01-09"; 
        boolean applyCharges = true; 
        
        List list = execQuery("select * from mlkp.tblsendout where strkptn like '"+kptn+"' order by intversion desc"); 
        dump(list); 

        if (applyCharges) 
        { 
            String objid = ((Map) list.get(0)).get("objid").toString(); 
            
            Request req = new Request(); 
            req.addParameter("SENDOUTID", objid); 
            req.addParameter("BILLDATE",  billDate); 
            calculateMonthlyDeduction(req); 
            chargeMonthlyStorage(req); 
        } 
    } 
    
    private Map xwaiveDormancyCharge(String kptn) throws Exception 
    {
        Request req = new Request(); 
        req.addParameter("KPTN", kptn);
        
        Response res = App.getServiceManager().invoke("sendout.waivedormant", req); 
        System.out.println("[sendout.waivedormant] " + res.getValues()); 
        return res.getValues(); 
    }
    
    private Response calculateMonthlyDeduction(Request req) throws Exception 
    {
        Response res = App.getServiceManager().invoke("system.calculateMonthlyDeductionKP3", req); 
        System.out.println(res.getValues()); 
        return res; 
    }
    
    private Response chargeMonthlyStorage(Request req) throws Exception  
    { 
        Response res = App.getServiceManager().invoke("system.chargeMonthlyStorageFeeKP3", req); 
        System.out.println("==============================================================="); 
        System.out.println(res.getValues()); 
        return res; 
    } 
    
    private Map execSingleQuery(String stmt) throws Exception { 
        return execSingleQuery(stmt, "java:mldb"); 
    } 
    
    private Map execSingleQuery(String stmt, String dsname) throws Exception 
    { 
        List list = execQuery(stmt, dsname); 
        if (list != null && list.size() > 0) 
            return (Map) list.get(0); 
        else 
            return null;  
    } 
    
    private List execQuery(String stmt) throws Exception { 
        return execQuery(stmt, "java:mldb3"); 
    } 
    
    private List execQuery(String stmt, String dsname) throws Exception 
    { 
        if (stmt == null || stmt.trim().length() == 0) throw new Exception("'stmt' parameter is required");
        if (dsname == null || dsname.trim().length() == 0) throw new Exception("'dsname' parameter is required");
        
        Request req = new Request(); 
        req.addParameter("DSNAME", dsname); 
        req.addParameter("SQLSTMT", stmt); 
        
        Response res = App.getServiceManager().invoke("system.db.list", req); 
        if ("0".equals(res.getValue("statuscode"))) 
        {
            System.out.println("[ERROR] " + res.getValue("statusmsg"));
            throw new Exception(res.getValue("statusmsg")+"");
        } 
        
        return (List) res.getValue("list"); 
    } 
    
    private void execUpdate(String stmt) throws Exception {
        execUpdate(stmt, "java:mldb");
    }
    
    private void execUpdate(String stmt, String dsname) throws Exception 
    { 
        if (stmt == null || stmt.trim().length() == 0) throw new Exception("'stmt' parameter is required");
        if (dsname == null || dsname.trim().length() == 0) throw new Exception("'dsname' parameter is required");
        
        Request req = new Request();
        req.addParameter("DSNAME", dsname);
        req.addParameter("SQLSTMT", stmt);
        
        Response res = App.getServiceManager().invoke("system.db.update", req);
        if ("0".equals(res.getValue("statuscode"))) 
        {
            System.out.println("[ERROR] " + res.getValue("statusmsg"));
            throw new Exception(res.getValue("statusmsg")+"");
        } 
    }

    private void dump(List list) throws Exception
    {
        System.out.println("");
        
        long counter = 1;
        Iterator itr = list.iterator();
        while (itr.hasNext())
        {
            System.out.println(counter + ") " + itr.next());
            counter += 1;
        }
        System.out.println("");
    }
    
}





