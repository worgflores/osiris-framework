package rule;

import junit.framework.*;
import rameses.osiris.client.app.App;
import rameses.osiris.common.service.Request;
import rameses.osiris.common.service.Response;

public class NewEmptyJUnitTest extends TestCase 
{
    
    public NewEmptyJUnitTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
        System.setProperty("app.host", "http://192.168.3.220:8080/mlhuillier/action");
    }

    protected void tearDown() throws Exception {
    }
    
    public void xtestDailySendout() throws Exception
    {
        Request req = new Request();
        req.addParameter("FROMDATE", "2009-01-28");
        req.addParameter("STATUS", "all");
        req.addParameter("BRANCHID", "RIATEL");
        req.addParameter("USERID", "RIATELU1");
        
        Response res = App.getServiceManager().invoke("report.dailySendout", req);
        System.out.println(res.getValue("REPORT"));
    }
    
    public void testDailyOperatorSendout() throws Exception
    {
        Request req = new Request();
        req.addParameter("FROMDATE", "2009-02-12");
        req.addParameter("STATUS", "all");
        req.addParameter("BRANCHID", "PATEROS");
        req.addParameter("USERID", "MARANO-C");
        
        Response res = App.getServiceManager().invoke("report.dailyOperatorSendout", req);
        System.out.println(res.getValue("REPORT"));
    }    
    
    public void XtestDailyPayout() throws Exception 
    {
        Request req = new Request();
        req.addParameter("FROMDATE", "2009-01-09");
        req.addParameter("STATUS", "all");
        req.addParameter("BRANCHID", "KETKA2");
        req.addParameter("USERID", "YANEZ-J");
        
        Response res = App.getServiceManager().invoke("report.dailyPayout", req);
        System.out.println(res.getValue("REPORT"));
    }
    
    public void xtestDailyOperatorPayout() throws Exception 
    {
        Request req = new Request();
        req.addParameter("FROMDATE", "2009-01-29");
        req.addParameter("STATUS", "all");
        req.addParameter("BRANCHID", "MALOLS");
        req.addParameter("USERID", "FABIAN-C");
        
        Response res = App.getServiceManager().invoke("report.dailyOperatorPayout", req);
        System.out.println(res.getValue("REPORT"));
    }    
    
    public void xtestDailyRFC() throws Exception 
    {
        Request req = new Request();
        req.addParameter("FROMDATE", "2009-01-31");
        req.addParameter("BRANCHID", "DNGALO");
        req.addParameter("USERID", "BINONGO-M");
        
        Response res = App.getServiceManager().invoke("report.dailyChangeRequest", req);
        System.out.println(res.getValue("REPORT"));
    }    
    
    public void xtestFSDRFC() throws Exception 
    {
        Request req = new Request();
        req.addParameter("FROMDATE", "2009-01-31");
        req.addParameter("TODATE", "2009-01-31");
        req.addParameter("PERIOD", "DAILY");
        req.addParameter("REPORTTYPE", "REQUEST_FOR_CHANGE");
        req.addParameter("BRANCHID", "DNGALO");
        req.addParameter("USERID", "ANGIE");
        
        Response res = App.getServiceManager().invoke("report.fsd", req);
        System.out.println(res.getValue("REPORT"));
    }        
    
    public void xtest1() throws Exception 
    {
        Request req = new Request();
        req.addParameter("DSNAME", "java:mldb");
        req.addParameter("QUERY", "0");
        req.addParameter("SQLSTMT", "SET global max_connections=300");
        
        App.getServiceManager().invoke("system.exec", req);
        //Response res = App.getServiceManager().invoke("system.getList", req);
        //System.out.println(res.getValue("list"));
    }    

}
