package rule;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Stack;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import junit.framework.*;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class TxtConnWSTest extends TestCase 
{
    
    public TxtConnWSTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
        
    }

    protected void tearDown() throws Exception {
    }
    
    public void test0() throws Exception
    {
        StringBuffer path = new StringBuffer();
        path.append("https://txtconnect.globesolutions.com.ph/webservices/txtconnws.asmx/ValidateUser?");
        path.append("username=ML_KWARTA_PADALA&password=globe123&org=M. LHUILLIER PHILS&hash=1");
        System.out.println(path);
        
        String response = invoke(path.toString());
        System.out.println(response);
    }
    
    public void xtest2() throws Exception
    {
        StringBuffer sb = new StringBuffer();
        sb.append("<?xml version=\"1.0\" encoding=\"utf-8\" ?>");
        sb.append("<c:string xmlns=\"http://txtconnect.globesolutions.com.ph/webservices/\">");
        sb.append("C093E6A2166542DB9F041C7AF9107C85F::549");
        sb.append("</c:string>");
        
        SAXParserFactory factory = SAXParserFactory.newInstance();
        SAXParser parser = factory.newSAXParser();
        CustomHandler handler = new CustomHandler();
        parser.parse(new ByteArrayInputStream(sb.toString().getBytes()), handler);
        System.out.println(handler.getData());
    }
    
    private Properties getConfig() throws Exception 
    {
        URL url = new URL("http://192.168.3.211:8080/wsproxy/TxtConnWSConfig");
        InputStream in = url.openStream();
        try
        {
            Properties props = new Properties();
            props.load(in);
            return props;
        }
        catch(Exception ex) {
            throw ex;
        }
        finally {
            try { in.close(); }catch(Exception ign){;}
        }
    }
    
    private String invoke(String requestPath) throws Exception
    {
        StringBuffer path = new StringBuffer("http://192.168.3.211:8080/wsproxy/redirect/");
        path.append(requestPath);
        
        URL url = new URL(path.toString());
        InputStream in = url.openStream();
        
        try
        {
            StringBuffer sb= new StringBuffer();
            int read = -1;
            while ((read=in.read()) != -1) {
                sb.append((char) read);
            }
            return sb.toString();
        }
        catch(Exception ex) {
            throw ex;
        }
        finally {
            try { in.close(); }catch(Exception ign){;}
        }
    }
    
    
    public class CustomHandler extends DefaultHandler
    {
        private Map data = new HashMap();
        private Stack stack = new Stack();
        
        private String getPath()
        {
            StringBuffer sb = new StringBuffer();
            for (int i=0, len=stack.size(); i<len; i++) 
            {
                if (sb.length() > 0) sb.append("/");
                
                sb.append(stack.get(i));
            }
            return sb.toString();
        }
        
        public Map getData() { return data; }
        
        public void characters(char[] ch, int start, int length) throws SAXException 
        {
            String path = getPath();
            data.put(path, String.valueOf(ch, start, length));
        }

        public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException 
        {
            int idx = qName.indexOf(":");
            if (idx < 0)
                stack.push(qName);
            else
                stack.push(qName.substring(idx+1));
        }
        
        public void endElement(String uri, String localName, String qName) throws SAXException 
        {
            if (!stack.isEmpty()) stack.pop();
        }
    }
    
}
