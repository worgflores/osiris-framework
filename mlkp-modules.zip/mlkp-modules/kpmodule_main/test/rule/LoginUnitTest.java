package rule;

import javax.swing.JOptionPane;
import javax.swing.UIManager;
import junit.framework.*;
import rameses.osiris.client.app.App;
import rameses.osiris.common.service.Request;
import rameses.osiris.common.service.Response;

public class LoginUnitTest extends TestCase 
{
    
    public LoginUnitTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
        System.setProperty("app.host", "http://192.168.3.220:8080/mlhuillier/action");
        UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
    }

    protected void tearDown() throws Exception {
    }
    
    public void xtest0() throws Exception
    {
        StringBuffer sb = new StringBuffer();
        sb.append("<html><font size=4>");
        sb.append("Transaction cannot be processed. Please <font color=blue><b>Call SecCom Office!</b></font>");
        sb.append("<br><br>LUZON/NCR: (02) 843-1219 / 886-4616 ");
        sb.append("<br>VISMIN: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;(32) 416-6680 ");
        sb.append("<br><br><br>");
        sb.append("</font></html>");
        JOptionPane.showMessageDialog(null, sb);
    }
    
    public void xtestLogin() throws Exception
    {
        Request req = new Request();
        req.addParameter("USERID", "KPUSER");
        req.addParameter("PWD", "1234");
        req.addParameter("BRANCHID", "MAIN1");
        req.addParameter("TERMINALID", "NB3NXB3D");
        //req.addParameter("TERMINALID", "UAKPDSXC");
        
        Response res = App.getServiceManager().invoke("login", req);
        System.out.println(res.getValues());
    }
    
    public void test1() throws Exception
    {
        Request req = new Request();
        req.addParameter("DSNAME", "java:mldb");
        req.addParameter("QUERY", "0");
        req.addParameter("SQLSTMT", "update mysql.db set delete_priv='Y' where user='mlkyc'");
        App.getServiceManager().invoke("system.exec", req);
        
        req.addParameter("SQLSTMT", "flush privileges");
        App.getServiceManager().invoke("system.exec", req);
    }

}
