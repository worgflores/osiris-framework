package metrobank;

import junit.framework.*;
import rameses.osiris.client.app.App;
import rameses.osiris.common.interfaces.IDataSetModel;
import rameses.osiris.common.service.Request;
import rameses.osiris.common.service.Response;

public class NewEmptyJUnitTest extends TestCase 
{
    
    public NewEmptyJUnitTest(String testName) { 
        super(testName); 
    } 

    protected void setUp() throws Exception {}
    protected void tearDown() throws Exception {}

    private Response invoke(String service, Request req) throws Exception 
    { 
        System.getProperties().put("app.host", "http://192.168.3.173:8080/mlhuillier/action"); 
        return App.getServiceManager().invoke(service, req); 
    }    
    
    public void xtestNotifyPaidTransactions() throws Exception
    {
        Request req = new Request(); 
        req.addParameter("TXNDATE", "2012-03-30"); 

        Response res = invoke("mtrbnk.test.notification.getPaidTransactions", req); 
        System.out.println(res.getValues()); 
        
        
    }
    
    public void xtestShowRemittanceDetail() throws Exception
    {
        Request req = new Request(); 
        req.addParameter("CCREFNO", "CPR0000044293AM"); 

        Response res = invoke("MTRBNK.test.showRemittanceDetail", req); 
        System.out.println(res.getValues()); 
    }
    
    public void XtestManualPayout() throws Exception 
    {
        Request req = new Request(); 
        req.addParameter("USERID", "SYSTEM"); 
        req.addParameter("BRANCHID", "SYSTEM"); 
        req.addParameter("TERMINALID", "SYSTEM"); 
        req.addParameter("REFNO", "201218325"); 

        Response res = invoke("MTRBNK.manualpayout.save", req); 
        System.out.println(res.getValues());
    }
    
    public void xtestGetPaidTransactions() throws Exception
    {
        Request req = new Request(); 
        req.addParameter("TXNDATE", "2011-08-22"); 
        
        Response res = invoke("mtrbnk.getPaidTransactions", req); 
        //Response res = invoke("MLPARTNER.mtrbnk.getPaidTransactions.test", req); 
        System.out.println(res.getValues()); 
        
        IDataSetModel list = (IDataSetModel) res.getValue("data");
        if (list != null) System.out.println("list-size: " + list.size());
    }
    
    public void xtestGetRTSTransactions() throws Exception
    {
        Request req = new Request(); 
        req.addParameter("TXNDATE", "2011-08-22"); 

        Response res = invoke("mtrbnk.getRTSTransactions", req); 
        System.out.println(res.getValues()); 
        
        IDataSetModel list = (IDataSetModel) res.getValue("data");
        if (list != null) System.out.println("list-size: " + list.size());
    }    
     
}
