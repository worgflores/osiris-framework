package printable;

import java.awt.Dimension;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import junit.framework.*;

public class NewEmptyJUnitTest extends TestCase 
{
    
    public NewEmptyJUnitTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
    }

    protected void tearDown() throws Exception {
    }
    
    public void testHello() throws Exception 
    {
        JLabel lbl = new JLabel();   
        lbl.setVerticalAlignment(1);
        lbl.setText("<html><p>A1 component which implements standard dialog box controls.</p><p>A2 component which implements standard dialog box controls.</p></html>");
        
        lbl.setPreferredSize(new Dimension(500, 200));
        
        JOptionPane.showMessageDialog(null, lbl);
    }

}
