package printable;

import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.PrintJob;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.print.PageFormat;
import java.awt.print.Printable;
import java.awt.print.PrinterJob;
import java.util.HashMap;
import java.util.Map;
import javax.swing.JComponent;
import javax.swing.JFrame;

public final class PrintManager 
{
    private PrintManager(){}
        
    public static void print(Container c, Map props, boolean showDialog) 
    {
        if (c == null) return;
        
        Map map = new HashMap();
        if (props != null) map = props;

        PrinterJob pjob = PrinterJob.getPrinterJob();
        DefaultPrintablePage ppage = new DefaultPrintablePage(c, map);
        pjob.setPrintable(ppage);

        try {
            if (showDialog)
            {
                if (pjob.printDialog()) pjob.print();
            }
            else
                pjob.print();
        }
        catch(Exception ex) {
            throw new RuntimeException(ex.getMessage(), ex);
        }
        finally{
            pjob = null;
        }
    }
    
    public static void printGraphics(JComponent jc, Map props) throws Exception  
    {
        // setup size and margin
        double[] size 	= new double[] {(8.5*72),(11*72)};
        double[] margin	= new double[] {(0.5*72),(0.5*72),(0.5*72),(0.5*72)};

        try { size[0] = 72 * ((Double) props.get("PAGE.WIDTH")).doubleValue(); }catch(Exception ex){;}
        try { size[1] = 72 * ((Double) props.get("PAGE.HEIGHT")).doubleValue(); }catch(Exception ex){;}

        try { margin[0] = 72 * ((Double) props.get("MARGIN.TOP")).doubleValue(); }catch(Exception ex){;}
        try { margin[1] = 72 * ((Double) props.get("MARGIN.LEFT")).doubleValue(); }catch(Exception ex){;}
        try { margin[2] = 72 * ((Double) props.get("MARGIN.BOTTOM")).doubleValue(); }catch(Exception ex){;}
        try { margin[3] = 72 * ((Double) props.get("MARGIN.RIGHT")).doubleValue(); }catch(Exception ex){;}

        PrintJob pjob = Toolkit.getDefaultToolkit().getPrintJob(new JFrame(), "Graphics Printing", null);
        if (pjob != null)
        {
            Graphics g = pjob.getGraphics();
            
            //point to first page
            g.translate(0, 0);	
            //set up margin
            g.translate((int) margin[1], (int) margin[0]);
            //set graphics clipping
            g.setClip(0, 0, (int)size[0], (int) size[1]);

            try {
                new PrintManager().paintComponent(jc, g);
            } 
            catch(Exception ex) {
                throw ex;
            }
            finally 
            {
                try { g.dispose(); }catch(Exception ign){;} 
                try { pjob.end(); }catch(Exception ign){;} 
            }
        } 
    }
    
    private void paintComponent(JComponent jc, Graphics g)
    {
        Rectangle rect = new Rectangle();

        rect = jc.getBounds(rect);

        Graphics cg = g.create(rect.x, rect.y, rect.width, rect.height);
        cg.setFont(jc.getFont());
        cg.setColor(jc.getForeground());

        jc.paint(cg);
        cg.dispose();
    }
}


class DefaultPrintablePage implements Printable 
{
    protected Container con = null;
    private Map props = null;

    public double[] size = new double[] {(8.5*72),(11*72)};
    public double[] margin = new double[] {(0.5*72),(0.5*72),(0.5*72),(0.5*72)};

    public DefaultPrintablePage(Container con, Map props) 
    {
        this.con = con;
        this.props = props;

        try { size[0] = 72 * ((Double)props.get("PAGE.WIDTH")).doubleValue(); }catch(Exception ex){;}
        try { size[1] = 72 * ((Double)props.get("PAGE.HEIGHT")).doubleValue(); }catch(Exception ex){;}

        try { margin[0] = 72 * ((Double)props.get("MARGIN.TOP")).doubleValue(); }catch(Exception ex){;}
        try { margin[1] = 72 * ((Double)props.get("MARGIN.LEFT")).doubleValue(); }catch(Exception ex){;}
        try { margin[2] = 72 * ((Double)props.get("MARGIN.BOTTOM")).doubleValue(); }catch(Exception ex){;}
        try { margin[3] = 72 * ((Double)props.get("MARGIN.RIGHT")).doubleValue(); }catch(Exception ex){;}
    } 

    public int print(Graphics g, PageFormat pg, int pageIndex) 
    {
        if (pageIndex >= 1)
            return Printable.NO_SUCH_PAGE;

        Graphics2D g2d = (Graphics2D) g;
        //point to first page
        g2d.translate(0, pageIndex * size[1]);
        //set up margin
        g2d.translate((int)margin[1], (int)margin[0]);				
        //set graphics clipping
        g2d.setClip(0, pageIndex * (int)size[1], (int)size[0], (int)size[1]); 	

        printComponent(g2d, con);			
        return Printable.PAGE_EXISTS;	
    }//

    private void printComponents(Graphics2D g, final Component[] comps) 
    {
    }
    
    protected void printComponent(Graphics2D g, final Component c) 
    {
        Rectangle rect = c.getBounds();
        Dimension dim = c.getPreferredSize(); 
        if (rect.width == 0 && rect.height == 0)
        {
            if (rect.width == 0) rect.width = dim.width;
            if (rect.height == 0) rect.height = dim.height;
        
            c.setBounds(rect.x, rect.y, rect.width, rect.height);
            rect = c.getBounds();
        }
        
        System.out.println("rect=" + rect + ", dim=" + dim);
        Graphics gp = g.create(rect.x, rect.y, rect.width, rect.height);
        c.paint(gp);
        gp.dispose();
    }    
}

class AdvancedPrintablePage extends DefaultPrintablePage 
{
    public AdvancedPrintablePage(Container c, Map props) {
        super(c, props);
    } 
}
