package adx;

import java.io.InputStream;
import java.net.URL;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.HashMap;
import java.util.Map;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import junit.framework.*;

public class ADXTest extends TestCase 
{
    
    public ADXTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
    }

    protected void tearDown() throws Exception 
    {
    }
    
    public void test000() throws Exception
    {
        TrustManager[] tm = new TrustManager[]
        {
            new X509TrustManager() 
            {
                public void checkClientTrusted(X509Certificate[] x509Certificate, String string) throws CertificateException {;}
                public void checkServerTrusted(X509Certificate[] x509Certificate, String string) throws CertificateException {;}
                public X509Certificate[] getAcceptedIssuers() { return null; }
            }
        };
        
        SSLContext ssl = SSLContext.getInstance("SSL");
        ssl.init(null, tm, new SecureRandom());
        
        URL u = new URL("http://192.168.3.211:8080/wsproxy/redirect/https://netbankingdr.chinatrust.com.ph/CTADX/adx.asmx?wsdl");
        u.openStream(); 
    }
    
    private String invoke(String name, String requestInfo)throws Exception 
    {
        InputStream is = null;

        try 
        {
            String path = "http://192.168.3.211:8080/wsproxy/redirect/http://www.nybp.info/PickupWebService/Service1.asmx/"+name+"?"+requestInfo;
            URL url = new URL(path);
            is = url.openStream();
            int i = -1;
            StringBuffer sb = new StringBuffer(); 
            while((i = is.read()) != -1 ){ 
                sb.append((char)i); 
            } 

            String txt = sb.toString();
            
            String s = "<"+name+"Return>";

            int idx0 = txt.indexOf(s);
            int idx1= txt.indexOf("</"+name+"Return>");

            String result = txt.substring(idx0+s.length(),idx1);
            return result;
        } 
        catch(Exception e) {
            throw e;
        } 
        finally {
            try { is.close(); }catch(Exception ign){;}
        }
    }
        
    private Map convert(String data, String[] keys) 
    {
        Map map = new HashMap();
        int startidx = 0;
        int idx = -1;
        int ctr = 0;
        while(true) 
        {
            if(ctr >= keys.length) break;
            
            idx = data.indexOf('|',startidx);
            if(idx < 0) break;

            map.put(keys[ctr], data.substring(startidx, idx));
            startidx = idx + 1;
            ctr ++;
        }

        if (ctr < keys.length && startidx > 0 && startidx < data.length())
            map.put(keys[ctr],data.substring(startidx));
        
        return map;
    }

}
