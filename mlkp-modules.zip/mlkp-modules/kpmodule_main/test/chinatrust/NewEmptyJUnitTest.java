package chinatrust;

import junit.framework.*;
import rameses.osiris.client.app.App;
import rameses.osiris.common.service.Request;
import rameses.osiris.common.service.Response;

public class NewEmptyJUnitTest extends TestCase 
{
    //SignOn
    //   http://192.168.3.211:8080/wsproxy/redirect/https://netbanking.chinatrust.com.ph/CTADX/adx.asmx/SignOnRequest?MessageType=1&CorpID=101-091114-00135&ClientPassword=micharl1    
    
    private String HOST = "http://192.168.3.247:8080/mlhuillier/action";
    
    public NewEmptyJUnitTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
    }

    protected void tearDown() throws Exception {
    }
    
    public void testADXConfig() throws Exception
    {
        //Response res = invoke("chinatrust.test.getADXConfig", new Request());
        Response res = invoke("chinatrust.test2", new Request());
        System.out.println(res.getValues());    
    }
    
    public void xtest2() throws Exception 
    {
        Request req = new Request();
        
        Response res = invoke("chinatrust.test2", req);
        System.out.println(res.getValues());    
        
        
//        StringBuffer sb = new StringBuffer(); 
//        ClassLoader loader = Thread.currentThread().getContextClassLoader();
//        java.util.Enumeration en = loader.getResources("");
//        while (en.hasMoreElements())
//        {
//            sb.append(en.nextElement().toString()); 
//            sb.append("\n");
//        }
//        System.out.println(sb);

//        ClassLoader loader = Thread.currentThread().getContextClassLoader();
//        java.net.URL url = loader.getResource("conf/ADXConfig.properties"); 
//        java.util.Properties props = new java.util.Properties(); 
//        if (url != null) props.load(url.openStream()); 
        
    }
    
    
    
    
    
    
    
    
    
    
    
    private Response invoke(String service, Request req) throws Exception 
    { 
        System.getProperties().put("app.host", HOST);
        return App.getServiceManager().invoke(service, req);
    }
    

}
