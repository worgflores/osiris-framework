package branchactivity;

import java.util.Iterator;
import junit.framework.*;
import rameses.osiris.client.app.App;
import rameses.osiris.common.interfaces.IDataModel;
import rameses.osiris.common.interfaces.IDataSetModel;
import rameses.osiris.common.service.Request;
import rameses.osiris.common.service.Response;

public class BranchActivityReportTest extends TestCase 
{
    private String HOST = "http://192.168.3.247:8080/mlhuillier/action";

    public BranchActivityReportTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception 
    {
    } 

    protected void tearDown() throws Exception {} 
    
    public void xtestBranchBillsPayment() throws Exception 
    {
        Request req = new Request();
        req.addParameter("USERID", "BAROT-HM");
        req.addParameter("BRANCHID", "CANLAO");
        req.addParameter("FROMDATE", "2011-01-12");
        req.addParameter("REPORTNAME", "branchmgr.billpayment");

        Response res = invoke("report.dailyBillPayment", req);
        System.out.println(res.getValue("REPORT")); 
        
    }
    
    private Response invoke(String service, Request req) throws Exception 
    { 
        System.getProperties().put("app.host", HOST);
        return App.getServiceManager().invoke(service, req);
    }
    
    private void list(IDataSetModel idsm, String name) throws Exception
    {
        if (name != null) System.out.println("["+name+"]");
        
        for (int i=0; i<idsm.size(); i++)
        {
            IDataModel doc = idsm.getItem(i);
            Iterator itr = doc.getFields();
            StringBuffer sb = new StringBuffer();
            while (itr.hasNext())
            {
                String key = itr.next().toString();
                Object val = doc.getValue(key);
                if (sb.length() > 0) sb.append(", ");
                
                sb.append(key + "=" + val);
            }
            System.out.println(i + ") " + sb);
        }
        
        if (name != null) System.out.println("");
    }
    
}
