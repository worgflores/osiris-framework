package webservice;

import java.rmi.server.UID;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import junit.framework.*;
import rameses.osiris.client.app.App;
import rameses.osiris.common.data.DefaultDataModel;
import rameses.osiris.common.data.FilterDataModel;
import rameses.osiris.common.interfaces.IDataModel;
import rameses.osiris.common.interfaces.IDataSetModel;
import rameses.osiris.common.service.Request;
import rameses.osiris.common.service.Response;

public class Test extends TestCase 
{   

    public Test(String testName) {
        super(testName);
    }
    
    protected void setUp() throws Exception {
        System.setProperty("app.host", "http://192.168.3.20:8080/mlhuillier/action");
    }
    
    protected void tearDown() throws Exception {}

    private Response invoke(String command, Request req) throws Exception {
        return App.getServiceManager().invoke(command, req);
    }
    
    public void xtest0() throws Exception 
    {
//        String branchid = "MATINA";
//        char seed = branchid.charAt((int) Math.random()*branchid.length()); 
//        System.out.println((seed+"SOUT1b7bbdf1:1336209322c:-151d").hashCode());
//        System.out.println((seed+"SOUT817dd54:132adc0e98c:-20ce").hashCode());
        String uid = new UID().toString(); 
        System.out.println(uid);
        System.out.println(uid.hashCode());
    }
    
    public void xtestOperatorSendoutReport() throws Exception 
    { 
        Request req = new Request();
        req.addParameter("PERIOD", "DAILY");
        req.addParameter("USERID", "VALERIO-S");
        req.addParameter("BRANCHID", "SMCAJE");
        req.addParameter("STATUS", "sendout");
        req.addParameter("FROMDATE", "2011-07-10");

        Response res = invoke("report.dw.branchuser", req);
        System.out.println(res.getValue("REPORT"));
    } 
    
    public void xtestUnclaimedCustomerService() throws Exception 
    {
        FilterDataModel filter = new FilterDataModel("bykptn");
        filter.setValue("kptn", "MARKT21840268247");
        filter.setValue("status", "1");
        
        Request req = new Request();
        req.addParameter("FILTER", filter);

        Response res = invoke("MLKP4.unclaimedcustomerservice", req);
        System.out.println(res.getValues());
        
        IDataSetModel list = (IDataSetModel) res.getValue("unclaimedcustomerservice"); 
        if (list != null) 
        {
            for (int i=0; i<list.size(); i++) 
            {
                System.out.println((i+1) + ") " + convertModelToMap(list.getItem(i)));
            }
        }
    }    
    
    public void xtestCustomerServiceByKPTN() throws Exception 
    {
        FilterDataModel filter = new FilterDataModel("bykptn");
        filter.setValue("kptn", "KIAMBA1506881815");
        filter.setValue("status", "2");
        
        Request req = new Request();
        req.addParameter("FILTER", filter);

        Response res = invoke("MLKP4.customerservice1", req);
        System.out.println(res.getValues());
        
        IDataSetModel list = (IDataSetModel) res.getValue("customerservice"); 
        if (list != null) 
        {
            for (int i=0; i<list.size(); i++) 
            {
                System.out.println((i+1) + ") " + convertModelToMap(list.getItem(i)));
            }
        }
    }     

    public void xtestCustomerServiceByReceiver() throws Exception 
    {
        FilterDataModel filter = new FilterDataModel("byreceiver");
        filter.setValue("receiverlastname", "PARAJA");
        filter.setValue("receiverfirstname", "ELMAH");
        filter.setValue("status", "2");
        
        Request req = new Request();
        req.addParameter("FILTER", filter);

        Response res = invoke("MLKP4.customerservice1", req);
        System.out.println(res.getValues());
        
        IDataSetModel list = (IDataSetModel) res.getValue("customerservice"); 
        if (list != null) 
        {
            for (int i=0; i<list.size(); i++) 
            {
                System.out.println((i+1) + ") " + convertModelToMap(list.getItem(i)));
            }
        }
    }     
    
    public void xtestPrintKPTNLog() throws Exception 
    {
        IDataModel data = new DefaultDataModel();
        data.setValue("txnowner", "MLKP4"); 
        
        Request req = new Request();
        req.addParameter("data", data);
        req.addParameter("KPTN", "PROSPE1506863972");

        Response res = invoke("print.kptnlog", req);
        System.out.println(res.getValues());
    }     
    
    public void xtestKPSendoutReport() throws Exception 
    {
        Request req = new Request();
        req.addParameter("USERID", "KPUSER");
        req.addParameter("BRANCHID", "FSD16");
        req.addParameter("STATUS", "all");
        req.addParameter("FROMDATE", "2011-09-12");
        req.addParameter("REPORTNAME", "branchmgr.sendout");
        
        Response res = invoke("report.branchmgrSendout", req);
        System.out.println(res.getValues());
    }
    
    public void xtestCalculateCharge() throws Exception 
    {
        Request req = new Request();
//        req.addParameter("PARTNERID", "SPDREM");
//        req.addParameter("CURRENCY", "PHP");
//        req.addParameter("AMOUNT", "50000.0");
        //req.addParameter("CCREFNO", "ISINPL0002078066");
        
        //Response res = invoke("MLPARTNER.payoutsearch.byCCREFNO_new", req);
        
        //req.addParameter("TERMINALID1", "0RWXKW10");
        Response res = invoke("authenticate", req);
        System.out.println(res.getValues());
    }    

    public void xtestRuleClearCache() throws Exception 
    {
        Request req = new Request();
        req.addParameter("RULENAME", "CSHSNS.fetchCashsenseDraft"); 
        
        Response res = invoke("sysrule.clearCache", req);
        System.out.println(res.getValues());
    } 
    
    public void xtestScreenClearCache() throws Exception 
    {
        Request req = new Request();
        req.addParameter("SCREENNAME", "FSDUSER"); 
        
        Response res = invoke("sysscreen.clearCache", req);
        System.out.println(res.getValues());
    } 
    
    public void xtestRule() throws Exception 
    { 
        Request req = new Request();
        req.addParameter("BRANCHID", "V & G");
        req.addParameter("USERID", "SYSTEM");
        req.addParameter("TERMINALID", "SYSTEM");
        req.addParameter("CCREFNO", "X061819302902953");
        
        //Response res = invoke("JMXAPIService.DataSourceBinding", req); 
        Response res = invoke("fetchDataHandler.XOOM", req); 
        System.out.println(res.getValues()); 
    } 
    
    private Map convertModelToMap(IDataModel doc) 
    {
        Map map = new HashMap();
        Iterator fields = doc.getFields();
        while (fields.hasNext()) 
        { 
            String fldname = fields.next().toString(); 
            Object fldvalue = null; 
            try 
            { 
                fldvalue = doc.getValue(fldname); 
                if (fldvalue == null || fldvalue.toString().length() == 0) fldvalue = null; 
            } catch(Exception ign) {;} 

            if (fldvalue != null) map.put(fldname, fldvalue); 
        } 
        return map; 
    }     
}
