package test;

import java.awt.Container;
import java.util.Iterator;
import java.util.Map;
import javax.swing.JDialog;
import javax.swing.UIManager;
import junit.framework.*;
import rameses.osiris.client.app.App;
import rameses.osiris.common.service.Request;
import rameses.osiris.common.service.Response;

public abstract class AbstractKPUnitTest extends TestCase 
{
    public AbstractKPUnitTest(String testName) {
        super(testName);
    }
    
    protected void setUp() throws Exception 
    {
        UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        System.setProperty("app.host","http://192.168.3.246:8080/mlhuillier/action");
        //System.setProperty("app.res.system","mlkp.Resource");
        //System.setProperty("app.res.shared","shared.Resource");
        //System.setProperty("app.res.svr","rameses.osiris.client.app.ScreenResource2");
        //System.setProperty("screen.host","http://192.168.3.246:8080/mlhuillier/screen");        
    }
    
    protected void tearDown() throws Exception {
    }
        
    public void test2() throws Exception
    {
    }
    
    
    protected Response invoke(String action, Map params) throws Exception
    {
        Request req = new Request();
        Iterator itr = params.keySet().iterator();
        while (itr.hasNext()) 
        {
            String key = itr.next().toString();
            req.addParameter(key.toUpperCase(), params.get(key));
        }
        return invoke(action, req);
    }
    
    protected Response invoke(String action, Request req) throws Exception
    {
        Response res = App.getServiceManager().invoke(action, req);
        return res;
    }
    
    protected void showDialog(Container con, String title)
    {
        JDialog d = new JDialog();
        d.setModal(true);
        d.setTitle(title);
        d.setContentPane(con);
        d.pack();
        d.setVisible(true);
    }
    
    protected void showDialog(JDialog d)
    {
        d.setModal(true);
        d.pack();
        d.setVisible(true);
    }    
        
}
