package test;

import com.rameses.ml.kyc.KYCController;
import com.rameses.osiris.client.AbstractFormController;
import com.rameses.osiris.client.FormGenerator;
import com.rameses.osiris.client.FormLauncher;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.util.HashMap;
import java.util.Map;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import junit.framework.*;
import rameses.osiris.client.app.App;
import rameses.osiris.client.app.CodeBase;
import rameses.osiris.common.data.DataUtil;

public class ControllerTest extends TestCase 
{
    public ControllerTest(String testName) {
        super(testName);
    }
    
    protected void setUp() throws Exception 
    {
        UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        System.setProperty("app.host","http://192.168.3.246:8080/mlhuillier/action");
        //System.setProperty("app.res.system","mlkp.Resource");
        //System.setProperty("app.res.shared","shared.Resource");
        System.setProperty("app.res.svr","rameses.osiris.client.app.ScreenResource2");
        System.setProperty("screen.host","http://192.168.3.246:8080/mlhuillier/screen");        
    }
    
    protected void tearDown() throws Exception {
    }
        
    public void test2() throws Exception
    {
        String text = "<html><img src=http://192.168.3.246:8080/kyc/renderer/00000000020></img></html>";
        JLabel lbl = new JLabel();
        lbl.setVerticalAlignment(SwingConstants.TOP);
        lbl.setText(text);

        JPanel p = new JPanel(new BorderLayout());
        p.add(lbl);
        
        java.awt.Dimension lblDim = lbl.getPreferredSize();
        int width = lblDim.width + 2;
        int height = lblDim.height + 2;
        
        Dimension scrDim = Toolkit.getDefaultToolkit().getScreenSize();
        if (height > (scrDim.height-100)) height = scrDim.height-100;
        
        width = Math.max(width, 300);
        height = Math.max(height, 200);
        
        JScrollPane jsp = new JScrollPane(p);
        jsp.getViewport().setBackground(Color.WHITE);
        jsp.setPreferredSize(new Dimension(width, height));
        
        JDialog d = new JDialog();
        d.setTitle("KYC Photo Preview");
        d.setContentPane(jsp);
        d.setLocation(0, 0);
        showDialog(d);
    }
    
    public void xtest1() throws Exception 
    {
        Map props = new HashMap();
        props.put("TERMINALID", "KGZZ3AQ8");
        App.getSecurityManager().login("KPUSER", "1234", props);

        launch(new KYCController());
    }
    
    private void launch(AbstractFormController afc) throws Exception
    {
        FormGenerator.getInstance().dump(afc);
        FormLauncher.newInstance().launch(afc);
    }
    
    private void showDialog(Container con, String title)
    {
        JDialog d = new JDialog();
        d.setModal(true);
        d.setTitle(title);
        d.setContentPane(con);
        d.pack();
        d.setVisible(true);
    }
    
    private void showDialog(JDialog d)
    {
        d.setModal(true);
        d.pack();
        d.setVisible(true);
    }    
    
    private class MyCodeBase extends CodeBase
    {
        public boolean beforeClose() 
        {
            boolean retValue;
            
            retValue = super.beforeClose();
            return retValue;
        }
        
    }
    
}
