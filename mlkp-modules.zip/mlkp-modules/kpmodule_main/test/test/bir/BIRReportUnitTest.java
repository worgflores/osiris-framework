package test.bir;

import junit.framework.*;

public class BIRReportUnitTest extends TestCase 
{
    
    public BIRReportUnitTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
    }

    protected void tearDown() throws Exception {
    }
    
    // TODO add test methods here. The name must begin with 'test'. For example:
    public void testHello() throws Exception 
    {
        
    }
    
}
