package test;

import com.rameses.ml.kyc.KYCController;
import com.rameses.osiris.client.AbstractFormController;
import com.rameses.osiris.client.FormGenerator;
import com.rameses.osiris.client.FormLauncher;
import java.awt.Container;
import java.util.HashMap;
import java.util.Map;
import javax.swing.JDialog;
import javax.swing.UIManager;
import junit.framework.*;
import rameses.osiris.client.app.App;

public class KYCTest extends TestCase 
{
    public KYCTest(String testName) {
        super(testName);
    }
    
    protected void setUp() throws Exception 
    {
        UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        System.setProperty("app.host","http://192.168.3.246:8080/mlhuillier/action");
        //System.setProperty("app.res.system","mlkp.Resource");
        //System.setProperty("app.res.shared","shared.Resource");
        System.setProperty("app.res.svr","rameses.osiris.client.app.ScreenResource2");
        System.setProperty("screen.host","http://192.168.3.246:8080/mlhuillier/screen");        
    }
    
    protected void tearDown() throws Exception {
    }
        
    public void test1() throws Exception 
    {
        Map props = new HashMap();
        props.put("TERMINALID", "KGZZ3AQ8");
        App.getSecurityManager().login("KPUSER", "1234", props);

        launch(new KYCController());
    }
    
    private void launch(AbstractFormController afc) throws Exception
    {
        FormGenerator.getInstance().dump(afc);
        FormLauncher.newInstance().launch(afc);
    }
    
    private void showDialog(Container con)
    {
        JDialog d = new JDialog();
        d.setModal(true);
        d.setContentPane(con);
        d.setSize(640,480);
        d.setVisible(true);
    }
}
