package test;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.URL;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import junit.framework.*;

public class NewEmptyJUnitTest extends TestCase 
{
    
    public NewEmptyJUnitTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
    }

    protected void tearDown() throws Exception {
    }
    
    public void xtest0() throws Exception
    {
        String url = "http://localhost:8080";
        String cmd = "rundll32 url.dll,FileProtocolHandler " + url;
        Runtime.getRuntime().exec(cmd);
    }
    
    public void xtest1() throws Exception
    {
        JarFile jf = new JarFile("D:/mlbillspayment.jar");
        JarEntry je = jf.getJarEntry("META-INF/app.conf");
        InputStream in = jf.getInputStream(je);
        StringBuffer sb = new StringBuffer();
        int read = -1;
        while ((read=in.read()) != -1) {
            sb.append((char) read);
        }
        in.close();
        System.out.println(sb);
    }
    
    public void test3() throws Exception
    {
        InputStream is = null;
        FileOutputStream fos = null;
        String filename = System.getProperty("java.io.tmpdir") + "/mlmainlogo.png";
        
        try
        {
            File f = new File(filename);
            if (f.exists()) return;
            
            URL url = new URL("http://192.168.3.187/mlhuillier/downloads/mlmainlogo.png");
            is = url.openStream(); 

            fos = new FileOutputStream(filename); 

            int read = -1; 
            while ((read=is.read()) != -1) {
                fos.write(read);
            }
            
            try { is.close(); }catch(Exception ing){;} 
            try { fos.close(); }catch(Exception ing){;}             
        }
        catch(Exception ex) 
        {
            try { is.close(); }catch(Exception ing){;} 
            try { fos.close(); }catch(Exception ing){;} 
            
            ex.printStackTrace();
        }
    }    
}
