package domantfee;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import junit.framework.*;
import rameses.osiris.client.app.App;
import rameses.osiris.common.interfaces.IDataModel;
import rameses.osiris.common.service.Request;
import rameses.osiris.common.service.Response;

public class MLKP4ChargeDormantFee extends TestCase 
{
    
    public MLKP4ChargeDormantFee(String testName) { 
        super(testName); 
    } 

    protected void setUp() throws Exception { 
        System.setProperty("app.host", "http://192.168.3.173:8080/mlhuillier/action");
    }

    protected void tearDown() throws Exception {} 
    
    
    public void testMain() throws Exception 
    {  
        String kptn = "MALABA2145779952"; 
        String billdate = "2012-01-18"; 
        
        Request req = new Request(); 
        req.addParameter("KPTN", kptn);
        req.addParameter("BILLDATE", billdate);
        Response res = invoke("mlkp4.reinstatement.calculateFee", req); 
        //System.out.println(res.getValues());
        
        System.out.println("");
        IDataModel doc = (IDataModel) res.getValue("sendout");
        if (doc != null) System.out.println(convertModelToMap(doc));
    } 

    
    private Map convertModelToMap(IDataModel doc) 
    {
        Map map = new HashMap();
        Iterator fields = doc.getFields();
        while (fields.hasNext()) 
        { 
            String fldname = fields.next().toString(); 
            Object fldvalue = null; 
            try 
            { 
                fldvalue = doc.getValue(fldname); 
                if (fldvalue == null || fldvalue.toString().length() == 0) fldvalue = null; 
            } catch(Exception ign) {;} 

            if (fldvalue != null) map.put(fldname, fldvalue); 
        } 
        return map; 
    }         
    
    private Response invoke(String command, Request req) throws Exception {
        return App.getServiceManager().invoke(command, req);
    }    
}





