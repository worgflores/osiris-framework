package chinabank;

import groovy.util.XmlSlurper;
import groovy.util.slurpersupport.GPathResult;
import junit.framework.*;
import org.jasypt.util.password.BasicPasswordEncryptor;
import rameses.osiris.client.app.App;
import rameses.osiris.common.service.Request;
import rameses.osiris.common.service.Response;

public class NewEmptyJUnitTest extends TestCase 
{
    private String HOST = "http://192.168.3.247:8080/mlhuillier/action";
    
    public NewEmptyJUnitTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
        
        XmlSlurper x = new XmlSlurper();
        GPathResult gpath = x.parseText("<root/>"); 
    }

    protected void tearDown() throws Exception {
    }
    
    private Response invoke(String service, Request req) throws Exception 
    { 
        System.getProperties().put("app.host", HOST);
        return App.getServiceManager().invoke(service, req);
    }
    

    public void test0000() throws Exception
    {
        String inputPwd = "!4wtU(I+*kfpZl3m"; 
        BasicPasswordEncryptor encryptor = new BasicPasswordEncryptor(); 
        String encPwd = encryptor.encryptPassword(inputPwd); 
        System.out.println("inputPwd: " + inputPwd);
        System.out.println("encPwd  : " + encPwd);
        System.out.println("matches : " + encryptor.checkPassword(inputPwd, encPwd));
        
    }
}
