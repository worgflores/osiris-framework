package com.rameses.soapws;

import java.io.StringWriter;
import java.net.URL;
import java.util.Vector;
import javax.mail.internet.MimeBodyPart;
import javax.xml.parsers.SAXParserFactory;
import org.apache.soap.Constants;
import org.apache.soap.Envelope;
import org.apache.soap.EnvelopeImpl;
import org.apache.soap.encoding.SOAPMappingRegistry;
import org.apache.soap.encoding.soapenc.StringDeserializer;
import org.apache.soap.rpc.Call;
import org.apache.soap.rpc.Parameter;
import org.apache.soap.rpc.SOAPContext;
import org.apache.soap.transport.http.SOAPHTTPConnection;
import org.apache.soap.util.xml.QName;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class XMLSOAP3 
{
    private SOAPMappingRegistry soapMappingRegistry;
    private URL serverURL; 
    private String serverHost;
    private String targetURI;
    private String namespace;
    private String headerXml;
    private String soapActionURI;
    private int timeout = 15000;
    private boolean debug = false;
    private boolean showParameterType = true;
    private boolean showParameterNamespace = false;
    
    public XMLSOAP3(String url) 
    {
        try 
        { 
            this.serverURL = new URL(url); 
            this.serverHost = url; 
        } 
        catch(Exception ex) { 
            throw new IllegalStateException(ex.getMessage(), ex); 
        } 
    } 
    
    public SOAPMappingRegistry getSoapMappingRegistry() 
    {
        if (soapMappingRegistry == null)
        {
            soapMappingRegistry = new SOAPMappingRegistry(); 
            soapMappingRegistry.mapTypes(Constants.NS_URI_SOAP_ENC, new QName("", "return"), null, null, new StringDeserializer()); 
        }
        return soapMappingRegistry;
    }

    public boolean isShowParameterType() { return showParameterType; }
    public void setShowParameterType(boolean showParameterType) { this.showParameterType = showParameterType; }

    public boolean isShowParameterNamespace() { return showParameterNamespace; }
    public void setShowParameterNamespace(boolean showParameterNamespace) { this.showParameterNamespace = showParameterNamespace; }
    
    public String getTargetURI() { return targetURI; }
    public void setTargetURI(String targetURI) { this.targetURI = targetURI; }
    
    public String getNamespace() { return namespace; }
    public void setNamespace(String namespace) { this.namespace = namespace; }
    
    public int getTimeout() { return timeout; }
    public void setTimeout(int timeout) { this.timeout = timeout; }
    
    public boolean isDebug() { return debug; }
    public void setDebug(boolean debug) { this.debug = debug; }
    
    public String getHeaderXml() { return headerXml; } 
    public void setHeaderXml(String headerXml) { this.headerXml = headerXml; }

    public String getSoapActionURI() { return soapActionURI; } 
    public void setSoapActionURI(String soapActionURI) { this.soapActionURI = soapActionURI; }
    
    public Action createAction(String name) throws Exception {
        return createAction(name, null); 
    }
    
    public Action createAction(String name, String alias) throws Exception 
    {
        Action a = new Action(name, this); 
        a.setAlias(alias); 
        return a; 
    }        
    
    public Object invoke(Action action) throws Exception
    {
        Call call = prepareCall(action);
        Envelope env = call.buildEnvelope();
        
        String ns = getNamespace();
        if (ns != null && ns.trim().length() > 0) 
            env.declareNamespace(Constants.NS_PRE_SOAP_ENV, ns);
        
        if (isDebug())
        {
            System.out.println("***** REQUEST *****");
            System.out.println(getEnvelopeContent(createEnvelopeWrapper(env, call, action.getAlias()), call.getSOAPMappingRegistry(), call.getSOAPContext()));
            System.out.println("");
        }        
        
        StringBuffer actionURI = new StringBuffer();
        if (call.getTargetObjectURI() != null)
        {
            String saction = call.getTargetObjectURI();
            actionURI.append(saction);
            
            if (!saction.endsWith("/")) actionURI.append("/"); 
        }
        
        actionURI.append(call.getMethodName());
        
        String saURI = getSoapActionURI();
        if (saURI != null && saURI.trim().length() > 0) actionURI = new StringBuffer(saURI); 
        
        SOAPHTTPConnection conn = new SOAPHTTPConnection();
        conn.send(serverURL, actionURI.toString(), null, createEnvelopeWrapper(env, call, action.getAlias()), call.getSOAPMappingRegistry(), call.getSOAPContext());
        
        SOAPContext respCtx = conn.getResponseSOAPContext(); 
        MimeBodyPart rootPart = respCtx.getRootPart(); 
        
        SAXParserFactory factory = SAXParserFactory.newInstance();
        factory.setNamespaceAware(true);
        factory.setValidating(false);
        
        MyDefaultHandler handler = new MyDefaultHandler();
        factory.newSAXParser().parse(rootPart.getInputStream(), handler); 
        String result = handler.getContent(); 
        if (result.startsWith("<Fault>"))
        {
            String faultcode = getElementValue(result, "faultcode");
            String faultstring = getElementValue(result, "faultstring");
            String faultdetail = getElementValue(result, "detail");
            
            StringBuffer errmsg = new StringBuffer();
            if (faultcode != null && faultcode.trim().length() > 0) errmsg.append(faultcode + ": ");
            if (faultstring != null) errmsg.append(faultstring);
            if (1==1) throw new Exception(errmsg.toString());
        }
        return result; 
    }
    
    
    private String getElementValue(String source, String element)
    {
        int idx0 = source.indexOf("<" + element + ">");
        if (idx0 < 0) return null;
        
        int idx1 = source.indexOf("</" + element + ">", idx0);
        if (idx1 < 0) return null;
        
        String s = source.substring(idx0, idx1);
        return s.replaceAll("<"+element+">", "");
    }
        
    private EnvelopeImpl createEnvelopeWrapper(Envelope env, Call call, String actionAlias) 
    {
        EnvelopeImpl ew = new EnvelopeImpl(env, call, getHeaderXml(), isShowParameterType(), isShowParameterNamespace(), actionAlias);
        return ew;
    }
        
    private Call prepareCall(Action action) throws Exception
    {
        Call call = action.getCall(); 
        call.setSOAPMappingRegistry(getSoapMappingRegistry()); 
        call.setEncodingStyleURI(Constants.NS_URI_SOAP_ENC); 
        
        String sURI = getTargetURI(); 
        if (sURI != null && sURI.trim().length() > 0) 
            call.setTargetObjectURI(sURI);             
        
        call.setTimeout(getTimeout());
        call.setMethodName(action.getName()); 
        call.setParams(action.getParameters()); 
        return call; 
    }
    
    private String getEnvelopeContent(Envelope env, SOAPMappingRegistry reg, SOAPContext ctx) throws Exception
    {
        SOAPMappingRegistry reg0 = (reg == null) ? new SOAPMappingRegistry() : reg;
        SOAPContext ctx0 = (ctx == null) ? new SOAPContext() : ctx;
        
        StringWriter swr = new StringWriter();
        env.marshall(swr, reg, ctx);
        return swr.toString();
    }

    public static class Action
    {
        private String alias;
        private String name;
        private XMLSOAP3 client;
        private Vector parameters;
        private Call call;
        
        private Action(String name, XMLSOAP3 client) 
        {
            this.name = name;
            this.client = client;
            this.parameters = new Vector();
            this.call = new Call(); 
        }
        
        public Call getCall() { return call; } 
                
        public void addParameter(String name, Object value) 
        {
            Class type = (value == null ? String.class : value.getClass()); 
            parameters.addElement(new Parameter(name, type, value, null));
        }
        
        public void addParameter(String name, Object value, Class type) 
        {
            Class ctype = (type == null) ? String.class : type;
            parameters.addElement(new Parameter(name, ctype, value, null));
        }
        
        String getAlias() { return alias; } 
        void setAlias(String alias) { this.alias = alias;  }
        
        String getName() { return name; }
        Vector getParameters() { return parameters; }
    }
    
    private class MyDefaultHandler extends DefaultHandler
    {
        private String SYSPATH = "Envelope/Body";
        private StringBuffer content;
        private String path = "";
        
        MyDefaultHandler() {
            content = new StringBuffer();
        }

        public String getContent() { return content.toString(); }
        
        public void startDocument() throws SAXException 
        {
            content = new StringBuffer();
            path = "";
        }
        
        public void startElement(String uri, String localName, String qName, Attributes attrs) throws SAXException 
        {
            if (path.length() > 0) path += "/";
            
            path += localName;
            
            if (path.equals(SYSPATH)) return;
            if (path.startsWith(SYSPATH)) content.append("<" + localName + ">");
        }

        public void endElement(String uri, String localName, String qName) throws SAXException 
        {
            if (path.equals(SYSPATH)) return;
            if (path.startsWith(SYSPATH)) content.append("</" + localName + ">");
            
            int idx = path.lastIndexOf('/');
            if (idx > 0)
                path = path.substring(0, idx);
            else
                path = "";
        }

        public void characters(char[] ch, int start, int length) throws SAXException 
        {
            if (path.equals(SYSPATH)) return;
            if (path.startsWith(SYSPATH)) content.append(String.valueOf(ch, start, length));
        }
    }
}
