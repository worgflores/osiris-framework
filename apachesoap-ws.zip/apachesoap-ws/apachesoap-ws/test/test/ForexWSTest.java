package test;

import com.rameses.soapws.XMLSOAPClient;
import junit.framework.*;

public class ForexWSTest extends TestCase 
{
    
    public ForexWSTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
    }

    protected void tearDown() throws Exception {
    }
    
    public void test000() throws Exception
    {
        XMLSOAPClient x = new XMLSOAPClient("http://119.93.91.41/WS/MLWebservice.asmx?wsdl");
        x.setTargetURI("http://119.93.91.41/WS/MLWebservice.asmx");
        x.setDebug(true);
        x.setTimeout(20000);
        x.setShowParameterType(false);
        x.setShowParameterNamespace(true);
        
        XMLSOAPClient.Action a = x.createAction("GetRemittance");
        a.addParameter("sessionId", "MLTEST");
        a.addParameter("username", "ml_user");
        a.addParameter("password", "mlpassword");
        a.addParameter("refno", "ABSPEXCAN723440");
        
        Object res = x.invoke(a);
        System.out.println(res);
    }
}
