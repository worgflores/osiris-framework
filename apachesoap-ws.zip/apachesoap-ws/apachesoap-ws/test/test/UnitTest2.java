package test;

import com.rameses.soapws.XMLSOAPClient;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import junit.framework.*;
import org.apache.soap.Constants;

public class UnitTest2 extends TestCase 
{

    public UnitTest2(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
    }

    protected void tearDown() throws Exception {
    }
    
    public void test000() throws Exception
    {
        XMLSOAPClient c = new XMLSOAPClient("http://localhost:8080/forex-webservice/ForexWS?wsdl");
        c.setTargetURI("http://ws.forex.ml/jaws");
        
        XMLSOAPClient.Action a = c.createAction("getRateSetting");
        a.addParameter("branchid", "fuent1", null, Constants.NS_URI_SOAP_ENC);
        a.addParameter("currency", "PHP");
        Object o = c.invoke(a);
        System.out.println(o);
    }
    
    public void xtestMT() throws Exception
    {
        List params = new ArrayList();
        params.add(new String[]{"branchid", "Fuent1"});
        params.add(new String[]{"currency", "PHP"});
        
        Map req = new HashMap();
        req.put("targetURI", "http://ws.forex.ml/jaws");
        req.put("wsdl", "http://localhost:8080/forex-webservice/ForexWS?wsdl");
        req.put("methodName", "getRateSetting");
        req.put("parameters", params);
        //req.put("returnType", "object");
        
        Map res = (Map) invoke("http://localhost:8080/services/soapws/invoke2", req);
        System.out.println(res);
    }
    
    private Object invoke(String host, Map req) throws Exception 
    {
        URL url = null;
        HttpURLConnection conn = null;
        ObjectOutputStream out = null;
        ObjectInputStream in = null;
        
        try 
        {
            url = new URL(host);
            conn = (HttpURLConnection) url.openConnection();
            conn.setDoOutput(true); 
            conn.setUseCaches(false); 
            
            out = new ObjectOutputStream(conn.getOutputStream());
            out.writeObject(req);
            
            System.out.println("reading result...");
            in = new ObjectInputStream(conn.getInputStream());
            Object res = in.readObject();
            if (res instanceof Exception) {
                throw (Exception) res;
            }
            else if (res instanceof Map)
            {
                Map map = (Map) res;
                if (!"1".equals(map.get("respcode")))
                {
                    System.out.println(map.get("respdetail")+"");
                    throw new Exception(map.get("respdesc")+"");
                }
            }
            return res;
        } 
        catch (Exception ex) {
            throw ex;
        } 
        finally 
        {
            try { in.close(); } catch(Exception ex){;}
            try { out.close(); } catch(Exception ex){;}
            try { conn.disconnect(); } catch(Exception ex){;}
        }
    }    
}
