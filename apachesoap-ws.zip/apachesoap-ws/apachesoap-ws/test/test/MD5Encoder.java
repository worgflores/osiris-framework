package test;

import java.security.MessageDigest;

public class MD5Encoder  
{   
    public static String encode(String value) 
    {
        try
        {
            MessageDigest md = MessageDigest.getInstance("MD5");
            md.update(value.getBytes());
            
            byte[] hash =  md.digest();
            String hexDigit = "0123456789abcdef";
            StringBuffer sb = new StringBuffer(hash.length);
            for (int i=0; i< hash.length; i++) 
            {
                int b = hash[i] & 0xFF;
                sb.append(hexDigit.charAt(b >>> 4));
                sb.append(hexDigit.charAt(b & 0xF));
            }
            return sb.toString();
        }
        catch(Exception e) {
            throw new IllegalStateException(e.getMessage(), e);
        }
    }
}
