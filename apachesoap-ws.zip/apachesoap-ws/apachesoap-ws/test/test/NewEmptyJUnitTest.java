package test;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import junit.framework.*;

public class NewEmptyJUnitTest extends TestCase 
{

    public NewEmptyJUnitTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
    }

    protected void tearDown() throws Exception {
    }
    
    public void testMT() throws Exception
    {
        String mttn     = "823704905"; 
        String userName = "phl00001";
        String password = "sysadmin";
        String branchid = "mlabra3";
        String citycode = "2800";
        String secretkey = MD5Encoder.encode(password) + branchid + citycode;
        
        List params = new ArrayList();
        params.add(new Object[]{"MTTN", mttn});
        params.add(new Object[]{"userName", userName});
        params.add(new Object[]{"password", MD5Encoder.encode(password)});
        params.add(new Object[]{"branchId", branchid});
        params.add(new Object[]{"secretKey", MD5Encoder.encode(secretkey)});
        params.add(new Object[]{"cityCode", citycode});
        
        Map req = new HashMap();
        req.put("wsdl", "https://194.165.134.230:8181/TransCore/GenericIntegration?wsdl");
        req.put("targetURI", "http://delegate.business.transcore.moneytranist.net/");
        req.put("methodName", "searchTransaction");
        req.put("parameters", params);
        req.put("returnType", "object");
        
        Map res = (Map) invoke("http://192.168.3.211:8080/services/soapws/invoke", req);
        System.out.println(res);
    }
    
    public void xtestAUB() throws Exception
    {
        List params = new ArrayList();
        params.add(new Object[]{"username", "testuser"});
        params.add(new Object[]{"password", "testpwd"});
        params.add(new Object[]{"refno", "test1111"});
        
        Map req = new HashMap();
        req.put("wsdl", "https://www.aubgintonghatid.com/ws/pickup.cfc?wsdl");
        req.put("methodName", "ShowRemittanceDetail");
        req.put("parameters", params);
        req.put("returnType", "object");
        
        Map res = (Map) invoke("http://192.168.3.211:8080/services/soapws/invoke", req);
        System.out.println(res);
    }    
    
    public void xtestLocal() throws Exception
    {
        List params = new ArrayList();
        params.add(new Object[]{"action", "getServerDate"});
        params.add(new Object[]{"parameters", new Hashtable()});
        
        Map req = new HashMap();
        req.put("wsdl", "https://192.168.3.246:8443/mlkpsoap?wsdl");
        req.put("targetURI", "http://com.mlhuillier.soap");
        req.put("methodName", "invoke");
        req.put("parameters", params);
        
        Object res = invoke("http://192.168.3.246:8080/services/soapws/invoke", req);
        System.out.println(res);
    }    
    
    private Object invoke(String host, Map req) throws Exception 
    {
        URL url = null;
        HttpURLConnection conn = null;
        ObjectOutputStream out = null;
        ObjectInputStream in = null;
        
        try 
        {
            url = new URL(host);
            conn = (HttpURLConnection) url.openConnection();
            conn.setDoOutput(true); 
            conn.setUseCaches(false); 
            
            out = new ObjectOutputStream(conn.getOutputStream());
            out.writeObject(req);
            
            System.out.println("reading result...");
            in = new ObjectInputStream(conn.getInputStream());
            Object res = in.readObject();
            if (res instanceof Exception) {
                throw (Exception) res;
            }
            else if (res instanceof Map)
            {
                Map map = (Map) res;
                if (!"1".equals(map.get("respcode")))
                {
                    System.out.println(map.get("respdetail")+"");
                    throw new Exception(map.get("respdesc")+"");
                }
            }
            return res;
        } 
        catch (Exception ex) {
            throw ex;
        } 
        finally 
        {
            try { in.close(); } catch(Exception ex){;}
            try { out.close(); } catch(Exception ex){;}
            try { conn.disconnect(); } catch(Exception ex){;}
        }
    }    
}
