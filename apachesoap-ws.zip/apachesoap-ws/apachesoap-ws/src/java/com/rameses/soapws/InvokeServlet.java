package com.rameses.soapws;

import java.io.*;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.servlet.*;
import javax.servlet.http.*;
import org.apache.soap.rpc.SOAPClient;

public class InvokeServlet extends HttpServlet 
{
    private String KEYNAME = "services/soapws/invoke";
    
    // <editor-fold defaultstate="collapsed" desc=" HttpServlet methods. Click on the + sign on the left to edit the code. ">
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response); 
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response); 
    }
    
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response); 
    }
    
    public String getServletInfo() { return KEYNAME; }
    // </editor-fold>
    
    protected Object processRequest(HttpServletRequest req, Map mapreq) throws Exception
    {
        Object oWsdl = mapreq.get("wsdl"); 
        if (oWsdl == null) throw new Exception("'wsdl' parameter is required");
        
        Object oName = mapreq.get("methodName"); 
        if (oName == null) throw new Exception("'methodName' parameter is required");
            
        SOAPClient c = new SOAPClient(oWsdl.toString());
        
        Object oURI = mapreq.get("targetURI");         
        if (oURI != null) c.setTargetURI(oURI.toString());
        
        try {
            c.setTimeout(Integer.parseInt(mapreq.get("timeout").toString()));
        } catch(Exception ign) {;} 
        
        SOAPClient.Action a = c.createAction(oName.toString());
        
        List params = (List) mapreq.get("parameters");
        if (params != null)
        {
            Iterator itr = params.iterator();
            while (itr.hasNext())
            {
                Object[] arr = (Object[]) itr.next();
                String varName = arr[0].toString(); 
                Object varValue = (arr.length >= 2 ? arr[1] : null);
                Class varType = (arr.length >= 3 ? (Class) arr[2] : null);
                if (varType == null) 
                {
                    if (varValue == null)
                        varType = String.class;
                    else
                        varType = varValue.getClass(); 
                } 
                
                a.addParameter(varName, (varValue == null ? "" : varValue), varType); 
            }
        }
        
        System.out.println("[SoapWS] " + oWsdl);
        //System.out.println(c.getRequestInXml(a));
        
        String retType = mapreq.get("returnType")+""; 
        if ("null".equals(retType) || "".equals(retType)) 
            return c.getResultInXml(a); 
        else if ("object".equalsIgnoreCase(retType)) 
            return c.invoke(a); 
        else 
            return c.getResultInXml(a); 
    }
    
    protected void processRequest(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException 
    {
        Map result = new HashMap(); 
        String keyname = KEYNAME;
        ObjectInputStream in = null;
        ObjectOutputStream out = null;
        
        try 
        {
            in = new ObjectInputStream(req.getInputStream());
            Map mapreq = (Map) in.readObject();
            Object value = processRequest(req, mapreq);
            
            result.put("result", value);  
            result.put("respcode", "1");
            result.put("respdesc", "OK");
            
            out = new ObjectOutputStream(res.getOutputStream());
            out.writeObject(result);
        } 
        catch (Exception ex) 
        {
            System.out.println("["+keyname+"-ERROR] " + ex.getMessage());
            
            String errdetail = getStackTrace(ex);
            try { System.out.println(errdetail); } catch(Throwable t) {;}
            
            result.put("respcode", "0");
            result.put("respdesc", ex.getMessage()+"");
            result.put("respdetail", errdetail);
            
            out = new ObjectOutputStream(res.getOutputStream());
            out.writeObject(result);       
        } 
        catch (Error err) 
        {
            System.out.println("["+keyname+"-ERROR] " + err.getMessage());
            
            String errdetail = getStackTrace(err);
            try { System.out.println(errdetail); } catch(Throwable t) {;}
            
            result.put("respcode", "0");
            result.put("respdesc", err.getMessage()+"");
            result.put("respdetail", errdetail);
            
            out = new ObjectOutputStream(res.getOutputStream());
            out.writeObject(result);     
        }         
        finally 
        {
            try { out.close(); } catch (Exception ex) {;}
            try { in.close(); } catch (Exception ex ){;}
        }
    }
    
    private String getStackTrace(Exception ex)
    {
        ByteArrayOutputStream baos = null;
        try
        {
            baos = new ByteArrayOutputStream();
            ex.printStackTrace(new PrintStream(baos));
            return new String(baos.toByteArray());
        }
        catch(Exception e) {
            return "";
        }
        finally {
            try { baos.close(); }catch(Exception ign) {;} 
        }
    }
    
    private String getStackTrace(Error ex)
    {
        ByteArrayOutputStream baos = null;
        try
        {
            baos = new ByteArrayOutputStream();
            ex.printStackTrace(new PrintStream(baos));
            return new String(baos.toByteArray());
        }
        catch(Exception e) {
            return "";
        }
        finally {
            try { baos.close(); }catch(Exception ign) {;} 
        }
    }    
}
