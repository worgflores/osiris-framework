package com.rameses.soapws;

import java.io.*;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.servlet.*;
import javax.servlet.http.*;

public class InvokeServlet2 extends HttpServlet 
{
    private String KEYNAME = "services/soapws/invoke2";
    
    // <editor-fold defaultstate="collapsed" desc=" HttpServlet methods. Click on the + sign on the left to edit the code. ">
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response); 
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response); 
    }
    
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response); 
    }
    
    public String getServletInfo() { return KEYNAME; }
    // </editor-fold>
    
    protected Object processRequest(HttpServletRequest req, Map mapreq) throws Exception
    {
        Object oWsdl = mapreq.get("wsdl"); 
        if (oWsdl == null) throw new Exception("'wsdl' parameter is required");
        
        Object oName = mapreq.get("methodName"); 
        if (oName == null) throw new Exception("'methodName' parameter is required");

        XMLSOAPClient c = new XMLSOAPClient(oWsdl.toString());
        
        Object oURI = mapreq.get("targetURI");
        if (oURI != null) c.setTargetURI(oURI.toString());
        
        Object oNS = mapreq.get("namespace"); 
        if (oNS != null) c.setNamespace(oNS.toString());
        
        try {
            c.setTimeout(Integer.parseInt(mapreq.get("timeout").toString()));
        } catch(Exception ign) {;} 
        
        try { 
            c.setDebug(Boolean.parseBoolean(mapreq.get("debug").toString())); 
        } catch(Exception ign) {;} 
        
        if ("true".equals(mapreq.get("showParameterNamespace")+"")) 
            c.setShowParameterNamespace(true); 
        else if ("false".equals(mapreq.get("showParameterNamespace")+"")) 
            c.setShowParameterNamespace(false); 

        if ("true".equals(mapreq.get("showParameterType")+"")) 
            c.setShowParameterType(true); 
        else if ("false".equals(mapreq.get("showParameterType")+"")) 
            c.setShowParameterType(false); 
        
        XMLSOAPClient.Action a = c.createAction(oName.toString());        
        List params = (List) mapreq.get("parameters");
        if (params != null) 
        {
            Iterator itr = params.iterator();
            while (itr.hasNext())
            {
                Object[] arr = (Object[]) itr.next();
                String varName = arr[0].toString(); 
                Object varValue = (arr.length >= 2 ? arr[1] : null);
                Class varType = (arr.length >= 3 ? (Class) arr[2] : null);
                if (varType == null) 
                {
                    if (varValue == null)
                        varType = String.class;
                    else
                        varType = varValue.getClass(); 
                } 
                
                a.addParameter(varName, (varValue == null ? "" : varValue), varType); 
            }
        }
        
        System.out.println("[SoapWS/Invoke2] " + oWsdl);
        return c.invoke(a); 
    }
    
    protected void processRequest(HttpServletRequest req, HttpServletResponse res)
    throws ServletException, IOException 
    {
        Map result = new HashMap(); 
        String keyname = KEYNAME;
        ObjectInputStream in = null;
        ObjectOutputStream out = null;
        
        try 
        {
            in = new ObjectInputStream(req.getInputStream());
            Map mapreq = (Map) in.readObject();
            Object value = processRequest(req, mapreq);
            
            result.put("result", value);  
            result.put("respcode", "1");
            result.put("respdesc", "OK");
            
            out = new ObjectOutputStream(res.getOutputStream());
            out.writeObject(result);
        } 
        catch (Exception ex) 
        {
            System.out.println("["+keyname+"-ERROR] " + ex.getMessage());
            
            String errdetail = getStackTrace(ex);
            try { System.out.println(errdetail); } catch(Throwable t) {;}
            
            result.put("respcode", "0");
            result.put("respdesc", ex.getMessage()+"");
            result.put("respdetail", errdetail);
            
            out = new ObjectOutputStream(res.getOutputStream());
            out.writeObject(result);       
        } 
        catch (Error err) 
        {
            System.out.println("["+keyname+"-ERROR] " + err.getMessage());
            
            String errdetail = getStackTrace(err);
            try { System.out.println(errdetail); } catch(Throwable t) {;}
            
            result.put("respcode", "0");
            result.put("respdesc", err.getMessage()+"");
            result.put("respdetail", errdetail);
            
            out = new ObjectOutputStream(res.getOutputStream());
            out.writeObject(result);     
        }         
        finally 
        {
            try { out.close(); } catch (Exception ex) {;}
            try { in.close(); } catch (Exception ex ){;}
        }
    }
    
    private String getStackTrace(Exception ex)
    {
        ByteArrayOutputStream baos = null;
        try
        {
            baos = new ByteArrayOutputStream();
            ex.printStackTrace(new PrintStream(baos));
            return new String(baos.toByteArray());
        }
        catch(Exception e) {
            return "";
        }
        finally {
            try { baos.close(); }catch(Exception ign) {;} 
        }
    }
    
    private String getStackTrace(Error ex)
    {
        ByteArrayOutputStream baos = null;
        try
        {
            baos = new ByteArrayOutputStream();
            ex.printStackTrace(new PrintStream(baos));
            return new String(baos.toByteArray());
        }
        catch(Exception e) {
            return "";
        }
        finally {
            try { baos.close(); }catch(Exception ign) {;} 
        }
    }    
}
