package org.apache.soap;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.apache.soap.rpc.SOAPContext;
import org.apache.soap.util.xml.XMLJavaMappingRegistry;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class EnvelopeWrapper extends Envelope 
{
    private SAXParserFactory factory;
    private Envelope env;
    private String action;
    private boolean showParameterType;
    private boolean showParameterNamespace;
    
    public EnvelopeWrapper(Envelope env, String action, boolean showParameterType, boolean showParameterNamespace) 
    {
        this.env = env;
        this.action = action;
        this.showParameterType = showParameterType;
        this.showParameterNamespace = showParameterNamespace;
        
        factory = SAXParserFactory.newInstance();
        factory.setNamespaceAware(true);
        factory.setValidating(false);
    }

    public void marshall(Writer writer, XMLJavaMappingRegistry xMLJavaMappingRegistry, SOAPContext sOAPContext) throws IllegalArgumentException, IOException 
    {
        StringWriter swriter = new StringWriter();
        env.marshall(swriter, xMLJavaMappingRegistry, sOAPContext);            
        String s = swriter.toString();

        try 
        {
            SAXParser sp = factory.newSAXParser();   
            XMLHandler handler = new XMLHandler(action);
            sp.parse(new ByteArrayInputStream(s.getBytes()), handler);
            writer.append(handler.getContent());
        } 
        catch (IllegalArgumentException iae) { throw iae; }
        catch (IOException ioe) { throw ioe; }
        catch (Exception ex) { 
            throw new IOException(ex.getMessage());
        }
    }
    
    private class XMLHandler extends DefaultHandler
    {
        private StringBuffer buffer = new StringBuffer();
        private StringBuffer prefixNamespace = new StringBuffer();
        private String SYSPATH = "";
        private String path = "";
        
        XMLHandler(String action) 
        {
            SYSPATH = "Envelope/Body/" + action;
        }
        
        public void startDocument() throws SAXException 
        {
            buffer = new StringBuffer();
            prefixNamespace = new StringBuffer();
            path = "";
        }
        
        public String getContent() {
            return buffer.toString(); 
        }
        
        public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException 
        {
            boolean child = false;
            String elemName = qName;
            if (path.equals(SYSPATH))
            {
                child = true;
                if (showParameterNamespace && elemName.indexOf(':') < 0) elemName = "ns1:" + qName;   
            }
            
            if (path.length() > 0) path += "/";
            
            path += localName;
            
            buffer.append("<"+elemName);
            if (prefixNamespace.length() > 0) 
            {
                buffer.append(prefixNamespace);
                prefixNamespace.delete(0, prefixNamespace.length());
            }
                
            for(int i=0, len=attributes.getLength(); i < len; i++)
            {
                String key = attributes.getQName(i); 
                if (child && key.endsWith(":type") && !showParameterType) continue; 
                
                String value = attributes.getValue(i);
                if (key.indexOf(':') < 0) key = "ns1:"+key;
                
                buffer.append(" " + key + "=\"" + value + "\"");
            }            
            
            buffer.append(">");
        }
        
        public void endElement(String uri, String localName, String qName) throws SAXException 
        {
            int idx = path.lastIndexOf('/');
            if (idx > 0)
                path = path.substring(0, idx);
            else
                path = "";
            
            String elemName = qName;
            if (path.equals(SYSPATH))
            {
                if (showParameterNamespace && elemName.indexOf(':') < 0) 
                    elemName = "ns1:" + qName;    
            }
            
            buffer.append("</" + elemName + ">\n");
        }
        
        public void characters(char[] ch, int start, int length) throws SAXException 
        {
            String s = String.valueOf(ch, start, length);
            if (s.trim().length() > 0) buffer.append(s);
        }

        public void startPrefixMapping(String prefix, String uri) throws SAXException {
            prefixNamespace.append(" xmlns:" + prefix + "=\""+ uri +"\"");
        }
        
    }
    
}
