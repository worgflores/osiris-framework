package org.apache.soap;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.apache.soap.rpc.Call;
import org.apache.soap.rpc.SOAPContext;
import org.apache.soap.util.xml.XMLJavaMappingRegistry;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class EnvelopeImpl extends Envelope 
{
    private SAXParserFactory factory;
    private Envelope env;
    private Call call;
    private String headerXml;
    private boolean showParameterType;
    private boolean showParameterNamespace;
    private String actionAlias;
    
    public EnvelopeImpl(Envelope env, Call call, String headerXml, boolean showParameterType, boolean showParameterNamespace, String actionAlias) 
    {
        this.env = env;
        this.call = call;
        this.headerXml = headerXml;
        this.showParameterType = showParameterType;
        this.showParameterNamespace = showParameterNamespace;
        this.actionAlias = actionAlias;
        
        factory = SAXParserFactory.newInstance();
        factory.setNamespaceAware(true);
        factory.setValidating(false);
    }
    
    public void marshall(Writer writer, XMLJavaMappingRegistry xMLJavaMappingRegistry, SOAPContext sOAPContext) throws IllegalArgumentException, IOException 
    {
        StringWriter swriter = new StringWriter();
        env.marshall(swriter, xMLJavaMappingRegistry, sOAPContext);            
        String s = swriter.toString();

        try 
        {
            SAXParser sp = factory.newSAXParser();   
            XMLHandler handler = new XMLHandler(call.getMethodName());
            sp.parse(new ByteArrayInputStream(s.getBytes()), handler);
            
            String content = handler.getContent(); 
//            System.out.println("************************");
//            System.out.println(content);
//            System.out.println("************************");
            writer.append(content);
        } 
        catch (IllegalArgumentException iae) { throw iae; }
        catch (IOException ioe) { throw ioe; }
        catch (Exception ex) { 
            throw new IOException(ex.getMessage());
        }
    }
    
    private class XMLHandler extends DefaultHandler
    {
        private StringBuffer buffer = new StringBuffer();
        private StringBuffer prefixNamespace = new StringBuffer();
        private String SYSPATH = "";
        private String path = "";
        
        XMLHandler(String action) 
        {
            SYSPATH = "Envelope/Body/" + action;
        }
        
        public void startDocument() throws SAXException 
        {
            buffer = new StringBuffer();
            prefixNamespace = new StringBuffer();
            path = "";
        }
        
        public String getContent() {
            return buffer.toString(); 
        }
        
        public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException 
        {
            boolean child = false;
            String elemName = qName;
            if (path.equals(SYSPATH))
            {
                child = true;
                if (showParameterNamespace && elemName.indexOf(':') < 0) elemName = "ns1:" + qName;   
            }
            
            if (path.length() > 0) path += "/";
            
            path += localName;
            
            if (child) buffer.append("\n"); 
            else if (path.equals(SYSPATH)) buffer.append("\n");
            
            buffer.append("<"+elemName);
            if (prefixNamespace.length() > 0) 
            {
                buffer.append(prefixNamespace);
                prefixNamespace.delete(0, prefixNamespace.length());
                
                String targetURI = call.getTargetObjectURI();
                if (targetURI != null && path.equals("Envelope")) 
                    buffer.append(" xmlns:ns1=\"" + targetURI + "\""); 
            }
                
            for(int i=0, len=attributes.getLength(); i < len; i++)
            {
                String key = attributes.getQName(i); 
                if (child && key.endsWith(":type") && !showParameterType) continue; 
                
                String value = attributes.getValue(i);
                if (key.indexOf(':') < 0) key = "ns1:"+key;
                
                buffer.append(" " + key + "=\"" + value + "\"");
            }            
            
            buffer.append(">");
            
            if (path.equals(SYSPATH) && actionAlias != null && actionAlias.trim().length() > 0)
            {
                if (showParameterNamespace) 
                    buffer.append("<ns1:"+actionAlias+">"); 
                else
                    buffer.append("<"+actionAlias+">"); 
            }
            
            if (path.equals("Envelope"))
            {
                buffer.append("\n<SOAP-ENV:Header>");
                if (headerXml != null)
                {
                    buffer.append("\n");
                    buffer.append(headerXml);
                    buffer.append("\n");
                }
                buffer.append("</SOAP-ENV:Header>\n");
            }
        }
        
        public void endElement(String uri, String localName, String qName) throws SAXException 
        {
            //System.out.println("e1: " + path);
            
            if (path.equals(SYSPATH)) 
            {
                buffer.append("\n");
                
                if (actionAlias != null && actionAlias.trim().length() > 0)
                {
                    if (showParameterNamespace)
                        buffer.append("</ns1:"+actionAlias+">");
                    else
                        buffer.append("</"+actionAlias+">");
                }
            } 
            else if (path.equals("Envelope") || path.equals("Envelope/Body")) buffer.append("\n"); 
                
            int idx = path.lastIndexOf('/');
            if (idx > 0)
                path = path.substring(0, idx);
            else
                path = "";
            
            //System.out.println("      e2: " + path);
            
            String elemName = qName;
            if (path.equals(SYSPATH))
            {
                if (showParameterNamespace && elemName.indexOf(':') < 0) 
                    elemName = "ns1:" + qName;                    
            }
            
            buffer.append("</" + elemName + ">\n");
        }
        
        public void characters(char[] ch, int start, int length) throws SAXException 
        {
            String s = String.valueOf(ch, start, length);
            if (s.trim().length() > 0) buffer.append(s);
        }

        public void startPrefixMapping(String prefix, String uri) throws SAXException {
            prefixNamespace.append(" xmlns:" + prefix + "=\""+ uri +"\"");
        }
        
    }
    
}
