package test;

import groovy.util.XmlSlurper;
import groovy.util.slurpersupport.GPathResult;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import junit.framework.*;
import rameses.osiris.client.app.App;
import rameses.osiris.common.service.Request;

public class XigniteTestUnit extends TestCase 
{
    private String HOST = "http://192.168.3.247:8080/mlhuillier/action";
    
    private String wsdl = "http://www.xignite.com/xCurrencies.asmx?wsdl";
    private String targetURI = "http://www.xignite.com/services/";
    private int timeout = 30000;
    private String username = "tonyray007@gmail.com";
    private String password = "mlinc1234";
    
    public XigniteTestUnit(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
    }

    protected void tearDown() throws Exception {
    }

    public void xtest000() throws Exception
    {
        XmlSlurper x = new XmlSlurper(); 
        GPathResult ox = x.parse(getClass().getResourceAsStream("GetLatestCrossRateResult.xml")); 
        System.out.println(ox.getProperty("Rate"));
        
//        GroovyShell sh = new GroovyShell();  
//        sh.setVariable("xml", ox); 
//        sh.evaluate(getClass().getResourceAsStream("GetLatestCrossRateResult.groovy")); 
    }    
    
    public void test001() throws Exception
    {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        DecimalFormat dec = new DecimalFormat("0.00000");
        
        HttpServiceClient c = new HttpServiceClient();
        c.setTimeout(timeout);
     
        String[] currencylist = new String[] { "EUR", "GBP", "JPY", "KRW", "SGD", "USD" };
        for (int i=0; i<currencylist.length; i++)
        {
            List list = new ArrayList();
            list.add(new Object[]{"From", currencylist[i]});
            list.add(new Object[]{"To", "PHP"});

            Map map = new HashMap(); 
            map.put("debug", "true"); 
            map.put("timeout", timeout+""); 
            map.put("wsdl", wsdl); 
            map.put("targetURI", targetURI); 
            map.put("header", createHeader()); 
            map.put("methodName", "GetRealTimeCrossRate");
            map.put("showParameterType", "false");
            map.put("showParameterNamespace", "true");
            map.put("parameters", list);

            Map res = (Map) c.invoke("http://192.168.3.211:8080/services/soapws/xmlsoap/invoker", map);
            System.out.println(res.get("result"));
            
            XmlSlurper x = new XmlSlurper(); 
            GPathResult ox = x.parseText(res.get("result").toString()); 
            Object rate = dec.format(dec.parse(ox.getProperty("Rate").toString())); 
            
            System.out.println(currencylist[i]  + "=" + rate); 
            String sdate = sdf.format(new Date()); 
//            execUpdate(" insert ignore into mlkp.tblglobalratehistory (objid,currency,rate,lastupdated,modifiedby) " + 
//                       " select objid,currency,rate,lastupdated,modifiedby from mlkp.tblglobalrate where currency='"+currencylist[i]+"' ");
//            
//            execUpdate("update mlkp.tblglobalrate set rate="+rate+", lastupdated='"+sdate+"' where currency='"+currencylist[i]+"' "); 
        }
    }
    
    private String createHeader()
    {
        StringBuffer sb = new StringBuffer(); 
        sb.append("<ns1:Header>");
        sb.append("   <ns1:Username>" + username + "</ns1:Username>");
        sb.append("   <ns1:Password>" + password + "</ns1:Password>");
        sb.append("</ns1:Header>");
        return sb.toString();
    }
    
    private void execUpdate(String stmt) throws Exception 
    { 
        System.getProperties().put("app.host", HOST);
        
        Request req = new Request();
        req.addParameter("DSNAME", "java:mldb");
        req.addParameter("QUERY", "0");
        req.addParameter("SQLSTMT", stmt);
        
        App.getServiceManager().invoke("system.exec", req);
    }

}
