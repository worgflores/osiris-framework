package test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import junit.framework.*;

public class AUBTest extends TestCase 
{
    private String HOST = "http://192.168.3.247:8080/mlhuillier/action";
    
    private String username = "mlf001";
    private String password = "mlf001101";
    private String wsdl = "https://www.AUBGintongHatid.com/ws/pickup.cfc?wsdl";
    private String targetURI = "http://ws";
    private Object httpClient;
    
    public AUBTest(String testName) { 
        super(testName); 
    } 

    protected void setUp() throws Exception {} 

    protected void tearDown() throws Exception { 
    } 

    public void testShowRemittanceDetail() throws Exception 
    {
        HttpServiceClient c = new HttpServiceClient(); 
        c.setTimeout(20000); 

        String refno = "alm00010032412046167"; 
        List list = new ArrayList();              
        list.add(new Object[]{"username", username}); 
        list.add(new Object[]{"password", password}); 
        list.add(new Object[]{"refno", refno});
        
        Map map = new HashMap(); 
        map.put("wsdl", wsdl); 
        map.put("targetURI", targetURI); 
        map.put("methodName", "ShowRemittanceDetail"); 
        map.put("showParameterNamespace", "false"); 
        map.put("showParameterType", "false"); 
        map.put("parameters", list); 
        

        Map res = (Map) c.invoke("http://192.168.3.211:8080/services/soapws/xmlsoap/invoker", map);
        System.out.println(res.get("result"));
    }
}
