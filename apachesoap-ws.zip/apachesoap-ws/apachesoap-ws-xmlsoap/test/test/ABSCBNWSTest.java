package test;

import com.rameses.soapws.XMLSOAPClient;
import junit.framework.*;

public class ABSCBNWSTest extends TestCase 
{
    
    public ABSCBNWSTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
    }

    protected void tearDown() throws Exception {
    }
    
    public void test000() throws Exception
    {
        XMLSOAPClient x = new XMLSOAPClient("http://63.68.150.6/MLWebService/MLWebService.asmx?wsdl");
        x.setTargetURI("http://10.0.32.6/WS/MLWebservice.asmx");
        x.setDebug(true);
        x.setTimeout(20000);
        x.setShowParameterType(false);
        x.setShowParameterNamespace(true);
        
        XMLSOAPClient.Action a = x.createAction("CompleteRemittance");
        a.addParameter("username", "ml_user");
        a.addParameter("password", "mlpassword");
        a.addParameter("refno", "FT10152951591057");
        a.addParameter("traceno", "MLMAIN1C11QAYUE");
        a.addParameter("sessionId", "MLMAIN1C11QAYUETEST");
        
        Object res = x.invoke(a);
        System.out.println(res);
    }
}
