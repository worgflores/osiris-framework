package test;

import java.util.Hashtable;
import java.util.Map;
import junit.framework.*;
import org.apache.soap.rpc.SoapClient;
import org.apache.soap.rpc.SoapClient.Action;

public class NewEmptyJUnitTest extends TestCase 
{
    
    public NewEmptyJUnitTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
    }

    protected void tearDown() throws Exception {
    }
    
    public void test000() throws Exception
    {
        Map params = new Hashtable();
        params.put("USERID", "KPUSER");
        params.put("PASSWORD", "1234");
        params.put("MACHINEID", "00-1B-FC-B8-A8-2E");
        
        SoapClient c = new SoapClient("https://192.168.3.246:8443/mlkpsoap?wsdl");
        Action a = c.createAction("invoke");
        a.addParameter("action", "ws.login");
        a.addParameter("parameters", params);
        Map res = (Map) c.invoke(a);
        System.out.println(res);
    }
}
