package org.apache.soap.rpc;

import java.net.URL;
import java.util.Vector;
import org.apache.soap.Constants;
import org.apache.soap.Fault;

public class SoapClient 
{
    public final static String TRUST_STORE = "javax.net.ssl.trustStore";
    public final static String TRUST_STORE_PWD = "javax.net.sst.trustStorePassword";
    
    private String serverHost;
    private URL serverURL; 
    
    public SoapClient(String url) 
    {
        try 
        {
            serverHost = url; 
            serverURL = new URL(url); 
            //loadTrustStoreSettings();
        }
        catch(Exception ex) {
            throw new IllegalStateException(ex.getMessage(), ex);
        }        
    }
    
    private void loadTrustStoreSettings()
    {
        try
        {
            if (!serverHost.startsWith("https:")) return;
            
            
        }
        catch(Exception ign) {
            ign.printStackTrace();
        }
    }
    
    public Action createAction(String name) throws Exception {
        return new Action(name);
    }
    
    public Object invoke(Action action) throws Exception
    {
        Response res = invoke(action.getName(), action.getParameters());
        if (res.getReturnValue() == null) return null;
        
        return res.getReturnValue().getValue();
    }
    
    private Response invoke(String method, Vector params) throws Exception 
    {
        Response res = invokeImpl(method, params);
        if (res.generatedFault()) 
        {
            Fault f = res.getFault();
            throw new Exception(f.getFaultString());
        }
        return res;
    }
    
    private Response invokeImpl(String method, Vector params) throws Exception
    {
        if (System.getProperties().containsKey("https.proxyHost"))
        {
            String shost = System.getProperty("https.proxyHost");
            if (shost == null || shost.trim().length() == 0)
                System.getProperties().remove("https.proxyHost");
        }
        
        // create soap RPC Call object
        String urn = null;
        Call call = new Call();

        //set encoding style to standard SOAP encoding
        call.setEncodingStyleURI(Constants.NS_URI_SOAP_ENC);
        call.setTargetObjectURI(serverHost);

        call.setMethodName(method);
        call.setParams(params);
        return call.invoke(serverURL, "");
    }        
    
    public static class Action
    {
        private String name;
        private Vector parameters;
        
        private Action(String name) 
        {
            this.name = name;
            this.parameters = new Vector();
        }
        
        public void addParameter(String name, Object value) 
        {
            Class type = (value == null ? String.class : value.getClass());
            parameters.addElement(new Parameter(name, type, value, null));
        }
        
        public void addParameter(String name, Object value, Class type) {
            parameters.addElement(new Parameter(name, type, value, null));            
        }
        
        String getName() { return name; }
        Vector getParameters() { return parameters; }
    }
    
}
