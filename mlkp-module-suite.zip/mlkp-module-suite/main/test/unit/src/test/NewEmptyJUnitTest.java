/*
 * NewEmptyJUnitTest.java
 * JUnit based test
 *
 * Created on April 16, 2008, 10:07 AM
 */

package test;

import junit.framework.*;

/**
 *
 * @author user
 */
public class NewEmptyJUnitTest extends TestCase {
    
    public NewEmptyJUnitTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
    }

    protected void tearDown() throws Exception {
    }
    
    // TODO add test methods here. The name must begin with 'test'. For example:
    // public void testHello() {}

}
