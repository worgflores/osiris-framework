package com.mlhuillier.fu;

public class FillGeneralInfoPage extends com.rameses.osiris.client.Page
{
    
    /** Creates new form CheckRemotePage */
    public FillGeneralInfoPage()
{
        initComponents();
    }
    
    // <editor-fold defaultstate="collapsed" desc=" Generated Code ">//GEN-BEGIN:initComponents
    private void initComponents() {
        xLabel1 = new com.rameses.osiris.client.component.XLabel();
        xPanel1 = new com.rameses.osiris.client.component.XPanel();
        xPanel3 = new com.rameses.osiris.client.component.XPanel();
        xLabel2 = new com.rameses.osiris.client.component.XLabel();
        xLabel3 = new com.rameses.osiris.client.component.XLabel();
        xLabel4 = new com.rameses.osiris.client.component.XLabel();
        xTextField1 = new com.rameses.osiris.client.component.XTextField();
        xTextField2 = new com.rameses.osiris.client.component.XTextField();
        xTextField3 = new com.rameses.osiris.client.component.XTextField();
        xPanel4 = new com.rameses.osiris.client.component.XPanel();
        xLabel5 = new com.rameses.osiris.client.component.XLabel();
        xLabel6 = new com.rameses.osiris.client.component.XLabel();
        xLabel011 = new com.rameses.osiris.client.component.template.XLabel01();
        xButton4 = new com.rameses.osiris.client.component.XButton();
        xTextArea1 = new com.rameses.osiris.client.component.XTextArea();
        xPanel5 = new com.rameses.osiris.client.component.XPanel();
        xLabel012 = new com.rameses.osiris.client.component.template.XLabel01();
        xPanel2 = new com.rameses.osiris.client.component.XPanel();
        xGlue1 = new com.rameses.osiris.client.component.spacer.XGlue();
        xButton3 = new com.rameses.osiris.client.component.XButton();
        xStrut2 = new com.rameses.osiris.client.component.spacer.XStrut();
        xButton2 = new com.rameses.osiris.client.component.XButton();
        xStrut1 = new com.rameses.osiris.client.component.spacer.XStrut();
        xButton1 = new com.rameses.osiris.client.component.XButton();

        setLayout(new java.awt.BorderLayout());

        xLabel1.setBackground(new java.awt.Color(0, 0, 153));
        xLabel1.setForeground(new java.awt.Color(255, 255, 255));
        xLabel1.setOpaque(true);
        xLabel1.setPadding(new java.awt.Insets(10, 10, 10, 10));
        xLabel1.setText("<html> <font size=\"5\">Fill General Information</font> </html>");
        add(xLabel1, java.awt.BorderLayout.NORTH);

        xPanel1.setLayout(null);

        xPanel3.setLayout(null);

        xPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(" Customer Information "));
        xLabel2.setText("<html>Name: <font color=\"red\"><b>*</b></font></html>");
        xPanel3.add(xLabel2);
        xLabel2.setBounds(20, 30, 80, 20);

        xLabel3.setText("<html>Address: <font color=\"red\"><b>*</b></font></html>");
        xPanel3.add(xLabel3);
        xLabel3.setBounds(20, 50, 80, 20);

        xLabel4.setText("Contact No:");
        xPanel3.add(xLabel4);
        xLabel4.setBounds(20, 70, 80, 20);

        xTextField1.setModelName("fileupload");
        xTextField1.setName("sendercontactno");
        xPanel3.add(xTextField1);
        xTextField1.setBounds(110, 70, 340, 19);

        xTextField2.setModelName("fileupload");
        xTextField2.setName("senderaddress");
        xPanel3.add(xTextField2);
        xTextField2.setBounds(110, 50, 340, 19);

        xTextField3.setDefaultFocus(true);
        xTextField3.setModelName("fileupload");
        xTextField3.setName("sendername");
        xPanel3.add(xTextField3);
        xTextField3.setBounds(110, 30, 340, 19);

        xPanel1.add(xPanel3);
        xPanel3.setBounds(10, 10, 470, 110);

        xPanel4.setLayout(null);

        xPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder(" File Detail "));
        xLabel5.setText("<html>File to upload: <font color=\"red\"><b>*</b></html>");
        xPanel4.add(xLabel5);
        xLabel5.setBounds(20, 30, 90, 20);

        xLabel6.setText("File Content:");
        xPanel4.add(xLabel6);
        xLabel6.setBounds(20, 60, 100, 14);

        xLabel011.setName("filename");
        xPanel4.add(xLabel011);
        xLabel011.setBounds(110, 30, 500, 20);

        xButton4.setOnclick("browseFile");
        xButton4.setText("Browse");
        xPanel4.add(xButton4);
        xButton4.setBounds(610, 30, 67, 23);

        xTextArea1.setEditable(false);
        xTextArea1.setEnabled(false);
        xTextArea1.setModelName("fileupload");
        xTextArea1.setName("filecontent");
        xPanel4.add(xTextArea1);
        xTextArea1.setBounds(20, 80, 660, 250);

        xPanel1.add(xPanel4);
        xPanel4.setBounds(10, 120, 700, 350);

        xPanel5.setLayout(null);

        xPanel5.setBorder(javax.swing.BorderFactory.createTitledBorder(" Batch No. "));
        xLabel012.setModelName("fileupload");
        xLabel012.setName("controlno");
        xPanel5.add(xLabel012);
        xLabel012.setBounds(10, 30, 210, 40);

        xPanel1.add(xPanel5);
        xPanel5.setBounds(480, 10, 230, 110);

        add(xPanel1, java.awt.BorderLayout.CENTER);

        xPanel2.setLayout(new javax.swing.BoxLayout(xPanel2, javax.swing.BoxLayout.X_AXIS));

        xPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        xPanel2.setOpaque(true);
        xPanel2.setPadding(new java.awt.Insets(5, 5, 5, 5));
        xPanel2.add(xGlue1);

        xButton3.setIconResource("shared/images/16/back.png");
        xButton3.setOnclick("gotoPage('default')");
        xButton3.setText("&lt; Back");
        xPanel2.add(xButton3);

        xStrut2.setLength(5);
        xPanel2.add(xStrut2);

        xButton2.setIconResource("shared/images/16/next.png");
        xButton2.setAlt('n');
        xButton2.setDefaultFocusInWindow(true);
        xButton2.setOnclick("doValidateFileContent");
        xButton2.setText("Next &gt;");
        xPanel2.add(xButton2);

        xPanel2.add(xStrut1);

        xButton1.setIconResource("shared/images/16/close.png");
        xButton1.setAlt('c');
        xButton1.setOnclick("doClose");
        xButton1.setText("Cancel");
        xPanel2.add(xButton1);

        add(xPanel2, java.awt.BorderLayout.SOUTH);

    }// </editor-fold>//GEN-END:initComponents
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private com.rameses.osiris.client.component.XButton xButton1;
    private com.rameses.osiris.client.component.XButton xButton2;
    private com.rameses.osiris.client.component.XButton xButton3;
    private com.rameses.osiris.client.component.XButton xButton4;
    private com.rameses.osiris.client.component.spacer.XGlue xGlue1;
    private com.rameses.osiris.client.component.template.XLabel01 xLabel011;
    private com.rameses.osiris.client.component.template.XLabel01 xLabel012;
    private com.rameses.osiris.client.component.XLabel xLabel1;
    private com.rameses.osiris.client.component.XLabel xLabel2;
    private com.rameses.osiris.client.component.XLabel xLabel3;
    private com.rameses.osiris.client.component.XLabel xLabel4;
    private com.rameses.osiris.client.component.XLabel xLabel5;
    private com.rameses.osiris.client.component.XLabel xLabel6;
    private com.rameses.osiris.client.component.XPanel xPanel1;
    private com.rameses.osiris.client.component.XPanel xPanel2;
    private com.rameses.osiris.client.component.XPanel xPanel3;
    private com.rameses.osiris.client.component.XPanel xPanel4;
    private com.rameses.osiris.client.component.XPanel xPanel5;
    private com.rameses.osiris.client.component.spacer.XStrut xStrut1;
    private com.rameses.osiris.client.component.spacer.XStrut xStrut2;
    private com.rameses.osiris.client.component.XTextArea xTextArea1;
    private com.rameses.osiris.client.component.XTextField xTextField1;
    private com.rameses.osiris.client.component.XTextField xTextField2;
    private com.rameses.osiris.client.component.XTextField xTextField3;
    // End of variables declaration//GEN-END:variables
    
}
