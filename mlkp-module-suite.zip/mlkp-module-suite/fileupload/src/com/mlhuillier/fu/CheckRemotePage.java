package com.mlhuillier.fu;

public class CheckRemotePage extends com.rameses.osiris.client.Page
{
    
    /** Creates new form CheckRemotePage */
    public CheckRemotePage()
{
        initComponents();
    }
    
    // <editor-fold defaultstate="collapsed" desc=" Generated Code ">//GEN-BEGIN:initComponents
    private void initComponents() {
        xLabel1 = new com.rameses.osiris.client.component.XLabel();
        xPanel1 = new com.rameses.osiris.client.component.XPanel();
        xLabel2 = new com.rameses.osiris.client.component.XLabel();
        xOption1 = new com.rameses.osiris.client.component.XOption();
        xOption2 = new com.rameses.osiris.client.component.XOption();
        xPanel2 = new com.rameses.osiris.client.component.XPanel();
        xGlue1 = new com.rameses.osiris.client.component.spacer.XGlue();
        xButton2 = new com.rameses.osiris.client.component.XButton();
        xStrut1 = new com.rameses.osiris.client.component.spacer.XStrut();
        xButton1 = new com.rameses.osiris.client.component.XButton();

        setLayout(new java.awt.BorderLayout());

        xLabel1.setBackground(new java.awt.Color(0, 0, 153));
        xLabel1.setForeground(new java.awt.Color(255, 255, 255));
        xLabel1.setOpaque(true);
        xLabel1.setPadding(new java.awt.Insets(10, 10, 10, 10));
        xLabel1.setText("<html>\n<font size=\"5\">Check Remote Transaction</font>\n</html>");
        add(xLabel1, java.awt.BorderLayout.NORTH);

        xPanel1.setLayout(null);

        xLabel2.setText("<html>\n<font size=\"4\">Is this a remote transaction?</font>\n</html>");
        xPanel1.add(xLabel2);
        xLabel2.setBounds(30, 30, 220, 20);

        xOption1.setSelected(true);
        xOption1.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        xOption1.setDefaultFocus(true);
        xOption1.setModelName("temp");
        xOption1.setName("isremote");
        xOption1.setText("Yes");
        xOption1.setValue("1");
        xPanel1.add(xOption1);
        xOption1.setBounds(60, 70, 90, 20);

        xOption2.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        xOption2.setModelName("temp");
        xOption2.setName("isremote");
        xOption2.setText("No");
        xOption2.setValue("0");
        xPanel1.add(xOption2);
        xOption2.setBounds(60, 95, 90, 20);

        add(xPanel1, java.awt.BorderLayout.CENTER);

        xPanel2.setLayout(new javax.swing.BoxLayout(xPanel2, javax.swing.BoxLayout.X_AXIS));

        xPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        xPanel2.setOpaque(true);
        xPanel2.setPadding(new java.awt.Insets(5, 5, 5, 5));
        xPanel2.add(xGlue1);

        xButton2.setIconResource("shared/images/16/next.png");
        xButton2.setAlt('n');
        xButton2.setDefaultFocusInWindow(true);
        xButton2.setOnclick("doCheckRemote");
        xButton2.setText("Next &gt;");
        xPanel2.add(xButton2);

        xPanel2.add(xStrut1);

        xButton1.setIconResource("shared/images/16/close.png");
        xButton1.setAlt('c');
        xButton1.setOnclick("doClose");
        xButton1.setText("Cancel");
        xPanel2.add(xButton1);

        add(xPanel2, java.awt.BorderLayout.SOUTH);

    }// </editor-fold>//GEN-END:initComponents
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private com.rameses.osiris.client.component.XButton xButton1;
    private com.rameses.osiris.client.component.XButton xButton2;
    private com.rameses.osiris.client.component.spacer.XGlue xGlue1;
    private com.rameses.osiris.client.component.XLabel xLabel1;
    private com.rameses.osiris.client.component.XLabel xLabel2;
    private com.rameses.osiris.client.component.XOption xOption1;
    private com.rameses.osiris.client.component.XOption xOption2;
    private com.rameses.osiris.client.component.XPanel xPanel1;
    private com.rameses.osiris.client.component.XPanel xPanel2;
    private com.rameses.osiris.client.component.spacer.XStrut xStrut1;
    // End of variables declaration//GEN-END:variables
    
}
