package com.mlhuillier.fu;

public class FillRemoteInfoPage extends com.rameses.osiris.client.Page
{
    
    /** Creates new form CheckRemotePage */
    public FillRemoteInfoPage()
{
        initComponents();
    }
    
    // <editor-fold defaultstate="collapsed" desc=" Generated Code ">//GEN-BEGIN:initComponents
    private void initComponents() {
        xLabel1 = new com.rameses.osiris.client.component.XLabel();
        xPanel1 = new com.rameses.osiris.client.component.XPanel();
        xLabel2 = new com.rameses.osiris.client.component.XLabel();
        xLabel3 = new com.rameses.osiris.client.component.XLabel();
        xTextField1 = new com.rameses.osiris.client.component.XTextField();
        xLabel4 = new com.rameses.osiris.client.component.XLabel();
        xTextField2 = new com.rameses.osiris.client.component.XTextField();
        xLabel5 = new com.rameses.osiris.client.component.XLabel();
        xTextField3 = new com.rameses.osiris.client.component.XTextField();
        xPanel2 = new com.rameses.osiris.client.component.XPanel();
        xGlue1 = new com.rameses.osiris.client.component.spacer.XGlue();
        xButton3 = new com.rameses.osiris.client.component.XButton();
        xStrut2 = new com.rameses.osiris.client.component.spacer.XStrut();
        xButton2 = new com.rameses.osiris.client.component.XButton();
        xStrut1 = new com.rameses.osiris.client.component.spacer.XStrut();
        xButton1 = new com.rameses.osiris.client.component.XButton();

        setLayout(new java.awt.BorderLayout());

        xLabel1.setBackground(new java.awt.Color(0, 0, 153));
        xLabel1.setForeground(new java.awt.Color(255, 255, 255));
        xLabel1.setOpaque(true);
        xLabel1.setPadding(new java.awt.Insets(10, 10, 10, 10));
        xLabel1.setText("<html> <font size=\"5\">Fill Remote Information</font> </html>");
        add(xLabel1, java.awt.BorderLayout.NORTH);

        xPanel1.setLayout(null);

        xLabel2.setText("<html> <font size=\"3\">Please provide the remote information below:</font> </html>");
        xPanel1.add(xLabel2);
        xLabel2.setBounds(30, 30, 320, 20);

        xLabel3.setText("Branch: *");
        xPanel1.add(xLabel3);
        xLabel3.setBounds(60, 70, 60, 20);

        xTextField1.setDefaultFocus(true);
        xTextField1.setModelName("temp");
        xTextField1.setName("branchid");
        xPanel1.add(xTextField1);
        xTextField1.setBounds(150, 70, 150, 19);

        xLabel4.setText("User: *");
        xPanel1.add(xLabel4);
        xLabel4.setBounds(60, 100, 60, 20);

        xTextField2.setModelName("temp");
        xTextField2.setName("userid");
        xPanel1.add(xTextField2);
        xTextField2.setBounds(150, 100, 150, 19);

        xLabel5.setText("Terminal Key: *");
        xPanel1.add(xLabel5);
        xLabel5.setBounds(60, 130, 80, 20);

        xTextField3.setModelName("temp");
        xTextField3.setName("terminalid");
        xPanel1.add(xTextField3);
        xTextField3.setBounds(150, 130, 150, 19);

        add(xPanel1, java.awt.BorderLayout.CENTER);

        xPanel2.setLayout(new javax.swing.BoxLayout(xPanel2, javax.swing.BoxLayout.X_AXIS));

        xPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        xPanel2.setOpaque(true);
        xPanel2.setPadding(new java.awt.Insets(5, 5, 5, 5));
        xPanel2.add(xGlue1);

        xButton3.setIconResource("shared/images/16/back.png");
        xButton3.setOnclick("gotoPage('default')");
        xButton3.setText("&lt; Back");
        xPanel2.add(xButton3);

        xStrut2.setLength(5);
        xPanel2.add(xStrut2);

        xButton2.setIconResource("shared/images/16/next.png");
        xButton2.setAlt('n');
        xButton2.setDefaultFocusInWindow(true);
        xButton2.setOnclick("doVerifyRemoteInfo");
        xButton2.setText("Next &gt;");
        xPanel2.add(xButton2);

        xPanel2.add(xStrut1);

        xButton1.setIconResource("shared/images/16/close.png");
        xButton1.setAlt('c');
        xButton1.setOnclick("doClose");
        xButton1.setText("Cancel");
        xPanel2.add(xButton1);

        add(xPanel2, java.awt.BorderLayout.SOUTH);

    }// </editor-fold>//GEN-END:initComponents
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private com.rameses.osiris.client.component.XButton xButton1;
    private com.rameses.osiris.client.component.XButton xButton2;
    private com.rameses.osiris.client.component.XButton xButton3;
    private com.rameses.osiris.client.component.spacer.XGlue xGlue1;
    private com.rameses.osiris.client.component.XLabel xLabel1;
    private com.rameses.osiris.client.component.XLabel xLabel2;
    private com.rameses.osiris.client.component.XLabel xLabel3;
    private com.rameses.osiris.client.component.XLabel xLabel4;
    private com.rameses.osiris.client.component.XLabel xLabel5;
    private com.rameses.osiris.client.component.XPanel xPanel1;
    private com.rameses.osiris.client.component.XPanel xPanel2;
    private com.rameses.osiris.client.component.spacer.XStrut xStrut1;
    private com.rameses.osiris.client.component.spacer.XStrut xStrut2;
    private com.rameses.osiris.client.component.XTextField xTextField1;
    private com.rameses.osiris.client.component.XTextField xTextField2;
    private com.rameses.osiris.client.component.XTextField xTextField3;
    // End of variables declaration//GEN-END:variables
    
}
