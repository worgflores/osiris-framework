package com.mlhuillier.fu;

import com.rameses.osiris.client.AbstractFormController;
import java.awt.Dimension;
import java.io.InputStream;

public class FileUploadController extends AbstractFormController
{
    
    public FileUploadController() 
    {
        addPage("fillRemoteInfo", FillRemoteInfoPage.class);
        addPage("fillGeneralInfo", FillGeneralInfoPage.class);
        addPage("confirm", ConfirmPage.class);
    }

    protected Class getDefaultPageClass() { return CheckRemotePage.class; }

    protected InputStream getCodeBaseAsStream() { 
        return getClass().getResourceAsStream("CodeBase.xml");
    }

    public String getPreferredID() { return "fileupload.frm"; }

    public Dimension getPreferredSize() {
        return new Dimension(750,590);
    }

    public boolean isDocument() { return true; }
    

    
}
