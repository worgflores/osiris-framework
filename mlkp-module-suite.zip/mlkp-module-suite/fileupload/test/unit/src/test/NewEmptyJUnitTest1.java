/*
 * NewEmptyJUnitTest1.java
 * JUnit based test
 *
 * Created on April 16, 2008, 10:02 AM
 */

package test;

import junit.framework.*;

/**
 *
 * @author user
 */
public class NewEmptyJUnitTest1 extends TestCase {
    
    public NewEmptyJUnitTest1(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
    }

    protected void tearDown() throws Exception {
    }
    
    public void testHello() {
        System.out.println("hello");
    }

}
