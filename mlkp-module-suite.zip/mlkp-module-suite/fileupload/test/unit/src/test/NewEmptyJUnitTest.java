package test;

import com.mlhuillier.fu.FileUploadController;
import com.rameses.osiris.client.FormLauncher;
import java.awt.Container;
import javax.swing.JDialog;
import javax.swing.UIManager;
import junit.framework.*;

public class NewEmptyJUnitTest extends TestCase 
{
    
    public NewEmptyJUnitTest(String testName) {
        super(testName);
    }
    
    protected void setUp() throws Exception {
        UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
    }
    
    protected void tearDown() throws Exception {
    }
    
    public void test1() throws Exception 
    {
        FileUploadController fuc = new FileUploadController();
        //FormGenerator.getInstance().dump(fuc);
        FormLauncher.newInstance().launch(fuc);
        //showDialog(new CheckRemotePage());
    }
    
    private void showDialog(Container con)
    {
        JDialog d = new JDialog();
        d.setModal(true);
        d.setContentPane(con);
        d.setSize(640,480);
        d.setVisible(true);
    }
}

