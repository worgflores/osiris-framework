package test;

import com.rameses.http.service.util.HTTPSOAPClient;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import junit.framework.*;

public class NewEmptyJUnitTest extends TestCase 
{
    
    public NewEmptyJUnitTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
    }

    protected void tearDown() throws Exception {
    }
        
    public void xtestHTTPSOAPInvoker() throws Exception
    {
        HTTPSOAPClient c = new HTTPSOAPClient(); 
        Object o = c.invoke("http://192.168.50.111:8080/services/common/HTTPSOAPInvoker?op=dumpinfo", "TESTAction", "<soap:envelope/>");
        System.out.println(o);
    }
    
    public void xtestCreateResource() throws Exception
    {
        StringBuffer content = new StringBuffer(); 
        InputStream inp = null;
        try 
        {
            String filepath = "C:\\jbosstemplate\\server\\mlkp3_mlweb\\apps\\mlweb.ear\\services.jar\\mlkp.jar\\META-INF\\sql\\"; 
            String filename = "userpeeplogsummary_usertxns_bak1";
            inp = new FileInputStream(new File(filepath+filename)); 
            
            int read = -1;
            while ((read=inp.read()) != -1) {
                content.append((char) read); 
            }
        }
        catch(Exception ex) {
            throw ex; 
        }
        finally {
            try { inp.close(); }catch(Exception ing){;} 
        }
        
        HttpServiceClient c = new HttpServiceClient(); 
        Object result = c.invoke("http://192.168.3.193:8080/services/common/createResource/apps/mlkp.jar/META-INF/sql/userpeeplogsummary_usertxns_bak1", content.toString().getBytes()); 
        System.out.println(result);        
    }
        
    
    public void xtestUpdateResource() throws Exception
    {
        StringBuffer content = new StringBuffer(); 
        InputStream inp = null;
        try 
        {
            String filepath = "C:\\jbosstemplate\\server\\mlkp3_mlweb\\apps\\mlweb.ear\\services.jar\\mlkp.jar\\META-INF\\sql\\"; 
            String filename = "userpeeplogsummary_usertxns";
            inp = new FileInputStream(new File(filepath+filename)); 
            
            int read = -1;
            while ((read=inp.read()) != -1) {
                content.append((char) read); 
            }
        }
        catch(Exception ex) {
            throw ex; 
        }
        finally {
            try { inp.close(); }catch(Exception ing){;} 
        }
        
        //System.out.println(content);
        
        HttpServiceClient c = new HttpServiceClient(); 
        Object result = c.invoke("http://192.168.3.193:8080/services/common/updateResource/apps/mlkp.jar/META-INF/sql/userpeeplogsummary_usertxns", content.toString().getBytes()); 
        System.out.println(result);
    }
    
    private String getResourceContent(String resname) throws Exception 
    {
        ClassLoader loader = Thread.currentThread().getContextClassLoader(); 
        InputStream inp = loader.getResourceAsStream(resname); 
        try 
        {
            int read = -1;
            StringBuffer sb = new StringBuffer(); 
            while ((read=inp.read()) != -1) {
                sb.append((char) read); 
            }
            return sb.toString(); 
        }
        catch(Exception ex) {
            throw ex; 
        }
        finally {
            try { inp.close(); }catch(Exception ign){;} 
        }
    }
}



