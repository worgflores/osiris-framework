package test;

import com.rameses.http.service.util.HTTPSOAPClient;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import junit.framework.*;

public class HTTPSOAPInvokerTest extends TestCase 
{
    
    public HTTPSOAPInvokerTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
    }

    protected void tearDown() throws Exception {
    }
    
    public void xtestHTTPSOAPInvoker() throws Exception
    {
        HTTPSOAPClient c = new HTTPSOAPClient(); 
        Object o = c.invoke("http://192.168.50.111:8080/services/common/HTTPSOAPInvoker?op=dumpinfo", "TESTAction", "<soap:envelope/>");
        System.out.println(o);
    }
    
    public void xtestCreateResource() throws Exception
    {
        HttpServiceClient c = new HttpServiceClient();
    }
        
    
    public void testUpdateResource() throws Exception
    {
        ByteArrayOutputStream baos = null;
        InputStream inp = null;
        byte[] bytes = null;
        try
        {
            File f = new File("C:\\jbosstemplate\\server\\mlglobal-test\\apps\\mlglobal.ear\\services.jar\\mlglobal-reports-services.jar\\META-INF\\sql\\admin_sales_report.sql");            
            inp = new FileInputStream(f); 
            baos = new ByteArrayOutputStream(); 
            int read = -1; 
            while ((read=inp.read()) != -1) {
                baos.write(read); 
            }
            baos.flush(); 
            bytes = baos.toByteArray(); 
        }
        catch(Exception ex) {
            throw ex; 
        }
        finally
        {
            try { inp.close(); }catch(Exception gin){;} 
            try { baos.close(); }catch(Exception gin){;} 
        }

        HttpServiceClient c = new HttpServiceClient(); 
        Object result = c.invoke("http://192.168.50.233:8080/services/common/updateResource/apps/mlglobal.ear/services.jar/mlglobal-reports-services.jar/META-INF/sql/admin_sales_report.sql", bytes); 
        System.out.println(result);
    }
    
    private String getResourceContent(String resname) throws Exception 
    {
        ClassLoader loader = Thread.currentThread().getContextClassLoader(); 
        InputStream inp = loader.getResourceAsStream(resname); 
        try 
        {
            int read = -1;
            StringBuffer sb = new StringBuffer(); 
            while ((read=inp.read()) != -1) {
                sb.append((char) read); 
            }
            return sb.toString(); 
        }
        catch(Exception ex) {
            throw ex; 
        }
        finally {
            try { inp.close(); }catch(Exception ign){;} 
        }
    }
}



