package test;

import junit.framework.*;

public class QPADALATest extends TestCase 
{
    public QPADALATest(String testName) {
        super(testName);
    }
    
    protected void setUp() throws Exception {
    }
    
    protected void tearDown() throws Exception {
    }
    
    /*
        <soapenv:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:com="http://com.mlhuillier.partner.soap">
           <soapenv:Header/>
           <soapenv:Body>
              <com:cancelSendout soapenv:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">
                 <branchid xsi:type="xsd:string">QP</branchid>
                 <userid xsi:type="xsd:string">QP12ZKN07X10</userid>
                 <terminalid xsi:type="xsd:string">QP12TER07X10</terminalid>
                 <kptn xsi:type="xsd:string">QP1820958563</kptn>
                 <reason xsi:type="xsd:string">CANCEL SENDOUT</reason>
                 <signature xsi:type="xsd:string">c086c2bb9c0da798d9a6447d97b5c16d</signature>
              </com:cancelSendout>
           </soapenv:Body>
        </soapenv:Envelope>     

     
        <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
           <soapenv:Body soapenv:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">
              <ns1:cancelSendoutResponse xmlns:ns1="http://com.mlhuillier.partner.soap">
                 <result href="#id0"/>
              </ns1:cancelSendoutResponse>
              <multiRef id="id0" soapenc:root="0" soapenv:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/" xsi:type="ns2:Map" xmlns:soapenc="http://schemas.xmlsoap.org/soap/encoding/" xmlns:ns2="http://xml.apache.org/xml-soap">
                 <item>
                    <key xsi:type="xsd:string">dtfiled</key>
                    <value xsi:type="xsd:string">2011-07-27 18:18:08.0</value>
                 </item>
                 <item>
                    <key xsi:type="xsd:string">objid</key>
                    <value xsi:type="xsd:string">CSOUT-559977ad:133b5ee506c:-7fe7</value>
                 </item>
                 <item>
                    <key xsi:type="xsd:string">dtcancelled</key>
                    <value xsi:type="xsd:string">2011-11-19 12:05:00.0</value>
                 </item>
              </multiRef>
           </soapenv:Body>
        </soapenv:Envelope>   
     */
    
    public void testMain() throws Exception 
    {
        String branchid = "QP";
        String userid   = "QP12ZKN07X10";
        String terminalid = "QP12TER07X10";
        String kptn = "QP1820958563"; 
        String secretkey = "5E3WQP7W8Z";
        
        String result = MD5Encoder.encode(branchid + userid + terminalid + kptn + secretkey); 
        System.out.println(result);
    }
}
