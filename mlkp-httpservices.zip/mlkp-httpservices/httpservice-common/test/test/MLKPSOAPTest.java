package test;

import com.rameses.http.service.util.HTTPSOAPClient;
import java.io.InputStream;
import junit.framework.*;

public class MLKPSOAPTest extends TestCase 
{
    private String HOST = "https://192.168.50.111:8443/mlkpsoap/changesendout"; 
    
    public MLKPSOAPTest(String testName) {
        super(testName);
    }
    
    protected void setUp() throws Exception {
    }
    
    protected void tearDown() throws Exception {
    }
    
    public void testChangeSendout() throws Exception 
    {
        String soaprequest = getResourceContent("test/resources/mtrbnk.showRemittanceDetail.xml"); 
        
        HTTPSOAPClient c = new HTTPSOAPClient(); 
        //Object o = c.send(GATEWAY, SOAP_HOST, "http://rts.crtsserviceconnect/ShowRemittanceDetail", soaprequest); 
        //Object o = c.invoke(SOAP_HOST, "http://rts.crtsserviceconnect/ShowRemittanceDetail", soaprequest); 
        //System.out.println(o);
    }
    
    
    private String getResourceContent(String resname) throws Exception 
    {
        ClassLoader loader = Thread.currentThread().getContextClassLoader(); 
        InputStream inp = loader.getResourceAsStream(resname); 
        try 
        {
            int read = -1;
            StringBuffer sb = new StringBuffer(); 
            while ((read=inp.read()) != -1) {
                sb.append((char) read); 
            }
            return sb.toString(); 
        }
        catch(Exception ex) {
            throw ex; 
        }
        finally {
            try { inp.close(); }catch(Exception ign){;} 
        }
    }       
}
