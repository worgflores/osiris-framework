package test;

import com.rameses.http.service.util.SimpleHTTPClient;
import java.util.HashMap;
import java.util.Map;
import junit.framework.*;

public class TrangloTest extends TestCase 
{
    public TrangloTest(String testName) {
        super(testName);
    }
    
    protected void setUp() throws Exception {
    }
    
    protected void tearDown() throws Exception {
    }
    
    public void testMain() throws Exception 
    {
        String UID = "testML"; 
        String SecKey = "MTA0MTAxMTE0OQ"; 
        String transID = "20110913002";
        String kptn = "TRANGL2102023096";
        
        Map params = new HashMap(); 
        params.put("Sign", MD5Encoder.encode(UID + kptn + SecKey));
        params.put("UID", UID);
        params.put("PWD", "MLTest0123");
        params.put("transID", kptn);
        params.put("status", "1");
        params.put("amount", "50000.00");
        params.put("branchID", "MLTest001");
        
        //SimpleHTTPClient c = new SimpleHTTPClient("http://apitest.r-tml.com/tml_service.asmx", "http://localhost:8080/services/common/SimpleHTTPInvoker"); 
        SimpleHTTPClient c = new SimpleHTTPClient("http://175.139.151.69:8099/PayoutServiceTest/Payout_Service.asmx"); 
        c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
        
        Object result = c.post("CashPayoutResp", params);
        System.out.println(result);
    }
}
