package test;

import java.security.MessageDigest;

public class MD5Encoder  
{   
    public static String encode(String value) 
    {
        try
        {
            MessageDigest md = MessageDigest.getInstance("MD5");
            md.update(value.getBytes());
            
            byte[] hash =  md.digest();
            return toHexString(hash);
        }
        catch(Exception e) {
            throw new IllegalStateException(e.getMessage(), e);
        }
    }
    
    public static String toHexString(byte[] bytes)
    {
        String hexDigit = "0123456789abcdef";
        StringBuffer sb = new StringBuffer(bytes.length);
        for (int i=0; i< bytes.length; i++) 
        {
            int b = bytes[i] & 0xFF;
            sb.append(hexDigit.charAt(b >>> 4));
            sb.append(hexDigit.charAt(b & 0xF));
        }
        return sb.toString();
    }
}
