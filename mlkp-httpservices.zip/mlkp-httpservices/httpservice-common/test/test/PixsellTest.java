package test;

import com.rameses.http.service.util.SimpleHTTPClient;
import java.util.HashMap;
import java.util.Map;
import junit.framework.*;

public class PixsellTest extends TestCase 
{
    public PixsellTest(String testName) {
        super(testName);
    }
    
    protected void setUp() throws Exception {
    }
    
    protected void tearDown() throws Exception {
    }
    
    public void testMain() throws Exception 
    {
        Map params = new HashMap(); 
        params.put("merchantID", "61");
        params.put("membersID", "22169");
        params.put("merchantUserName", "MLHUILLIER");
        params.put("merchantPassword", "ADX116");
        params.put("ePin", "14PQJX1");
        
        SimpleHTTPClient c = new SimpleHTTPClient("http://58.71.11.197/PXWS/Service.asmx", "http://localhost:8080/services/common/SimpleHTTPInvoker"); 
        c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
        
        Object result = c.post("PxClientAuthentication", params);
        System.out.println(result);
    }
}
