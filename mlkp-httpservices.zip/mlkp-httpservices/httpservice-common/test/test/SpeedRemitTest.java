package test;

import com.rameses.http.service.util.HTTPSOAPClient;
import java.io.File;
import java.io.InputStream;
import junit.framework.*;

public class SpeedRemitTest extends TestCase 
{
    private String SOAP_HOST = "http://payoutapi.speedremit.net/Service.asmx";
    private String GATEWAY = "http://localhost:8080/services/common/HTTPSOAPInvoker"; 
    
    public SpeedRemitTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
    }

    protected void tearDown() throws Exception {
    }

    public void testShowTransfer() throws Exception
    {
        String soaprequest = getResourceContent("test/resources/spdrmt.ShowTransfer.xml"); 
        
        HTTPSOAPClient c = new HTTPSOAPClient(); 
        Object o = c.send(GATEWAY, SOAP_HOST, "http://payoutapi.speedremit.net/Service.asmx/ShowTransfer", soaprequest); 
        System.out.println(o);
    } 
    
    private String getResourceContent(String resname) throws Exception 
    {
        ClassLoader loader = Thread.currentThread().getContextClassLoader(); 
        InputStream inp = loader.getResourceAsStream(resname); 
        try 
        {
            int read = -1;
            StringBuffer sb = new StringBuffer(); 
            while ((read=inp.read()) != -1) {
                sb.append((char) read); 
            }
            return sb.toString(); 
        }
        catch(Exception ex) {
            throw ex; 
        }
        finally {
            try { inp.close(); }catch(Exception ign){;} 
        }
    }     
}



