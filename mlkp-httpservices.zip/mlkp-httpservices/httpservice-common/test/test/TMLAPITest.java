package test;

import com.rameses.http.service.util.SimpleHTTPClient;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import junit.framework.*;

public class TMLAPITest extends TestCase 
{
    public TMLAPITest(String testName) {
        super(testName);
    }
    
    protected void setUp() throws Exception {
    }
    
    protected void tearDown() throws Exception {
    }
    
    public void testMain() throws Exception 
    {
        Map params = new HashMap(); 
        params.put("pUsername", "mlkp_Admin@mlhuillier1.com");
        params.put("pPass", "1234");
        params.put("pRemitCode", "393900514633");
        params.put("pStatus", "1");
        params.put("pClaimDate", "9/15/2011 06:43:26 PM");
        params.put("pClaimBranchID", "RECLAM");
        
        //SimpleHTTPClient c = new SimpleHTTPClient("http://apitest.r-tml.com/tml_service.asmx", "http://localhost:8080/services/common/SimpleHTTPInvoker"); 
        SimpleHTTPClient c = new SimpleHTTPClient("http://apitest.r-tml.com/tml_service.asmx"); 
        c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
        
        Object result = c.post("Update_TxnStatus", params);
        System.out.println(result);
    }
}
