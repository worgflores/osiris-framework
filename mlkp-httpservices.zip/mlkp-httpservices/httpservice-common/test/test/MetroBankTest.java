package test;

import com.rameses.http.service.util.HTTPSOAPClient;
import common.net.SSLLoader;
import java.io.InputStream;
import junit.framework.*;

public class MetroBankTest extends TestCase 
{
    //private String GATEWAY = "http://58.71.17.50:8080/services/common/HTTPSOAPInvoker"; 
    
    private String SOAP_HOST = "https://paystation.mbremit.com/CRTSServiceConnect.asmx";
    private String GATEWAY = "http://localhost:8080/services/common/HTTPSOAPInvoker"; 
    
    public MetroBankTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception { 
        SSLLoader.initialize(); 
    }

    protected void tearDown() throws Exception {
    }

    public void testShowRemittanceDetail() throws Exception
    {
        String soaprequest = getResourceContent("test/resources/mtrbnk.showRemittanceDetail.xml"); 
        
        HTTPSOAPClient c = new HTTPSOAPClient(); 
        //Object o = c.send(GATEWAY, SOAP_HOST, "http://rts.crtsserviceconnect/ShowRemittanceDetail", soaprequest); 
        Object o = c.invoke(SOAP_HOST, "http://rts.crtsserviceconnect/ShowRemittanceDetail", soaprequest); 
        System.out.println(o);
    } 
    
    private String getResourceContent(String resname) throws Exception 
    {
        ClassLoader loader = Thread.currentThread().getContextClassLoader(); 
        InputStream inp = loader.getResourceAsStream(resname); 
        try 
        {
            int read = -1;
            StringBuffer sb = new StringBuffer(); 
            while ((read=inp.read()) != -1) {
                sb.append((char) read); 
            }
            return sb.toString(); 
        }
        catch(Exception ex) {
            throw ex; 
        }
        finally {
            try { inp.close(); }catch(Exception ign){;} 
        }
    }     
}



