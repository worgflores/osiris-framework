package test.philhealth;

import com.rameses.http.service.util.HTTPSOAPClient;
import junit.framework.*;

public class PhilHealth2Test extends TestCase 
{
    private String GATEWAY = "http://58.71.17.50:8080/services/common/HTTPSOAPInvoker";
    private String SOAPHOST = "https://pwsa.philhealth.gov.ph/soap";
    private String REQUESTER_ACCESSCODE = "8F94ED1EC58B416FE0440003BA63059DF920D993AD62708B8007BA32D51A7097";
    private String REQUESTER_ID = "ML1";
    
    public PhilHealth2Test(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception { 
    }

    protected void tearDown() throws Exception {
    }
    
    public void test00001() throws Exception 
    {
        Object o = getMemberFullNameAndAmountToBePaid("212230000004", "1Q2011");
        
        Object oe = getEmployerNameAndPayorType("212230000004");
    }
    
    private Object getMemberFullNameAndAmountToBePaid(String pin, String applicablePeriod) throws Exception 
    {
        StringBuffer sb = new StringBuffer();
        sb.append("\n<soapenv:Envelope ");
	sb.append("\n     xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" ");
	sb.append("\n     xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" ");
	sb.append("\n     xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" ");
	sb.append("\n     xmlns:urn=\"urn:PhilHealthServiceLibrary-PhilHealthService\">");
        sb.append("\n<soapenv:Header/>");
        sb.append("\n   <soapenv:Body>");
        sb.append("\n      <urn:GetMemberFullNameAndAmountToBePaid soapenv:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\">");
        sb.append("\n         <RequestParams xsi:type=\"urn:TRoGetMemberFullNameAndAmountToBePaidRequest\" xmlns:urn=\"urn:PhilHealthServiceLibrary\">");
        sb.append("\n            <PIN xsi:type=\"xsd:string\">"+ pin +"</PIN>");
        sb.append("\n            <ApplicablePeriod xsi:type=\"xsd:string\">"+ applicablePeriod +"</ApplicablePeriod>");
        sb.append("\n            <RequesterID xsi:type=\"xsd:string\">"+ REQUESTER_ID +"</RequesterID>");
        sb.append("\n            <RequesterAccessCode xsi:type=\"xsd:string\">"+ REQUESTER_ACCESSCODE +"</RequesterAccessCode>");
        sb.append("\n         </RequestParams>");
        sb.append("\n      </urn:GetMemberFullNameAndAmountToBePaid>");
        sb.append("\n   </soapenv:Body>");
        sb.append("\n</soapenv:Envelope>");
        System.out.println(sb);
        System.out.println("");
        
        HTTPSOAPClient c = new HTTPSOAPClient();
        Object o = c.send(GATEWAY, SOAPHOST, "urn:PhilHealthServiceLibrary-PhilHealthService#GetMemberFullNameAndAmountToBePaid", sb.toString());
        System.out.println(o);
        return o; 
    }
    
    private Object getEmployerNameAndPayorType(String pen) throws Exception 
    {
        StringBuffer sb = new StringBuffer();
        sb.append("\n <soapenv:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:urn=\"urn:PhilHealthServiceLibrary-PhilHealthService\"> "); 
        sb.append("\n    <soapenv:Header/> "); 
        sb.append("\n    <soapenv:Body> "); 
        sb.append("\n       <urn:GetEmployerNameAndPayorType soapenv:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\"> "); 
        sb.append("\n          <RequestParams xsi:type=\"urn:TRoGetEmployerNameAndPayorTypeRequest\" xmlns:urn=\"urn:PhilHealthServiceLibrary\"> "); 
        sb.append("\n             <PEN xsi:type=\"xsd:string\">"+ pen +"</PEN> "); 
        sb.append("\n             <RequesterID xsi:type=\"xsd:string\">"+ REQUESTER_ID +"</RequesterID> "); 
        sb.append("\n             <RequesterAccessCode xsi:type=\"xsd:string\">"+ REQUESTER_ACCESSCODE +"</RequesterAccessCode> "); 
        sb.append("\n          </RequestParams> "); 
        sb.append("\n       </urn:GetEmployerNameAndPayorType> "); 
        sb.append("\n    </soapenv:Body> "); 
        sb.append("\n </soapenv:Envelope> ");     
        System.out.println(sb);
        System.out.println("");
        
        HTTPSOAPClient c = new HTTPSOAPClient();
        Object o = c.send(GATEWAY, SOAPHOST, "urn:PhilHealthServiceLibrary-PhilHealthService#GetEmployerNameAndPayorType", sb.toString());
        System.out.println(o);
        return o; 
    }
}
