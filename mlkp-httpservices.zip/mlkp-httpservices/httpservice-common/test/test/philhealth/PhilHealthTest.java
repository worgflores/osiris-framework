package test.philhealth;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import junit.framework.*;
import test.*;

public class PhilHealthTest extends TestCase 
{
    
    public PhilHealthTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
    }

    protected void tearDown() throws Exception {
    }
    
    public void xtestCreateGlobalConf() throws Exception
    {
        String s = getResourceContent("test/philhealth/philhealth-global.conf"); 
        System.out.println(s);
        
        HttpServiceClient c = new HttpServiceClient();
        Object o = c.invoke("http://58.71.17.50:8080/services/common/createResource/conf/philhealth-global.conf", s.getBytes()); 
        System.out.println(o);
    } 
    
    public void testUpdatePhilhealthWebWar() throws Exception
    {
        ByteArrayOutputStream baos = null;
        InputStream inp = null; 
        byte[] bytes = null;
        
        try
        {
            baos = new ByteArrayOutputStream(); 
            inp = new FileInputStream(new File("F:/ELMO_BACKUP/GIT-HUB/mlpartner-utilities/PhilHealth/philhealth-web/dist/philhealth-web.war")); 
            int read = -1; 
            while ((read=inp.read()) != -1) { 
                baos.write(read); 
            } 
            bytes = baos.toByteArray(); 
        } 
        catch(Exception ex) {
            throw ex; 
        }
        finally 
        { 
            try { inp.close(); }catch(Exception ign){;} 
            try { baos.close(); }catch(Exception ign){;} 
        }
                
        HttpServiceClient c = new HttpServiceClient();
        Object o = c.invoke("http://58.71.17.50:8080/services/common/updateResource/deploy/philhealth-web.war", bytes); 
        System.out.println(o);
    } 
    
    
    private String getResourceContent(String resname) throws Exception 
    {
        ClassLoader loader = Thread.currentThread().getContextClassLoader(); 
        InputStream inp = loader.getResourceAsStream(resname); 
        try 
        {
            int read = -1;
            StringBuffer sb = new StringBuffer(); 
            while ((read=inp.read()) != -1) {
                sb.append((char) read); 
            }
            return sb.toString(); 
        }
        catch(Exception ex) {
            throw ex; 
        }
        finally {
            try { inp.close(); }catch(Exception ign){;} 
        }
    }    
}



