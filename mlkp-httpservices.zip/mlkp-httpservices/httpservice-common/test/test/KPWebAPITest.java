package test;

import com.rameses.http.service.util.SimpleHTTPClient;
import java.util.HashMap;
import java.util.Map;
import junit.framework.*;

public class KPWebAPITest extends TestCase 
{
    public KPWebAPITest(String testName) {
        super(testName);
    }
    
    protected void setUp() throws Exception {
    }
    
    protected void tearDown() throws Exception {
    }
    
    public void testMain() throws Exception 
    {
        Map params = new HashMap(); 
        params.put("user", "mlkp");
        params.put("password", "mlinc1234");
        params.put("kptn", "MIS6989968331");
        
        SimpleHTTPClient c = new SimpleHTTPClient("http://192.168.50.112/api/index.php/api/service"); 
        c.setRequestProperty("Accept", "*/*");
        
        System.out.println("[searchByKPTN]");
        Object result = c.post("searchByKPTN", params);
        System.out.println(result);
        

        System.out.println("[openTransaction]");
        params.put("branchid", "MIS");
        params.put("userid", "KPBRANCHUSER");
        result = c.post("openTransaction", params);
        System.out.println(result);
    }
}
