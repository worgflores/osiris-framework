package test;

import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Iterator;
import java.util.Map;

public class HttpServiceClient  
{
    private int timeout;
    
    public int getTimeout() { return timeout; }
    public void setTimeout(int timeout) { this.timeout = timeout; }
    
    public Object invoke(String host, Object req) throws Exception 
    {
        if (host == null || host.trim().length() == 0)
            throw new NullPointerException("'host' parameter is required");
        
        URL url = null;
        HttpURLConnection conn = null;
        ObjectOutputStream out = null;
        ObjectInputStream in = null;
        
        try 
        {
            url = new URL(host);
            conn = (HttpURLConnection) url.openConnection();
            conn.setDoOutput(true); 
            conn.setUseCaches(false); 
            if (getTimeout() > 0)
            {
                conn.setConnectTimeout(getTimeout());  
                conn.setReadTimeout(getTimeout()); 
            }
            
            out = new ObjectOutputStream(conn.getOutputStream());
            out.writeObject(req);
            
            in = new ObjectInputStream(conn.getInputStream());
            Object res = in.readObject();
            if (res instanceof Exception) {
                throw (Exception) res;
            }
            else if (res instanceof Map)
            {
                Map map = (Map) res;
                if (!"1".equals(map.get("respcode")))
                {
                    System.out.println(map.get("respmsg")+"");
                    throw new Exception(map.get("respdetail")+"");
                } 
            } 
            return res; 
        } 
        catch (Exception ex) { 
            throw ex; 
        }  
        finally 
        {
            try { in.close(); } catch(Exception ex){;}
            try { out.close(); } catch(Exception ex){;}
            try { conn.disconnect(); } catch(Exception ex){;}
        }
    }    
    
    public Object invokeURL(String host, Map req) throws Exception 
    {
        if (host == null || host.trim().length() == 0)
            throw new NullPointerException("'host' parameter is required");
        
        HttpURLConnection conn = null;
        
        try 
        {
            StringBuffer request = new StringBuffer(); 
            if (req != null)
            {
                Iterator keys = req.keySet().iterator(); 
                while (keys.hasNext())
                {
                    String key = keys.next().toString(); 
                    Object val = req.get(key); 
                    if (val == null) val = "";
                    
                    if (request.length() != 0) request.append("&"); 
                    
                    request.append(key + "=" + URLEncoder.encode(val.toString()));
                }
            }
            
            URL url = new URL(host);
            conn = (HttpURLConnection) url.openConnection();
            conn.setDoOutput(true); 
            conn.setUseCaches(false); 
            conn.setRequestMethod("POST"); 
            
            OutputStreamWriter out = null; 
            try
            {
                out = new OutputStreamWriter(conn.getOutputStream()); 
                out.write(request.toString()); 
                out.flush(); 
            }
            catch(Exception e1) {
                throw e1; 
            }
            finally {
                try { out.close(); }catch(Exception ing){;} 
            }
            
            InputStream inp = null;
            try
            {
                inp = conn.getInputStream(); 
                int read = -1;
                StringBuffer sb = new StringBuffer(); 
                while ((read=inp.read()) != -1) {
                    sb.append((char) read);
                }
                return sb.toString(); 
            }
            catch(Exception e1) {
                throw e1; 
            }
            finally {
                try { inp.close(); }catch(Exception ing){;} 
            }
        } 
        catch (Exception ex) { 
            throw ex; 
        }  
        finally {
            try { conn.disconnect(); } catch(Exception ex){;}
        }
    }        
}
