package test;

import com.rameses.http.service.util.SimpleHTTPClient;
import java.util.HashMap;
import java.util.Map;
import junit.framework.*;

public class PayoutWSTest extends TestCase 
{
    public PayoutWSTest(String testName) {
        super(testName);
    }
    
    protected void setUp() throws Exception {
    }
    
    protected void tearDown() throws Exception {
    }
    
    public void testSearch() throws Exception 
    {
        String branchid = "MAIN1"; 
        String userid = "KPUSER"; 
        String terminalid = "MAINT1";
        String kptn = "FSD171833774207";
        String signature = "com.rameses.ml.ws.WSService"; 
        
        Map params = new HashMap(); 
        params.put("branchid", branchid);
        params.put("userid", userid);
        params.put("terminalid", terminalid);
        params.put("kptn", kptn);        
        params.put("signature", signature);        
        
        SimpleHTTPClient c = new SimpleHTTPClient("http://192.168.50.111:18080/mlkp-webservice/PayoutWS"); 
        c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
        
        Object result = c.post("searchByKPTN", params);
        System.out.println(result);
    }
}
