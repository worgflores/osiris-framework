package test;

import com.rameses.http.service.util.HTTPSOAPClient;
import common.net.SSLLoader;
import java.io.InputStream;
import java.net.URL;
import junit.framework.*;

public class ABSCBNTest extends TestCase 
{
    private String SOAP_HOST = "https://221.121.187.60/MLWebservice.asmx";
    private String GATEWAY = "http://localhost:8080/services/common/HTTPSOAPInvoker"; 
    
    public ABSCBNTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception { 
        SSLLoader.initialize();         
    }

    protected void tearDown() throws Exception {
    }
    
    public void xtestDumpWSDL() throws Exception 
    {
        InputStream inp = null;
        try
        {
            URL url = new URL(SOAP_HOST + "?wsdl"); 
            inp = url.openStream(); 
            
            StringBuffer sb = new StringBuffer(); 
            int read = -1;
            while ((read=inp.read()) != -1) {
                sb.append((char) read); 
            }
            System.out.println(sb);
        } 
        catch(Exception ex) {
            throw ex; 
        }
        finally { 
            try { inp.close(); }catch(Exception ign){;} 
        }
    }

    public void testGetRemittance() throws Exception
    {
        String soaprequest = getResourceContent("test/resources/abscbn.GetRemittance.xml"); 
        System.out.println(soaprequest);
        
        HTTPSOAPClient c = new HTTPSOAPClient(); 
        //Object o = c.send(GATEWAY, SOAP_HOST, "http://api.ezremit.com/GetTransaction", soaprequest); 
        Object o = c.invoke(SOAP_HOST, "http://10.0.32.6/WS/MLWebservice.asmx/GetRemittance", soaprequest); 
        System.out.println(o);
    } 
    
    private String getResourceContent(String resname) throws Exception 
    {
        ClassLoader loader = Thread.currentThread().getContextClassLoader(); 
        InputStream inp = loader.getResourceAsStream(resname); 
        try 
        {
            int read = -1;
            StringBuffer sb = new StringBuffer(); 
            while ((read=inp.read()) != -1) {
                sb.append((char) read); 
            }
            return sb.toString(); 
        }
        catch(Exception ex) {
            throw ex; 
        }
        finally {
            try { inp.close(); }catch(Exception ign){;} 
        }
    }     
}



