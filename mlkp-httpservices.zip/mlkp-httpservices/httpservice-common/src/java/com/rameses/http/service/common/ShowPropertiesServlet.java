package com.rameses.http.service.common;

import java.io.*;
import java.util.Iterator;

import javax.servlet.*;
import javax.servlet.http.*;

public class ShowPropertiesServlet extends HttpServlet 
{
    private String KEYNAME = "services/common/showProperties";
    
    // <editor-fold defaultstate="collapsed" desc=" HttpServlet methods. Click on the + sign on the left to edit the code. ">
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response, "GET");
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response, "POST");
    }
    
    public String getServletInfo() { return KEYNAME; }
    // </editor-fold>
    
    private void processRequest(HttpServletRequest req, HttpServletResponse res, String reqMethod) throws ServletException, IOException 
    {
        PrintWriter out = null;
        Helper helper = new Helper();
        
        try
        { 
            out = res.getWriter(); 
            
            Iterator keys = System.getProperties().keySet().iterator(); 
            while (keys.hasNext()) 
            {
                String name = keys.next().toString(); 
                String value = System.getProperty(name); 
                out.println(name + "=" + value); 
            } 
        } 
        catch(Exception ex) 
        { 
            out.println("ERROR: "); 
            out.println(helper.getStackTrace(ex)); 
        }
        finally {
            try { out.close(); }catch(Exception ing){;} 
        } 
    } 
    
} 
