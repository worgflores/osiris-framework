package com.rameses.http.service.common;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

class Helper 
{

    public String getStackTrace(Exception ex)
    {
        ByteArrayOutputStream baos = null;
        try
        {
            baos = new ByteArrayOutputStream();
            ex.printStackTrace(new PrintStream(baos));
            return new String(baos.toByteArray());
        }
        catch(Exception e) {
            return "";
        }
        finally {
            try { baos.close(); }catch(Exception ign) {;} 
        }
    } 
    
}
