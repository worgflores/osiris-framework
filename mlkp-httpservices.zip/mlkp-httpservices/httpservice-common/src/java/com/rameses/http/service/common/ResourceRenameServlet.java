package com.rameses.http.service.common;

import java.io.*;

import javax.servlet.*;
import javax.servlet.http.*;

public class ResourceRenameServlet extends HttpServlet 
{
    private String KEYNAME = "services/common/renameResource"; 
    
    // <editor-fold defaultstate="collapsed" desc=" HttpServlet methods. Click on the + sign on the left to edit the code. ">
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response, "GET");
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response, "POST");
    }
    
    public String getServletInfo() { return KEYNAME; }
    // </editor-fold>
    
    private void processRequest(HttpServletRequest req, HttpServletResponse res, String reqMethod) throws ServletException, IOException 
    {
        PrintWriter out = null;
        Helper helper = new Helper();
        
        try
        { 
            res.setContentType("text/plain"); 
            out = res.getWriter(); 
            
            String pathInfo = req.getPathInfo(); 
            if (pathInfo == null || pathInfo.trim().length() == 0) 
                throw new Exception("'PathInfo' is required"); 
            
            String name = req.getParameter("name"); 
            if (name == null || name.trim().length() == 0)
                throw new Exception("'name' parameter is required");  
            
            StringBuffer path = new StringBuffer(); 
            path.append(System.getProperty("jboss.server.home.dir",""));
            if (!path.toString().endsWith("/")) path.append("/"); 
            
            path.append(pathInfo); 
            
            File file = new File(path.toString()); 
            if (!file.exists()) throw new Exception("'"+pathInfo+"' resource not found"); 
            
            String filepath = file.getAbsolutePath(); 
            filepath = filepath.substring(0, filepath.lastIndexOf(File.separatorChar)); 
            File dir = new File(filepath);
            boolean b = file.renameTo(new File(dir, name));
            if (!b) throw new Exception("Unable to rename the resource file"); 
            
            out.println("success"); 
        } 
        catch(Exception ex) 
        { 
            out.println("ERROR: "); 
            out.println(helper.getStackTrace(ex)); 
        } 
        finally {
            try { out.close(); }catch(Exception ing){;} 
        } 
    } 
}
