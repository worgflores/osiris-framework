package com.rameses.http.service.common;

import java.io.*;

import javax.servlet.*;
import javax.servlet.http.*;

public class ResourceViewServlet extends HttpServlet 
{
    private String KEYNAME = "services/common/viewResource"; 
    
    // <editor-fold defaultstate="collapsed" desc=" HttpServlet methods. Click on the + sign on the left to edit the code. ">
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response, "GET");
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response, "POST");
    }
    
    public String getServletInfo() { return KEYNAME; }
    // </editor-fold>
    
    private void processRequest(HttpServletRequest req, HttpServletResponse res, String reqMethod) throws ServletException, IOException 
    {
        PrintWriter out = null;
        Helper helper = new Helper();
        
        try
        { 
            out = res.getWriter(); 
            
            String pathInfo = req.getPathInfo(); 
            if (pathInfo == null || pathInfo.trim().length() == 0)
                throw new Exception("'PathInfo' is required");
            
            StringBuffer path = new StringBuffer(); 
            path.append(System.getProperty("jboss.server.home.dir",""));
            if (!path.toString().endsWith("/")) path.append("/"); 
            
            path.append(pathInfo); 
            
            File file = new File(path.toString()); 
            if (!file.exists()) throw new Exception("'"+pathInfo+"' resource not found"); 
            
            if (file.isDirectory())
            {
                out.println("DIRECTORY: ");
                File[] files = file.listFiles();
                for (int i=0; i<files.length; i++) {
                    out.println(files[i].getName() + "=" + files[i].getAbsolutePath()); 
                } 
            }
            else
            {
                InputStream inp = null;
                try
                {
                    inp = new FileInputStream(file); 
                    int read = -1; 
                    StringBuffer content = new StringBuffer(); 
                    while ((read=inp.read()) != -1) { 
                        content.append((char) read); 
                    } 
                    out.println(content.toString()); 
                } 
                catch(Exception ex) { 
                    throw ex; 
                } 
                finally {
                    try { inp.close(); }catch(Exception ign){;} 
                }
            }
        } 
        catch(Exception ex) 
        { 
            out.println("ERROR: "); 
            out.println(helper.getStackTrace(ex)); 
        }
        finally {
            try { out.close(); }catch(Exception ing){;} 
        } 
    }     
}
