package com.rameses.http.service.common;

import java.io.*;
import java.util.Enumeration;
import java.util.Iterator;

import javax.servlet.*;
import javax.servlet.http.*;

public class ShowClasspathServlet extends HttpServlet 
{
    private String KEYNAME = "services/common/showClasspath";
    
    // <editor-fold defaultstate="collapsed" desc=" HttpServlet methods. Click on the + sign on the left to edit the code. ">
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response, "GET");
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response, "POST");
    }
    
    public String getServletInfo() { return KEYNAME; }
    // </editor-fold>
    
    private void processRequest(HttpServletRequest req, HttpServletResponse res, String reqMethod) throws ServletException, IOException 
    {
        PrintWriter out = null;
        Helper helper = new Helper();
        
        try
        { 
            out = res.getWriter(); 
            
            ClassLoader loader = Thread.currentThread().getContextClassLoader(); 
            Enumeration en = loader.getResources("");
            while (en.hasMoreElements()) { 
                out.println(en.nextElement().toString()); 
            } 
        } 
        catch(Exception ex) 
        { 
            out.println("ERROR: "); 
            out.println(helper.getStackTrace(ex)); 
        }
        finally {
            try { out.close(); }catch(Exception ing){;} 
        } 
    } 
}
