package com.rameses.http.service.common;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Date;

import javax.servlet.*;
import javax.servlet.http.*;

public class ResourceDescServlet extends HttpServlet 
{
    private String KEYNAME = "services/common/descResource"; 
    
    // <editor-fold defaultstate="collapsed" desc=" HttpServlet methods. Click on the + sign on the left to edit the code. ">
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response, "GET");
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response, "POST");
    }
    
    public String getServletInfo() { return KEYNAME; }
    // </editor-fold>
    
    private void processRequest(HttpServletRequest req, HttpServletResponse res, String reqMethod) throws ServletException, IOException 
    {
        PrintWriter out = null;
        Helper helper = new Helper();
        
        try
        { 
            res.setContentType("text/plain"); 
            out = res.getWriter(); 
            
            String pathInfo = req.getPathInfo(); 
            if (pathInfo == null || pathInfo.trim().length() == 0) 
                throw new Exception("'PathInfo' is required"); 
            
            StringBuffer path = new StringBuffer(); 
            path.append(System.getProperty("jboss.server.home.dir",""));
            if (!path.toString().endsWith("/")) path.append("/"); 
            
            path.append(pathInfo); 
            
            File file = new File(path.toString()); 
            if (!file.exists()) throw new Exception("'"+pathInfo+"' resource not found"); 
            
            out.println("AbsolutePath=" + file.getAbsolutePath()); 
            out.println("CanonicalPath=" + file.getCanonicalPath()); 
            out.println("Name=" + file.getName()); 
            out.println("Parent=" + file.getParent()); 
            out.println("Path=" + file.getPath()); 
            out.println("Directory=" + file.isDirectory()); 
            out.println("Hidden=" + file.isHidden()); 
            out.println("LastModifiedMillis=" + file.lastModified()); 
            out.println("LastModifiedDate=" + new Date(file.lastModified())); 
            
            HttpURLConnection conn = null; 
            try
            {
                URL url = file.toURL(); 
                conn = (HttpURLConnection) url.openConnection(); 
                out.println("ContentType=" + conn.getContentType());
                out.println("ContentEncoding=" + conn.getContentEncoding());
                out.println("ContentLength=" + conn.getContentLength());
            }
            catch(Exception ex) {;} 
            finally {
                try { conn.disconnect(); }catch(Exception ign){;} 
            }
        } 
        catch(Exception ex) 
        { 
            out.println("ERROR: "); 
            out.println(helper.getStackTrace(ex)); 
        }
        finally {
            try { out.close(); }catch(Exception ing){;} 
        } 
    }         
    
}
