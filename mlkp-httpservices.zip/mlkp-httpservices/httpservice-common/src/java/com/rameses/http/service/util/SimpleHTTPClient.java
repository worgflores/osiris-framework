package com.rameses.http.service.util;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;

public class SimpleHTTPClient 
{
    private Properties reqProperties = new Properties();
    private String gatewayHost = null; 
    private String host = null;
    private int connectTimeout;
    private int readTimeout;
    
    public SimpleHTTPClient(String host) {
        this.host = host;
    }
    
    public SimpleHTTPClient(String host, String gatewayHost) 
    {
        this.host = host;
        this.gatewayHost = gatewayHost; 
    }    
    
    public int getConnectTimeout() { return connectTimeout; }
    public void setConnectTimeout(int connectTimeout) { this.connectTimeout = connectTimeout; }

    public int getReadTimeout() { return readTimeout; }
    public void setReadTimeout(int readTimeout) { this.readTimeout = readTimeout; }
    
    public String getRequestProperty(String key) {
        return reqProperties.getProperty(key);
    }
    
    public void setRequestProperty(String key, String value) {
        reqProperties.setProperty(key, value);
    }
    
    public Object post(String opName, Map params) throws Exception {
        return post(opName, createQueryString(params));
    }

    public Object post(String opName, String queryString) throws Exception {
        return invoke(opName, queryString, "POST");
    }
    
    public Object get(String opName, Map params) throws Exception {
        return get(opName, createQueryString(params));
    }

    public Object get(String opName, String queryString) throws Exception {
        return invoke(opName, queryString, "GET");
    }
    
    private String createQueryString(Map params) throws Exception 
    {
        StringBuffer buffer = new StringBuffer();
        if (params != null) 
        {
            Iterator entries = params.entrySet().iterator();
            while (entries.hasNext()) 
            {
                Map.Entry entry = (Map.Entry) entries.next();
                if (entry.getKey() == null) continue;

                Object oval = entry.getValue();
                if (oval == null) oval = "";

                if (buffer.length() > 0) buffer.append("&");

                buffer.append(entry.getKey() + "=" + URLEncoder.encode(oval.toString()));
            }
        } 
        return buffer.toString(); 
    }
    
    private Object invoke(String pathInfo, String queryString, String requestMethod) throws Exception 
    {
        HttpURLConnection conn = null;
        OutputStream out = null;
        InputStream inp = null;
        URL url = null; 
                
        try 
        {
            boolean hasGatewayHost = (gatewayHost != null); 
            String urlhost = null; 
            
            if (hasGatewayHost) { 
                urlhost = gatewayHost; 
            } 
            else 
            {
                urlhost = host; 
                if (pathInfo != null && pathInfo.length() > 0)
                    urlhost = host + "/" + pathInfo;
            }

            url = new URL(urlhost); 
            conn = (HttpURLConnection) url.openConnection();
            
            Iterator entries = reqProperties.entrySet().iterator();
            while (entries.hasNext()) 
            {
                Map.Entry entry = (Map.Entry) entries.next();
                if (entry.getKey() == null) continue;
                
                Object oval = entry.getValue();
                if (oval == null) oval = "";
                
                conn.setRequestProperty(entry.getKey().toString(), oval.toString());
            }
                        
            conn.setRequestMethod(requestMethod);
            conn.setDoInput(true);
            conn.setDoOutput(true);
            conn.setUseCaches(false);
            
            int cTimeout = getConnectTimeout(); 
            int rTimeout = getReadTimeout(); 
            if (cTimeout > 0) conn.setConnectTimeout(cTimeout); 
            if (rTimeout > 0) conn.setReadTimeout(rTimeout); 
            
            if (hasGatewayHost) 
            {
                conn.setRequestProperty("App-Host", host);
                conn.setRequestProperty("App-PathInfo", pathInfo); 
            }
            
            try 
            {
                if (queryString == null) queryString = "";
                
                out = conn.getOutputStream();
                out.write(queryString.getBytes());
                out.flush();
            } 
            catch(Exception ex) {
                throw ex;
            }
            
            try  {
                inp = conn.getInputStream();
            } catch(java.io.IOException ioe) {
                return getErrorMessage(conn);
            } catch(Exception ex) {
                throw ex;
            }
            
            try 
            {
                int read = -1;
                StringBuffer sb = new StringBuffer();
                while ((read=inp.read()) != -1) {
                    sb.append((char) read);
                }
                return sb.toString();
            } 
            catch(Exception ex) {
                throw ex;
            }
        } 
        catch(Exception ex) {
            throw ex;
        } 
        finally 
        {
            try { inp.close(); }catch(Exception ign){;}
            try { out.close(); }catch(Exception ign){;}
            try { conn.disconnect(); }catch(Exception ign){;}
        }
    }
    
    private String getErrorMessage(HttpURLConnection conn) throws Exception 
    {
        InputStream inp = null;
        try 
        {
            inp = conn.getErrorStream();
            int read = -1;
            StringBuffer sb = new StringBuffer();
            while ((read=inp.read()) != -1) {
                sb.append((char) read);
            }
            return sb.toString();
        } 
        catch(Exception ex) {
            return ex.getClass().getName() + ": " + ex.getMessage();
        } 
        finally {
            try { inp.close(); }catch(Exception ing){;}
        }
    }
}
