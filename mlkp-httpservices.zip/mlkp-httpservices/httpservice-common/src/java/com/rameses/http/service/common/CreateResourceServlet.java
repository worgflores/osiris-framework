package com.rameses.http.service.common;

import java.io.*;
import java.net.*;

import javax.servlet.*;
import javax.servlet.http.*;

public class CreateResourceServlet extends HttpServlet 
{
    private String KEYNAME = "services/common/createResource"; 
    
    // <editor-fold defaultstate="collapsed" desc=" HttpServlet methods. Click on the + sign on the left to edit the code. ">
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        processRequest(req, resp); 
    }        
    
    public String getServletInfo() { return KEYNAME; }
    // </editor-fold>
    
    private void processRequest(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException 
    {
        ObjectInputStream ois = null;
        ObjectOutputStream oos = null; 
        Helper helper = new Helper();
        
        try
        { 
            ois = new ObjectInputStream(req.getInputStream());
            byte[] bytes = (byte[]) ois.readObject();            
            
            String pathInfo = req.getPathInfo(); 
            if (pathInfo == null || pathInfo.trim().length() == 0)
                throw new Exception("'PathInfo' is required");
            
            StringBuffer path = new StringBuffer(); 
            path.append(System.getProperty("jboss.server.home.dir",""));
            if (!path.toString().endsWith("/")) path.append("/"); 
            
            path.append(pathInfo); 
            
            File file = new File(path.toString()); 
            if (file.exists()) throw new ServletException("'"+pathInfo+"' resource already exist"); 
            if (file.isDirectory()) throw new ServletException("'"+pathInfo+"' resource is a directory"); 

            FileOutputStream fos = null;
            try 
            {
                fos = new FileOutputStream(file); 
                fos.write(bytes); 
                fos.flush(); 
            } 
            catch(Exception ex) {
                throw ex; 
            }
            finally { 
                try{ fos.close(); }catch(Exception ign){;} 
            } 
            
            oos = new ObjectOutputStream(res.getOutputStream());
            oos.writeObject("success");
        } 
        catch(Exception ex) 
        { 
            String errmsg = ex.getMessage(); 
            String className = ex.getClass().getName();
            if (className.startsWith("java.io.") || className.startsWith("java.net.")) 
                errmsg = ex.getClass().getName() + ": " + ex.getMessage();
            
            oos = new ObjectOutputStream(res.getOutputStream());
            oos.writeObject("ERROR: " + errmsg + "\n" + helper.getStackTrace(ex));
        } 
        finally 
        {
            try { oos.close(); }catch(Exception ing){;} 
            try { ois.close(); }catch(Exception ing){;} 
        } 
    }  
}
