package com.rameses.http.service.common;

import com.rameses.http.service.util.SimpleHTTPClient;
import java.io.*;
import java.net.URLEncoder;
import java.util.Enumeration;

import javax.servlet.*;
import javax.servlet.http.*;

public class SimpleHTTPInvokerServlet extends HttpServlet 
{
    private String KEYNAME = "services/common/SimpleHTTPInvoker";
    
    // <editor-fold defaultstate="collapsed" desc=" HttpServlet methods. Click on the + sign on the left to edit the code. ">
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response, "GET");
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response, "POST");
    }
    
    public String getServletInfo() { return KEYNAME; }
    // </editor-fold>
        
    private void processRequest(HttpServletRequest req, HttpServletResponse res, String reqMethod) throws ServletException, IOException 
    {
        PrintWriter out = null;
        Helper helper = new Helper();
        String appHost = req.getHeader("App-Host");
        String appPathInfo = req.getHeader("App-PathInfo"); 
        
        try 
        { 
            out = res.getWriter(); 
                        
            String op = req.getParameter("op");
            if ("dumpinfo".equals(op)) 
            {
                out.println("[Attributes]");
                Enumeration attrNames = req.getAttributeNames();
                while (attrNames.hasMoreElements()) 
                {
                    String name = attrNames.nextElement().toString(); 
                    out.println(name + "=" + req.getAttribute(name)); 
                }

                out.println(""); 
                out.println("[Headers]");
                Enumeration headerNames = req.getHeaderNames();
                while (headerNames.hasMoreElements()) 
                {
                    String name = headerNames.nextElement().toString(); 
                    out.println(name + "=" + req.getHeader(name));  
                } 
                
                out.println(""); 
                out.println("[Properties]");
                out.println("contextPath=" + req.getContextPath());  
                out.println("method=" + req.getMethod());  
                out.println("pathInfo=" + req.getPathInfo());  
                out.println("pathTranslated=" + req.getPathTranslated());  
                out.println("queryString=" + req.getQueryString());  
                out.println("remoteAddr=" + req.getRemoteAddr());  
                out.println("remoteHost=" + req.getRemoteHost());  
                out.println("remotePort=" + req.getRemotePort());  
                out.println("remoteUser=" + req.getRemoteUser());  
                out.println("requestURI=" + req.getRequestURI());  
                out.println("requestedSessionId=" + req.getRequestedSessionId());  
                out.println("servletPath=" + req.getServletPath());  
                out.println("userPrincipal=" + req.getUserPrincipal());  
                out.println("Request-Object=" + req.toString()); 
            } 
            else 
            {
                if (appHost == null || appHost.trim().length() == 0) 
                    throw new Exception("'App-Host' request header is required"); 
                
                StringBuffer buffer = new StringBuffer(); 
                Enumeration names = req.getParameterNames();
                while (names.hasMoreElements()) 
                {
                    String name = names.nextElement().toString(); 
                    String value = req.getParameter(name); 
                    if (value == null) value = ""; 
                    
                    if (buffer.length() > 0) buffer.append("&"); 

                    buffer.append(name + "=" + URLEncoder.encode(value)); 
                } 
                
                SimpleHTTPClient c = new SimpleHTTPClient(appHost); 
                Enumeration headerNames = req.getHeaderNames();
                while (headerNames.hasMoreElements()) 
                {
                    String name = headerNames.nextElement().toString(); 
                    if ("content-type".equalsIgnoreCase(name))
                        c.setRequestProperty(name, req.getHeader(name));   
                    else if ("user-agent".equalsIgnoreCase(name))
                        c.setRequestProperty(name, req.getHeader(name));   
                } 

                Object result = null; 
                if ("POST".equalsIgnoreCase(reqMethod+"")) 
                    result = c.post(appPathInfo, buffer.toString()); 
                else 
                    result = c.get(appPathInfo, buffer.toString()); 
                
                out.println(result+""); 
            } 
        } 
        catch(Exception ex) 
        { 
            System.out.println("App-Host: " + appHost); 
            System.out.println("App-PathInfo: " + appPathInfo); 
            System.out.println("ERROR: " + ex.getMessage());
            ex.printStackTrace();
            
            out.println("ERROR: " + ex.getMessage()); 
            out.println(helper.getStackTrace(ex)); 
        }
        finally 
        {
            try { out.close(); }catch(Exception ing){;} 
        } 
    } 
    
    private String toString(InputStream inp) throws Exception 
    {
        StringBuffer sb = new StringBuffer(); 
        int read = -1;
        while ((read=inp.read()) != -1) {
            sb.append((char) read); 
        } 
        
        try { inp.close(); }catch(Exception ing){;}
        
        return sb.toString(); 
    }
    
} 
