package com.rameses.http.service.common;

import java.io.*;
import java.util.Calendar;

import javax.servlet.*;
import javax.servlet.http.*;

public class ResourceTouchServlet extends HttpServlet 
{
    private String KEYNAME = "services/common/touchResource"; 
    
    // <editor-fold defaultstate="collapsed" desc=" HttpServlet methods. Click on the + sign on the left to edit the code. ">
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response, "GET");
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response, "POST");
    }
    
    public String getServletInfo() { return KEYNAME; }
    // </editor-fold>
    
    private void processRequest(HttpServletRequest req, HttpServletResponse res, String reqMethod) throws ServletException, IOException 
    {
        PrintWriter out = null;
        Helper helper = new Helper();
        
        try
        { 
            res.setContentType("text/plain"); 
            out = res.getWriter(); 
            
            String pathInfo = req.getPathInfo(); 
            if (pathInfo == null || pathInfo.trim().length() == 0) 
                throw new Exception("'PathInfo' is required"); 
            
            StringBuffer path = new StringBuffer(); 
            path.append(System.getProperty("jboss.server.home.dir",""));
            if (!path.toString().endsWith("/")) path.append("/"); 
            
            path.append(pathInfo); 
            
            File file = new File(path.toString()); 
            if (!file.exists()) throw new Exception("'"+pathInfo+"' resource not found"); 
            if (file.isDirectory()) throw new Exception("'"+pathInfo+"' resource is a directory"); 
            
            Calendar cal = Calendar.getInstance();
            cal.setTimeInMillis(file.lastModified()); 
            cal.add(Calendar.SECOND, 1); 
            file.setLastModified(cal.getTimeInMillis()); 
            
            out.println("success"); 
            out.println(file.lastModified()+"");
            out.println(cal.getTime()+"");
        } 
        catch(Exception ex) 
        { 
            out.println("ERROR: "); 
            out.println(helper.getStackTrace(ex)); 
        }
        finally {
            try { out.close(); }catch(Exception ing){;} 
        } 
    }         
}
