package test;

import java.util.HashMap;
import java.util.Map;
import junit.framework.*;

public class NewEmptyJUnitTest extends TestCase {
    
    public NewEmptyJUnitTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
    }

    protected void tearDown() throws Exception {
    }
    
    public void test0000() throws Exception 
    {
        HttpServiceClient c = new HttpServiceClient();
        Map map = new HashMap(); 
        map.put("BRANCHID", "MIS");
        map.put("CURRENCYID", "PHP");
        map.put("PRINCIPAL", new Double(100.0));
        
        Object o = c.invoke("http://192.168.3.246:8080/services/rule/invoker~/getForexList?_host=http://192.168.3.246:8080/mlhuillier/action&_debug=true", map); 
        System.out.println(o);
    }
}
