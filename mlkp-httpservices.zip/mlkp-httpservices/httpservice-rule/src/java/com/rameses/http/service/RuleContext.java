package com.rameses.http.service;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import rameses.osiris.common.interfaces.IDataModel;
import rameses.osiris.common.interfaces.IDataSetModel;
import rameses.osiris.common.service.Request;
import rameses.osiris.common.service.Response;

public class RuleContext 
{
    private HttpServletRequest req;
    private String apphost;
    private String rulename;
    private boolean debug;
    private int timeout;
    
    public RuleContext(HttpServletRequest req) {
        this.req = req; 
    }
    
    public boolean isDebug(HttpServletRequest req) 
    { 
        debug = "true".equalsIgnoreCase(req.getParameter("_debug")+"");
        return debug; 
    } 
    
    public boolean isDebug() { return debug; } 
    public int getTimeout() { return timeout; }

    public void initialize() throws ServletException
    {
        String pathInfo = req.getPathInfo(); 
        if (pathInfo == null || "/".equals(pathInfo))
            throw new ServletException("'pathInfo' request is required");

        String rulename = pathInfo.substring(1); 
        String apphost = req.getParameter("_host"); 
        if (apphost == null || apphost.trim().length() == 0) 
            apphost = getAppHost(); 
        if (apphost == null || apphost.trim().length() == 0) 
            throw new ServletException("'host' parameter is required"); 
        
        this.apphost = apphost; 
        this.rulename = rulename; 
        
        debug = "true".equalsIgnoreCase(req.getParameter("_debug")+"");
        try { timeout = Integer.parseInt(req.getParameter("_timeout")); } catch(Exception ign) {;}         
    }
 
    private String getAppHost() 
    {
        String apphost = System.getProperty("HttpRuleService.host", ""); 
        if (apphost == null || apphost.trim().length() == 0) 
        {
            InputStream inp = null;
            try 
            {
                ClassLoader loader = Thread.currentThread().getContextClassLoader();
                URL url = loader.getResource("mlkpsoap.properties"); 
                if (url != null) 
                {
                    inp = url.openStream(); 
                
                    Properties props = new Properties(); 
                    props.load(inp); 
                    
                    apphost = props.getProperty("app.host", ""); 
                    if (apphost != null && apphost.trim().length() > 0) 
                        System.setProperty("HttpRuleService.host", apphost); 
                } 
            }
            catch(Exception ign) { 
                System.out.println("[ERROR " + getClass().getSimpleName() + "] " + ign.getClass().getName() + ": " +  ign.getMessage());
            } 
            finally {
                try { inp.close(); }catch(Exception ign){;} 
            }
        }
        return apphost; 
    } 
    
    public Object[] resolveException(Throwable t)
    {
        Throwable p = t;
        while (true)
        {
            String msg = p.getMessage(); 
            if (msg != null) 
            {
                int idx0 = msg.indexOf("ErrCode("); 
                int idx1 = -1;

                if (idx0 >= 0) idx1 = msg.indexOf(')', idx0); 

                String errcode = "0";
                String errmsg = msg;
                
                try { errcode = msg.substring(idx0+8, idx1); } catch(Exception ign) {;}
                try { errmsg  = msg.substring(idx1+1); } catch(Exception ign) {;}
                
                return new Object[]{ t, errmsg, errcode };
            } 
            else  
            {
                if (p.getCause() == null) break;
                
                p = p.getCause(); 
            }  
        }
        
        return new Object[]{ t, t.getMessage(), "0" };
    } 

    public Map invoke(Map params) throws Exception 
    {
        if (apphost == null || apphost.trim().length() == 0)
            throw new NullPointerException("'host' parameter is required");
        if (rulename == null || rulename.trim().length() == 0)
            throw new NullPointerException("'action' parameter is required");

        HttpURLConnection conn = null;
        ObjectOutputStream oos = null;
        ObjectInputStream ois = null;
        try 
        {
            URL url = new URL(apphost);
            conn = (HttpURLConnection) url.openConnection();
            conn.setDoOutput(true); 
            conn.setUseCaches(false); 
            if (timeout > 0) conn.setConnectTimeout(timeout);  

            Request req = new Request(); 
            req.addHeader("ACTION", rulename);

            Iterator paramKeys = params.keySet().iterator(); 
            while (paramKeys.hasNext()) 
            {
                Object paramKey = paramKeys.next(); 
                Object paramVal = params.get(paramKey); 
                req.addParameter(paramKey.toString(), paramVal); 
            } 

            oos = new ObjectOutputStream(conn.getOutputStream());
            oos.writeObject(req);

            ois = new ObjectInputStream(conn.getInputStream());
            Object readObj = ois.readObject();
            if (readObj instanceof Exception) { 
                throw (Exception) readObj; 
            } 

            Response res = (Response) readObj; 
            switch (res.getMessageType()) 
            { 
                case Response.FATAL_ERROR: 
                    StringBuffer serr = new StringBuffer(); 
                    Iterator msgs =  res.getMessages().values().iterator(); 
                    while( msgs.hasNext() ) {
                        serr.append( msgs.next() + "\n" ); 
                    } 
                    throw new Exception(serr.toString()); 
            } 
            return res.getValues(); 
        } 
        catch (Exception ex) { 
            throw ex; 
        }  
        finally 
        {
            try { ois.close(); } catch(Exception ex){;}
            try { oos.close(); } catch(Exception ex){;}
            try { conn.disconnect(); } catch(Exception ex){;}
        } 
    }     
    
    public Map convertDataModel(IDataModel doc, Iterator fields) throws Exception 
    {
        Map data = new HashMap(); 
        while (fields.hasNext()) 
        {
            String fldname = fields.next().toString(); 
            data.put(fldname, doc.getValue(fldname)); 
        }
        return data;
    }
    
    public List convertDataSetModel(IDataSetModel idsm) throws Exception 
    {
        List list = new ArrayList(); 
        for (int i=0; i<idsm.size(); i++)
        {
            IDataModel doc = idsm.getItem(i); 
            list.add(convertDataModel(doc, idsm.getFields()));
        }
        return list;
    }    
    
    public String getStackTrace(Exception ex)
    {
        ByteArrayOutputStream baos = null;
        try
        {
            baos = new ByteArrayOutputStream();
            ex.printStackTrace(new PrintStream(baos));
            return new String(baos.toByteArray());
        }
        catch(Exception e) {
            return "";
        }
        finally {
            try { baos.close(); }catch(Exception ign) {;} 
        }
    } 
    
}
