package com.rameses.http.service;

import java.io.*;
import java.net.URLEncoder;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.servlet.*;
import javax.servlet.http.*;
import rameses.osiris.common.interfaces.IDataModel;
import rameses.osiris.common.interfaces.IDataSetModel;

public class SimpleRuleInvokerServlet extends HttpServlet 
{
    private String KEYNAME = "services/rule/invoker";
    
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);
    }
    
    public String getServletInfo() { return KEYNAME; }
    // </editor-fold>
    
    protected void processRequest(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException 
    {
        PrintWriter out = null;
        RuleContext ctx = new RuleContext(req); 
        
        try
        {
            out = res.getWriter(); 
            ctx.initialize(); 
                        
            Map params = new HashMap(); 
            Enumeration names = req.getParameterNames(); 
            while (names.hasMoreElements()) 
            {
                String key = names.nextElement().toString(); 
                if ("_host".equalsIgnoreCase(key)) continue; 
                if (key.startsWith("_")) continue; 
                
                String val = req.getParameter(key); 
                try {
                    params.put(key.toUpperCase(), URLEncoder.encode(val.toString())); 
                } catch(Exception ex) { 
                    params.put(key.toUpperCase(), ""); 
                } 
            } 
            
            Map map = ctx.invoke(params); 
            Iterator keys = map.keySet().iterator(); 
            while (keys.hasNext()) 
            { 
                String key = keys.next().toString(); 
                Object val = map.get(key);
                if (val instanceof IDataModel)
                {
                    IDataModel idm = (IDataModel) val;
                    Iterator flds = idm.getFields();
                    if (val instanceof IDataSetModel)
                    {
                        IDataSetModel idsm = (IDataSetModel) val;
                        if (idsm.size() == 0) continue;
                        
                        idm = idsm.getItem(0); 
                        flds = idsm.getFields(); 
                    }
                    
                    String idmname = idm.getName();
                    if (idmname == null) idmname = "data";
                    
                    while (flds.hasNext()) 
                    {
                        String fldname = flds.next().toString(); 
                        try { 
                            out.println(idmname + "_" + fldname + "=" + idm.getValue(fldname)); 
                        } catch(Exception ign){;} 
                    } 
                } 
                else { 
                    out.println(key + "=" + val); 
                } 
            }             
            out.println("respcode=1"); 
            out.println("respmsg=success"); 
        }
        catch(Exception ex) 
        {
            System.out.println("[ERROR " + KEYNAME + "] " + ex.getClass().getName() + ": " + ex.getMessage());   
            
            Object[] arr = ctx.resolveException(ex); 
            String errcode = "0"; 
            Object errmsg = null;
            try { errcode = arr[2].toString(); }catch(Exception ign){;} 
            try { errmsg = arr[1]; }catch(Exception ign){;} 
            
            out.println("respcode=0"); 
            out.println("respmsg=" + errmsg); 
            out.println("errcode=" + errcode); 
            out.println("respdetail=" + ctx.getStackTrace(ex)); 
        }
        finally {
            try { out.close(); }catch(Exception ing){;}             
        }        
    }
    
}
