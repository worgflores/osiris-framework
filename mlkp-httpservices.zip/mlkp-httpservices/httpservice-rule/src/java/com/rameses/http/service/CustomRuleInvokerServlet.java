package com.rameses.http.service;

import java.io.*;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.servlet.*;
import javax.servlet.http.*;
import rameses.osiris.common.interfaces.IDataModel;
import rameses.osiris.common.interfaces.IDataSetModel;

public class CustomRuleInvokerServlet extends HttpServlet 
{
    private String KEYNAME = "services/rule/invoker~";
    
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    protected void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        processRequest(req, res); 
    }
    
    public String getServletInfo() { return KEYNAME; }
    // </editor-fold>
    
    protected void processRequest(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException 
    {
        ObjectInputStream ois = null;
        ObjectOutputStream oos = null; 
        RuleContext ctx = new RuleContext(req); 
        try
        {
            ois = new ObjectInputStream(req.getInputStream());
            Map params = (Map) ois.readObject();

            ctx.initialize();
            
            Map result = ctx.invoke(params); 
            Iterator keys = result.keySet().iterator(); 
            while (keys.hasNext()) 
            { 
                String key = keys.next().toString(); 
                Object val = result.get(key);
                if (val instanceof IDataModel)
                {
                    IDataModel idm = (IDataModel) val;
                    if (val instanceof IDataSetModel)
                        result.put(idm.getName(), ctx.convertDataSetModel((IDataSetModel) val)); 
                    else 
                        result.put(idm.getName(), ctx.convertDataModel(idm, idm.getFields()));
                } 
            }           
            
            result.put("respcode", "1"); 
            result.put("respmsg", "success"); 
            
            oos = new ObjectOutputStream(res.getOutputStream());
            oos.writeObject(result);            
        }
        catch(Exception ex) 
        {
            System.out.println("[ERROR " + KEYNAME + "] " + ex.getClass().getName() + ": " + ex.getMessage());   
            
            if (ctx.isDebug(req)) ex.printStackTrace(); 
            
            Object[] arr = ctx.resolveException(ex); 
            String errcode = "0"; 
            Object errmsg = null;
            try { errcode = arr[2].toString(); }catch(Exception ign){;} 
            try { errmsg = arr[1]; }catch(Exception ign){;} 
            
            Map result = new HashMap(); 
            result.put("respcode", "0"); 
            result.put("respmsg", ex.getMessage());
            result.put("errcode", errcode); 
            result.put("respdetail", ctx.getStackTrace(ex));           
            
            oos = new ObjectOutputStream(res.getOutputStream());
            oos.writeObject(result); 
        }
        finally 
        {
            try { oos.close(); }catch(Exception ing){;}
            try { ois.close(); }catch(Exception ing){;}
        } 
    } 
} 
