package test;

import com.rameses.http.service.util.HTTPSOAPClient;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import junit.framework.*;

public class NewEmptyJUnitTest extends TestCase 
{
    
    public NewEmptyJUnitTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
    }

    protected void tearDown() throws Exception {
    }
    
    public void xtestHTTPSOAPInvoker() throws Exception
    {
        HTTPSOAPClient c = new HTTPSOAPClient(); 
        Object o = c.invoke("http://192.168.50.111:8080/services/common/HTTPSOAPInvoker?op=dumpinfo", "TESTAction", "<soap:envelope/>");
        System.out.println(o);
    }
    
    public void xtestCreateResource() throws Exception
    {
        HttpServiceClient c = new HttpServiceClient();
    }
        
    
    public void xtestUpdateResource() throws Exception
    {
        ByteArrayOutputStream baos = null;
        InputStream inp = null; 
        byte[] bytes = null;
        
        try
        {
            inp = new FileInputStream(new File("D:\\Applications\\jboss-4.0.5.GA\\server\\mldb-transfer-18080\\apps\\mlweb.ear\\app-libs.jar\\schedulermonitoring.jar\\controllers\\rmilogviewer.xml")); 
            baos = new ByteArrayOutputStream(); 
            int read = -1;
            while ((read=inp.read()) != -1) {
                baos.write(read); 
            }
            bytes = baos.toByteArray(); 
        }
        catch(Exception ex) {
            throw ex; 
        }
        finally 
        {
            try { baos.close(); }catch(Exception ign){;} 
        }
        
        HttpServiceClient c = new HttpServiceClient(); 
        Object result = c.invoke("http://192.168.3.190:8080/services/common/createResource/apps-core/schedulermonitoring.jar/controllers/rmilogviewer.xml", bytes); 
        System.out.println(result);
    }
    
    private String getResourceContent(String resname) throws Exception 
    {
        ClassLoader loader = Thread.currentThread().getContextClassLoader(); 
        InputStream inp = loader.getResourceAsStream(resname); 
        try 
        {
            int read = -1;
            StringBuffer sb = new StringBuffer(); 
            while ((read=inp.read()) != -1) {
                sb.append((char) read); 
            }
            return sb.toString(); 
        }
        catch(Exception ex) {
            throw ex; 
        }
        finally {
            try { inp.close(); }catch(Exception ign){;} 
        }
    }
}



