package test;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import junit.framework.*;

public class SQLTest extends TestCase 
{
    
    public SQLTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
    }

    protected void tearDown() throws Exception {
    }
    
    public void xtestSQLSelect() throws Exception
    {
        HttpServiceProvider p = new HttpServiceProvider(); 
        Map req = new HashMap();
        req.put("dsname", "java:mldb");
        req.put("sql", "select now() as rundate");
        
        Object res = p.invoke("http://localhost:8080/services/common/SQLSelect", req); 
        System.out.println(res);
    }    
    
    public void testSQLUpdate() throws Exception 
    {
        HttpServiceProvider p = new HttpServiceProvider(); 
        Map req = new HashMap(); 
        req.put("dsname", "java:mldb"); 
        req.put("sql", "insert into test.x (txndate,txntype,custid) values (?, ?, ?) "); 
        req.put("sqlparam", new Object[]{new Date(), "test2", "t2"}); 
        
        Object res = p.invoke("http://localhost:8080/services/common/SQLUpdate", req);  
        System.out.println(res); 
    }    
    
}
