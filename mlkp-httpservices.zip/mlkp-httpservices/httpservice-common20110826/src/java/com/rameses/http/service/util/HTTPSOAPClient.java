package com.rameses.http.service.util;

import java.io.BufferedOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Iterator;
import java.util.Properties;

public class HTTPSOAPClient 
{
    private Properties properties = new Properties();
    private int timeout = 20000;
    
    public HTTPSOAPClient() {
    }
    
    public int getTimeout() { return timeout; }
    public void setTimeout(int timeout) { this.timeout = timeout; }
    
    public void removeProperties() { properties.clear();  }
    
    public void rmoveProperty(String key) {
        properties.remove(key); 
    }
    
    public void setProperty(String key, String value) {
        properties.setProperty(key, value);
    }
    

    public Object send(String gatewayhost, String soaphost, String soapaction, String soaprequest) throws Exception 
    {  
        HttpURLConnection conn = null;
        OutputStream out = null;
        InputStream inp = null; 
        BufferedOutputStream bos = null;
        
        try
        {
            URL url = new URL(gatewayhost); 
            conn = (HttpURLConnection) url.openConnection(); 
            if (getTimeout() > 0) conn.setConnectTimeout(getTimeout()); 
            
            conn.setRequestMethod("POST"); 
            conn.setRequestProperty("User-Agent", "MLhuillier"); 
            conn.setRequestProperty("Content-Type", "text/xml;charset=utf-8"); 
            conn.setRequestProperty("SOAPHost", soaphost); 
            conn.setRequestProperty("SOAPAction", soapaction);
            
            Iterator keys = properties.keySet().iterator(); 
            while (keys.hasNext()) 
            {
                String key = keys.next().toString(); 
                String val = properties.getProperty(key); 
                if (val == null) continue; 
                
                conn.setRequestProperty(key, val); 
            }
            
            conn.setDoOutput(true); 
            conn.setDoInput(true); 
            
            try
            {
                out = conn.getOutputStream(); 
                out.write(soaprequest.getBytes());
                out.flush(); 
            }
            catch(Exception ex) {
                throw ex; 
            }
            
            try { 
                inp = conn.getInputStream(); 
            } 
            catch(java.io.IOException ioe) {
                return getErrorMessage(conn); 
            }
            catch(Exception ex) {
                throw ex; 
            }            
            
            try
            {
                int read = -1;
                StringBuffer sb = new StringBuffer();
                while ((read=inp.read()) != -1) {
                    sb.append((char) read); 
                }
                return sb.toString(); 
            }
            catch(Exception ex) {
                throw ex; 
            }
        }
        catch(Exception ex) {
            throw ex; 
        }
        finally 
        {
            try { inp.close(); }catch(Exception ing){;} 
            try { out.close(); }catch(Exception ing){;} 
            try { conn.disconnect(); }catch(Exception ing){;} 
        }        
    } 
    
    public Object invoke(String soaphost, String soapaction, String soaprequest) throws Exception
    {
        HttpURLConnection conn = null;
        OutputStream out = null;
        InputStream inp = null; 
        BufferedOutputStream bos = null;
        
        try
        {
            URL url = new URL(soaphost); 
            conn = (HttpURLConnection) url.openConnection(); 
            if (getTimeout() > 0) conn.setConnectTimeout(getTimeout()); 
            
            conn.setRequestMethod("POST"); 
            conn.setRequestProperty("User-Agent", "MLhuillier"); 
            conn.setRequestProperty("Content-Type", "text/xml;charset=UTF-8"); 
            conn.setRequestProperty("SOAPAction", soapaction); 
            
            Iterator keys = properties.keySet().iterator(); 
            while (keys.hasNext()) 
            {
                String key = keys.next().toString(); 
                String val = properties.getProperty(key); 
                if (val == null) continue; 
                
                conn.setRequestProperty(key, val); 
            }
            
            conn.setDoOutput(true); 
            conn.setDoInput(true); 
            
            try
            {
                out = conn.getOutputStream(); 
                out.write(soaprequest.getBytes());
                out.flush(); 
            }
            catch(Exception ex) {
                throw ex; 
            }

            try { 
                inp = conn.getInputStream(); 
            } 
            catch(java.io.IOException ioe) {
                return getErrorMessage(conn); 
            }
            catch(Exception ex) {
                throw ex; 
            }            
            
            try
            {
                int read = -1;
                StringBuffer sb = new StringBuffer();
                while ((read=inp.read()) != -1) {
                    sb.append((char) read); 
                }
                return sb.toString(); 
            }
            catch(Exception ex) {
                throw ex; 
            }
        }
        catch(Exception ex) {
            throw ex; 
        }
        finally 
        {
            try { inp.close(); }catch(Exception ing){;} 
            try { out.close(); }catch(Exception ing){;} 
            try { conn.disconnect(); }catch(Exception ing){;} 
        }
    }
    
    private String getErrorMessage(HttpURLConnection conn) throws Exception 
    {
        InputStream inp = null;
        try
        {
            inp = conn.getErrorStream(); 
            
            int read = -1;
            StringBuffer sb = new StringBuffer(); 
            while ((read=inp.read()) != -1) { 
                sb.append((char) read); 
            } 
            return sb.toString(); 
        } 
        catch(Exception ex) { 
            throw ex; 
        } 
        finally { 
            try { inp.close(); }catch(Exception ing){;} 
        }
    }
}
