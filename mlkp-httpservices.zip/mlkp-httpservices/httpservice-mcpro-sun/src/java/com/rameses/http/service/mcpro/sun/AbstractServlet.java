package com.rameses.http.service.mcpro.sun;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import javax.servlet.*;
import javax.servlet.http.*;

public abstract class AbstractServlet extends HttpServlet 
{
    protected static Object TREE_LOCKED = new Object();
        
    // <editor-fold defaultstate="collapsed" desc=" HttpServlet methods. Click on the + sign on the left to edit the code. ">
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response, "GET");
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response, "POST");
    }
    
    public void init() throws ServletException 
    {
        Config.getInstance();
    }    
    // </editor-fold>

    public abstract String getServletInfo();
    
    protected abstract void processRequest(HttpServletRequest req, HttpServletResponse res, String reqMethod) throws ServletException, IOException;  
    
    String login(HttpServletRequest req) throws Exception
    {
        String sesskey = "_session" + new SimpleDateFormat("yyyyMMdd").format(new Date()); 
        if (!Config.getInstance().getProperties().containsKey(sesskey))
        {
            Map params = new HashMap(); 
            params.put("user", Config.getInstance().getUserName()); 
            params.put("pass", Config.getInstance().getPassword()); 

            String urlpath = Config.getInstance().getProperty("login.url"); 
            String result = invoke(req, urlpath, "POST", params); 
            String[] arr = result.split(","); 
            if (!"20100".equals(arr[0])) 
                throw new Exception(result); 

            String sessionid = arr[2].trim(); 
            Config.getInstance().getProperties().put(sesskey, sessionid); 
            Config.getInstance().getProperties().put("_sessionid", sessionid); 
            return sessionid;
        }  
        else 
            return Config.getInstance().getProperty(sesskey); 
    } 
    
    
    String invoke(HttpServletRequest req, String urlpath, String reqMethod, Map params) throws Exception 
    {
        URLConnection conn = null; 
        try
        {
            URL url = new URL(urlpath); 
            conn = url.openConnection(); 
            if (conn instanceof HttpURLConnection)
            {
                if (reqMethod != null && reqMethod.length() > 1) 
                    ((HttpURLConnection) conn).setRequestMethod(reqMethod); 
            }
            
            StringBuffer buff = new StringBuffer(); 
            if (params != null)
            {
                int counter = 0;
                Iterator keys = params.keySet().iterator(); 
                while (keys.hasNext()) 
                {
                    String key = keys.next().toString(); 
                    Object val = params.get(key); 
                    if (val == null) val = ""; 
                    
                    if (counter > 0) buff.append("&"); 
                    
                    buff.append(URLEncoder.encode(key) + "=" + URLEncoder.encode(val.toString())); 
                    counter += 1;
                } 
            }
            
            conn.setDoInput(true);
            conn.setDoOutput(true);
            conn.setUseCaches(false); 
            
            try 
            { 
                int timeout = Integer.parseInt(req.getParameter("_timeout")); 
                conn.setConnectTimeout(timeout); 
            } 
            catch(Exception ing){;} 
            
            
            OutputStreamWriter osw = null;
            try
            {
                osw = new OutputStreamWriter(conn.getOutputStream()); 
                osw.write(buff.toString()); 
                osw.flush(); 
            } 
            catch(Exception e1) {
                throw e1;
            }
            finally {
                try { osw.close(); }catch(Exception ign){;} 
            }
            
            InputStream inp = conn.getInputStream(); 
            int read = -1; 
            
            try
            {
                StringBuffer resbuff = new StringBuffer(); 
                while ((read=inp.read()) != -1) {
                    resbuff.append((char) read); 
                } 
                return resbuff.toString(); 
            } 
            catch(Exception e1){
                throw e1; 
            } 
            finally {
                try { inp.close(); }catch(Exception ign){;} 
            }
        }
        catch(Exception ex) {
            throw ex; 
        }
    }
    
    protected String getStackTrace(Exception ex)
    {
        ByteArrayOutputStream baos = null;
        try
        {
            baos = new ByteArrayOutputStream();
            ex.printStackTrace(new PrintStream(baos));
            return new String(baos.toByteArray());
        }
        catch(Exception e) {
            return "";
        }
        finally {
            try { baos.close(); }catch(Exception ign) {;} 
        }
    }

}
