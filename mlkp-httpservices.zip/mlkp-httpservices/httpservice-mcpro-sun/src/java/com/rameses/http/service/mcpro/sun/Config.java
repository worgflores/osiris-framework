package com.rameses.http.service.mcpro.sun;

import java.io.File;
import java.io.FileWriter;
import java.io.InputStream;
import java.net.URL;
import java.util.Iterator;
import java.util.Properties;

public class Config 
{
    private static Config instance = null; 
    
    public static Config getInstance() 
    {
        if (instance == null) instance = new Config(); 
        
        return instance; 
    }

    private String confName = "mcpro-sun.conf"; 
    private Properties properties;  
    
    private Config() 
    {
        InputStream inp = null;
        try 
        { 
            ClassLoader loader = Thread.currentThread().getContextClassLoader();
            URL url = loader.getResource(confName); 
            if (url == null) throw new Exception("'"+confName+"' file does not exist"); 
            
            inp = url.openStream(); 

            properties = new Properties(); 
            properties.load(inp); 
        } 
        catch(Exception ex) { 
            throw new IllegalStateException(ex.getClass().getName() + ": " + ex.getMessage(), ex); 
        } 
        finally { 
            try { inp.close(); }catch(Exception ing){;} 
        }         
    }
    
    Properties getProperties() { return properties; }
    
    public String getUserName() { return properties.getProperty("user"); }
    public String getPassword() { return properties.getProperty("pass"); }
    
    public String getProperty(String key) { 
        return properties.getProperty(key); 
    } 
    
    public String getProperty(String key, String defaultValue) { 
        return properties.getProperty(key, defaultValue); 
    } 
    
    public void setProperty(String key, String value) {
        properties.put(key, value); 
    }

    void update(Properties props) throws Exception 
    { 
        Properties newprops = getSyncConfig(); 
        newprops.putAll(properties); 
        newprops.putAll(props); 
        
        FileWriter writer = null;  
        try
        {
            File file = new File(System.getProperty("jboss.server.home.dir") + "/conf/" + confName); 
            writer = new FileWriter(file); 
            
            Iterator keys = newprops.keySet().iterator(); 
            while (keys.hasNext()) 
            {
                String key = keys.next().toString(); 
                if (key.startsWith("_")) continue; 
                
                String val = newprops.getProperty(key, ""); 
                writer.write(key + "=" + val); 
                writer.write((char)13); 
                writer.write((char)10); 
            } 
            writer.flush(); 
        } 
        catch(Exception ex) {
            throw ex; 
        }
        finally { 
            try { writer.close(); }catch(Exception ign){;} 
        } 
        
        properties.putAll(newprops); 
    } 
    
    private Properties getSyncConfig() throws Exception 
    {
        InputStream inp = null;
        try 
        { 
            ClassLoader loader = Thread.currentThread().getContextClassLoader();
            URL url = loader.getResource(confName); 
            if (url == null) throw new Exception("'"+confName+"' file does not exist"); 
            
            inp = url.openStream(); 

            Properties p = new Properties(); 
            p.load(inp); 
            return p; 
        } 
        catch(Exception ex) { 
            throw new IllegalStateException(ex.getClass().getName() + ": " + ex.getMessage(), ex); 
        } 
        finally { 
            try { inp.close(); }catch(Exception ing){;} 
        } 
    } 
}
