package com.rameses.http.service.mcpro.sun;

import java.io.*;
import java.net.URLDecoder;
import java.util.Enumeration;
import java.util.Properties;
import javax.servlet.*;
import javax.servlet.http.*;

public class UpdateConfigServlet extends AbstractServlet
{
    private String KEYNAME = "services/mcpro-sun/updateConfig";
    
    public String getServletInfo() { return KEYNAME; }
    
    protected void processRequest(HttpServletRequest req, HttpServletResponse res, String reqMethod) throws ServletException, IOException 
    {
        PrintWriter out = null;
        
        try
        { 
            out = res.getWriter(); 
            
            Properties props = new Properties(); 
            Enumeration names = req.getParameterNames(); 
            while (names.hasMoreElements()) 
            {
                String name = names.nextElement().toString(); 
                String value = req.getParameter(name); 
                if (value == null) value = "";
                
                props.setProperty(name, URLDecoder.decode(value)); 
            } 
            
            if (!props.isEmpty()) Config.getInstance().update(props); 
            
            out.println("respcode=1");
            out.println("respmsg=success");
        } 
        catch(Exception ex) 
        { 
            out.println("respcode=0");
            out.println("respmsg=" + ex.getClass().getName() + ": " + ex.getMessage());
            out.println("respdetail=" + getStackTrace(ex));
        }
        finally {
            try { out.close(); }catch(Exception ing){;} 
        }
    }    

}
