package com.rameses.http.service.mcpro.sun;

import java.io.*;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import javax.servlet.*;
import javax.servlet.http.*;

public class StatusInquiryServlet extends AbstractServlet
{
    private String KEYNAME = "services/mcpro-sun/statusInquiry";
    
    public String getServletInfo() { return KEYNAME; }
    
    protected void processRequest(HttpServletRequest req, HttpServletResponse res, String reqMethod) throws ServletException, IOException 
    {
        PrintWriter out = null;
        
        try
        { 
            out = res.getWriter(); 
            
            String sessionid = login(req);
            
            Map params = new HashMap(); 
            params.put("user", Config.getInstance().getUserName()); 
            params.put("pass", Config.getInstance().getPassword()); 
            params.put("session", sessionid); 
            
            String sval = req.getParameter("transid");
            if (sval != null && sval.length() > 0) params.put("transid", sval);    

            sval = req.getParameter("msgid");
            if (sval != null && sval.length() > 0) params.put("msgid", sval);    

            sval = req.getParameter("msisdn");
            if (sval != null && sval.length() > 0) params.put("msisdn", sval);    

            sval = req.getParameter("dtefrom");
            if (sval != null && sval.length() > 0) params.put("dtefrom", sval);    
            
            sval = req.getParameter("dteto");
            if (sval != null && sval.length() > 0) params.put("dteto", sval);    
            
            String urlpath = Config.getInstance().getProperty("statusinquiry.url"); 
            String result = invoke(req, urlpath, "POST", params); 
            
            out.println("respcode=1");
            out.println("respmsg=success");
            out.println("result=" + result); 
        } 
        catch(Exception ex) 
        { 
            out.println("respcode=0");

            String className = ex.getClass().getName(); 
            if (className.startsWith("java.net.") || className.startsWith("java.io."))
                out.println("respmsg=" + className + ": " + ex.getMessage());
            else 
                out.println("respmsg=" + ex.getMessage());
            
            out.println("respdetail=" + getStackTrace(ex));
        }
        finally {
            try { out.close(); }catch(Exception ing){;} 
        }
    } 
}
