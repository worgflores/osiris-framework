package com.rameses.http.service.mcpro.sun;

import java.io.*;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import javax.servlet.*;
import javax.servlet.http.*;

public class SendMessageServlet extends AbstractServlet
{
    private String KEYNAME = "services/mcpro-sun/send";
    
    public String getServletInfo() { return KEYNAME; }
    
    protected void processRequest(HttpServletRequest req, HttpServletResponse res, String reqMethod) throws ServletException, IOException 
    {
        PrintWriter out = null;
        
        try
        { 
            out = res.getWriter(); 
            
            String sessionid = login(req);
            String from = req.getParameter("from");
            if (from == null || from.length() == 0)
                from = Config.getInstance().getProperty("send.msisdn");
            
            Map params = new HashMap(); 
            params.put("user", Config.getInstance().getUserName()); 
            params.put("pass", Config.getInstance().getPassword()); 
            params.put("session", sessionid); 
            params.put("from", from);
            params.put("to", req.getParameter("to")); 
            params.put("msg", req.getParameter("message")); 
            
            String urlpath = Config.getInstance().getProperty("send.url"); 
            String result = invoke(req, urlpath, "POST", params); 
            String[] arr = result.split(","); 
            if (!"20300".equals(arr[0])) 
                throw new Exception(result); 
            
            out.println("respcode=1");
            out.println("respmsg=success");
            out.println("result=" + result); 
        } 
        catch(Exception ex) 
        { 
            out.println("respcode=0");
            
            String className = ex.getClass().getName(); 
            if (className.startsWith("java.net.") || className.startsWith("java.io."))
                out.println("respmsg=" + className + ": " + ex.getMessage());
            else 
                out.println("respmsg=" + ex.getMessage());
            
            out.println("respdetail=" + getStackTrace(ex));
        }
        finally {
            try { out.close(); }catch(Exception ing){;} 
        }
    } 
}
