package common.net;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.security.KeyStore;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.KeyManager;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

public final class SSLLoader 
{
    private final static SSLLoader instance = new SSLLoader();
    private final static Object TREE_LOCKED = new Object(); 
    private static SSLSocketFactory sslSocketFactory = null; 
    
    public static SSLSocketFactory getSSLSocketFactory() 
    {
        try
        {
            if (sslSocketFactory != null) 
                HttpsURLConnection.setDefaultSSLSocketFactory(sslSocketFactory); 
        } 
        catch(Exception ex) {;} 
        
        return sslSocketFactory; 
    } 
    
    public static void initialize() throws Exception 
    {
        synchronized (TREE_LOCKED)
        {
            if (sslSocketFactory == null) 
            {
                System.out.println("   SSLLoader.instance-> " + instance);
                instance.initializeImpl(); 
                sslSocketFactory = instance.SSLSF; 
            } 
            else 
            {
                try {
                    HttpsURLConnection.setDefaultSSLSocketFactory(sslSocketFactory); 
                } catch(Exception ex) {
                    ex.printStackTrace(); 
                } 
            } 
        }  
    } 

    public static void reload() throws Exception 
    {
        synchronized (TREE_LOCKED)
        {
            instance.initializeImpl(); 
            sslSocketFactory = instance.SSLSF; 
            
            try {
                HttpsURLConnection.setDefaultSSLSocketFactory(sslSocketFactory); 
            } catch(Exception ex) {
                ex.printStackTrace(); 
            } 
        }         
    }
    
    
    private SSLSocketFactory SSLSF; 
    
    private SSLLoader() {}
    
    private void initializeImpl() throws Exception 
    {
        List kmlist = new ArrayList(); 
        File[] configFiles = getKeyStoreConfigFiles(); 
        if (configFiles == null) configFiles = new File[]{};

        for (int i=0; i<configFiles.length; i++) 
        {
            File configFile = configFiles[i]; 
            Properties props = getKeyStoreConfig(configFile); 
            if (props == null) continue; 

            try
            {
                File fileObj = (File) props.get("FileObject"); 
                char[] passwd = props.getProperty("keystore.password","").toCharArray(); 
                KeyStore ksObj = KeyStore.getInstance(props.getProperty("keystore.type","PKCS12").trim());
                ksObj.load(new FileInputStream(fileObj), passwd);

                KeyManagerFactory kmFactory = KeyManagerFactory.getInstance("SunX509");
                kmFactory.init(ksObj, passwd); 

                KeyManager[] kms = kmFactory.getKeyManagers(); 
                for (int ii=0; ii<kms.length; ii++) { 
                    kmlist.add(kms[ii]); 
                } 
                System.out.println("> " + configFile.getName() + " ...OK ");
            }
            catch(Exception ex) 
            {
                System.out.println("> " + configFile.getName() + ": Unable to load keystore config caused by " + ex.getMessage());
                System.out.println("> " + configFile.getName() + ": " + props); 
                ex.printStackTrace();
            }
        }            

        TrustManager[] tm = new TrustManager[]
        {
            new X509TrustManager() {
                public void checkClientTrusted(X509Certificate[] x509Certificate, String string) throws CertificateException {}
                public void checkServerTrusted(X509Certificate[] x509Certificate, String string) throws CertificateException {}
                public X509Certificate[] getAcceptedIssuers() { return null; }
            }
        };

        KeyManager[] keyManagers = (KeyManager[]) kmlist.toArray(new KeyManager[kmlist.size()]); 
        SSLContext ssl = SSLContext.getInstance("SSL");
        ssl.init(keyManagers, tm, new SecureRandom());
        SSLSF = ssl.getSocketFactory(); 
        System.out.println("   SSLSocketFactory-> " + SSLSF);
        
        HttpsURLConnection.setDefaultSSLSocketFactory(SSLSF);
        HttpsURLConnection.setDefaultHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String string, SSLSession sSLSession) {
                return true; 
            }
        }); 

        System.getProperties().put("SSLSocketFactory", SSLSF); 
    }  
    
    private File[] getKeyStoreConfigFiles() 
    {
        File dir = new File(System.getProperty("jboss.server.home.dir") + File.separator + "conf/keystores");        
        if (!dir.exists()) return null; 
        if (!dir.isDirectory()) return null; 
        
        List configFiles = new ArrayList(); 
        File[] files = dir.listFiles();
        for (int i=0; i<files.length; i++) 
        {
            File file = files[i];
            if (file.isDirectory()) continue;
            if (!file.getName().endsWith("-keystore.conf")) continue; 
            
            configFiles.add(file); 
        }
        return (File[]) configFiles.toArray(new File[configFiles.size()]); 
    }
    
    private Properties getKeyStoreConfig(File file) throws Exception 
    {
        InputStream inp = null;
        try 
        {
            inp = new FileInputStream(file); 
            
            Properties props = new Properties(); 
            props.load(inp); 
            
            String ksfile = props.getProperty("keystore.file"); 
            if (ksfile == null || ksfile.trim().length() == 0) 
            {
                System.out.println("> " + file.getName() + ": keystore file not specified ");
                return null;
            } 
            
            boolean ksfileFound = false; 
            File[] files = file.getParentFile().listFiles();
            for (int i=0; i<files.length; i++) 
            {
                if (files[i].isDirectory()) continue; 
                if (files[i].getName().equals(ksfile.trim())) 
                {
                    props.put("FileObject", files[i]);
                    ksfileFound = true; 
                    break;
                }
            } 
            
            if (ksfileFound) return props; 
            
            System.out.println("> " + file.getName() + ": '"+ksfile+"' keystore file not found");
            return null; 
        }
        catch(Exception ex) {
            throw ex; 
        } 
        finally {
            try { inp.close(); }catch(Exception ing){;} 
        } 
    }     
    
}
