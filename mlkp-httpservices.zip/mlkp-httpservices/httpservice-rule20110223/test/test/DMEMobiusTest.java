package test;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import junit.framework.*;

public class DMEMobiusTest extends TestCase 
{
    
    public DMEMobiusTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
        //https://localhost:8443/services/rule/invoke/getForexSetting?
    }

    //http://dapi.dev.mobiusonline.net/get_transaction_details.php?dist_id=mlhuillier&dist_txn_id=test&hash=
    
    protected void tearDown() throws Exception {
    }
    
    /*
        SecretKeySpec skey = new SecretKeySpec(key.getBytes(), "HmacMD5");
        Mac mac = Mac.getInstance("HmacMD5");
        mac.init(skey);

        byte[] bytes = mac.doFinal(text.getBytes());
        System.out.println(MD5Util.toHexString(bytes));
     */

    String dist_id =   "mlhuillier";
    String username =  "mlinc1234";
    String secretkey = "OlFUFwodyCCWh5Gg"; 
    SimpleDateFormat YMDHMS = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); 
    
    private String hash_hmac(String value, String key) throws Exception
    {
        SecretKeySpec skey = new SecretKeySpec(key.getBytes(), "HmacMD5");
        Mac mac = Mac.getInstance("HmacMD5");
        mac.init(skey);

        byte[] bytes = mac.doFinal(value.getBytes());
        return MD5Encoder.toHexString(bytes);
    }
    
    public void testGetUserBalance() throws Exception
    {
        System.out.println("");
        System.out.println("/get_user_balance.php");
        String path = "http://dapi.dev.mobiusonline.net/get_user_balance.php";
        String hash = hash_hmac(dist_id + username, secretkey);
        
        Map data = new HashMap();
        data.put("dist_id", dist_id);
        data.put("username", username);
        data.put("hash", hash);

        System.out.println(invokeHttpWS(path, data));
    } 

    public void xtestGetDistBalance() throws Exception
    { 
        System.out.println("");
        System.out.println("/get_dist_balance.php"); 
        String hash = hash_hmac(dist_id, secretkey); 
        String path = "http://dapi.dev.mobiusonline.net/get_dist_balance.php"; 
        
        Map data = new HashMap();
        data.put("dist_id", dist_id);
        data.put("hash", hash);
        
        System.out.println(invokeHttpWS(path, data));
    } 
    
    private String txnid = "TXN0000000005"; 
    public void xtestLoadUp() throws Exception 
    { 
        System.out.println("");
        System.out.println("/load_up_user.php"); 
        double amount = 10.0;
        String path = "http://dapi.dev.mobiusonline.net/load_up_user.php";
        String hash = hash_hmac(dist_id + username + amount + txnid, secretkey); 

        Map data = new HashMap();
        data.put("dist_id", dist_id);
        data.put("username", username);
        data.put("amount", amount+"");
        data.put("dist_txn_id", txnid);
        data.put("hash", hash);
        
        System.out.println("start-time: " + YMDHMS.format(new Date()));        
        System.out.println(invokeHttpWS(path, data));
        System.out.println("end-time:   " + YMDHMS.format(new Date()));                
    } 
    
    public void xtestGetTransactionDetails() throws Exception
    { 
        System.out.println("");
        System.out.println("/get_txn_details.php"); 
        String hash = hash_hmac(dist_id + txnid, secretkey);  
        String path = "http://dapi.dev.mobiusonline.net/get_txn_details.php";
        
        Map data = new HashMap();
        data.put("dist_id", dist_id);
        data.put("dist_txn_id", txnid);
        data.put("hash", hash);
        
        System.out.println(invokeHttpWS(path, data));        
    } 
    
    private Object invokeHttpWS(String host, Map data) throws Exception 
    {
        Map req = new HashMap();        
        req.put("host", host);
        req.put("parameters", data);
        
        HttpServiceClient c = new HttpServiceClient();
        return c.invoke("http://192.168.3.188:8080/services/httpws/url/invoker", req);
    }     
    
    private String invoke(String urlPath) throws Exception 
    {
        InputStream is = null;
        try
        {
            URL url = new URL(urlPath); 
            is = url.openStream(); 
            
            StringBuffer sb = new StringBuffer(); 
            int read = -1; 
            while ((read=is.read()) != -1) {
                sb.append((char) read); 
            }
            return sb.toString(); 
        }
        catch(Exception ex) { 
            return "[ERROR] " + ex.getClass().getName() + "\n\t" +  ex.getMessage(); 
        } 
        finally { 
            try { is.close(); }catch(Exception ign){;} 
        } 
    } 
    
    private String post(String urlPath, String request)
    {
        try
        {
            System.out.println(urlPath + "?" + request);
            URL url = new URL(urlPath); 
            URLConnection conn = (URLConnection) url.openConnection(); 
            if (conn instanceof HttpURLConnection) ((HttpURLConnection) conn).setRequestMethod("POST");
            
            conn.setDoInput(true);
            conn.setDoOutput(true);
            conn.setUseCaches(false);

            OutputStreamWriter writer = null;            
            try
            {
                writer = new OutputStreamWriter(conn.getOutputStream());
                writer.write(request);
                writer.flush();
            }
            catch(Exception e) {
                throw e; 
            }
            finally {
                try { writer.close(); }catch(Exception ign){;} 
            }
            
            BufferedReader reader = null; 
            StringBuffer sb = new StringBuffer();
            String text = null;
            try
            {
                reader = new BufferedReader(new InputStreamReader(conn.getInputStream())); 
                while ((text=reader.readLine()) != null) { sb.append(text); } 
            }
            catch(Exception e) {
                throw e; 
            }
            finally {
                try { reader.close(); }catch(Exception ign){;} 
            }
            return sb.toString(); 
        } 
        catch(Exception ex) {
            return "[ERROR] " + ex.getClass().getName() + "\n\t" +  ex.getMessage();
        }
    }    
}
