package com.rameses.httpws;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.Iterator;
import java.util.Map;

public class HttpURLInvoker 
{ 
    private String uri; 
    private URL url; 
    private int timeout = 20000;
    
    public HttpURLInvoker(String uri) 
    {
        this.uri = uri;
        
        try {
            this.url = new URL(uri); 
        } catch(Exception ex) {
            throw new RuntimeException(ex.getMessage(), ex); 
        }
    }

    public int getTimeout() { return timeout; }
    public void setTimeout(int timeout) { this.timeout = timeout; }  
    
    public Object invoke(Map parameters) throws Exception {
        return invoke(parameters, "GET");  
    } 
    
    public Object invoke(Map parameters, String requestMethod) throws Exception 
    {
        try
        {
            if ("POST".equalsIgnoreCase(requestMethod+"")) {;}
            else if ("GET".equalsIgnoreCase(requestMethod+"")) {;}
            else throw new Exception("'"+requestMethod+"' request method is invalid"); 
            
            StringBuffer request = new StringBuffer(); 
            if (parameters != null)
            {
                Iterator itr = parameters.entrySet().iterator(); 
                while (itr.hasNext())
                {
                    Map.Entry me = (Map.Entry) itr.next(); 
                    if (me.getKey() == null) continue; 
                    
                    String key = me.getKey().toString();
                    if (key == null || key.trim().length() == 0) continue;
                    
                    Object val = me.getValue(); 
                    if (val == null) val = ""; 
                    
                    if (request.length() > 0) request.append("&");
                    
                    request.append(URLEncoder.encode(key) + "=" + URLEncoder.encode(val.toString()));
                }
            }
            
            URLConnection conn = (URLConnection) url.openConnection(); 
            if (conn instanceof HttpURLConnection) ((HttpURLConnection) conn).setRequestMethod(requestMethod);
            
            conn.setDoInput(true);
            conn.setDoOutput(true);
            conn.setUseCaches(false);

            OutputStreamWriter writer = null;            
            try
            {
                writer = new OutputStreamWriter(conn.getOutputStream());
                writer.write(request.toString());
                writer.flush();
            }
            catch(Exception e) {
                throw e; 
            }
            finally {
                try { writer.close(); }catch(Exception ign){;} 
            }

            String text = null;
            BufferedReader reader = null; 
            StringBuffer response = new StringBuffer();
            try
            {
                reader = new BufferedReader(new InputStreamReader(conn.getInputStream())); 
                while ((text=reader.readLine()) != null) { response.append(text); } 
            }
            catch(Exception e) {
                throw e; 
            }
            finally {
                try { reader.close(); }catch(Exception ign){;} 
            }
            return response.toString(); 
        } 
        catch(Exception ex) {
            throw ex; 
        }         
    } 
}
