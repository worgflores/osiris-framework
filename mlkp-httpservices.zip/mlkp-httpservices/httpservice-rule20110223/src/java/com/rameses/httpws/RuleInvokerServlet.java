package com.rameses.httpws;

import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import javax.servlet.*;
import javax.servlet.http.*;
import rameses.osiris.client.app.App;
import rameses.osiris.common.interfaces.IDataModel;
import rameses.osiris.common.interfaces.IDataSetModel;
import rameses.osiris.common.service.Request;

public class RuleInvokerServlet extends HttpServlet 
{
    private String KEYNAME = "services/rule/invoke";
    
    // <editor-fold defaultstate="collapsed" desc=" HttpServlet methods. Click on the + sign on the left to edit the code. ">
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response); 
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response); 
    }
    
    protected void service(HttpServletRequest request, HttpServletResponse response) 
    throws ServletException, IOException {
        processRequest(request, response); 
    }
    
    public String getServletInfo() { return KEYNAME; }
    // </editor-fold>
    
    private void loadConfig() 
    {
        String apphost = System.getProperty("app.host", ""); 
        if (apphost == null || apphost.trim().length() == 0) 
        {
            InputStream inp = null;
            try 
            {
                ClassLoader loader = Thread.currentThread().getContextClassLoader();
                inp = loader.getResource("mlkpsoap.properties").openStream(); 
                
                Properties props = new Properties(); 
                props.load(inp); 
                apphost = props.getProperty("app.host", ""); 
                
                if (apphost != null && apphost.trim().length() > 0) 
                    System.setProperty("app.host", apphost); 
            }
            catch(Exception ign) {;} 
            finally {
                try { inp.close(); }catch(Exception ign){;} 
            }
        }
        //System.out.println("apphost=" + System.getProperty("app.host"));
    } 
    
    private Object IFNULL(Object value, Object defvalue)
    {
        if (value == null) return defvalue;
        
        return value; 
    }
    
    public Object[] resolveException(Throwable t)
    {
        Throwable p = t;
        while (true)
        {
            String msg = p.getMessage(); 
            if (msg != null) 
            {
                int idx0 = msg.indexOf("ErrCode("); 
                int idx1 = -1;

                if (idx0 >= 0) idx1 = msg.indexOf(')', idx0); 

                String errcode = null;
                String errmsg = null;
                
                try { errcode = msg.substring(idx0+8, idx1); } catch(Exception ign) {;}
                try { errmsg  = msg.substring(idx1+1); } catch(Exception ign) {;}
                
                return new Object[]{ t, errmsg, errcode };
            } 
            else  
            {
                if (p.getCause() == null) break;
                
                p = p.getCause(); 
            }  
        }
        
        return new Object[]{ t, t.getMessage() };
    } 
    
    protected Map processRequest(HttpServletRequest req, String action, IDataModel data) throws Exception 
    { 
        Request rreq = new Request(); 
        rreq.addParameter("data", data); 
        return processRequest(req, action, rreq); 
    } 
    
    protected Map processRequest(HttpServletRequest req, String action, Request rreq) throws Exception 
    { 
        rreq.addParameter("REQ_AUTHTYPE", IFNULL(req.getAuthType(), "")); 
        rreq.addParameter("REQ_LOCALADDR", IFNULL(req.getLocalAddr(), "")); 
        rreq.addParameter("REQ_REMOTEADDR", IFNULL(req.getRemoteAddr(), "")); 
        rreq.addParameter("REQ_REMOTEHOST", IFNULL(req.getRemoteHost(), "")); 
        rreq.addParameter("REQ_REMOTEPORT", req.getRemotePort()+""); 
        rreq.addParameter("REQ_SESSIONID", IFNULL(req.getRequestedSessionId(), "")); 
        rreq.addParameter("REQ_QUERYSTRING", IFNULL(req.getQueryString(), "")); 
        
        Map map = App.getServiceManager().invoke(action, rreq).getValues();
        List list = new ArrayList(); 
        Iterator keys = map.keySet().iterator(); 
        while (keys.hasNext()) 
        {
            String key = keys.next()+"";
            if (key.toLowerCase().startsWith("req_")) list.add(key); 
        }
        while (!list.isEmpty()) {
            map.remove(list.remove(0)); 
        }
        return map;
    } 
    
    protected void processRequest(HttpServletRequest req, HttpServletResponse res)
    throws ServletException, IOException 
    {
        Map result = new HashMap(); 
        String keyname = KEYNAME;
        PrintWriter out = null;
        int read = -1; 
        
        try 
        {
            out = res.getWriter();
            
            loadConfig(); 
            
            String pathInfo = req.getPathInfo(); 
            if (pathInfo == null || "/".equals(pathInfo))
                throw new ServletException("Request PathInfo is required");

            int idxQ = pathInfo.indexOf('?'); 
            String rulename = pathInfo.substring(1); 
            if (idxQ > 0) rulename = pathInfo.substring(1, idxQ);
            
            Request rreq = new Request(); 
            Iterator keys = req.getParameterMap().keySet().iterator(); 
            while (keys.hasNext())
            {
                String key = keys.next().toString(); 
                String val = req.getParameter(key); 
                try {
                    rreq.addParameter(key.toUpperCase(), val.toString()); 
                } catch(Exception ex) {
                    rreq.addParameter(key.toUpperCase(), ""); 
                } 
            } 

            Map map = processRequest(req, rulename, rreq);
            System.out.println(map);
            keys = map.keySet().iterator(); 
            while (keys.hasNext()) 
            { 
                String key = keys.next().toString(); 
                Object val = map.get(key);
                if (val == null) continue; 
                
                if (val instanceof IDataModel)
                {
                    IDataModel idm = (IDataModel) val;
                    Iterator flds = idm.getFields();
                    if (val instanceof IDataSetModel)
                    {
                        IDataSetModel idsm = (IDataSetModel) val;
                        if (idsm.size() == 0) continue;
                        
                        idm = idsm.getItem(0); 
                        flds = idsm.getFields(); 
                    }
                    
                    String idmname = idm.getName();
                    if (idmname == null) idmname = "data";
                    
                    while (flds.hasNext()) 
                    {
                        String fldname = flds.next().toString(); 
                        try { 
                            out.println(idmname + "_" + fldname + "=" + idm.getValue(fldname)); 
                        } catch(Exception ign){;} 
                    } 
                } 
                else { 
                    out.println(key + "=" + val); 
                } 
            }             
            out.println("respcode=0"); 
        } 
        catch (Exception ex) 
        {
            Object[] arr = resolveException(ex); 
            String errcode = "0"; 
            Object errmsg = null;
            try { errcode = arr[2].toString(); }catch(Exception ign){;} 
            try { errmsg = arr[1]; }catch(Exception ign){;} 
            
            out.println("respcode=1"); 
            out.println("errcode=" + errcode); 
            out.println("errmsg=" + errmsg); 
            out.println("errtrace=" + getStackTrace(ex)); 
            
            ex.printStackTrace();
        } 
        finally 
        {
            try { out.close(); }catch(Exception ing){;} 
        }
    }
    
    private String getStackTrace(Exception ex)
    {
        ByteArrayOutputStream baos = null;
        try
        {
            baos = new ByteArrayOutputStream();
            ex.printStackTrace(new PrintStream(baos));
            return new String(baos.toByteArray());
        }
        catch(Exception e) {
            return "";
        }
        finally {
            try { baos.close(); }catch(Exception ign) {;} 
        }
    }
    
    private String getStackTrace(Error ex)
    {
        ByteArrayOutputStream baos = null;
        try
        {
            baos = new ByteArrayOutputStream();
            ex.printStackTrace(new PrintStream(baos));
            return new String(baos.toByteArray());
        }
        catch(Exception e) {
            return "";
        }
        finally {
            try { baos.close(); }catch(Exception ign) {;} 
        }
    }    
}
