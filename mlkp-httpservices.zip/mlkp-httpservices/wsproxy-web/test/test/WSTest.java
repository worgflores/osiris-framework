package test;

import junit.framework.*;

public class WSTest extends TestCase 
{
    
    public WSTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
    }

    protected void tearDown() throws Exception {
    }
    
    public void test0() throws Exception
    {
        /*
         *  WSProxy wsp = new WSProxy("http://192.168.3.211:8080/wsproxy-ext/groovyws"); 
         *  wsp.setWSDL("http://222.127.151.21/ws/pickup.cfc?wsdl"); 
         *  wsp.invoke("ShowRemittanceDetail", 
         *
         */
        
        /*
         *  WSProxy wsp = new WSProxy("http://192.168.3.211:8080/wsproxy/rpcsoap"); 
         *  wsp.setWSDL("http://222.127.151.21/ws/pickup.cfc?wsdl"); 
         *  wsp.invoke("ShowRemittanceDetail"
         *
         */
    }
}
