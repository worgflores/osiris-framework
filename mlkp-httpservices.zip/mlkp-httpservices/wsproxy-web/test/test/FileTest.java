package test;

import java.io.File;
import java.io.InputStream;
import java.net.URL;
import java.util.jar.JarFile;
import junit.framework.*;

public class FileTest extends TestCase 
{
    
    public FileTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
    }

    protected void tearDown() throws Exception {
    }
    
    public void xtest0() throws Exception 
    {
        String path = "file:/D:/Applications/jboss-4.0.5.GA/server/mlweb/app-test/mlbillspayment.jar!/pack.bat"; 
        String filepath = path.substring(0, path.indexOf("!/"));
        String fileres = path.substring(path.indexOf("!/")+2);
        
        URL url = new URL(filepath);
        JarFile jf = new JarFile(new File(url.toURI()));
        InputStream in = jf.getInputStream(jf.getJarEntry(fileres));
        int read = -1;
        StringBuffer sb = new StringBuffer();
        while ((read=in.read()) != -1) {
            sb.append((char) read);
        }
        in.close();
        System.out.println(sb);
    } 
    
    public void test1() throws Exception 
    {
        URL url = new URL("http://192.168.3.157:8080/jbossws/services");
        InputStream in = url.openStream();
        StringBuffer out = new StringBuffer();
        int read = -1;
        while ((read=in.read()) != -1) {
            out.append((char) read);
        }        
        System.out.println(out);
        System.out.println(url.openConnection().getContentType());
    }
    
}
