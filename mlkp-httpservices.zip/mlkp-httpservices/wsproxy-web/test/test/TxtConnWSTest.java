package test;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.Properties;
import junit.framework.*;

public class TxtConnWSTest extends TestCase 
{
    
    public TxtConnWSTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
    }

    protected void tearDown() throws Exception {
    }
    
    public void test0() throws Exception 
    {
        URL url = new URL("http://localhost:8080/wsproxy/TxtConnWSConfig");
        Properties props = new Properties();
        props.load(url.openStream());
        
        StringBuffer sb = new StringBuffer();
        sb.append("https://txtconnect.globesolutions.com.ph/webservices/txtconnws.asmx/ValidateUser");
        sb.append("?username=" + props.getProperty("username")); 
        sb.append("&password=" + props.getProperty("password")); 
        sb.append("&org=" + props.getProperty("org")); 
        sb.append("&hash=0"); 
        
        String res = getResults(sb.toString()).toString();
        System.out.println(res);
    } 

    
    
    
    
    
    private StringBuffer getResults(String reqpath) throws Exception
    {
        StringBuffer sb = new StringBuffer();
        InputStream in = null;
        int read = -1;
        
        try
        {
            URL url = new URL("http://192.168.3.220:8080/wsproxy/redirect/" + reqpath);
            in = url.openStream();
            while ((read=in.read()) != -1) {
                sb.append((char) read);
            }
            return sb;
        }
        catch(IOException ioe) {
            throw new Exception("Not found " + reqpath);
        }
        catch(Exception ex) {
            throw ex;
        }
        finally {
            try { in.close(); }catch(Exception ing){;}
        }
    }
    
}
