package com.rameses.wsproxy;

import common.net.SSLLoader;
import java.io.*;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.*;
import javax.servlet.http.*;

public class RedirectServlet extends HttpServlet 
{
    
    // <editor-fold defaultstate="collapsed" desc=" HttpServlet methods. Click on the + sign on the left to edit the code. ">
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);
    }
    
    public String getServletInfo() { return "Redirect Servlet"; }
    // </editor-fold>
    
    public void init() throws ServletException 
    {
        System.out.println(getClass().getSimpleName() + " initializing...");
        super.init();
        try {
            SSLLoader.initialize(); 
        } catch(Exception ex) { 
            ex.printStackTrace(); 
        } 
        System.out.println(getClass().getSimpleName() + " started ");
    }    
    
    protected void processRequest(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException 
    {
        String pathInfo = req.getPathInfo(); 
        if (pathInfo == null || "/".equals(pathInfo))
            throw new ServletException("Request PathInfo is required");
        
        int idx = pathInfo.indexOf(":/");
        StringBuffer spec = new StringBuffer();
        spec.append(pathInfo.substring(1, idx));
        spec.append("://");
        spec.append(pathInfo.substring(idx+2));
        
        if (req.getQueryString() != null)
            spec.append("?" + req.getQueryString());
        
        System.out.println("[REDIRECT] " + spec);
        
        InputStream in = null;
        int read = -1;

        try 
        {
            URL url = new URL(spec.toString());
            in = url.openStream();

            res.setContentType(url.openConnection().getContentType());
            PrintWriter out = res.getWriter();
            while ((read=in.read()) != -1) {
                out.print((char) read);
            }
            out.close();
        }
        catch(Exception ex) 
        {
            FileLogger logger = new FileLogger();
            logger.write(getLogFile(), ex);
            
            throw new ServletException(ex.getMessage(), ex); 
        }
        finally {
            try { in.close(); }catch(Exception ing){;}
        }
    }
    
    private File getLogFile()
    {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
        String filename = "redirect.log." + sdf.format(new Date());
        
        String logdir = System.getProperty("jboss.server.log.dir");            
        File f = new File(logdir + File.separator + filename);
        return f;
    }
    
}
