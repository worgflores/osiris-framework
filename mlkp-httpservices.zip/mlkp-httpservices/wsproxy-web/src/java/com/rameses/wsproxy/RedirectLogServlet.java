package com.rameses.wsproxy;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.*;
import javax.servlet.http.*;

public class RedirectLogServlet extends HttpServlet 
{
    // <editor-fold defaultstate="collapsed" desc=" HttpServlet methods. Click on the + sign on the left to edit the code. ">
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);
    }
    
    public String getServletInfo() { return "Redirect Log Servlet"; }
    // </editor-fold>
    
    protected void processRequest(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException 
    {
        String pathInfo = req.getPathInfo(); 
        if (pathInfo == null || "/".equals(pathInfo))
            throw new ServletException("Request PathInfo is required");

        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
        String filename = "redirect.log." + sdf.format(new Date());
        
        InputStream in = null;
        PrintWriter out = null;
        int read = -1;

        try 
        {
            res.setContentType("text/plain");            
            out = res.getWriter();

            String logdir = System.getProperty("jboss.server.log.dir");            
            File f = new File(logdir + File.separator + filename);
            in = new FileInputStream(f);
            
            while ((read=in.read()) != -1) {
                out.print((char) read);
            }
        }
        catch(Exception ex) 
        {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            ex.printStackTrace(new PrintStream(baos));
            String msg = new String(baos.toByteArray());
            System.out.println(msg);
            out.print(msg); 
        }
        finally 
        {
            try { in.close(); }catch(Exception ing){;}
            try { out.close(); }catch(Exception ing){;}
        }
    }
    
}
