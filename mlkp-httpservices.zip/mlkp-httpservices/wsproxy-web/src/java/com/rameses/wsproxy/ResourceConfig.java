package com.rameses.wsproxy;

import java.io.*;
import java.net.URL;
import java.util.jar.JarFile;

import javax.servlet.*;
import javax.servlet.http.*;

public class ResourceConfig extends HttpServlet 
{
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);
    }
    
    public String getServletInfo() {
        return "ResourceConfig Servlet";
    }
    // </editor-fold>
    
    private InputStream getResourceAsStream(String resource) throws Exception
    {
        String homedir = System.getProperty("jboss.server.home.url");
        if (resource.indexOf(".jar!") > 0)
        {
            String filepath = resource.substring(0, resource.indexOf("!/"));
            String fileres = resource.substring(resource.indexOf("!/")+2);
            System.out.println(filepath + ",   " + fileres);
            
            URL url = new URL(homedir + filepath);
            System.out.println("Resource config '" + url + "'");                
            JarFile jf = new JarFile(new File(url.toURI()));
            return jf.getInputStream(jf.getJarEntry(fileres));          
        }
        else 
        {
            URL url = new URL(homedir + resource);
            System.out.println("Resource config '" + url + "'");    
            return url.openStream();
        }
    }
    
    protected void processRequest(HttpServletRequest req, HttpServletResponse response) throws ServletException, IOException 
    {
        InputStream in = null;
        int read = -1;
        
        try
        {
            String pathInfo = req.getPathInfo(); 
            if (pathInfo == null || "/".equals(pathInfo))
                throw new Exception("Request PathInfo is required");
            
            String resource = pathInfo.substring(1); 
            ClassLoader loader = Thread.currentThread().getContextClassLoader();
            URL url = loader.getResource(resource);
            if (url != null) 
            {
                System.out.println("Resource config '" + url + "'");    
                in = url.openStream();
            }
            else
            {
                in = getResourceAsStream(resource);
                if (in == null) 
                    throw new Exception("'"+ resource +"' resource does not exists");
            }
            
            response.setContentType("text/plain");
            PrintWriter out = response.getWriter();
            while ((read=in.read()) != -1) {
                out.print((char) read);
            }
            out.close();
        }
        catch(Exception ex) 
        {
            ex.printStackTrace();
            throw new ServletException(ex.getMessage(), ex);
        }
        finally { 
            try { in.close(); }catch(Exception ign) {;}
        } 
    }     
}
