package test;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Map;
import rameses.osiris.common.service.Request;

public class HttpServiceProvider 
{
    
    public Object invoke(String host, Object req) throws Exception 
    {
        HttpURLConnection conn = null;
        ObjectOutputStream out = null;
        ObjectInputStream in = null;
        
        try 
        {
            URL url = new URL(host);
            conn = (HttpURLConnection)url.openConnection();
            conn.setDoInput(true);
            conn.setDoOutput(true);
            conn.setUseCaches(false);
            conn.setDefaultUseCaches(false);
            
            out = new ObjectOutputStream(conn.getOutputStream());
            out.writeObject(req);
            out.flush(); 
            
            in = new ObjectInputStream(conn.getInputStream());
            Object res = in.readObject();
            return res;
        } 
        catch ( Exception ex ) {
            throw ex;
        } 
        finally 
        {
            try { out.close(); } catch (Exception ex){;}
            try { in.close(); } catch (Exception ex){;}
            try { conn.disconnect(); } catch (Exception ex){;}
        }
    }
    
}
