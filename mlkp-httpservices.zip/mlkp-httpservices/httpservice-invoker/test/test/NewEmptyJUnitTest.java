package test;

import java.io.InputStream;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import junit.framework.*;

public class NewEmptyJUnitTest extends TestCase 
{
    
    public NewEmptyJUnitTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
        
        java.util.Calendar cal = java.util.Calendar.getInstance(); 
        cal.setTime(new Date()); 
        cal.add(java.util.Calendar.MINUTE, 5); 
    }

    protected void tearDown() throws Exception {
    }
    
    public void xtest00001() throws Exception
    {
        Map params = new HashMap(); 
        params.put("kptn", "MIS1890760024");
        
        HttpServiceClient c = new HttpServiceClient(); 
        Object result = c.invoke("http://192.168.3.246:8080/services/invoker/dynamic~/PayoutService.searchByKPTN?host=192.168.12.62:8080&context=mlkp4", params); 
        System.out.println(result);
    }
    
    public void testScriptService() throws Exception
    {
        String script = getResourceContent("test/resources/getServerDate");
        HttpServiceClient c = new HttpServiceClient(); 
        Object result = c.invoke("http://192.168.50.111:8080/services/invoker/dynamic~/ScriptServiceAnalyzer.execute?host=192.168.50.109:8080&context=mlkp4", script); 
        System.out.println(result);
//        System.out.println("*******************");
//        script = getResourceContent("test/resources/forex.updateSettings");
//        result = c.invoke("http://192.168.3.211:8080/services/invoker/dynamic~/ScriptServiceAnalyzer.execute?host=124.6.157.254:8080&context=mlglobal", script); 
//        System.out.println(result);        
    }

    
    private String getResourceContent(String resname) throws Exception 
    {
        ClassLoader loader = Thread.currentThread().getContextClassLoader(); 
        InputStream inp = loader.getResourceAsStream(resname); 
        try 
        {
            int read = -1;
            StringBuffer sb = new StringBuffer(); 
            while ((read=inp.read()) != -1) {
                sb.append((char) read); 
            }
            return sb.toString(); 
        }
        catch(Exception ex) {
            throw ex; 
        }
        finally {
            try { inp.close(); }catch(Exception ign){;} 
        }
    }
}



