package com.rameses.http.service.invoker;

import com.rameses.invoker.client.DynamicHttpInvoker;
import java.io.*;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.*;
import javax.servlet.http.*;

public class DynamicHttpCustomServlet extends HttpServlet 
{
    private String KEYNAME = "services/invoker/dynamic~";
    
    // <editor-fold defaultstate="collapsed" desc=" HttpServlet methods. Click on the + sign on the left to edit the code. ">
    protected void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        processRequest(req, res); 
    }
    
    public String getServletInfo() { return KEYNAME; }
    // </editor-fold>
    
    protected void processRequest(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException 
    {
        ObjectInputStream ois = null;
        ObjectOutputStream oos = null; 
        Map result = new HashMap(); 
        
        try 
        {
            ois = new ObjectInputStream(req.getInputStream());
            Object reqobj= ois.readObject();
            
            String pathInfo = req.getPathInfo(); 
            if (pathInfo == null || "/".equals(pathInfo))
                throw new ServletException("Request PathInfo is required");
            
            pathInfo = pathInfo.substring(1); 
            int idx = pathInfo.indexOf('.'); 
            if (idx < 0) throw new ServletException("Please specify the method name");
            if (idx == 0) throw new ServletException("Please specify the service name");
                        
            String serviceName = pathInfo.substring(0, idx); 
            String actionName = pathInfo.substring(idx+1); 
            String host = req.getParameter("host"); 
            String context = req.getParameter("context"); 

            Map env = new HashMap();
            env.put("session_checked", Boolean.TRUE);
            DynamicHttpInvoker inv = new DynamicHttpInvoker(host, context); 
            DynamicHttpInvoker.Action a = inv.create(serviceName, env); 
            Object resultValue = null; 
            if (reqobj == null) 
                resultValue = a.invoke(actionName); 
            else if (reqobj instanceof Object[])
                resultValue = a.invoke(actionName, (Object[]) reqobj); 
            else if (reqobj instanceof List) 
                resultValue = a.invoke(actionName, (List) reqobj); 
            else
                resultValue = a.invoke(actionName, new Object[]{reqobj}); 
                
            result.put("respcode", "1"); 
            result.put("respmsg", "success"); 
            result.put("result", resultValue); 
            
            oos = new ObjectOutputStream(res.getOutputStream());
            oos.writeObject(result);
        } 
        catch (Exception ex) 
        {
            System.out.println("[ERROR " + KEYNAME + "] " + ex.getClass().getName() + ": " + ex.getMessage()); 
            if ("true".equalsIgnoreCase(req.getParameter("_debug")+"")) ex.printStackTrace(); 
            
            result.put("respcode", "0"); 
            
            String className = ex.getClass().getName(); 
            if (className.startsWith("java.net.") || className.startsWith("java.io."))
                result.put("respmsg", className + ": " + ex.getMessage()); 
            else 
                result.put("respmsg", ex.getMessage()); 
            
            result.put("respdetail", getStackTrace(ex)); 

            oos = new ObjectOutputStream(res.getOutputStream());
            oos.writeObject(result); 
        } 
        finally 
        {
            try { ois.close(); }catch(Exception ing){;}  
            try { oos.close(); }catch(Exception ing){;}  
        }  
    } 
    
    private String getStackTrace(Exception ex)
    {
        ByteArrayOutputStream baos = null;
        try
        {
            baos = new ByteArrayOutputStream();
            ex.printStackTrace(new PrintStream(baos));
            return new String(baos.toByteArray());
        }
        catch(Exception e) {
            return "";
        }
        finally {
            try { baos.close(); }catch(Exception ign) {;} 
        }
    }
}
