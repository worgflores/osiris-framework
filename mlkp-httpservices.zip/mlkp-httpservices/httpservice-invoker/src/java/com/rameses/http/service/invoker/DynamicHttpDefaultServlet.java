package com.rameses.http.service.invoker;

import com.rameses.invoker.client.DynamicHttpInvoker;
import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.*;
import javax.servlet.http.*;

public class DynamicHttpDefaultServlet extends HttpServlet 
{
    private String KEYNAME = "services/invoker/dynamic";
    
    // <editor-fold defaultstate="collapsed" desc=" HttpServlet methods. Click on the + sign on the left to edit the code. ">
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response); 
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response); 
    }
    
    public String getServletInfo() { return KEYNAME; }
    // </editor-fold>
    
    private Object IFNULL(Object value, Object defvalue)
    {
        if (value == null) return defvalue;
        
        return value; 
    }
    
    protected void processRequest(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException 
    {
        PrintWriter out = null;
        StringBuffer debugInfo = new StringBuffer(); 
                
        try 
        {
            out = res.getWriter(); 
            
            String pathInfo = req.getPathInfo(); 
            if (pathInfo == null || "/".equals(pathInfo))
                throw new ServletException("Request PathInfo is required");

            pathInfo = pathInfo.substring(1); 
            int idx = pathInfo.indexOf('.'); 
            if (idx < 0) throw new ServletException("Please specify the method name");
            if (idx == 0) throw new ServletException("Please specify the service name");
            
            String serviceName = pathInfo.substring(0, idx); 
            String actionName = pathInfo.substring(idx+1); 
            Object[] actionParams = new Object[]{};
            String host = req.getParameter("host"); 
            String context = req.getParameter("context"); 
            
            Object args = req.getParameterMap().get("args"); 
            if (args == null)
            {
                List list = new ArrayList(); 
                for (int i=1; i<1000; i++) 
                {
                    if (!req.getParameterMap().containsKey("arg"+i)) break; 
                    
                    list.add(req.getParameter("arg"+i)); 
                } 
                actionParams = list.toArray(new Object[list.size()]); 
            }
            else {
                actionParams = (Object[]) args; 
            } 
            
            Map env = new HashMap();
            env.put("session_checked", Boolean.TRUE);
            DynamicHttpInvoker inv = new DynamicHttpInvoker(host, context); 
            DynamicHttpInvoker.Action a = inv.create(serviceName, env); 
            Object resultValue = null; 
            if (actionParams == null || actionParams.length == 0) 
                resultValue = a.invoke(actionName); 
            else 
                resultValue = a.invoke(actionName, actionParams); 
            
            out.println("respcode=1"); 
            out.println("respmsg=success"); 
            out.println("result=" + resultValue); 
        } 
        catch (Exception ex) 
        {
            System.out.println("[ERROR " + KEYNAME + "] " + ex.getClass().getName() + ": " + ex.getMessage());
            if ("true".equalsIgnoreCase(req.getParameter("_debug")+"")) ex.printStackTrace(); 
            
            out.println("respcode=0"); 
            
            String className = ex.getClass().getName(); 
            if (className.startsWith("java.net.") || className.startsWith("java.io."))
                out.println("respmsg=" + className + ": " + ex.getMessage()); 
            else 
                out.println("respmsg=" + ex.getMessage()); 
            
            out.println("respdetail=" + getStackTrace(ex)); 
        } 
        finally {
            try { out.close(); }catch(Exception ing){;}  
        }  
    } 
    
    private String getStackTrace(Exception ex)
    {
        ByteArrayOutputStream baos = null;
        try
        {
            baos = new ByteArrayOutputStream();
            ex.printStackTrace(new PrintStream(baos));
            return new String(baos.toByteArray());
        }
        catch(Exception e) {
            return "";
        }
        finally {
            try { baos.close(); }catch(Exception ign) {;} 
        }
    }
}
