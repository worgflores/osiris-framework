package com.rameses.wsproxy.services; 

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintStream;
import java.text.SimpleDateFormat;
import java.util.Date;

public class FileLogger 
{
    private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    
    public FileLogger() {}
    
    public void write(File file, String message)
    {
        if (message == null) return;
        
        FileWriter writer = null;
        
        try
        {
            writer = new FileWriter(file, true);
            writer.write("["+sdf.format(new Date())+"] ");
            writer.write(message); 
        }
        catch(Exception ex) {
            ex.printStackTrace();
        }
        finally {
            try { writer.close(); }catch(Exception ign){;} 
        }
    }
    
    public void write(File file, Throwable t)
    {
        FileWriter writer = null;
        
        try
        {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            t.printStackTrace(new PrintStream(baos));            
            
            writer = new FileWriter(file, true);
            writer.write("["+sdf.format(new Date())+"] ");
            writer.write(new String(baos.toByteArray())); 
        }
        catch(Exception ex) {
            ex.printStackTrace();
        }
        finally {
            try { writer.close(); }catch(Exception ign){;} 
        }
    }
}
