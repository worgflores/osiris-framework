package com.rameses.wsproxy.services;

import java.net.URL;
import java.util.List;
import java.util.Map;
import java.util.Vector;
import javax.servlet.http.*;
import org.apache.soap.Constants;
import org.apache.soap.Fault;
import org.apache.soap.rpc.Call;
import org.apache.soap.rpc.Parameter;
import org.apache.soap.rpc.Response;

public class SoapRPCServlet extends AbstractWSServlet
{
    private String keyname = "SoapRPCServlet";
    
    protected String getName() { return keyname; }

    protected Object processRequest(HttpServletRequest req, Map data) throws Exception 
    {
        String wsdl = (String) data.get("wsdl");
        String method = (String) data.get("method");            
        
        Response resp = invoke(wsdl, method, data.get("params"));
        if (resp.generatedFault()) 
        {
            Fault f = resp.getFault();
            throw new Exception(f.getFaultString());
        }

        Parameter retPar = resp.getReturnValue();
        return (retPar != null ? retPar.getValue() : null);
    }
    
    private Response invoke(String wsdl, String method, Object params) throws Exception 
    {
        Map[] arr = new Map[]{};
        if (params != null)
        {
            if (params instanceof List)
            {
                List list = (List) params;
                arr = (Map[]) list.toArray(new Map[list.size()]);
            }
            else 
                arr = (Map[]) params;
        }
        
        return invoke(wsdl, method, arr);
    }
    
    private Response invoke(String wsdl, String method, Map[] params) throws Exception
    {
        URL url = new URL(wsdl);
        Vector v = new Vector();
        if (params != null)
        {
            for (int i=0; i<params.length; i++)
            {
                String name = (String) params[i].get("name"); 
                Object value = params[i].get("value");
                Class valueType = String.class;
                try 
                {
                    Object otype = (Class) params[i].get("type");
                    otype.toString();
                    
                    valueType = (Class) otype; 
                } 
                catch(Exception ign) { 
                    valueType = String.class; 
                } 
                
                v.addElement(new Parameter(name, valueType, value, null));
            }
        }
        
        Call call = new Call();

        //set encoding style to standard SOAP encoding
        call.setEncodingStyleURI(Constants.NS_URI_SOAP_ENC);
        call.setTargetObjectURI(url.toString());

        call.setMethodName(method);
        call.setParams(v);
        return call.invoke(url, "");
    }    
}
