package com.rameses.wsproxy.services;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.*;
import javax.servlet.http.*;

public abstract class AbstractWSServlet extends HttpServlet 
{
    private boolean trustMgrLoaded;
    
    // <editor-fold defaultstate="collapsed" desc=" HttpServlet methods. Click on the + sign on the left to edit the code. ">
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response); 
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response); 
    }
    
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response); 
    }
    
    public String getServletInfo() { return "SoapRPC Servlet"; }
    // </editor-fold>
    
    protected abstract String getName();
    protected abstract Object processRequest(HttpServletRequest req, Map data) throws Exception; 
    
    protected void processRequest(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException 
    {
        Map result = new HashMap(); 
        String keyname = getName();
        ObjectInputStream in = null;
        ObjectOutputStream out = null;
        
        try 
        {
            in = new ObjectInputStream(req.getInputStream());
            Map mapreq = (Map) in.readObject();
            Object value = processRequest(req, mapreq);
            
            result.put("result", value);  
            result.put("respcode", "1");
            result.put("respdesc", "OK");
            
            out = new ObjectOutputStream(res.getOutputStream());
            out.writeObject(result);
        } 
        catch (Exception ex) 
        {
            System.out.println("["+keyname+"-ERROR] " + ex.getMessage());
            
            String errdetail = getStackTrace(ex);
            try { System.out.println(errdetail); } catch(Throwable t) {;}
            
            logMessage(errdetail);
            
            result.put("respcode", "0");
            result.put("respdesc", ex.getMessage()+"");
            result.put("respdetail", errdetail);
            
            out = new ObjectOutputStream(res.getOutputStream());
            out.writeObject(result);       
        } 
        catch (Error err) 
        {
            System.out.println("["+keyname+"-ERROR] " + err.getMessage());
            
            String errdetail = getStackTrace(err);
            try { System.out.println(errdetail); } catch(Throwable t) {;}
            
            logMessage(errdetail);
            
            result.put("respcode", "0");
            result.put("respdesc", err.getMessage()+"");
            result.put("respdetail", errdetail);
            
            out = new ObjectOutputStream(res.getOutputStream());
            out.writeObject(result);     
        }         
        finally 
        {
            try { out.close(); } catch (Exception ex) {;}
            try { in.close(); } catch (Exception ex ){;}
        }
    }
    
    private String getStackTrace(Exception ex)
    {
        ByteArrayOutputStream baos = null;
        try
        {
            baos = new ByteArrayOutputStream();
            ex.printStackTrace(new PrintStream(baos));
            return new String(baos.toByteArray());
        }
        catch(Exception e) {
            return "";
        }
        finally {
            try { baos.close(); }catch(Exception ign) {;} 
        }
    }
    
    private String getStackTrace(Error ex)
    {
        ByteArrayOutputStream baos = null;
        try
        {
            baos = new ByteArrayOutputStream();
            ex.printStackTrace(new PrintStream(baos));
            return new String(baos.toByteArray());
        }
        catch(Exception e) {
            return "";
        }
        finally {
            try { baos.close(); }catch(Exception ign) {;} 
        }
    }    
    
    private void logThrowable(Throwable t)
    {
        try
        {
            FileLogger logger = new FileLogger();
            logger.write(getLogFile(), t);        
        }
        catch(Exception x) {
            x.printStackTrace();
        }        
    }
    
    private void logMessage(String message)
    {
        try
        {
            FileLogger logger = new FileLogger();
            logger.write(getLogFile(), message);        
        }
        catch(Exception x) {
            x.printStackTrace();
        }
    }    
    
    private File getLogFile()
    {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
        String filename = getName() + "." + sdf.format(new Date());
        
        String logdir = System.getProperty("jboss.server.log.dir");            
        File f = new File(logdir + File.separator + filename);
        return f;
    }

    /*
    private Object invoke(String wsdl, String method, Object[] params) throws Exception
    {
        WSClient ws = new WSClient(wsdl, Thread.currentThread().getContextClassLoader()); 
        ws.initialize(); 
        
        GroovyShell sh = new GroovyShell();
        sh.setVariable("proxy", ws);
        
        StringBuffer script = new StringBuffer();
        script.append("result = proxy." + method + "(");
        
        if (params != null)
        {
            for (int i=0; i<params.length; i++)
            {
                if (i > 0) script.append(", ");
                
                sh.setVariable("var"+i, params[i]);
                script.append("var"+i);
            }
        }
        script.append(");");
        
        sh.evaluate(script.toString());
        Object result = sh.getVariable("result");
        return result;
    }
    */
}
