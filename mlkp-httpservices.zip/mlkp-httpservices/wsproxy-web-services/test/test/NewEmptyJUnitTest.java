package test;

import groovy.lang.GroovyShell;
import groovy.util.XmlSlurper;
import groovy.util.slurpersupport.GPathResult;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;
import junit.framework.*;
import org.apache.soap.Constants;
import org.apache.soap.Fault;
import org.apache.soap.rpc.Call;
import org.apache.soap.rpc.Parameter;
import org.apache.soap.rpc.Response;

public class NewEmptyJUnitTest extends TestCase 
{
    private String host = "http://localhost:8080/wsproxy/services/groovyws";
    
    public NewEmptyJUnitTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
    }

    protected void tearDown() throws Exception {
    }
    
    public void test000() throws Exception
    {
        GroovyShell sh = new GroovyShell();
        sh.evaluate(getClass().getResourceAsStream("groovy"));
    }
    
    public void xtest0() throws Exception
    {
        Object result = invoke("http://localhost:8080/forex-webservice/ForexWS?wsdl", "getRateSetting", new Object[]
                        {
                            "FUENT1", "USD"
                        });
        System.out.println(result);
        
//        Object result = invoke("http://localhost:8080/forex-webservice/ForexWS?wsdl", "getRateSetting", new Parameter[] 
//                        {
//                            new Parameter("branchid", String.class, "FUENT1", null), 
//                            new Parameter("currency", String.class, "USD", null) 
//                        });
//        System.out.println(result);
    }
    
    private Map createMap(String name, Object value)
    {
        Map data = new HashMap();
        data.put("name", name);
        data.put("value", value);
        return data;
    }

    public Object invoke(String wsdl, String method, Object[] params) throws Exception 
    {
        URL url = null;
        HttpURLConnection conn = null;
        ObjectOutputStream out = null;
        ObjectInputStream in = null;
        
        try 
        {
            url = new URL(host);
            conn = (HttpURLConnection) url.openConnection();
            conn.setDoOutput(true); 
            conn.setUseCaches(false); 
            
            out = new ObjectOutputStream(conn.getOutputStream());
            
            Map req = new HashMap();
            req.put("wsdl", wsdl);
            req.put("method", method);
            req.put("params", params);
            out.writeObject(req);
            
            in = new ObjectInputStream(conn.getInputStream());
            Object res = in.readObject();
            if (res instanceof Exception) {
                throw (Exception) res;
            }
            else if (res instanceof Map)
            {
                Map map = (Map) res;
                if (!"1".equals(map.get("respcode")))
                    throw new Exception(map.get("respdesc")+"");
            }
            return res;
        } 
        catch (Exception ex) {
            throw ex;
        } 
        finally 
        {
            try { in.close(); } catch(Exception ex){;}
            try { out.close(); } catch(Exception ex){;}
            try { conn.disconnect(); } catch(Exception ex){;}
        }
    }    
    
    private Object invoke(String wsdl, String method, Parameter[] params) throws Exception
    {
        URL url = new URL(wsdl);       
        Call call = new Call();

        //set encoding style to standard SOAP encoding
        call.setEncodingStyleURI(Constants.NS_URI_SOAP_ENC);
        call.setTargetObjectURI(url.toString());
        call.setMethodName(method);
        
        Vector v = new Vector();        
        if (params != null)
        {
            for (int i=0; i<params.length; i++)
                v.addElement(params[i]);
        }
        call.setParams(v);
        
        Response resp = call.invoke(url, "");
        if (resp.generatedFault()) 
        {
            Fault f = resp.getFault();
            throw new Exception(f.getFaultString());
        }

        Parameter retPar = resp.getReturnValue();
        return (retPar != null ? retPar.getValue() : null);
    }
    
}
