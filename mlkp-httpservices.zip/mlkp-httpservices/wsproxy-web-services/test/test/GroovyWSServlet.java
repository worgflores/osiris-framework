package test;

import com.rameses.wsproxy.services.*;
import groovy.lang.GroovyShell;
import groovyx.net.ws.WSClient;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.http.*;

public class GroovyWSServlet extends AbstractWSServlet
{
    private String keyname = "GroovyWSServlet";
    
    protected String getName() { return keyname; }

    public void init() throws ServletException 
    {
        super.init();
        
        Map workspace = (Map) getServletContext().getAttribute(keyname);
        if (workspace == null) getServletContext().setAttribute(keyname, new Hashtable());
    }

    protected Object processRequest(HttpServletRequest req, Map data) throws Exception 
    {
        String wsdl = (String) data.get("wsdl");
        String method = (String) data.get("method");            
        Object[] params = (Object[]) data.get("params");
        return invoke(wsdl, method, params);
    }
    
    private Object invoke(String wsdl, String method, Object[] params) throws Exception
    {
        Map workspace = (Map) getServletContext().getAttribute(keyname);
        WSClient ws = (WSClient) workspace.get(wsdl);
        if (ws == null)
        {
            ws = new WSClient(wsdl, Thread.currentThread().getContextClassLoader()); 
            ws.initialize(); 
            workspace.put(wsdl, ws);
        }

        GroovyShell sh = new GroovyShell();
        sh.setVariable("proxy", ws);
        
        StringBuffer script = new StringBuffer();
        script.append("result = proxy." + method + "(");
        
        if (params != null) 
        {
            for (int i=0; i<params.length; i++)
            {
                if (i > 0) script.append(", ");
                
                sh.setVariable("var"+i, params[i]);
                 script.append("var"+i);
            }
        }
        script.append(");");
        
        sh.evaluate(script.toString());
        
        Object result = sh.getVariable("result");
        sh = null;
        
        if (result == null) 
            return null;
        else if (result.getClass().getName().startsWith("java."))
        {
            if (result instanceof List)
                return convertList((List) result);
            else
                return result;
        }
        else
            return convertBean(result);
    }

    private Map convertBean(Object bean) throws Exception 
    {
        if (bean instanceof Map) return (Map) bean;
            
        Map data = new HashMap();
        Class beanClass = bean.getClass();
        Method[] methods = beanClass.getMethods();
        for (int i=0; i<methods.length; i++)
        {
            String methodName = methods[i].getName();
            if (!methodName.startsWith("get")) continue;
            if (methodName.equals("getClass")) continue;
            
            Method m = methods[i];
            if (m.getParameterTypes() != null && m.getParameterTypes().length > 0) continue;
            if (m.getReturnType() == void.class) continue;
            
            String sm = methodName.substring(3).toLowerCase();
            if (sm.length() > 0)
                data.put(sm, methods[i].invoke(bean, new Object[]{}));
        }
        return data;
    }

    private List convertList(List list) throws Exception 
    {
        List resultList = new ArrayList();
        Iterator itr = list.iterator();
        while (itr.hasNext())
        {
            Object item = itr.next();
            if (item == null) continue;
            
            resultList.add(convertBean(item));
        }
        return resultList;
    }
    
}
