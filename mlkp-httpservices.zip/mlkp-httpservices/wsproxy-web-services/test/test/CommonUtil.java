package test;

import java.security.MessageDigest;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class CommonUtil 
{
    
    public static String createSignature(String value) throws Exception 
    {
        MessageDigest md = MessageDigest.getInstance("MD5");
        md.update(value.getBytes());
        return toHexString(md.digest());
    }
    
    public static String toHexString(byte[] hash) 
    {
        String hexDigit = "0123456789abcdef";
        StringBuffer sb = new StringBuffer(hash.length);
        for (int i=0; i < hash.length; i++) 
        {
            int b = hash[i] & 0xFF;
            sb.append(hexDigit.charAt(b >>> 4));
            sb.append(hexDigit.charAt(b & 0xF));
        }
        return sb.toString();
    }
    
    public static String formatDate(Object value, String pattern) throws Exception 
    {
        if (value == null) return null;
        
        SimpleDateFormat sdf = new SimpleDateFormat(pattern);
        if (value instanceof Date) return sdf.format(value);
        
        return sdf.format(sdf.parse(value.toString()));
    }
    
    public static String formatNumber(Object value, String pattern) throws Exception 
    {
        if (value == null) return null;
        
        DecimalFormat sdf = new DecimalFormat(pattern);
        if (value instanceof Number) return sdf.format(value);
        
        return sdf.format(sdf.parse(value.toString()));
    } 
    
    private CommonUtil() {;}

}
