package test;

import groovy.lang.GroovyShell;
import junit.framework.*;

public class Test2 extends TestCase 
{
    
    public Test2(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
    }

    protected void tearDown() throws Exception {
    }
    
    public void test000() throws Exception 
    {
        GroovyShell sh = new GroovyShell();
        sh.evaluate(getClass().getResourceAsStream("test3.groovy"));
    }

}
