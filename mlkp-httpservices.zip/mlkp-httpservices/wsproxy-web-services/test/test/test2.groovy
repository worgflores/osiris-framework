import test.*;

String mttn     = "823704905"; 
String userName = "phl00001";
String password = "sysadmin";
String branchid = "mlabra3";
String citycode = "2800";
String secretkey = CommonUtil.createSignature(password) + branchid + citycode;

List params = [
    ["MTTN", mttn] as Object[],
    ["userName", userName] as Object[],
    ["password", CommonUtil.createSignature(password)] as Object[],
    ["branchId", branchid] as Object[],
    ["secretKey", CommonUtil.createSignature(secretkey)] as Object[],
    ["cityCode", citycode] as Object[]
] as ArrayList;

def req = [
    wsdl:"https://194.165.134.230:8181/TransCore/GenericIntegration?wsdl",
    targetURI:"http://delegate.business.transcore.moneytranist.net/",
    methodName:"searchTransaction",
    parameters:params
];

HttpServiceClient c = new HttpServiceClient();
Object o = c.invoke("http://192.168.3.211:8080/services/soapws/invoke", req);
println o;
