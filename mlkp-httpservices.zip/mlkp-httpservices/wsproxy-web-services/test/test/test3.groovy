import java.util.HashMap;
import java.util.Map;
import java.util.ArrayList;
import java.util.List;
import test.*;

String username = "phl00001";
String password = "sysadmin";
String citycode = "2800";
String branchid = "mlabra3";
String wsdl = "https://194.165.134.230:8181/TransCore/GenericIntegration?wsdl";    
String targetURI = "http://delegate.business.transcore.moneytranist.net/";

String md5password = CommonUtil.createSignature(password);
String secretkey = md5password + branchid + citycode;

def params = [refno:"823704905"];
def list = [
    ["MTTN",      params.refno] as Object[],
    ["userName",  username] as Object[],
    ["password",  md5password] as Object[],
    ["branchId",  branchid] as Object[],
    ["secretKey", CommonUtil.createSignature(secretkey)] as Object[],
    ["cityCode", citycode] as Object[]
] as ArrayList;

def map = [
    wsdl:wsdl, targetURI:targetURI, methodName:"searchTransaction", parameters:list
];

HttpServiceClient c = new HttpServiceClient();
def res = c.invoke("http://192.168.3.211:8080/services/soapws/invoke", map );    
print res;
