package test;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import junit.framework.*;

public class MLGLOBALTest extends TestCase 
{
    
    public MLGLOBALTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
    }

    protected void tearDown() throws Exception {
    }
    
    public void test0000() throws Exception
    {

    }
       
    public void xtestUpdateResource() throws Exception
    {
        //byte[] bytes = toBytes(new FileInputStream(new File("F:/ELMO_BACKUP/mlglobal/services/mlglobal-reports-services.jar/META-INF/sql/admin_sales_report.sql"))); 
        byte[] bytes = toBytes(new FileInputStream(new File("F:/ELMO_BACKUP/mlglobal/services/mlglobal-reports-services.jar/META-INF/scripts/AdminSalesReport"))); 
        
        
        HttpServiceClient c = new HttpServiceClient(); 
        Object result = c.invoke("http://124.6.157.254:8080/services/common/updateResource/apps/mlglobal.ear/services.jar/mlglobal-reports-services.jar/META-INF/scripts/AdminSalesReport", bytes);  
        System.out.println(result);
    }
    
    private String getResourceContent(String resname) throws Exception 
    {
        ClassLoader loader = Thread.currentThread().getContextClassLoader(); 
        InputStream inp = loader.getResourceAsStream(resname); 
        try 
        {
            int read = -1;
            StringBuffer sb = new StringBuffer(); 
            while ((read=inp.read()) != -1) {
                sb.append((char) read); 
            }
            return sb.toString(); 
        }
        catch(Exception ex) {
            throw ex; 
        }
        finally {
            try { inp.close(); }catch(Exception ign){;} 
        }
    } 
    
    private byte[] toBytes(InputStream inp) throws Exception 
    {
        ByteArrayOutputStream baos = null; 
        try
        {
            baos = new ByteArrayOutputStream(); 
            int read = -1;
            while ((read=inp.read()) != -1) {
                baos.write(read); 
            }
            return baos.toByteArray(); 
        }
        catch(Exception ex) {
            throw ex; 
        }
        finally 
        {
            try { inp.close(); }catch(Exception ing){;} 
            try { baos.close(); }catch(Exception ing){;} 
        }
    }
}



