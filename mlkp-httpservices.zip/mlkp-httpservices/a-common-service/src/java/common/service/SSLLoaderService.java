package common.service;

import common.net.SSLLoader;
import java.io.*;

import javax.servlet.*;
import javax.servlet.http.*;

public class SSLLoaderService extends HttpServlet 
{
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);
    }
    
    public String getServletInfo() { return "SSLLoaderService"; }
    // </editor-fold>
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
    {
        PrintWriter out = response.getWriter();
        try {
            out.println(getClass().getSimpleName() + " OK"); 
        } 
        catch(Exception ex) 
        {
            out.println("ERROR: " + ex.getClass().getName() + ": " + ex.getMessage()); 
        }
        finally {
            try { out.close(); }catch(Exception ing){;} 
        }
    }

    public void init() throws ServletException 
    {
        System.out.println(getClass().getSimpleName() + " initializing...");
        super.init(); 
        try { 
            SSLLoader.initialize(); 
        } catch(Exception ex) {
            ex.printStackTrace(); 
        } 
        System.out.println(getClass().getSimpleName() + " started "); 
    } 
}
