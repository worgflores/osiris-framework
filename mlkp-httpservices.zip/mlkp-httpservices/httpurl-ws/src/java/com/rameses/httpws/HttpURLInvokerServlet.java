package com.rameses.httpws;

import java.io.*;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.*;
import javax.servlet.http.*;

public class HttpURLInvokerServlet extends HttpServlet 
{
    private String KEYNAME = "services/httpws/url/invoker";
    
    // <editor-fold defaultstate="collapsed" desc=" HttpServlet methods. Click on the + sign on the left to edit the code. ">
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response); 
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response); 
    }
    
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response); 
    }
    
    public String getServletInfo() { return KEYNAME; }
    // </editor-fold>
    
    protected Object processRequest(HttpServletRequest req, Map mapreq) throws Exception
    {
        Object oHost = mapreq.get("host"); 
        if (oHost == null) throw new Exception("'host' parameter is required");
        
        HttpURLInvoker c = new HttpURLInvoker(oHost.toString()); 
        try {
            c.setTimeout(Integer.parseInt(mapreq.get("timeout").toString()));
        } catch(Exception ign) {;} 

        Map parameters = (Map) mapreq.get("parameters"); 
        Object oReqMethod = mapreq.get("requestMethod"); 
        
        System.out.println("[HttpWS/URL/Invoker] " + oHost); 
        if (oReqMethod == null) 
            return c.invoke(parameters); 
        else
            return c.invoke(parameters, oReqMethod.toString()); 
    }
    
    protected void processRequest(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException 
    {
        Map result = new HashMap(); 
        String keyname = KEYNAME;
        ObjectInputStream in = null;
        ObjectOutputStream out = null;
        
        try 
        {
            in = new ObjectInputStream(req.getInputStream());
            Map mapreq = (Map) in.readObject();
            Object value = processRequest(req, mapreq);
            
            result.put("result", value);  
            result.put("respcode", "1");
            result.put("respdesc", "OK");
            
            out = new ObjectOutputStream(res.getOutputStream());
            out.writeObject(result);
        } 
        catch (Exception ex) 
        {
            System.out.println("["+keyname+"-ERROR] " + ex.getMessage());
            
            String errdetail = getStackTrace(ex);
            try { System.out.println(errdetail); } catch(Throwable t) {;}
            
            result.put("respcode", "0");
            result.put("respdesc", ex.getMessage()+"");
            result.put("respdetail", errdetail);
            
            out = new ObjectOutputStream(res.getOutputStream());
            out.writeObject(result);       
        } 
        catch (Error err) 
        {
            System.out.println("["+keyname+"-ERROR] " + err.getMessage());
            
            String errdetail = getStackTrace(err);
            try { System.out.println(errdetail); } catch(Throwable t) {;}
            
            result.put("respcode", "0");
            result.put("respdesc", err.getMessage()+"");
            result.put("respdetail", errdetail);
            
            out = new ObjectOutputStream(res.getOutputStream());
            out.writeObject(result);     
        }         
        finally 
        {
            try { out.close(); } catch (Exception ex) {;}
            try { in.close(); } catch (Exception ex ){;}
        }
    }
    
    private String getStackTrace(Exception ex)
    {
        ByteArrayOutputStream baos = null;
        try
        {
            baos = new ByteArrayOutputStream();
            ex.printStackTrace(new PrintStream(baos));
            return new String(baos.toByteArray());
        }
        catch(Exception e) {
            return "";
        }
        finally {
            try { baos.close(); }catch(Exception ign) {;} 
        }
    }
    
    private String getStackTrace(Error ex)
    {
        ByteArrayOutputStream baos = null;
        try
        {
            baos = new ByteArrayOutputStream();
            ex.printStackTrace(new PrintStream(baos));
            return new String(baos.toByteArray());
        }
        catch(Exception e) {
            return "";
        }
        finally {
            try { baos.close(); }catch(Exception ign) {;} 
        }
    }    
}
