package com.rameses.http.service.mail;

import java.io.*;
import java.net.URLDecoder;
import javax.naming.InitialContext;
import javax.servlet.*;
import javax.servlet.http.*;

public class SendInvokerServlet extends HttpServlet 
{
    private String KEYNAME = "services/mail/send";    
    
    // <editor-fold defaultstate="collapsed" desc=" HttpServlet methods. Click on the + sign on the left to edit the code. ">
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response); 
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response); 
    }
    
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response); 
    }
    
    public String getServletInfo() { return KEYNAME; }
    // </editor-fold>
    
    private Object IFNULL(Object value, Object defvalue)
    {
        if (value == null) return defvalue;
        
        return value; 
    }    
    
    protected void processRequest(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException 
    {
        PrintWriter out = null;
        
        try 
        { 
            out = res.getWriter(); 
            
            String jndiName = req.getParameter("jndiname"); 
            if (jndiName == null || jndiName.trim().length() == 0) throw new Exception("'jndiname' parameter is required"); 
            
            String subject = req.getParameter("subject"); 
            if (subject == null || subject.trim().length() == 0) throw new Exception("'subject' parameter is required"); 

            String to = req.getParameter("to"); 
            if (to == null || to.trim().length() == 0) throw new Exception("'to' parameter is required"); 

            String text = req.getParameter("message"); 
            if (text == null || text.length() == 0) throw new Exception("'message' parameter is required"); 
            
            InitialContext ctx = new InitialContext(); 
            javax.mail.Session session = (javax.mail.Session) ctx.lookup("java:" + jndiName); 
            javax.mail.internet.MimeMessage msg = new javax.mail.internet.MimeMessage(session); 
            msg.setFrom(); 
            msg.setSubject(URLDecoder.decode(subject));
            msg.setSentDate(new java.util.Date()); 
            
            int recipientCount = 0;
            String[] values = req.getParameterValues("to"); 
            for (int i=0;i <values.length; i++) 
            {
                String sv = values[i]; 
                if (sv == null || sv.trim().length() == 0) continue; 
                
                msg.addRecipients(javax.mail.Message.RecipientType.TO, sv.trim()); 
                recipientCount += 1;
            }
            
            if (recipientCount == 0)
                throw new Exception("Please specify a valid recipient email address"); 
            
            msg.setText(URLDecoder.decode(text)); 
            javax.mail.Transport.send(msg); 
            
            out.println("respcode=1"); 
            out.println("respmsg=Message successfully sent."); 
        } 
        catch(Exception ex) 
        {
            out.println("respcode=0"); 
            out.println("respmsg=" + ex.getClass().getName() + ": " + ex.getMessage()); 
            out.println("respdetail=" + getStackTrace(ex)); 
            
            System.out.println("[ERROR "+KEYNAME+"] " + ex.getClass().getName() + ": " + ex.getMessage());
        } 
        finally {
            try { out.close(); }catch(Exception ing){;}             
        }
    }
    
    private String getStackTrace(Exception ex)
    {
        ByteArrayOutputStream baos = null;
        try
        {
            baos = new ByteArrayOutputStream();
            ex.printStackTrace(new PrintStream(baos));
            return new String(baos.toByteArray());
        }
        catch(Exception e) {
            return "";
        }
        finally {
            try { baos.close(); }catch(Exception ign) {;} 
        }
    }
}
