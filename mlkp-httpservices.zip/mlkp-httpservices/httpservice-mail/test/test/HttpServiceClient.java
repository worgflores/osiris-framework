package test;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Map;

public class HttpServiceClient  
{
    private int timeout;
    
    public int getTimeout() { return timeout; }
    public void setTimeout(int timeout) { this.timeout = timeout; }
    
    public Object invoke(String host, Map req) throws Exception 
    {
        if (host == null || host.trim().length() == 0)
            throw new NullPointerException("'host' parameter is required");
        
        URL url = null;
        HttpURLConnection conn = null;
        ObjectOutputStream out = null;
        ObjectInputStream in = null;
        
        try 
        {
            url = new URL(host);
            conn = (HttpURLConnection) url.openConnection();
            conn.setDoOutput(true); 
            conn.setUseCaches(false); 
            if (getTimeout() > 0)
            {
                conn.setConnectTimeout(getTimeout());  
                conn.setReadTimeout(getTimeout()); 
            }
            
            out = new ObjectOutputStream(conn.getOutputStream());
            out.writeObject(req);
            
            in = new ObjectInputStream(conn.getInputStream());
            Object res = in.readObject();
            if (res instanceof Exception) {
                throw (Exception) res;
            }
            else if (res instanceof Map)
            {
                Map map = (Map) res;
                if ("1".equals(map.get("respcode")))
                {
                    System.out.println(map.get("errdetail")+"");
                    throw new Exception(map.get("errmsg")+"");
                }
            }
            return res;
        } 
        catch (Exception ex) {
            throw ex;
        } 
        finally 
        {
            try { in.close(); } catch(Exception ex){;}
            try { out.close(); } catch(Exception ex){;}
            try { conn.disconnect(); } catch(Exception ex){;}
        }
    }    
}
