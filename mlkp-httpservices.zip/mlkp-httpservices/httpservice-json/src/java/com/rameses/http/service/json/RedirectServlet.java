package com.rameses.http.service.json;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import javax.servlet.*;
import javax.servlet.http.*;
import net.sf.json.JSONObject;

public class RedirectServlet extends HttpServlet 
{
    private String KEYNAME = "services/json/redirect";
    
    // <editor-fold defaultstate="collapsed" desc=" HttpServlet methods. Click on the + sign on the left to edit the code. ">
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response, "GET");
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response, "POST");
    }
    
    public String getServletInfo() { return "Redirect Servlet"; }
    // </editor-fold>
    
    protected void processRequest(HttpServletRequest req, HttpServletResponse res, String reqMethod) throws ServletException, IOException 
    {
        String pathInfo = req.getPathInfo(); 
        if (pathInfo == null || "/".equals(pathInfo))
            throw new ServletException("Request PathInfo is required");
        
        pathInfo = pathInfo.substring(1); 
        pathInfo = pathInfo.replaceAll(":/", "://");
        
        String retType = req.getParameter("_type")+""; 
        if ("object".equalsIgnoreCase(retType)) 
            processCustomRequest(req, res, reqMethod, pathInfo); 
        else
            processDefaultRequest(req, res, reqMethod, pathInfo);         
    }    
    
    private void processCustomRequest(HttpServletRequest req, HttpServletResponse res, String reqMethod, String pathInfo) throws ServletException, IOException 
    {
        ObjectInputStream in = null;
        ObjectOutputStream out = null;        
        try
        {
            in = new ObjectInputStream(req.getInputStream());
            Map reqmap = (Map) in.readObject();
            
            String text = invoke(req, pathInfo, reqMethod, reqmap); 
            JSONObject jsonbean = (JSONObject) new net.sf.json.groovy.JsonSlurper().parseText(text); 
            
            Map resmap = new HashMap(); 
            Iterator keys = jsonbean.keys(); 
            while (keys.hasNext())
            {
                Object key = keys.next(); 
                Object val = jsonbean.get(key); 
                resmap.put(key, val); 
            } 
            
            resmap.put("respcode", "1"); 
            out = new ObjectOutputStream(res.getOutputStream());
            out.writeObject(resmap);            
        } 
        catch(Exception ex) 
        { 
            System.out.println("[ERROR] " + KEYNAME + ": " + ex.getMessage());
            System.out.println("        Path-Info: " + req.getPathInfo());
            
            Map resmap = new HashMap(); 
            resmap.put("respcode", "0"); 
            resmap.put("respmsg", ex.getMessage()); 
            resmap.put("respdetail", getStackTrace(ex));  
            
            out = new ObjectOutputStream(res.getOutputStream());
            out.writeObject(resmap);                        
        } 
        finally 
        {
            try { in.close(); } catch (Exception ex ){;}
            try { out.close(); } catch (Exception ex) {;}            
        }
    }

    private void processDefaultRequest(HttpServletRequest req, HttpServletResponse res, String reqMethod, String pathInfo) throws ServletException, IOException   
    {
        PrintWriter out = null;
        try
        {
            res.setContentType("text/plain"); 
            out = res.getWriter(); 
            
            String result = invoke(req, pathInfo, reqMethod, null); 
            JSONObject jsonbean = (JSONObject) new net.sf.json.groovy.JsonSlurper().parseText(result); 
            Iterator keys = jsonbean.keys(); 
            while (keys.hasNext()) 
            {
                Object key = keys.next(); 
                Object val = jsonbean.get(key); 
                out.println(key + "=" + val);
            } 
            out.println("respcode=1");
        } 
        catch(Exception ex) 
        {
            System.out.println("[ERROR] " + KEYNAME + ": " + ex.getMessage());
            System.out.println("        Path-Info: " + req.getPathInfo());
            
            out.println("respcode=0");
            out.println("respmsg=" + ex.getMessage());
            out.println("respdetail=" + getStackTrace(ex));
        } 
        finally { 
            try { out.close(); }catch(Exception ing){;} 
        } 
    }
    
    private String invoke(HttpServletRequest req, String urlpath, String reqmethod, Map reqmap) throws Exception 
    {
        URLConnection conn = null; 
        try
        {
            URL url = new URL(urlpath); 
            conn = url.openConnection(); 
            if (conn instanceof HttpURLConnection)
            {
                if (reqmethod != null && reqmethod.length() > 1) 
                    ((HttpURLConnection) conn).setRequestMethod(reqmethod); 
            }
            
            StringBuffer request = new StringBuffer(); 
            if (reqmap == null || reqmap.isEmpty())
            {
                Enumeration names = req.getParameterNames();
                while (names.hasMoreElements()) 
                {
                    String name = names.nextElement().toString(); 
                    if (name.startsWith("_")) continue;

                    String[] values = req.getParameterValues(name); 
                    if (values == null) values = new String[]{};

                    for (int i=0; i<values.length; i++) 
                    {
                        String svalue = values[i]; 
                        if (svalue == null) svalue = "";
                        if (request.length() > 0) request.append("&"); 

                        request.append(URLEncoder.encode(name) + "=" + URLEncoder.encode(svalue)); 
                    }
                }
            }
            else
            {
                Iterator names = reqmap.keySet().iterator(); 
                while (names.hasNext()) 
                {
                    String key = names.next().toString(); 
                    Object val = reqmap.get(key); 
                    String sval = (val == null ? "" : val.toString()); 
                    
                    if (request.length() > 0) request.append("&"); 
                    request.append(URLEncoder.encode(key) + "=" + URLEncoder.encode(sval)); 
                }
            }
            
            conn.setDoInput(true);
            conn.setDoOutput(true);
            conn.setUseCaches(false); 
            
            try 
            { 
                int timeout = Integer.parseInt(req.getParameter("_timeout")); 
                conn.setConnectTimeout(timeout); 
            } 
            catch(Exception ing){;} 
            
            
            OutputStreamWriter osw = null;
            try
            {
                osw = new OutputStreamWriter(conn.getOutputStream()); 
                osw.write(request.toString()); 
                osw.flush(); 
            } 
            catch(Exception e1) {
                throw e1;
            }
            finally {
                try { osw.close(); }catch(Exception ign){;} 
            }
            
            InputStream inp = conn.getInputStream(); 
            int read = -1; 
            
            try
            {
                StringBuffer resbuff = new StringBuffer(); 
                while ((read=inp.read()) != -1) {
                    resbuff.append((char) read); 
                } 
                return resbuff.toString(); 
            } 
            catch(Exception e1){
                throw e1; 
            } 
            finally {
                try { inp.close(); }catch(Exception ign){;} 
            }
        }
        catch(Exception ex) {
            throw ex; 
        }
    }
    
    private String getStackTrace(Exception ex)
    {
        ByteArrayOutputStream baos = null;
        try
        {
            baos = new ByteArrayOutputStream();
            ex.printStackTrace(new PrintStream(baos));
            return new String(baos.toByteArray());
        }
        catch(Exception e) {
            return "";
        }
        finally {
            try { baos.close(); }catch(Exception ign) {;} 
        }
    }

}
