package test;

import java.util.Iterator;
import junit.framework.*;
import net.sf.json.JSONObject;

public class NewEmptyJUnitTest extends TestCase 
{
    
    public NewEmptyJUnitTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
    }

    protected void tearDown() throws Exception {
    }
    
    public void test0000() throws Exception 
    {
        JSONObject jsonbean = (JSONObject) new net.sf.json.groovy.JsonSlurper().parseText("{\"code\":\"1234\", \"desc\":\"sample\"}"); 
        Iterator keys = jsonbean.keys();
        while (keys.hasNext())
        {
            Object key = keys.next();
            Object val = jsonbean.get(key); 
            System.out.println(key + "=" + val);
        }
    }

}
