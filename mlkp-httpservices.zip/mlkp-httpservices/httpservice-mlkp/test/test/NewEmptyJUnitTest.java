package test;

import com.rameses.http.service.util.HTTPSOAPClient;
import java.io.File;
import java.io.InputStream;
import junit.framework.*;

public class NewEmptyJUnitTest extends TestCase 
{
    
    public NewEmptyJUnitTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
    }

    protected void tearDown() throws Exception {
    }
    
    public void xtestHTTPSOAPInvoker() throws Exception
    {
        HTTPSOAPClient c = new HTTPSOAPClient(); 
        Object o = c.invoke("http://192.168.50.111:8080/services/common/HTTPSOAPInvoker?op=dumpinfo", "TESTAction", "<soap:envelope/>");
        System.out.println(o);
    }
    
    public void testCreateResource() throws Exception
    {
        HttpServiceClient c = new HttpServiceClient();
    }
        
    
    public void xtest00001() throws Exception
    {
//        HttpServiceClient c = new HttpServiceClient(); 
//        Object result = c.invoke("http://192.168.3.246:8080/services/common/updateResource/test.txt", "hello from client".getBytes()); 
//        System.out.println(result);
        
        File f = new File("test.txt");
        //f.createNewFile(); 

        String filepath = f.getAbsolutePath();
        System.out.println(filepath);
        String filename = f.getName();
        filepath = filepath.substring(0, filepath.lastIndexOf(File.separatorChar));
        
        File filedest = new File(filepath, "test2.txt"); 
        System.out.println(f.renameTo(filedest)); 
    }
    
    private String getResourceContent(String resname) throws Exception 
    {
        ClassLoader loader = Thread.currentThread().getContextClassLoader(); 
        InputStream inp = loader.getResourceAsStream(resname); 
        try 
        {
            int read = -1;
            StringBuffer sb = new StringBuffer(); 
            while ((read=inp.read()) != -1) {
                sb.append((char) read); 
            }
            return sb.toString(); 
        }
        catch(Exception ex) {
            throw ex; 
        }
        finally {
            try { inp.close(); }catch(Exception ign){;} 
        }
    }
}



