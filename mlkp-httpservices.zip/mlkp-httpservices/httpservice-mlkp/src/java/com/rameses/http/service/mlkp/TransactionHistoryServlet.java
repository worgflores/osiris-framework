package com.rameses.http.service.mlkp;

import com.rameses.http.service.util.SQLDB;
import java.io.*;
import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import javax.servlet.*;
import javax.servlet.http.*;

public class TransactionHistoryServlet extends HttpServlet 
{
    // <editor-fold defaultstate="collapsed" desc=" HttpServlet methods. Click on the + sign on the left to edit the code. ">
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);
    }
    
    public String getServletInfo() { 
        return getClass().getName(); 
    }
    // </editor-fold>
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
    {
        response.setContentType("text/xml;charset=UTF-8");
        
        Helper helper = new Helper();
        XmlResponse xmlres = new XmlResponse(); 
        PrintWriter out = null; 
        
        try
        {
            out = response.getWriter();
            
            xmlres.setRespcode(1); 
            xmlres.setRespmsg("OK"); 
            
            checkRequiredField(request, "kycno", "KYC-Number"); 
            checkRequiredField(request, "requesterid", "Requester"); 
            checkRequiredField(request, "custtype", "Customer-Type"); 
            checkRequiredField(request, "startdate", "Start-Date"); 
            checkRequiredField(request, "enddate", "End-Date"); 
            
            String custtype = request.getParameter("custtype");
            if (!custtype.toLowerCase().matches("sender|receiver")) 
                throw new Exception("'"+custtype+"' unsupported customer type"); 
            
            String startdate = request.getParameter("startdate"); 
            String enddate = request.getParameter("enddate"); 
            if (!helper.isDate(startdate)) throw new Exception("'"+startdate+"' startdate is invalid"); 
            if (!helper.isDate(enddate)) throw new Exception("'"+enddate+"' enddate is invalid"); 
            
            Date dtfrom = helper.encodeDate(startdate); 
            Date dtto = helper.encodeDate(enddate); 
            if (dtfrom.after(dtto)) 
                throw new Exception("startdate must be less than of equal to enddate"); 
            
            Calendar cal = Calendar.getInstance(); 
            cal.setTime(dtfrom); 
            cal.add(Calendar.DATE, 6); 
            if (dtto.after(cal.getTime())) 
                throw new Exception("The maximum date interval allowed is only up to 7 days"); 
            
            //check KYC-NO if exist 
            SQLDB sqldb = new SQLDB();
            Connection conn = null;
            Map kycdata = null;
            try
            {
                conn = sqldb.createConnection("java:mlkyc"); 
                
                String kycno = request.getParameter("kycno");
                kycdata = sqldb.getSingleResult(conn, "select lastname, firstname, ifnull(middlename,'') as middlename from mlkyc.customer where custno=?", new Object[]{kycno});  
                if (kycdata == null || kycdata.isEmpty()) throw new Exception("'"+kycno+"' KYC Number not found");
            }
            catch(Exception ex) {
                throw ex; 
            }
            finally {
                try { conn.close(); }catch(Exception ign){;} 
            }
            
            SimpleDateFormat YMD = new SimpleDateFormat("yyyy-MM-dd"); 
            try
            {
                conn = sqldb.createConnection("java:mlauditordb"); 
                List results = new ArrayList(); 
                
                cal.setTime(dtfrom); 
                while (true)
                {
                    Date dt = cal.getTime();
                    if (dt.after(dtto)) break;
                    
                    String sdate = YMD.format(dt); 
                    if (custtype.equalsIgnoreCase("sender"))
                    {
                        String sql = helper.convertStreamAsString(TransactionHistoryServlet.class.getResourceAsStream("sql/sendoutdailybysender.sql")); 
                        List list = sqldb.getList(conn, sql, new Object[]{ 
                            sdate+" 00:00:00", sdate+" 23:59:59", kycdata.get("lastname"), 
                            kycdata.get("firstname"), kycdata.get("middlename") 
                        });
                        results.addAll(list); 
                    }
                    else if (custtype.equalsIgnoreCase("receiver"))
                    {
                        String sql = helper.convertStreamAsString(TransactionHistoryServlet.class.getResourceAsStream("sql/sendoutdailybyreceiver.sql")); 
                        List list = sqldb.getList(conn, sql, new Object[]{ 
                            sdate+" 00:00:00", sdate+" 23:59:59", kycdata.get("lastname"), 
                            kycdata.get("firstname"), kycdata.get("middlename") 
                        });
                        results.addAll(list); 
                    }
                    
                    cal.add(Calendar.DATE, 1); 
                } 
                xmlres.setResult(results); 
            }
            catch(Exception ex) {
                throw ex; 
            }
            finally {
                try { conn.close(); }catch(Exception ign){;} 
            }
        }
        catch(Exception ex)
        {
            xmlres.setRespcode(0); 
            xmlres.setRespmsg(ex.getMessage()); 
            xmlres.setRespdetail(helper.getStackTrace(ex)); 
        } 
        finally 
        {
            try { out.println(xmlres.encode()); }catch(Exception ign){;} 
            try { out.close(); }catch(Exception ign){;} 
        }
    }
    
    private void checkRequiredField(HttpServletRequest request, String name, String title) 
    {
        if (request.getParameterMap().containsKey(name)) 
        {
            String value = request.getParameter(name); 
            if (value != null) return;
        }
        
        String title0 = title;
        if (title0 == null) title0 = name;
        
        throw new NullPointerException("'"+title0+"' parameter is required               "); 
    } 
    
}
