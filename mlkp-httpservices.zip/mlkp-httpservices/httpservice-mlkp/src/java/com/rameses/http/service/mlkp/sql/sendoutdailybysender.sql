select 
	s.dtfiled, s.strkptn as kptn, s.state,  
	case
		when s.state=0 then 'UNCLAIMED' 
		when s.state=1 then 'CLAIMED' 
		when s.state=2 then 'CANCELLED' 
		when s.state=3 then 'UNCLAIMED' 
		when s.state=5 then 'RETURNED' 
	end as `status`, 
	concat(s.strsenderlname,', ',s.strsenderfname,' ',ifnull(s.strsendermname,'')) as sendername,  
	concat(s.strreceiverlname,', ',s.strreceiverfname,' ',ifnull(s.strreceivermname,'')) as receivername,  
	s.curprincipal as sendamount, ifnull(sif.strcurrencyid,'PHP') as sendcurrency, 
	s.strbranchid as sendbranchid, p.dtclaimed, p.strbranchid as paybranchid 
from (
		select objid, strsenderlname, strsenderfname, ifnull(strsendermname,'') as strsendermname 
		from mlkp.tblsendout where dtfiled between ? and ? 
		having strsenderlname=? and strsenderfname=? and strsendermname=?  
	)bt 
	inner join mlkp.tblsendout s on bt.objid=s.objid 
	left join mlkp.tblsendoutinfo sif on s.objid=sif.objid 
	left join mlkp.tblpayout p on s.objid=p.strsendoutid 
where s.state in (0,1,2,3,5) 
order by s.dtfiled 
