package com.rameses.http.service.mlkp;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class XmlResponse 
{
    private int respcode = 1;
    private String respmsg = "OK";
    private String respdetail;
    private Object result;
    
    public XmlResponse() {
    }

    public int getRespcode() { return respcode; }
    public void setRespcode(int respcode) { this.respcode = respcode; }

    public String getRespmsg() { return respmsg; }
    public void setRespmsg(String respmsg) { this.respmsg = respmsg; }

    public String getRespdetail() { return respdetail; }
    public void setRespdetail(String respdetail) { this.respdetail = respdetail; }

    public Object getResult() { return result; }
    public void setResult(Object result) { this.result = result; }
    
    public String encode() throws Exception 
    {
        StringBuffer sb = new StringBuffer(); 
        sb.append("<response>"); 
        sb.append("<respcode>"+ getRespcode() +"</respcode>");  
        sb.append("<respmsg>"+ getRespmsg() +"</respmsg>"); 
        sb.append("<respdetail>"+ IFNULL(getRespdetail(),"") +"</respdetail>"); 
        sb.append("<result>"); 
        
        Object ov = getResult(); 
        if (ov == null) {;} 
        else if (ov instanceof Map) 
            sb.append(encode((Map) ov)); 
        else if (ov instanceof List) 
            sb.append(encode((List) ov)); 
        else 
            sb.append("<![CDATA["+ ov +"]]>"); 
        
        sb.append("</result>"); 
        sb.append("</response>"); 
        return sb.toString(); 
    }
    
    private Object IFNULL(Object value, Object defaultValue)
    {
        if (value == null) return defaultValue;
        else if (value.toString().length() == 0) return defaultValue;
        else return value; 
    }
    
    private String encode(Map data) throws Exception 
    {
        StringBuffer sb = new StringBuffer(); 
        Iterator keys = data.keySet().iterator();
        while (keys.hasNext()) 
        {
            String key = keys.next().toString(); 
            Object val = data.get(key); 
            sb.append("<"+ key +">");
            if (val == null) {;} 
            else if (val instanceof Map)
                sb.append(encode((Map) val));
            else
                sb.append("<![CDATA["+ val +"]]>"); 

            sb.append("</"+ key +">");
        }   
        return sb.toString(); 
    }

    private String encode(List list) throws Exception 
    {
        StringBuffer sb = new StringBuffer(); 
        while (!list.isEmpty()) 
        {
            Object o = list.remove(0); 
            sb.append("<item>");
            if (o == null) {;}
            else if (o instanceof Map)
                sb.append(encode((Map) o)); 
            else 
                sb.append("<![CDATA["+ o +"]]>"); 
                    
            sb.append("</item>");
        }   
        return sb.toString(); 
    }
    
}
