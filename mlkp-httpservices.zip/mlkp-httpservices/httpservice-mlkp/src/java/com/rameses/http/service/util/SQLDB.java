package com.rameses.http.service.util;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class SQLDB 
{
    public Connection createConnection(String dsname) throws Exception 
    {
        InitialContext ctx = new InitialContext(); 
        DataSource ds = (DataSource) ctx.lookup(dsname); 
        return ds.getConnection(); 
    }
    
    public Date getServerDate(Connection conn) throws Exception { 
        return (Date) getSingleResult(conn, "select now() as serverdate", null).get("serverdate");
    }
    
    public int execUpdate(Connection conn, String sql, Object[] params) throws Exception 
    {
        PreparedStatement ps = null;
        try 
        {
            ps = conn.prepareStatement(sql);
            if (params != null) 
            {
                for (int i=0; i<params.length; i++) {
                    ps.setObject(i+1, params[i]);
                }
            }
            return ps.executeUpdate();
        } 
        catch(Exception e) {
            throw e;
        } 
        finally {
            try { ps.close(); }catch(Exception ign){;}
        } 
    } 
    
    public int insertData(Connection conn, String tablename, Map data) throws Exception 
    {
        PreparedStatement ps = null;
        try 
        {
            StringBuffer fieldBuff = new StringBuffer(); 
            StringBuffer valueBuff = new StringBuffer(); 
            Iterator keys = data.keySet().iterator(); 
            while (keys.hasNext()) 
            {
                String key = keys.next().toString(); 
                if (fieldBuff.length() > 0) 
                {
                    fieldBuff.append(", ");
                    valueBuff.append(", ");
                } 
                
                fieldBuff.append(key); 
                valueBuff.append("?"); 
            } 
            
            int counter = 1;
            String sql = " insert ignore into " + tablename + " (" + fieldBuff + ") values (" +  valueBuff + ")";
            ps = conn.prepareStatement(sql);
            keys = data.keySet().iterator(); 
            while (keys.hasNext()) 
            {
                ps.setObject(counter, data.get(keys.next().toString()));
                counter += 1; 
            }
            return ps.executeUpdate();
        } 
        catch(Exception e) {
            throw e;
        } 
        finally {
            try { ps.close(); }catch(Exception ign){;}
        } 
    }    
    
    public Map getSingleResult(Connection conn, String sql, Object[] params) throws Exception 
    {
        List list = (List) execQuery(conn, sql, params, true); 
        if (list.isEmpty()) return new HashMap(); 
        
        return (Map) list.remove(0); 
    }
    
    public List getList(Connection conn, String sql, Object[] params) throws Exception {
        return (List) execQuery(conn, sql, params, false);
    }
    
    private Object execQuery(Connection conn, String sql, Object[] params, boolean singleResult) throws Exception 
    {
        PreparedStatement ps = null;
        ResultSet rs = null;
        try 
        {
            ps = conn.prepareStatement(sql);
            if (params != null) 
            {
                for (int i=0; i<params.length; i++) {
                    ps.setObject(i+1, params[i]);
                }
            }
            rs = ps.executeQuery();
            
            ResultSetMetaData meta = rs.getMetaData(); 
            int columnCount = meta.getColumnCount(); 
            List list = new ArrayList();
            while (rs.next()) 
            {
                Map data = new HashMap();
                for (int i=1; i<= columnCount; i++) 
                {
                    String colname = meta.getColumnName(i); 
                    try {
                        data.put(colname, rs.getObject(i)); 
                    } 
                    catch(SQLException sqle) 
                    { 
                        Object colvalue = null; 
                        if (meta.getColumnType(i) == java.sql.Types.DATE) {;} 
                        else if (meta.getColumnType(i) == java.sql.Types.TIMESTAMP) {;} 
                        else throw sqle; 
                        
                        data.put(colname, colvalue); 
                    } 
                }
                
                list.add(data);
                if (singleResult) break; 
            }
            return list;
        } 
        catch(SQLException sqle) 
        {
//            System.out.println("error-code: " + sqle.getErrorCode());
//            System.out.println("sql-state: " + sqle.getSQLState());
//            System.out.println("sql-message: " + sqle.getMessage());
            throw sqle;
        }         
        catch(Exception e) {
            throw e;
        } 
        finally 
        {            
            try { rs.close(); }catch(Exception ign){;}
            try { ps.close(); }catch(Exception ign){;}
        } 
    }
    
    public Object[] execQuery2(Connection conn, String sql, Object[] params, boolean singleResult) throws Exception 
    {
        PreparedStatement ps = null;
        ResultSet rs = null;
        try 
        {
            ps = conn.prepareStatement(sql);
            if (params != null) 
            {
                for (int i=0; i<params.length; i++) {
                    ps.setObject(i+1, params[i]);
                }
            }
            rs = ps.executeQuery();
            
            ResultSetMetaData meta = rs.getMetaData(); 
            int columnCount = meta.getColumnCount(); 
            String[] colNames = new String[columnCount];
            for (int i=1; i<= columnCount; i++) { 
                colNames[i-1] = meta.getColumnName(i); 
            }
            
            Object resultData = null;
            List list = new ArrayList();
            while (rs.next()) 
            {
                Map data = new HashMap();
                for (int i=1; i<= columnCount; i++) 
                {
                    String colname = meta.getColumnName(i); 
                    try {
                        data.put(colname, rs.getObject(i)); 
                    } 
                    catch(SQLException sqle) 
                    { 
                        Object colvalue = null; 
                        if (meta.getColumnType(i) == java.sql.Types.DATE) {;} 
                        else if (meta.getColumnType(i) == java.sql.Types.TIMESTAMP) {;} 
                        else throw sqle; 
                        
                        data.put(colname, colvalue); 
                    } 
                }
                
                if (singleResult) 
                    return new Object[]{colNames, data};
                
                list.add(data);
            }
            return new Object[]{colNames, list};
        } 
        catch(SQLException sqle) { 
            throw sqle;
        } 
        catch(Exception e) {
            throw e;
        } 
        finally 
        {            
            try { rs.close(); }catch(Exception ign){;}
            try { ps.close(); }catch(Exception ign){;}
        } 
    }    
}
