package com.rameses.http.service.mlkp;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.PrintStream;
import java.text.SimpleDateFormat;
import java.util.Date;

class Helper 
{
    private SimpleDateFormat YMD = new SimpleDateFormat("yyyy-MM-dd"); 
    private SimpleDateFormat YMDHMS = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); 
    
    public String getStackTrace(Exception ex)
    {
        ByteArrayOutputStream baos = null;
        try
        {
            baos = new ByteArrayOutputStream();
            ex.printStackTrace(new PrintStream(baos));
            return new String(baos.toByteArray());
        }
        catch(Exception e) {
            return "";
        }
        finally {
            try { baos.close(); }catch(Exception ign) {;} 
        }
    } 
    
    public boolean isDate(Object value)
    {
        if (value == null) return false; 
        if (value instanceof Date) return true; 
        
        String sdate = value.toString(); 
        Date date = null; 
        try { 
            date = java.sql.Date.valueOf(sdate); 
        } catch(Exception ing){;} 
        
        try {
            if (date == null) date = java.sql.Timestamp.valueOf(sdate);
        } catch(Exception ign){;}  
        
        if (date == null) 
            return false; 
        else if (date instanceof java.sql.Timestamp)
            return YMDHMS.format(date).equals(sdate); 
        else
            return YMD.format(date).equals(sdate); 
    } 
    
    public Date encodeDate(String value) 
    {
        try {
            return java.sql.Date.valueOf(value); 
        }
        catch(java.lang.NumberFormatException nfe) { 
            throw new java.lang.NumberFormatException("Invalid date format"); 
        } 
        catch(RuntimeException rex) { 
            throw rex; 
        } 
    }    
    
    public Date encodeTimestamp(String value) 
    {
        try {
            return java.sql.Timestamp.valueOf(value); 
        }
        catch(java.lang.NumberFormatException nfe) { 
            throw new java.lang.NumberFormatException("Invalid timestamp format"); 
        } 
        catch(RuntimeException rex) { 
            throw rex; 
        } 
    } 
    
    public String convertStreamAsString(InputStream inp) throws Exception 
    {
        try 
        {
            StringBuffer sb = new StringBuffer(); 
            int read = -1;
            while ((read=inp.read()) != -1) {
                sb.append((char) read); 
            }
            return sb.toString(); 
        }
        catch(Exception ex) {
            throw ex; 
        }
        finally {
            try { inp.close(); }catch(Exception ign){;} 
        }
    }
    
}
