package com.mlhuillier.util.ui;

import com.mlhuillier.util.migration2.IDataTransfer;
import com.mlhuillier.util.migration2.TransferBillsPayment;
import com.mlhuillier.util.migration2.TransferBillsPaymentCancelled;
import com.mlhuillier.util.migration2.TransferBillsPaymentInvalidated;
import com.mlhuillier.util.migration2.TransferChangeRequest;
import com.mlhuillier.util.migration2.TransferPayout;
import com.mlhuillier.util.migration2.TransferPayoutCreditRemote;
import com.mlhuillier.util.migration2.TransferPerson;
import com.mlhuillier.util.migration2.TransferRTS;
import com.mlhuillier.util.migration2.TransferSendout;
import com.mlhuillier.util.migration2.TransferSendoutCancel;
import com.mlhuillier.util.migration2.TransferSendoutCreditRemote;
import com.mlhuillier.util.migration2.TransferSendoutInvalidate;
import com.mlhuillier.util.migration2.TransferUniTeller;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

public class TransferUtil 
{
    private JComponent[] components;
    private JLabel lblMsg;
    private String startdate;
    private String enddate;
    private String targetDS;
    
    public TransferUtil() {}
    
    void setComponents(JComponent[] components) {
        this.components = components;
    }
   
    void setMsgComponent(JLabel lbl) {
        this.lblMsg = lbl;
    }
    
    void start(String startdate, String enddate, String targetDS) 
    {
        this.startdate = startdate;
        this.enddate = enddate;
        this.targetDS = targetDS;
        
        Thread t = new Thread(new Runnable() 
        {
            public void run() { runImpl(); }
        });
        t.start();
    }
    
    private void runImpl()
    {
        try
        {
            Date dtstart = java.sql.Date.valueOf(startdate);
            Date dtend = java.sql.Date.valueOf(enddate);
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            Calendar cal = new GregorianCalendar();
            cal.setTime(dtstart);
            
            enableComponents(false);
            while (true)
            {
                Date dt = cal.getTime(); 
                if (dt.after(dtend)) break;

                String date = sdf.format(dt);
                
                refreshComponents("Starting changerequest... ["+date+"]");
                IDataTransfer idt = new TransferChangeRequest("master", targetDS);
                idt.transfer(date);                
                
                refreshComponents("Starting person... ["+date+"]");
                idt = new TransferPerson("master", targetDS);
                idt.transfer(date);

                refreshComponents("Starting sendout... ["+date+"]");
                idt = new TransferSendout("master", targetDS);
                idt.transfer(date);

                refreshComponents("Starting sendoutcancel... ["+date+"]");
                idt = new TransferSendoutCancel("master", targetDS);
                idt.transfer(date);            

                refreshComponents("Starting sendoutcredit... ["+date+"]");
                idt = new TransferSendoutCreditRemote("master", targetDS);
                idt.transfer(date);            

                refreshComponents("Starting sendoutinvalidate... ["+date+"]");
                idt = new TransferSendoutInvalidate("master", targetDS);
                idt.transfer(date);            

                refreshComponents("Starting returntosender... ["+date+"]");
                idt = new TransferRTS("master", targetDS);
                idt.transfer(date);            

                refreshComponents("Starting payout... ["+date+"]");
                idt = new TransferPayout("master", targetDS);
                idt.transfer(date);     

                refreshComponents("Starting payoutcredit... ["+date+"]");
                idt = new TransferPayoutCreditRemote("master", targetDS);
                idt.transfer(date); 

                refreshComponents("Starting uniteller... ["+date+"]");
                idt = new TransferUniTeller("master", targetDS);
                idt.transfer(date);
                
                refreshComponents("Starting billspayment... ["+date+"]");
                idt = new TransferBillsPayment("master", targetDS);
                idt.transfer(date);                
                
                refreshComponents("Starting billspaymentcancelled... ["+date+"]");
                idt = new TransferBillsPaymentCancelled("master", targetDS);
                idt.transfer(date);                                
                
                refreshComponents("Starting billspaymentinvalidated... ["+date+"]");
                idt = new TransferBillsPaymentInvalidated("master", targetDS);
                idt.transfer(date);                                                
                
                cal.add(Calendar.DATE, 1);
            }
            
            JOptionPane.showMessageDialog(lblMsg, "Finished");
        }
        catch(Exception ex) 
        {
            ex.printStackTrace();
            logToFile(ex);
            JOptionPane.showMessageDialog(lblMsg, ex.getMessage());
        }
        finally 
        {
            enableComponents(true);
            refreshComponents("Finished");
        }
    }
    
    private void refreshComponents(String message)
    {
        lblMsg.setText(message);
        lblMsg.revalidate();
        lblMsg.repaint();
    }
    
    private void enableComponents(boolean enable)
    {
        for (int i=0; i<components.length; i++) {
            components[i].setEnabled(enable);
        }
    }    
    
    private void logToFile(Throwable t) 
    {
        FileOutputStream fos = null;
        try
        {
            fos = new FileOutputStream(System.getProperty("user.dir") + "/errlog.txt");
            PrintStream ps = new PrintStream(fos, true);
            t.printStackTrace(ps);
        }
        catch(Exception ex) {
            ex.printStackTrace();
        }
        finally 
        {
            try { fos.close(); }catch(Exception ign){;}
        }
    }

}
