package com.mlhuillier.util.ui;

import com.mlhuillier.util.migration2.IDataTransfer;
import com.mlhuillier.util.migration2.TransferBillsPayment;
import com.mlhuillier.util.migration2.TransferBillsPaymentCancelled;
import com.mlhuillier.util.migration2.TransferBillsPaymentInvalidated;
import com.mlhuillier.util.migration2.TransferChangeRequest;
import com.mlhuillier.util.migration2.TransferPayout;
import com.mlhuillier.util.migration2.TransferPayoutCreditRemote;
import com.mlhuillier.util.migration2.TransferPerson;
import com.mlhuillier.util.migration2.TransferRTS;
import com.mlhuillier.util.migration2.TransferResend;
import com.mlhuillier.util.migration2.TransferSendout;
import com.mlhuillier.util.migration2.TransferSendoutCancel;
import com.mlhuillier.util.migration2.TransferSendoutCreditRemote;
import com.mlhuillier.util.migration2.TransferSendoutInvalidate;
import com.mlhuillier.util.migration2.TransferUniTeller;
import com.mlhuillier.util.migration2.gillamac.GillamacTransfer;
import com.mlhuillier.util.migration2.mlcs.BillsPaymentRequest;
import com.mlhuillier.util.migration2.mlkpupload.MLKPUploadTransfer;
import com.mlhuillier.util.migration2.mlpartner.ABSCBN;
import com.mlhuillier.util.migration2.mlpartner.AUB;
import com.mlhuillier.util.migration2.mlpartner.MoneyTransit;
import com.mlhuillier.util.migration2.mlpartner.NYBAY;
import com.mlhuillier.util.migration2.philhealth.PhilhealthTransfer;
import java.io.File;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class TransferService 
{

    public static void main(String[] args) throws Exception
    {
        TransferService ts = new TransferService(); 
        ts.start("DB-204", "DB-212", "2010-08-07", "2010-08-07"); 
    }
    
    
    public TransferService() {}
    
    public void start(String srcDS, String targetDS, String startdate, String enddate) throws Exception 
    {
        Date dtstart = java.sql.Date.valueOf(startdate);
        Date dtend = java.sql.Date.valueOf(enddate);
        
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Calendar cal = new GregorianCalendar();
        cal.setTime(dtstart);
        
        while (true)
        {
            Date dt = cal.getTime(); 
            if (dt.after(dtend)) break;

            String date = sdf.format(dt);
            
            FileWriter fw = null;
            try 
            {
                fw = new FileWriter(new File("TransferService" + date.replaceAll("-","")));
                fw.write("["+date+"]");
                fw.flush();
            }
            catch(Exception ex) {
                throw ex; 
            }
            finally {
                try { fw.close(); }catch(Exception ign){;} 
            }

            
            run(new TransferChangeRequest(srcDS, targetDS), date);
            run(new TransferPerson(srcDS, targetDS), date);
            run(new TransferSendout(srcDS, targetDS), date);
            run(new TransferSendoutCancel(srcDS, targetDS), date);
            run(new TransferSendoutCreditRemote(srcDS, targetDS), date);
            run(new TransferSendoutInvalidate(srcDS, targetDS), date);
            run(new TransferRTS(srcDS, targetDS), date);
            run(new TransferResend(srcDS, targetDS), date);
            run(new TransferPayout(srcDS, targetDS), date);
            run(new TransferPayoutCreditRemote(srcDS, targetDS), date);
            run(new TransferBillsPayment(srcDS, targetDS), date);
            run(new BillsPaymentRequest(srcDS, targetDS), date);
            run(new TransferBillsPaymentCancelled(srcDS, targetDS), date);
            run(new TransferBillsPaymentInvalidated(srcDS, targetDS), date);
            
            run(new MLKPUploadTransfer(srcDS, targetDS), date);
            run(new GillamacTransfer(srcDS, targetDS), date);
            run(new PhilhealthTransfer(srcDS, targetDS), date);
            run(new TransferUniTeller(srcDS, targetDS), date);
            run(new NYBAY(srcDS, targetDS), date);
            run(new ABSCBN(srcDS, targetDS), date);
            run(new AUB(srcDS, targetDS), date);
            run(new MoneyTransit(srcDS, targetDS), date);
            
            cal.add(Calendar.DATE, 1);
        }
    }
    
    private void run(IDataTransfer idt, String sdate) throws Exception 
    {
        int counter = 3;
        while (true)
        {
            if (counter <= 0) break;
            
            try 
            {
                idt.transfer(sdate);
                break; 
            } 
            catch(Exception ex) {
                System.out.println("[ERROR] " + ex.getMessage());
            }
            
            counter -= 1;
        }
    }
    
}
