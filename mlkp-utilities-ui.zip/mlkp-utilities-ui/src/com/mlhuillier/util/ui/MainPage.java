package com.mlhuillier.util.ui;

import com.mlhuillier.util.DBConfig;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JComponent;
import javax.swing.JOptionPane;

public class MainPage extends javax.swing.JPanel 
{
    
    public MainPage() 
    {
        initComponents();
        
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String sdate = sdf.format(new Date());
        txtStartDate.setText(sdate);
        txtEndDate.setText(sdate);
        
        DBConfig cfg = new DBConfig();
        String[] dslist = cfg.getDatasources();
        if (dslist != null)
        {
            for (int i=0; i<dslist.length; i++) 
                cboTargetDS.addItem(dslist[i]);
        }
    }
    
    // <editor-fold defaultstate="collapsed" desc=" Generated Code ">//GEN-BEGIN:initComponents
    private void initComponents() {
        jLabel1 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        txtStartDate = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        btnStart = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        txtEndDate = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        cboTargetDS = new javax.swing.JComboBox();
        lblMsg = new javax.swing.JLabel();

        setLayout(new java.awt.BorderLayout());

        setPreferredSize(new java.awt.Dimension(464, 282));
        jLabel1.setBackground(new java.awt.Color(0, 51, 153));
        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18));
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("<html>DB Transfer</html>");
        jLabel1.setBorder(javax.swing.BorderFactory.createEmptyBorder(10, 10, 10, 10));
        jLabel1.setOpaque(true);
        add(jLabel1, java.awt.BorderLayout.NORTH);

        jPanel1.setLayout(null);

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 12));
        jLabel2.setText("Start Date :");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(24, 54, 100, 26);

        txtStartDate.setFont(new java.awt.Font("Tahoma", 1, 14));
        txtStartDate.setForeground(new java.awt.Color(153, 0, 0));
        txtStartDate.setText("2009-05-16");
        jPanel1.add(txtStartDate);
        txtStartDate.setBounds(126, 54, 120, 26);

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 12));
        jLabel3.setText("YYYY-MM-DD");
        jPanel1.add(jLabel3);
        jLabel3.setBounds(252, 57, 94, 20);

        btnStart.setText("Start");
        btnStart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnStartActionPerformed(evt);
            }
        });

        jPanel1.add(btnStart);
        btnStart.setBounds(126, 126, 88, 36);

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 12));
        jLabel4.setText("End Date :");
        jPanel1.add(jLabel4);
        jLabel4.setBounds(24, 87, 100, 26);

        txtEndDate.setFont(new java.awt.Font("Tahoma", 1, 14));
        txtEndDate.setForeground(new java.awt.Color(153, 0, 0));
        txtEndDate.setText("2009-05-16");
        jPanel1.add(txtEndDate);
        txtEndDate.setBounds(126, 87, 120, 26);

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 12));
        jLabel5.setText("YYYY-MM-DD");
        jPanel1.add(jLabel5);
        jLabel5.setBounds(252, 87, 94, 27);

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 12));
        jLabel7.setText("Target DS :");
        jPanel1.add(jLabel7);
        jLabel7.setBounds(24, 21, 100, 26);

        cboTargetDS.setFont(new java.awt.Font("Tahoma", 0, 16));
        jPanel1.add(cboTargetDS);
        cboTargetDS.setBounds(126, 21, 120, 27);

        add(jPanel1, java.awt.BorderLayout.CENTER);

        lblMsg.setBackground(new java.awt.Color(255, 255, 255));
        lblMsg.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        lblMsg.setBorder(javax.swing.BorderFactory.createEmptyBorder(5, 5, 5, 5));
        lblMsg.setOpaque(true);
        lblMsg.setPreferredSize(new java.awt.Dimension(44, 50));
        add(lblMsg, java.awt.BorderLayout.SOUTH);

    }// </editor-fold>//GEN-END:initComponents

    private void btnStartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnStartActionPerformed

        try {
            java.sql.Date.valueOf(txtStartDate.getText());
        } catch(Exception ex) {
            JOptionPane.showMessageDialog(MainPage.this, "Invalid start date");
            return;
        }
        
        try {
            java.sql.Date.valueOf(txtEndDate.getText());
        } catch(Exception ex) {
            JOptionPane.showMessageDialog(MainPage.this, "Invalid end date");
            return;
        }        
        
        try
        {
            btnStart.setEnabled(false);
            TransferUtil u = new TransferUtil();
            u.setComponents(new JComponent[]{btnStart, txtStartDate, txtEndDate, cboTargetDS});
            u.setMsgComponent(lblMsg);
            u.start(txtStartDate.getText(), txtEndDate.getText(), cboTargetDS.getSelectedItem().toString());
            btnStart.setEnabled(true);
        }
        catch(Exception ex) 
        {
            ex.printStackTrace();
            btnStart.setEnabled(true);
            JOptionPane.showMessageDialog(MainPage.this, ex.getMessage());
        }
        
    }//GEN-LAST:event_btnStartActionPerformed
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnStart;
    private javax.swing.JComboBox cboTargetDS;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel lblMsg;
    private javax.swing.JTextField txtEndDate;
    private javax.swing.JTextField txtStartDate;
    // End of variables declaration//GEN-END:variables
    
}
