package com.mlhuillier.util.ui;

import com.mlhuillier.util.DBConfig;
import com.mlhuillier.util.migration2.DataService;
import java.sql.Connection;
import java.util.Map;

public class TransferServiceTestUnit 
{
    
    public static void main(String[] args) throws Exception 
    {
        String startdate = args[0]+"";
        String enddate = args[1]+"";
        String fromds = args[2]+"";
        String tods = args[3]+"";
        
        TransferService s = new TransferService(); 
        s.start(fromds, tods, startdate, enddate); 
    }
    
    private void updatePayoutControlNo(String dsname, String prefix, int startseries, int endseries) throws Exception
    {
        Connection conn = null;
        
        try
        {
            DBConfig dbConfig = new DBConfig();
            conn = dbConfig.createConnection(dsname);

            DataService ds = new DataService(); 
            int startIdx = startseries;
            int endIdx = endseries;
            while (startIdx <= endIdx)
            {
                String controlno = prefix + startIdx;
                System.out.print("\nprocessing " + controlno + "... ");
                Map data = ds.getSingleResult(conn, " select objid, state, strcontrolno, dtclaimed from mlkp.tblpayout where strcontrolno='"+controlno+"' "); 
                if (data != null && !data.isEmpty())
                {
                    System.out.print(data);
                
                    ds.exec(conn,  "update mlkp.tblpayout set strcontrolno='"+controlno+"-1' where objid='"+data.get("objid")+"'");
                }
                else
                    System.out.print("Not found.");
                
                
                startIdx += 1;
            }
        }
        catch(Exception ex) {
            throw ex;
        }
        finally {
            try { conn.close(); }catch(Exception ign){;} 
        }
    }
     
    private void updateSendoutControlNo(String dsname, String prefix, int startseries, int endseries) throws Exception
    {
        Connection conn = null;
        
        try
        {
            DBConfig dbConfig = new DBConfig();
            conn = dbConfig.createConnection(dsname);

            DataService ds = new DataService(); 
            int startIdx = startseries;
            int endIdx = endseries;
            while (startIdx <= endIdx)
            {
                String controlno = prefix + startIdx;
                System.out.print("\nprocessing " + controlno + "... ");
                Map data = ds.getSingleResult(conn, " select objid, state, strcontrolno, dtfiled from mlkp.tblsendout where strcontrolno='"+controlno+"' "); 
                if (data != null && !data.isEmpty())
                {
                    System.out.print(data);
                
                    ds.exec(conn,  "update mlkp.tblsendout set strcontrolno='"+controlno+"-1' where objid='"+data.get("objid")+"'");
                }
                else
                    System.out.print("Not found.");
                
                
                startIdx += 1;
            }
        }
        catch(Exception ex) {
            throw ex;
        }
        finally {
            try { conn.close(); }catch(Exception ign){;} 
        }
    }    
}
