package com.mlhuillier.util.ui;

import com.mlhuillier.util.DBConfig;
import javax.swing.JDialog;
import javax.swing.JOptionPane;

public final class Launcher 
{
    
    public static void main(String[] args) 
    {
        try
        {
            DBConfig db = new DBConfig();
            
            JDialog d = new JDialog();
            d.setModal(true);
            d.setTitle("DB Transfer");
            d.setContentPane(new MainPage());
            d.pack();
            d.setVisible(true);
        }
        catch(Exception ex) 
        {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
        finally {
            System.exit(0);
        }
    }
    
    private Launcher() {;} 
    
}
