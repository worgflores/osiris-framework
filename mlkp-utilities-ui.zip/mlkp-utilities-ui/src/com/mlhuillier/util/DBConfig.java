package com.mlhuillier.util;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

public class DBConfig 
{
    private Properties properties;
    
    public DBConfig() 
    {
        properties = new Properties();
        try
        {
            String resname = System.getProperty("user.dir") + "/connection.properties";
            properties.load(new FileInputStream(resname));
        }
        catch(Exception ex) {
            throw new IllegalStateException("Unable to load connection properties", ex);
        }
    }
    
    public String[] getDatasources()
    {
        List dslist = new ArrayList();
        Iterator keys = properties.keySet().iterator();
        while (keys.hasNext())
        {
            String key = keys.next().toString(); 
            if (key.startsWith("DB-") && key.endsWith(".db.host")) 
            {
                int idx0 = key.indexOf(".db.host");
                dslist.add(key.substring(0, idx0));
            }
        }
        return (String[]) dslist.toArray(new String[]{});
    }
    
    public Connection createSourceConnection() throws Exception
    {
        return createConnection(properties.getProperty("src.db.host"),
                                properties.getProperty("src.db.user"),
                                properties.getProperty("src.db.password"));
    }
    
    public Connection createTargetConnection() throws Exception
    {
        return createConnection(properties.getProperty("target.db.host"),
                                properties.getProperty("target.db.user"),
                                properties.getProperty("target.db.password"));
    }    
    
    public Connection createSlaveConnection() throws Exception
    {
        return createConnection(properties.getProperty("slave.db.host"),
                                properties.getProperty("slave.db.user"),
                                properties.getProperty("slave.db.password"));        
    }
    
    public Connection createMasterConnection() throws Exception
    {
        return createConnection(properties.getProperty("master.db.host"),
                                properties.getProperty("master.db.user"),
                                properties.getProperty("master.db.password"));        
    }    
    
    public Connection createArchiveConnection() throws Exception
    {
        return createConnection(properties.getProperty("arch.db.host"),
                                properties.getProperty("arch.db.user"),
                                properties.getProperty("arch.db.password"));        
    }        
    
    public Connection createConnection(String name) throws Exception
    {
        String host = properties.getProperty(name + ".db.host");
        String user = properties.getProperty(name + ".db.user");
        String pwd = properties.getProperty(name + ".db.password");
        
        try 
        {
            //System.out.println("creating connection: [datasource="+name+", host="+host+", username="+user+", password="+pwd+"]");
            return createConnection(host, user, pwd);
        } 
        catch(Exception ex) {
            throw new Exception("[ datasource="+name+", host="+host+", username="+user+", password="+pwd+"]\n " + ex.getMessage(), ex);
        }
    }
    
    private Connection createConnection(String host, String user, String pwd) throws Exception
    {
        Class.forName("com.mysql.jdbc.Driver");
        return DriverManager.getConnection(host, user, pwd);
    }    
}
