package com.mlhuillier.util.migration2;

import com.mlhuillier.util.DBConfig;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.ArrayList;
import java.util.List;

public class TransferSendoutCreditRemote implements IDataTransfer 
{

    private DBConfig dbConfig;
    private String srcDS;
    private String destDS;
    
    public TransferSendoutCreditRemote(String srcDS, String destDS) 
    {
        this.srcDS = srcDS;
        this.destDS = destDS;
        this.dbConfig = new DBConfig();
    }
    
    public void transfer(String sdate) throws Exception    
    {
        Connection conn = null;
        Connection connDest = null;

        java.sql.Date.valueOf(sdate);
        
        try
        {
            if (srcDS.equals(destDS))
                throw new Exception("source-ds and target-ds must not be the same");
            
            conn = dbConfig.createConnection(srcDS);
            connDest = dbConfig.createConnection(destDS);
            
            long counter = 1;
            for (int h=0; h < 24; h++)
            {
                String shour = h+"";
                if (h < 10) shour = "0"+h;

                String fromdate = sdate + " " + shour + ":00:00";
                String todate   = sdate + " " + shour + ":59:59";                

                System.out.println("fetching sendoutcredit ids... [" + sdate + " " + shour + "]"); 
                List ids = getIds(conn, fromdate, todate); 
                while (!ids.isEmpty())
                {
                    String[] arr = (String[]) ids.remove(0);
                    String objid  = arr[0];
                    String soutid = arr[1];
                    String refno  = arr[2];
                    String errmsg = "OK";
                    Exception error = null;
                    
                    try 
                    {
                        if (exists(connDest, objid)) continue;
                        
                        transferImpl(conn, connDest, objid, soutid, refno, arr); 
                    } 
                    catch(Exception x) 
                    { 
                        errmsg = "[ERROR] " + x.getMessage(); 
                        error = x;
                    } 

                    System.out.println(counter + ") processed " + objid + "... " + errmsg);
                    if (error != null) throw error;
                    
                    counter +=1;
                }
            }
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { conn.close(); }catch(Exception ign) {;} 
            try { connDest.close(); }catch(Exception ign) {;} 
        }         
    }
    
    public void transfer(String fromdate, String todate) throws Exception
    {
        Connection conn = null;
        Connection connDest = null;
        
        try
        {
            if (srcDS.equals(destDS))
                throw new Exception("source-ds and target-ds must not be the same");
            
            conn = dbConfig.createConnection(srcDS);
            connDest = dbConfig.createConnection(destDS);
            
            System.out.println("fetching sendoutcredit ids...");
            List ids = getIds(conn, fromdate, todate);
            int counter = 1;
            
            while (!ids.isEmpty())
            {
                String[] arr = (String[]) ids.remove(0);
                String objid  = arr[0];
                String soutid = arr[1];
                String refno  = arr[2];
                String errmsg = "OK";

                try 
                {
                    if (exists(connDest, objid)) continue;
                    
                    transferImpl(conn, connDest, objid, soutid, refno, arr); 
                } 
                catch(Exception x) { 
                    errmsg = "[ERROR] " + x.getMessage(); 
                } 

                System.out.println(counter + ") processed " + objid + "... " + errmsg);
                counter +=1;
            }
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { conn.close(); }catch(Exception ign) {;} 
            try { connDest.close(); }catch(Exception ign) {;} 
        } 
    } 

    public void transferImpl(Connection conn, Connection connDest, String objid, String soutid, String refno, String[] args) throws Exception
    {
        String senderid = args[3];
        String receiverid = args[4];
        String controlid = args[5];
        
        PersonService ps = new PersonService();
        if (senderid != null) ps.transfer(conn, connDest, senderid);
        if (receiverid != null) ps.transfer(conn, connDest, receiverid);
        
        DataService ds = new DataService(); 
        if (controlid != null)
            ds.transferData(conn, connDest, "select * from mlkp.tblcontrol where objid='"+ controlid +"'", "mlkp.tblcontrol", true); 
        
        exec(conn, "update mlkp.tblsendoutinfo set dtsenderbirthdate=null where objid='"+soutid+"' and dtsenderbirthdate='0000-00-00'");
        exec(conn, "update mlkp.tblsendoutinfo set dtreceiverbirthdate=null where objid='"+soutid+"' and dtreceiverbirthdate='0000-00-00'");
        
        ds.transferData(conn, connDest, "select * from mlkp.tblsendout where objid='"+ soutid +"'", "mlkp.tblsendout", true);
        ds.transferData(conn, connDest, "select * from mlkp.tblsendoutext where objid='"+ objid +"'", "mlkp.tblsendoutext", true);
        ds.transferData(conn, connDest, "select * from mlkp.tblsendoutcharge where parentid='"+ soutid +"'", "mlkp.tblsendoutcharge", true); 
        ds.transferData(conn, connDest, "select * from mlkp.tblsendoutinfo where objid='"+ soutid +"'", "mlkp.tblsendoutinfo", true); 
        ds.transferData(conn, connDest, "select * from mlkp.tblsendoutoption where objid='"+ soutid +"'", "mlkp.tblsendoutoption", true); 
        ds.transferData(conn, connDest, "select * from mlkp.tblsendoutor where objid='"+ soutid +"'", "mlkp.tblsendoutor", true); 
        ds.transferData(conn, connDest, "select * from mlkp.tblsendoutwalkinid where objid='"+ soutid +"'", "mlkp.tblsendoutwalkinid", true); 
        ds.transferData(conn, connDest, "select * from mlkp.tblremotesendout where objid='"+ soutid +"'", "mlkp.tblremotesendout", true); 
        
        ds.transferData(conn, connDest, "select * from mlkp.tblkptnlog where kptn=(select strkptn from mlkp.tblsendout where objid='"+soutid+"')", "mlkp.tblkptnlog", true); 
        
        ds.transferData(conn, connDest, "select * from mlkp.tblchangerequest where strrefno='"+ refno +"'", "mlkp.tblchangerequest", true); 
        ds.transferData(conn, connDest, "select * from mlkp.tblchangerequestor where objid=(select objid from mlkp.tblchangerequest where strrefno='"+refno+"')", "mlkp.tblchangerequestor", true); 
        
        ds.transferData(conn, connDest, "select * from mlkp.tblcreditsendouttoremote where objid='"+ objid +"'", "mlkp.tblcreditsendouttoremote"); 
    }
    
    private int exec(Connection conn, String sql) throws Exception
    {
        PreparedStatement ps = null;
        try
        {
            ps = conn.prepareStatement(sql);
            return ps.executeUpdate();
        }
        catch(Exception ex) {
            throw ex;
        }
        finally {
            try { ps.close(); }catch(Exception ign) {;}
        }
    }
    
    private List getIds(Connection conn, String fromdate, String todate) throws Exception
    {
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        try
        {
            StringBuffer sql = new StringBuffer();
            sql.append(" select bt.*, s.strsenderid, s.strreceiverid, s.strcontrolid ");
            sql.append(" from ( ");
            sql.append("        select objid, strsendoutid, strrefno from mlkp.tblcreditsendouttoremote ");
            sql.append("        where txndate between '"+fromdate+"' and '"+todate+"' ");
            sql.append("      )bt ");
            sql.append(" inner join mlkp.tblsendout s on bt.strsendoutid=s.objid ");
            
            ps = conn.prepareStatement(sql.toString()); 
            rs = ps.executeQuery(); 
            
            List results = new ArrayList();
            while (rs.next()) 
            {
                String[] arr = new String[] 
                {
                    rs.getString("objid"), rs.getString("strsendoutid"), rs.getString("strrefno"),
                    rs.getString("strsenderid"), rs.getString("strreceiverid"), rs.getString("strcontrolid")                     
                };
                results.add(arr);
            }
            return results;
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { rs.close(); }catch(Exception ign) {;}
            try { ps.close(); }catch(Exception ign) {;}
        } 
    }        
    
    private boolean exists(Connection conn, String objid) throws Exception
    {
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        try
        {
            String sql = " select objid from mlkp.tblcreditsendouttoremote where objid='"+objid+"' "; 
            
            ps = conn.prepareStatement(sql); 
            rs = ps.executeQuery(); 
            boolean b = rs.next(); 
            return b;
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { rs.close(); }catch(Exception ign) {;}
            try { ps.close(); }catch(Exception ign) {;}
        } 
    }       
    
}
