package com.mlhuillier.util.migration2;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class PersonService 
{
    private DataService dataService = new DataService();
    
    public void transfer(Connection connSrc, Connection connDest, String objid) throws Exception
    {
        transferPerson(connSrc, connDest, objid);
        
        List receivers = getPersonReceivers(connSrc, objid);
        while (!receivers.isEmpty())
        {
            String receiverid = (String) receivers.remove(0);
            transferPerson(connSrc, connDest, receiverid);
            transferData(connSrc, connDest, "select * from mlkp.tblreceiver where strsenderid='"+objid+"' and strreceiverid='"+receiverid+"'", "mlkp.tblreceiver", true);
        }
    }
    
    private void transferPerson(Connection connSrc, Connection connDest, String objid) throws Exception
    {
        Map data = null;
        try
        {
            try { exec(connSrc, " update mlkp.tblperson set dtbirthdate=null where objid='"+objid+"' and dtbirthdate='0000-00-00'"); }catch(Exception ign){;} 
            try { exec(connSrc, " update mlkp.tblperson set dtidexpiry=null where objid='"+objid+"' and dtidexpiry='0000-00-00'"); }catch(Exception ign){;} 
            try { 
                    exec(connSrc, " update mlkp.tblpersonfamilyinfo set " +
                          "   dtspousebirthdate=case when dtspousebirthdate='0000-00-00' then null else dtspousebirthdate end, " + 
                          "   dtchildbirth1=case when dtchildbirth1='0000-00-00' then null else dtchildbirth1 end, " + 
                          "   dtchildbirth2=case when dtchildbirth2='0000-00-00' then null else dtchildbirth2 end, " +
                          "   dtchildbirth3=case when dtchildbirth3='0000-00-00' then null else dtchildbirth3 end, " +
                          "   dtchildbirth4=case when dtchildbirth4='0000-00-00' then null else dtchildbirth4 end " +
                          " where objid='"+objid+"'"); 
            }catch(Exception ign){;}         

            if (!dataService.exists(connDest, "select objid from mlkp.tblperson where objid='"+objid+"'"))
            {
                data = dataService.getSingleResult(connSrc, " select objid, strcardid from mlkp.tblperson where objid='"+objid+"' "); 
                String objidSrc = data.get("objid")+"";
                String cardid = data.get("strcardid")+"";
                
                Map dataDest = dataService.getSingleResult(connDest, " select objid, concat(strfirstname,' ',ifnull(strmiddlename,'')) as strfirstname from mlkp.tblperson where strcardid='"+cardid+"' "); 
                String objidDest = dataDest.get("objid")+"";
                String firstname = dataDest.get("strfirstname")+"";

                if (!objidSrc.equals(objidDest))
                {
                    exec(connDest, " update mlkp.tblperson set " + 
                                   "    state=1, strcardid='"+cardid+"-TRASH', strfirstname='"+firstname+"', strmiddlename='"+objidDest+"' " + 
                                   " where objid='"+objidDest+"'");  
                }
                
                dataService.insertOnDuplicateKey(connSrc, connDest, "select * from mlkp.tblperson where objid='"+ objid +"'", "mlkp.tblperson");
                dataService.transferData(connSrc, connDest, "select * from mlkp.tblpersonfamilyinfo where objid='"+ objid +"'", "mlkp.tblpersonfamilyinfo", true);
                dataService.transferData(connSrc, connDest, "select * from mlkp.tblpersonworkinfo where objid='"+ objid +"'", "mlkp.tblpersonworkinfo", true);
            }
        }
        catch (Exception ex) 
        {
            System.out.println("Error on personid '" + objid + "' : " + data);
            ex.printStackTrace();
            throw ex;
        }
    }

    private List getPersonReceivers(Connection conn, String objid) throws Exception
    {
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        try
        {
            String sql = " select strreceiverid from mlkp.tblreceiver where strsenderid='"+objid+"' ";
            
            ps = conn.prepareStatement(sql); 
            rs = ps.executeQuery(); 
            
            List results = new ArrayList();
            while (rs.next()) {
                results.add(rs.getString("strreceiverid"));
            }
            return results;
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { rs.close(); }catch(Exception ign) {;}
            try { ps.close(); }catch(Exception ign) {;}
        }         
    }
    
    private int exec(Connection conn, String sql) throws Exception
    {
        PreparedStatement ps = null;
        try
        {
            ps = conn.prepareStatement(sql);
            return ps.executeUpdate();
        }
        catch(Exception ex) {
            throw ex;
        }
        finally {
            try { ps.close(); }catch(Exception ign) {;}
        }
    }

    private void transferData(Connection connSrc, Connection connDest, String sql, String targetTable) throws Exception {
        transferData(connSrc, connDest, sql, targetTable, false);
    }
    
    private void transferData(Connection connSrc, Connection connDest, String sql, String targetTable, boolean ignore) throws Exception
    {
        PreparedStatement ps = null;
        ResultSet rs = null;

        int startRow = 0;
        int limit = 100000;
        while (true)
        {
            int batchSize = limit + 1;
            int counter = 0;
            
            try
            {
                ps = connSrc.prepareStatement(sql + " LIMIT " + startRow + "," + batchSize);
                rs = ps.executeQuery();
                while (rs.next()) 
                {
                    copyData(connDest, rs, targetTable, ignore);
                    counter +=1 ;
                }
            }
            catch(Exception ex) {
                throw ex;
            }
            finally 
            {
                try { rs.close(); }catch(Exception ign) {;}
                try { ps.close(); }catch(Exception ign) {;}
            }
            
            if (counter <= limit) break;
            
            startRow += limit;
        }
    }
    
    private void copyData(Connection conn, ResultSet rs, String targetTable, boolean ignore) throws Exception
    {
        ResultSetMetaData meta = rs.getMetaData();
        int columnCount = meta.getColumnCount();
        
        StringBuffer sql = new StringBuffer();
        sql.append(" INSERT ");
        if (ignore) sql.append(" IGNORE ");
        
        sql.append(" INTO " + targetTable +"\n\t (");
        for (int i=1; i<=columnCount; i++)
        {
            if (i > 1) sql.append(",");
            
            sql.append(meta.getColumnName(i));
        }
        sql.append(" ) \n");
        sql.append(" VALUES \n\t (");
        for (int i=0; i<columnCount; i++)
        {
            if (i > 0) sql.append(",");
            
            sql.append("?");
        }        
        sql.append(")");

        PreparedStatement ps = null;
        try
        {
            ps = conn.prepareStatement(sql.toString());
            
            for (int i=1; i<=columnCount; i++) {
                ps.setObject(i, rs.getObject(i));
            }
            
            ps.execute();
        }
        catch(Exception ex) {
            throw ex;
        }
        finally {
            try { ps.close(); }catch(Exception ign) {;}
        } 
    }
    
}
