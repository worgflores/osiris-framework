package com.mlhuillier.util.migration2.mltmp;

import com.mlhuillier.util.DBConfig;
import com.mlhuillier.util.migration2.DataService;
import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class MLTMPTransfer 
{
    public static void main1(String[] args) throws Exception 
    {
        new MLTMPTransfer("DB-204", "DB-212").sync(); 
        new MLTMPTransfer("DB-204", "DB-202").sync(); 
    }
    
    private SimpleDateFormat YMD = new SimpleDateFormat("yyyy-MM-dd");
    private DBConfig dbConfig;
    private String srcDS;
    private String destDS;
    
    public MLTMPTransfer(String srcDS, String destDS) 
    {
        this.srcDS = srcDS;
        this.destDS = destDS;
        this.dbConfig = new DBConfig();
    }
    
    public void sync() throws Exception 
    {
        Connection conn = null;
        Connection connDest = null;

        try
        {
            if (srcDS.equals(destDS))
                throw new Exception("source-ds and target-ds must not be the same");
            
            conn = dbConfig.createConnection(srcDS);
            connDest = dbConfig.createConnection(destDS);
            
            DataService dataService = new DataService();
            System.out.println("   transferring master files... ");
            dataService.insertOnDuplicateKey(conn, connDest, "select * from mltmp.mlpartneraccount", "mltmp.mlpartneraccount");
            dataService.insertOnDuplicateKey(conn, connDest, "select * from mltmp.mlpartnerconfig", "mltmp.mlpartnerconfig");
            dataService.transferData(conn, connDest, "select * from mltmp.mlpartneraccounthistory", "mltmp.mlpartneraccounthistory", true);
        }
        catch(Exception ex) { 
            throw ex; 
        }
        finally
        {
            try { conn.close(); }catch(Exception ign) {;} 
            try { connDest.close(); }catch(Exception ign) {;} 
        }         
    }       
}
