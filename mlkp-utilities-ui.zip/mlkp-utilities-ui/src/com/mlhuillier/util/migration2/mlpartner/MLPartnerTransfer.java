package com.mlhuillier.util.migration2.mlpartner;

public class MLPartnerTransfer 
{
    public static void main1(String[] args) throws Exception 
    {
        String fromDS = "DB-204";
        String toDS   = "DB-206"; 
        String fromdate = "2010-07-14";
        String todate   = "2010-07-14"; 
        
        new ABSCBN(fromDS, toDS).transfer(fromdate, todate);
        new AUB(fromDS, toDS).transfer(fromdate, todate);
        new BPI(fromDS, toDS).transfer(fromdate, todate);
        new ChinaBank(fromDS, toDS).transfer(fromdate, todate);
        new NYBAY(fromDS, toDS).transfer(fromdate, todate);
    }    
}
