package com.mlhuillier.util.migration2.mlpartner;

import com.mlhuillier.util.DBConfig;
import com.mlhuillier.util.migration2.*;
import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class AUB implements IDataTransfer 
{
    public static void main1(String[] args) throws Exception 
    {
//        new AUB("DB-204", "DB-206").transfer("2010-07-01", "2010-07-18"); 
//        new AUB("DB-204", "DB-202").transfer("2010-07-01", "2010-07-09");
//        
//        new AUB("DB-204", "DB-206").transfer("2010-06-01", "2010-06-30"); 
//        new AUB("DB-204", "DB-202").transfer("2010-06-01", "2010-06-30"); 
//        
//        new AUB("DB-204", "DB-202").transfer("2010-01-01", "2010-05-31"); 
//        new AUB("DB-204", "DB-202").transfer("2009-01-01", "2009-12-31"); 
        
//        for (int day=1; day < 10; day++)
//        {
//            String sday = ""+day;
//            if (day < 10) sday = "0"+day;
//            
//            String sdate = "2010-07-" + sday;
//            new ABSCBN("DB-204", "DB-202").transfer(sdate, sdate);
//            new ABSCBN("DB-204", "DB-206").transfer(sdate, sdate);
//            new ABSCBN("DB-204", "DB-212").transfer(sdate, sdate);
//        }
    }
    
    private SimpleDateFormat YMD = new SimpleDateFormat("yyyy-MM-dd");
    private DBConfig dbConfig;
    private String srcDS;
    private String destDS;
    
    public AUB(String srcDS, String destDS) 
    {
        this.srcDS = srcDS;
        this.destDS = destDS;
        this.dbConfig = new DBConfig();
    }
    
    public void transfer(String startdate) throws Exception {
        transfer(startdate, startdate); 
    }
    
    public void transfer(String startdate, String enddate) throws Exception 
    {
        Connection conn = null;
        Connection connDest = null;

        Date dtstart = java.sql.Date.valueOf(startdate);
        Date dtend = java.sql.Date.valueOf(enddate);
        
        try
        {
            if (srcDS.equals(destDS))
                throw new Exception("source-ds and target-ds must not be the same");
            
            conn = dbConfig.createConnection(srcDS);
            connDest = dbConfig.createConnection(destDS);
            
            DataService dataService = new DataService();
            Calendar cal = new GregorianCalendar(); 
            cal.setTime(dtstart);
            while (true)
            {
                Date dt = cal.getTime();
                if (dt.after(dtend)) break;
                
                String sdate = YMD.format(dt);
                String fromdate = sdate + " 00:00:00";
                String todate = sdate + " 23:59:59";
                
                System.out.println("processing AUB transfer... ["+sdate+", targetDS="+destDS+"]");
                transfer(conn, connDest, dataService, fromdate, todate);
                
                cal.add(Calendar.DATE, 1);
            }
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { conn.close(); }catch(Exception ign) {;} 
            try { connDest.close(); }catch(Exception ign) {;} 
        }         
    }   
    
    private void transfer(Connection connSrc, Connection connDest, DataService dataService, String fromdate, String todate) throws Exception 
    {
        try {
            dataService.exec(connSrc, "update mlpartner.aubpayoutdraft set idexpiry=null where dtclaimed between '"+fromdate+"' and '"+todate+"' and idexpiry='0000-00-00 00:00:00'");
        } catch(Exception ign){;} 
        
        dataService.transferData(connSrc, connDest, "select * from mlpartner.aubpayoutdraft where dtclaimed between '"+fromdate+"' and '"+todate+"'", "mlpartner.aubpayoutdraft", true); 
        dataService.insertOnDuplicateKey(connSrc, connDest, "select * from mlpartner.aubpayout where dtclaimed between '"+fromdate+"' and '"+todate+"'", "mlpartner.aubpayout"); 
        dataService.transferData(connSrc, connDest, "select * from mlpartner.aubpayoutcancelled where dtclaimed between '"+fromdate+"' and '"+todate+"'", "mlpartner.aubpayoutcancelled", true); 
        dataService.transferData(connSrc, connDest, "select * from mlpartner.aubpayoutcredit where dtfiled between '"+fromdate+"' and '"+todate+"'", "mlpartner.aubpayoutcredit", true); 
    }
}
