package com.mlhuillier.util.migration2.mlpartner;

import com.mlhuillier.util.DBConfig;
import com.mlhuillier.util.migration2.*;
import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class NYBAY implements IDataTransfer 
{
    public static void main(String[] args) throws Exception 
    {
        new NYBAY("DB-204", "DB-206").transfer("2010-07-01", "2010-07-19");
        
//        for (int day=1; day < 30; day++)
//        {
//            String sday = ""+day; 
//            if (day < 10) sday = "0"+day; 
//            
//            String sdate = "2010-06-" + sday; 
//            new NYBAY("DB-204", "DB-202").transfer(sdate, sdate); 
//        } 
    } 
    
    private SimpleDateFormat YMD = new SimpleDateFormat("yyyy-MM-dd");
    private DBConfig dbConfig;
    private String srcDS;
    private String destDS;
    
    public NYBAY(String srcDS, String destDS) 
    {
        this.srcDS = srcDS;
        this.destDS = destDS;
        this.dbConfig = new DBConfig();
    }
    
    public void transfer(String startdate) throws Exception {
        transfer(startdate, startdate);
    }
    
    public void transfer(String startdate, String enddate) throws Exception 
    {
        Connection conn = null;
        Connection connDest = null;

        Date dtstart = java.sql.Date.valueOf(startdate);
        Date dtend = java.sql.Date.valueOf(enddate);
        
        try
        {
            if (srcDS.equals(destDS))
                throw new Exception("source-ds and target-ds must not be the same");
            
            conn = dbConfig.createConnection(srcDS);
            connDest = dbConfig.createConnection(destDS);
            
            DataService dataService = new DataService();
            Calendar cal = new GregorianCalendar(); 
            cal.setTime(dtstart);
            while (true)
            {
                Date dt = cal.getTime();
                if (dt.after(dtend)) break;
                
                String sdate = YMD.format(dt);
                String fromdate = sdate + " 00:00:00";
                String todate = sdate + " 23:59:59";
                
                System.out.println("processing NYBAY transfer... ["+sdate+", targetDS="+destDS+"]");
                transfer(conn, connDest, dataService, fromdate, todate);
                
                cal.add(Calendar.DATE, 1);
            }
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { conn.close(); }catch(Exception ign) {;} 
            try { connDest.close(); }catch(Exception ign) {;} 
        }         
    }   
    
    private void transfer(Connection connSrc, Connection connDest, DataService dataService, String fromdate, String todate) throws Exception 
    {
        dataService.transferData(connSrc, connDest, "select * from mlpartner.nybaypayoutdraft where dtclaimed between '"+fromdate+"' and '"+todate+"'", "mlpartner.nybaypayoutdraft", true); 
        dataService.transferData(connSrc, connDest, "select * from mlpartner.nybaypayouttxn where dtclaimed between '"+fromdate+"' and '"+todate+"'", "mlpartner.nybaypayouttxn", true); 
        dataService.transferData(connSrc, connDest, "select * from mlpartner.nybaypayouttxncancelled where dtclaimed between '"+fromdate+"' and '"+todate+"'", "mlpartner.nybaypayouttxncancelled", true); 
    }
    
    public void correctIDExpiry(String startdate, String enddate) throws Exception 
    {
        Connection conn = null;
        Connection connDest = null;

        Date dtstart = java.sql.Date.valueOf(startdate);
        Date dtend = java.sql.Date.valueOf(enddate);
        
        try
        {
            if (srcDS.equals(destDS))
                throw new Exception("source-ds and target-ds must not be the same");
            
            conn = dbConfig.createConnection(srcDS);
            connDest = dbConfig.createConnection(destDS);
            
            DataService dataService = new DataService();
            Calendar cal = new GregorianCalendar(); 
            cal.setTime(dtend);
            while (true)
            {
                Date dt = cal.getTime();
                if (dt.before(dtstart)) break;
                
                String sdate = YMD.format(dt);
                String fromdate = sdate + " 00:00:00";
                String todate = sdate + " 23:59:59";
                
                System.out.println("processing NYBAY... ["+sdate+"]");
                dataService.exec(connDest, " update mlpartner.nybaypayoutdraft set idexpiry=null where dtclaimed between '"+fromdate+"' and '"+todate+"' and idexpiry='0000-00-00 00:00:00' ");
                dataService.exec(connDest, " update mlpartner.nybaypayouttxn set idexpiry=null where dtclaimed between '"+fromdate+"' and '"+todate+"' and idexpiry='0000-00-00 00:00:00' ");
                cal.add(Calendar.DATE, -1);
            }
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { conn.close(); }catch(Exception ign) {;} 
            try { connDest.close(); }catch(Exception ign) {;} 
        }         
    }   
    
}
