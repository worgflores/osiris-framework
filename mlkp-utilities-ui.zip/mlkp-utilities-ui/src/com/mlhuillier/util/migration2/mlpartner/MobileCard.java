package com.mlhuillier.util.migration2.mlpartner;

import com.mlhuillier.util.DBConfig;
import com.mlhuillier.util.migration2.*;
import java.sql.Connection;
import java.text.SimpleDateFormat;

public class MobileCard 
{
    public static void main(String[] args) throws Exception 
    {
        new MobileCard("DEV-1262", "DB-204").transfer(); 
    }
    
    private SimpleDateFormat YMD = new SimpleDateFormat("yyyy-MM-dd");
    private DBConfig dbConfig;
    private String srcDS;
    private String destDS;
    
    public MobileCard(String srcDS, String destDS) 
    {
        this.srcDS = srcDS;
        this.destDS = destDS;
        this.dbConfig = new DBConfig();
    }
    
    public void transfer() throws Exception 
    {
        Connection conn = null;
        Connection connDest = null;

        try
        {
            if (srcDS.equals(destDS))
                throw new Exception("source-ds and target-ds must not be the same");
            
            conn = dbConfig.createConnection(srcDS);
            connDest = dbConfig.createConnection(destDS);
            
            DataService dataService = new DataService();
            dataService.transferData(conn, connDest, "select * from (select * from mlpartner.tblmobilecard where curamount=500 limit 10)bt ", "mlpartner.tblmobilecard", true);
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { conn.close(); }catch(Exception ign) {;} 
            try { connDest.close(); }catch(Exception ign) {;} 
        }         
    }   
}
