package com.mlhuillier.util.migration2.mlpartner;

import com.mlhuillier.util.DBConfig;
import com.mlhuillier.util.migration2.*;
import java.sql.Connection;

public class MLPartnerAccount 
{
    public static void main1(String[] args) throws Exception 
    {
        MLPartnerAccount b = new MLPartnerAccount("DB-204", "DB-202");
        b.transfer();
    }
    
    private DBConfig dbConfig;
    private String srcDS;
    private String destDS;
    
    public MLPartnerAccount(String srcDS, String destDS) 
    {
        this.srcDS = srcDS;
        this.destDS = destDS;
        this.dbConfig = new DBConfig();
    }
    
    public void transfer() throws Exception 
    {
        Connection conn = null;
        Connection connDest = null;

        try
        {
            if (srcDS.equals(destDS))
                throw new Exception("source-ds and target-ds must not be the same");
            
            conn = dbConfig.createConnection(srcDS);
            connDest = dbConfig.createConnection(destDS);
            
            DataService dataService = new DataService();
            String[] tables = new String[]
            {
                "mlpartneraccount", "mlpartneraccounthistory", "mlpartnerconfig"
            };
            
            for (int i=0; i<tables.length; i++)
            {
                String tablename = tables[i];
                System.out.println("[mltmp."+tablename+"]");
                dataService.insertOnDuplicateKey(conn, connDest, "select * from mltmp."+tablename, "mltmp."+tablename); 
            }
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { conn.close(); }catch(Exception ign) {;} 
            try { connDest.close(); }catch(Exception ign) {;} 
        }         
    }
}
