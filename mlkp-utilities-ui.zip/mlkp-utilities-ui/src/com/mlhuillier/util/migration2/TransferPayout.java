package com.mlhuillier.util.migration2;

import com.mlhuillier.util.DBConfig;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class TransferPayout implements IDataTransfer 
{   
    
    public static void xmain(String[] args) throws Exception 
    { 
        new TransferPayout("DB-204", "DB-206").transfer("2010-09-11"); 
    } 
    
    private DBConfig dbConfig; 
    private String srcDS; 
    private String destDS;
    private boolean retryOnError; 
    
    public boolean debug; 
    
    public TransferPayout(String srcDS, String destDS) {
        this(srcDS, destDS, false);
    }
    
    public TransferPayout(String srcDS, String destDS, boolean retryOnError) 
    { 
        this.srcDS = srcDS; 
        this.destDS = destDS; 
        this.retryOnError = retryOnError;
        this.dbConfig = new DBConfig(); 
    } 
    
    public void transfer(String sdate) throws Exception    
    {
        Connection conn = null; 
        Connection connDest = null; 

        java.sql.Date.valueOf(sdate); 
        
        try 
        { 
            if (srcDS.equals(destDS)) 
                throw new Exception("source-ds and target-ds must not be the same"); 
            
            conn = dbConfig.createConnection(srcDS); 
            connDest = dbConfig.createConnection(destDS); 
            
            long counter = 1; 
            for (int h=0; h < 24; h++) 
            {
                String shour = h+"";
                if (h < 10) shour = "0"+h;

                String fromdate = sdate + " " + shour + ":00:00";
                String todate   = sdate + " " + shour + ":59:59";                

                System.out.println("*fetching payout ids... ["+sdate+" "+shour+", targetDS="+destDS+"]");
                List ids = getIds(conn, fromdate, todate);
                while (!ids.isEmpty()) 
                { 
                    Map data = (Map) ids.remove(0); 
                    String objid = data.get("objid").toString(); 
                    String errmsg = "OK"; 
                    Exception error = null; 
                    
                    while (true)
                    {
                        try 
                        { 
                            if (exists(connDest, objid)) break; 

                            transferImpl(conn, connDest, objid, data); 
                        } 
                        catch(Exception x) 
                        {
                            errmsg = "[ERROR] " + x.getMessage(); 
                            error = x; 
                        }

                        System.out.println(counter + ") processed " + objid + "... ["+sdate+" "+shour+", targetDS="+destDS+"] " + errmsg);
                        
                        if (error != null) 
                        {
                            if (retryOnError) continue;
                            
                            throw error;
                        } 

                        counter +=1; 
                        break;
                    }
                } 
            } 
        } 
        catch(Exception ex) { 
            throw ex; 
        } 
        finally 
        {
            try { conn.close(); }catch(Exception ign) {;} 
            try { connDest.close(); }catch(Exception ign) {;} 
        } 
    }
    
    public void transferByHour(String sdate, int hour) throws Exception    
    {
        Connection conn = null;
        Connection connDest = null;

        java.sql.Date.valueOf(sdate);
        
        try
        {
            if (srcDS.equals(destDS))
                throw new Exception("source-ds and target-ds must not be the same");
            
            conn = dbConfig.createConnection(srcDS);
            connDest = dbConfig.createConnection(destDS);
            
            long counter = 1;
            String shour = hour+"";
            if (hour < 10) shour = "0"+hour;

            String fromdate = sdate + " " + shour + ":00:00";
            String todate   = sdate + " " + shour + ":59:59";                

            System.out.println("*fetching payout ids... ["+sdate+" "+shour+", targetDS="+destDS+"]");
            List ids = getIds(conn, fromdate, todate);
            while (!ids.isEmpty())
            {
                Map data = (Map) ids.remove(0);
                String objid = data.get("objid").toString();
                String errmsg = "OK";

                try 
                {
                    if (exists(connDest, objid)) continue;

                    transferImpl(conn, connDest, objid, data);
                } 
                catch(Exception x) {
                    errmsg = "[ERROR] " + x.getMessage();
                }

                System.out.println(counter + ") processed " + objid + "... " + errmsg);
                counter +=1;
            }
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { conn.close(); }catch(Exception ign) {;} 
            try { connDest.close(); }catch(Exception ign) {;} 
        }         
    }    
    
    public void listUnsyncTransactions(String sdate, int hour) throws Exception    
    {
        Connection conn = null;
        Connection connDest = null;

        java.sql.Date.valueOf(sdate);
        
        try
        {
            if (srcDS.equals(destDS))
                throw new Exception("source-ds and target-ds must not be the same");
            
            conn = dbConfig.createConnection(srcDS);
            connDest = dbConfig.createConnection(destDS);
            
            long counter = 1;
            String shour = hour+"";
            if (hour < 10) shour = "0"+hour;

            String fromdate = sdate + " " + shour + ":00:00";
            String todate   = sdate + " " + shour + ":59:59";                

            System.out.println("*fetching payout ids... ["+sdate+" "+shour+", targetDS="+destDS+"]");
            List ids = getIds(conn, fromdate, todate);
            while (!ids.isEmpty())
            {
                Map data = (Map) ids.remove(0);
                String objid = data.get("objid").toString();
                String errmsg = "";

                try 
                {
                    if (exists(connDest, objid)) continue;
                } 
                catch(Exception x) {
                    errmsg = "[ERROR] " + x.getMessage();
                }

                System.out.println(counter + ") processed " + objid + "... " + errmsg);
                counter +=1;
            }
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { conn.close(); }catch(Exception ign) {;} 
            try { connDest.close(); }catch(Exception ign) {;} 
        }         
    }        
    
    public void transferByControlNo(String controlno) throws Exception    
    {
        Connection conn = null;
        Connection connDest = null;

        try
        {
            if (srcDS.equals(destDS))
                throw new Exception("source-ds and target-ds must not be the same");
            
            conn = dbConfig.createConnection(srcDS);
            connDest = dbConfig.createConnection(destDS);
            
            Iterator itr = getControlNoLink(conn, controlno).iterator();
            while (itr.hasNext())
            {
                Map data = (Map) itr.next();
                String objid = data.get("objid").toString();
                String msg = "[OK]";

                try 
                {
                    if (exists(connDest, objid)) continue;

                    transferImpl(conn, connDest, objid, data);
                } 
                catch(Exception x) { 
                    msg = "[ERROR] " + x.getMessage(); 
                } 

                System.out.println("processing " + objid + "... " + msg);                    
            }
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { conn.close(); }catch(Exception ign) {;} 
            try { connDest.close(); }catch(Exception ign) {;} 
        }         
    }            
    
    public void transferRecord(String objid) throws Exception    
    {
        Connection conn = null;
        Connection connDest = null;

        try
        {
            if (srcDS.equals(destDS))
                throw new Exception("source-ds and target-ds must not be the same");
            
            conn = dbConfig.createConnection(srcDS);
            connDest = dbConfig.createConnection(destDS);
            
            String errmsg = "OK";

            try 
            {
                Map data = getId(conn, objid);
                data.put("restrict", "1");
                
                transferImpl(conn, connDest, objid, data);
            } 
            catch(Exception x) 
            {
                errmsg = "[ERROR] " + x.getMessage();
                throw x;
            }

            System.out.println("processed " + objid + "... " + errmsg);
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { conn.close(); }catch(Exception ign) {;} 
            try { connDest.close(); }catch(Exception ign) {;} 
        }         
    }    
    
    public void transferImpl(Connection conn, Connection connDest, String objid, Map data) throws Exception
    {
        String soutid = (String) data.get("strsendoutid"); 
        String poutcontrolid = (String) data.get("strcontrolid"); 
        String soutcontrolid = (String) data.get("soutcontrolid");        
        String kptn = (String) data.get("strkptn");
        String senderid = (String) data.get("strsenderid");
        String receiverid = (String) data.get("strreceiverid");      
        
        DataService ds = new DataService(); 
        if (soutcontrolid != null)
            ds.transferData(conn, connDest, "select * from mlkp.tblcontrol where objid='"+ soutcontrolid +"'", "mlkp.tblcontrol", true);
        if (poutcontrolid != null)
            ds.transferData(conn, connDest, "select * from mlkp.tblcontrol where objid='"+ poutcontrolid +"'", "mlkp.tblcontrol", true);
        
        PersonService ps = new PersonService();
        if (senderid != null) ps.transfer(conn, connDest, senderid);
        if (receiverid != null) ps.transfer(conn, connDest, receiverid);
        
        try { exec(conn, "update mlkp.tblsendoutinfo set dtsenderbirthdate=null where objid='"+soutid+"' and dtsenderbirthdate='0000-00-00'"); }catch(Exception ign){;} 
        try { exec(conn, "update mlkp.tblsendoutinfo set dtreceiverbirthdate=null where objid='"+soutid+"' and dtreceiverbirthdate='0000-00-00'");  }catch(Exception ign){;} 
        
        if ("1".equals(data.get("restrict")+"")) 
            ds.transferData(conn, connDest, "select * from mlkp.tblsendout where objid='"+ soutid +"'", "mlkp.tblsendout"); 
        else
            ds.transferData(conn, connDest, "select * from mlkp.tblsendout where objid='"+ soutid +"'", "mlkp.tblsendout", true); 
        
        ds.transferData(conn, connDest, "select * from mlkp.tblsendoutext where objid='"+ objid +"'", "mlkp.tblsendoutext", true);
        ds.transferData(conn, connDest, "select * from mlkp.tblsendoutcharge where parentid='"+ soutid +"'", "mlkp.tblsendoutcharge", true);
        ds.transferData(conn, connDest, "select * from mlkp.tblsendoutinfo where objid='"+ soutid +"'", "mlkp.tblsendoutinfo", true);
        ds.transferData(conn, connDest, "select * from mlkp.tblsendoutext where objid='"+ soutid +"'", "mlkp.tblsendoutext", true);
        ds.transferData(conn, connDest, "select * from mlkp.tblsendoutoption where objid='"+ soutid +"'", "mlkp.tblsendoutoption", true);
        ds.transferData(conn, connDest, "select * from mlkp.tblsendoutor where objid='"+ soutid +"'", "mlkp.tblsendoutor", true);
        ds.transferData(conn, connDest, "select * from mlkp.tblsendoutwalkinid where objid='"+ soutid +"'", "mlkp.tblsendoutwalkinid", true);
        ds.transferData(conn, connDest, "select * from mlkp.tblremotesendout where objid='"+ soutid +"'", "mlkp.tblremotesendout", true); 

        String poutcontrolno = (String) data.get("strcontrolno"); 
        String poutdate = (String) data.get("dtclaimed"); 
        if (ds.exists(connDest, "select objid from mlkp.tblpayout where strcontrolno='"+poutcontrolno+"' and not(dtclaimed='"+poutdate+"')"))
            ds.exec(connDest, "update mlkp.tblpayout set strcontrolno='"+poutcontrolno+"-1' where strcontrolno='"+poutcontrolno+"' and not(dtclaimed='"+poutdate+"')"); 
        
        ds.transferData(conn, connDest, "select * from mlkp.tblpayout where objid='"+ objid +"'", "mlkp.tblpayout");

        exec(connDest, "update mlkp.tblsendout set state=1 where objid='"+ soutid +"' "); 

        ds.transferData(conn, connDest, "select * from mlkp.tblkptnlog where kptn='"+ kptn +"'", "mlkp.tblkptnlog", true);

        ds.transferData(conn, connDest, "select * from mlkp.tblpayoutinfo where objid='"+ objid +"'", "mlkp.tblpayoutinfo");
        ds.transferData(conn, connDest, "select * from mlkp.tblremotepayout where objid='"+ objid +"'", "mlkp.tblremotepayout");
        
        try {
            ds.transferData(conn, connDest, "select * from mlkp.tblkptnlog_new where kptn='"+ kptn +"'", "mlkp.tblkptnlog", true);
        } catch(Exception ign) {;} 
        try {
            ds.transferData(conn, connDest, "select * from mlkp.tblkptnlog_new2 where kptn='"+ kptn +"'", "mlkp.tblkptnlog", true);
        } catch(Exception ign) {;}         
        try {
            ds.transferData(conn, connDest, "select * from mlkp.tblkptnlog_old where kptn='"+ kptn +"'", "mlkp.tblkptnlog", true);
        } catch(Exception ign) {;}                 
    }
    
    private int exec(Connection conn, String sql) throws Exception
    {
        PreparedStatement ps = null;
        try
        {
            ps = conn.prepareStatement(sql);
            return ps.executeUpdate();
        }
        catch(Exception ex) {
            throw ex;
        }
        finally {
            try { ps.close(); }catch(Exception ign) {;}
        }
    }

    
    private List getIds(Connection conn, String fromdate, String todate) throws Exception
    {
        PreparedStatement ps = null; 
        ResultSet rs = null; 
        
        try
        {
            String sql = " select p.*, s.strkptn, s.strcontrolid as soutcontrolid, s.strsenderid, s.strreceiverid " + 
                         " from ( " + 
                         "        select objid, dtclaimed, state, strsendoutid, strcontrolid, strcontrolno from mlkp.tblpayout " + 
                         "        where dtclaimed between '"+fromdate+"' and '"+todate+"' " + 
                         "      )p " + 
                         "    inner join mlkp.tblsendout s on p.strsendoutid=s.objid " + 
                         " where p.state=1 "; 
            
            ps = conn.prepareStatement(sql);  
            rs = ps.executeQuery(); 
            
            List results = new ArrayList(); 
            while (rs.next()) 
            { 
                Map data = new HashMap(); 
                data.put("objid", rs.getString("objid")); 
                data.put("dtclaimed", rs.getString("dtclaimed")); 
                data.put("strsendoutid", rs.getString("strsendoutid")); 
                data.put("strcontrolid", rs.getString("strcontrolid")); 
                data.put("strcontrolno", rs.getString("strcontrolno")); 
                data.put("strkptn", rs.getString("strkptn")); 
                data.put("soutcontrolid", rs.getString("soutcontrolid")); 
                data.put("strsenderid", rs.getString("strsenderid"));     
                data.put("strreceiverid", rs.getString("strreceiverid")); 
                results.add(data); 
            }
            return results;
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { rs.close(); }catch(Exception ign) {;}
            try { ps.close(); }catch(Exception ign) {;}
        } 
    }        
    
    private List getControlNoLink(Connection conn, String controlno) throws Exception
    {
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        try
        {
            String sql = " select p.*, s.strkptn, s.strcontrolid as soutcontrolid, s.strsenderid, s.strreceiverid " + 
                         " from ( " + 
                         "        select objid, state, strsendoutid, strcontrolid from mlkp.tblpayout " + 
                         "        where strcontrolno like '"+controlno+"' " + 
                         "      )p " + 
                         "    inner join mlkp.tblsendout s on p.strsendoutid=s.objid " + 
                         " where p.state=1 ";
            
            ps = conn.prepareStatement(sql); 
            rs = ps.executeQuery(); 
            
            List results = new ArrayList();
            while (rs.next()) 
            {
                Map data = new HashMap();
                data.put("objid", rs.getString("objid")); 
                data.put("strsendoutid", rs.getString("strsendoutid")); 
                data.put("strcontrolid", rs.getString("strcontrolid")); 
                data.put("strkptn", rs.getString("strkptn"));
                data.put("soutcontrolid", rs.getString("soutcontrolid"));
                data.put("strsenderid", rs.getString("strsenderid"));
                data.put("strreceiverid", rs.getString("strreceiverid"));
                results.add(data);
            }
            return results;
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { rs.close(); }catch(Exception ign) {;}
            try { ps.close(); }catch(Exception ign) {;}
        } 
    }            
    
    private Map getId(Connection conn, String objid) throws Exception
    {
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        try
        {
            String sql = " select p.*, s.strkptn, s.strcontrolid as soutcontrolid, s.strsenderid, s.strreceiverid " + 
                         " from ( " + 
                         "        select objid, dtclaimed, state, strsendoutid, strcontrolid, strcontrolno from mlkp.tblpayout " + 
                         "        where objid='"+objid+"' " + 
                         "      )p " + 
                         "    inner join mlkp.tblsendout s on p.strsendoutid=s.objid " + 
                         " where p.state=1 ";
            
            ps = conn.prepareStatement(sql); 
            rs = ps.executeQuery(); 
            
            if (rs.next()) 
            {
                Map data = new HashMap();
                data.put("objid", rs.getString("objid")); 
                data.put("dtclaimed", rs.getString("dtclaimed")); 
                data.put("strsendoutid", rs.getString("strsendoutid")); 
                data.put("strcontrolid", rs.getString("strcontrolid")); 
                data.put("strcontrolno", rs.getString("strcontrolno")); 
                data.put("strkptn", rs.getString("strkptn"));
                data.put("soutcontrolid", rs.getString("soutcontrolid"));
                data.put("strsenderid", rs.getString("strsenderid"));
                data.put("strreceiverid", rs.getString("strreceiverid"));
                return data;
            }

            return null;
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { rs.close(); }catch(Exception ign) {;}
            try { ps.close(); }catch(Exception ign) {;}
        } 
    }            
    

    
    private boolean exists(Connection conn, String objid) throws Exception
    {
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        try
        {
            String sql = " select objid from mlkp.tblpayout where objid='"+objid+"' "; 
            
            ps = conn.prepareStatement(sql); 
            rs = ps.executeQuery(); 
            boolean b = rs.next(); 
            return b;
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { rs.close(); }catch(Exception ign) {;}
            try { ps.close(); }catch(Exception ign) {;}
        } 
    }     
}
