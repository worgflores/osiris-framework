package com.mlhuillier.util.migration2;

import com.mlhuillier.util.DBConfig;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class TransferBillsPaymentInvalidated implements IDataTransfer 
{
    private DBConfig dbConfig;
    private String srcDS;
    private String destDS;
    
    public TransferBillsPaymentInvalidated(String srcDS, String destDS) 
    {
        this.srcDS = srcDS;
        this.destDS = destDS;
        this.dbConfig = new DBConfig();
    }
    
    public void transfer(String sdate) throws Exception    
    {
        Connection conn = null;
        Connection connDest = null;

        java.sql.Date.valueOf(sdate);
        
        try
        {
            if (srcDS.equals(destDS))
                throw new Exception("source-ds and target-ds must not be the same");
            
            conn = dbConfig.createConnection(srcDS);
            connDest = dbConfig.createConnection(destDS);
            
            long counter = 1;
            for (int h=0; h < 24; h++)
            {
                String shour = h+"";
                if (h < 10) shour = "0"+h;

                String fromdate = sdate + " " + shour + ":00:00";
                String todate   = sdate + " " + shour + ":59:59";                

                System.out.println("fetching billspaymentinvalidated ids... [" + sdate + " " + shour + "]"); 
                List ids = getIds(conn, fromdate, todate); 
                while (!ids.isEmpty())
                {
                    String[] arr = (String[]) ids.remove(0);
                    String objid  = arr[0];
                    String bpid   = arr[1];
                    String refno  = arr[2];
                    String errmsg = "OK";

                    try 
                    {
                        if (exists(connDest, objid)) continue;
                        
                        transferImpl(conn, connDest, objid, bpid, refno); 
                    } 
                    catch(Exception x) { 
                        errmsg = "[ERROR] " + x.getMessage(); 
                    } 

                    System.out.println(counter + ") processed " + objid + "... " + errmsg);
                    counter +=1;
                }
            }
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { conn.close(); }catch(Exception ign) {;} 
            try { connDest.close(); }catch(Exception ign) {;} 
        }         
    }
    
    public void transferImpl(Connection conn, Connection connDest, String objid, String bpid, String refno) throws Exception 
    {
        DataService ds = new DataService(); 
        ds.transferData(conn, connDest, "select * from mlcs.tblbilllog where refid='"+ objid +"'", "mlcs.tblbilllog", true); 
        ds.transferData(conn, connDest, "select * from mlcs.tblbilllog where refid='"+ bpid +"'", "mlcs.tblbilllog", true); 
        
        ds.transferData(conn, connDest, "select * from mlcs.tblbillpayment where objid='"+ objid +"'", "mlcs.tblbillpayment", true); 
        ds.transferData(conn, connDest, "select * from mlcs.tblremotepayment where objid='"+ objid +"'", "mlcs.tblremotepayment", true); 
        
        ds.transferData(conn, connDest, "select * from mlcs.tblbillpayment where objid='"+ bpid +"'", "mlcs.tblbillpayment", true); 
        ds.transferData(conn, connDest, "select * from mlcs.tblremotepayment where objid='"+ bpid +"'", "mlcs.tblremotepayment", true);  
        
        ds.transferData(conn, connDest, "select * from mlcs.tblbillchangerequest where strrefno='"+ refno +"'", "mlcs.tblbillchangerequest", true); 
        ds.transferData(conn, connDest, "select * from mlcs.tblinvalidatedbillpayment where objid='"+ objid +"'", "mlcs.tblinvalidatedbillpayment", true); 
    }
    
    private int exec(Connection conn, String sql) throws Exception
    {
        PreparedStatement ps = null;
        try
        {
            ps = conn.prepareStatement(sql);
            return ps.executeUpdate();
        }
        catch(Exception ex) {
            throw ex;
        }
        finally {
            try { ps.close(); }catch(Exception ign) {;}
        }
    }

    
    private List getIds(Connection conn, String fromdate, String todate) throws Exception
    {
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        try
        {
            String sql = " select objid, strbillpaymentid, strrefno from mlcs.tblinvalidatedbillpayment " + 
                         " where dtmodified between '"+fromdate+"' and '"+todate+"' "; 
            
            ps = conn.prepareStatement(sql); 
            rs = ps.executeQuery(); 
            
            List results = new ArrayList();
            while (rs.next()) 
            {
                String[] arr = new String[]
                {
                    rs.getString("objid"), 
                    rs.getString("strbillpaymentid"),
                    rs.getString("strrefno")
                };
                results.add(arr);
            }
            return results;
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { rs.close(); }catch(Exception ign) {;}
            try { ps.close(); }catch(Exception ign) {;}
        } 
    }        
    
    private boolean exists(Connection conn, String objid) throws Exception
    {
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        try
        {
            String sql = " select objid from mlcs.tblinvalidatedbillpayment where objid='"+objid+"' "; 
            
            ps = conn.prepareStatement(sql); 
            rs = ps.executeQuery(); 
            boolean b = rs.next(); 
            return b;
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { rs.close(); }catch(Exception ign) {;}
            try { ps.close(); }catch(Exception ign) {;}
        } 
    }    
}
