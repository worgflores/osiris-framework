package com.mlhuillier.util.migration2;

import com.mlhuillier.util.DBConfig;
import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class TransferResend implements IDataTransfer 
{  
    public static void main1(String[] args) throws Exception 
    {
        TransferResend p = new TransferResend("DB-204", "DB-212"); 
        p.transfer("2010-01-01", "2010-06-30");
    }
    
    
    private DBConfig dbConfig;
    private String srcDS;
    private String destDS;
    
    public TransferResend(String srcDS, String destDS) 
    {
        this.srcDS = srcDS;
        this.destDS = destDS;
        this.dbConfig = new DBConfig();
    }
    
    public void transfer(String sdate) throws Exception    
    {
        transfer(sdate, sdate);
    }
    
    public void transfer(String fromdate, String todate) throws Exception
    {
        Connection conn = null;
        Connection connDest = null;
        
        Date dtstart = java.sql.Date.valueOf(fromdate);
        Date dtend   = java.sql.Date.valueOf(todate); 
        
        try
        {
            if (srcDS.equals(destDS))
                throw new Exception("source-ds and target-ds must not be the same");
            
            conn = dbConfig.createConnection(srcDS);
            connDest = dbConfig.createConnection(destDS);

            DataService dataService = new DataService(); 
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            Calendar cal = new GregorianCalendar(); 
            cal.setTime(dtstart);
            while (true)
            {
                Date dt = cal.getTime();
                if (dt.after(dtend)) break;
                
                String sdate = sdf.format(dt);
                System.out.println("processing resend... [date="+sdate+", targetDS="+destDS+"]");
                dataService.insertOnDuplicateKey(conn, connDest, "select * from mlkp.tblresend where dttxndate between '"+sdate+" 00:00:00' and '"+sdate+" 23:59:59'", "mlkp.tblresend");
                
                cal.add(Calendar.DATE, 1);
            }
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { conn.close(); }catch(Exception ign) {;} 
            try { connDest.close(); }catch(Exception ign) {;} 
        } 
    } 
}
