package com.mlhuillier.util.migration2;

import com.mlhuillier.util.DBConfig;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class TransferSendout implements IDataTransfer 
{
    public static void xmain(String[] args) throws Exception 
    {
        new TransferSendout("DB-204", "DB-206").transferRecord("SOUTba6823f:12c1f351728:-43db"); 
    } 
    
    private DBConfig dbConfig;
    private String srcDS;
    private String destDS;
    private boolean retryOnError; 
    
    public TransferSendout(String srcDS, String destDS) {
        this(srcDS, destDS, false);
    }
    
    public TransferSendout(String srcDS, String destDS, boolean retryOnError) 
    {
        this.srcDS = srcDS;
        this.destDS = destDS;
        this.retryOnError = retryOnError;
        this.dbConfig = new DBConfig();
    }    
    
    public void transfer(String sdate) throws Exception    
    {
        Connection conn = null;
        Connection connDest = null;

        java.sql.Date.valueOf(sdate);
        
        try
        {
            if (srcDS.equals(destDS))
                throw new Exception("source-ds and target-ds must not be the same");
            
            conn = dbConfig.createConnection(srcDS);
            connDest = dbConfig.createConnection(destDS);
            
            int counter = 1;
            for (int h=0; h < 24; h++)
            {
                String shour = h+"";
                if (h < 10) shour = "0"+h;

                String fromdate = sdate + " " + shour + ":00:00";
                String todate   = sdate + " " + shour + ":59:59";                

                System.out.println("fetching sendout ids... [" + sdate + " " + shour + ", targetDS="+destDS+"]"); 
                List ids = getIds(conn, fromdate, todate); 
                while (!ids.isEmpty())
                {
                    Map data = (Map) ids.remove(0);
                    String objid = data.get("objid").toString();
                    String msg = "[OK]";
                    Exception error = null;
                    
                    while (true)
                    {
                        try 
                        {
                            if (exists(connDest, objid)) break;

                            error = null;
                            transferImpl(conn, connDest, objid, data); 
                        } 
                        catch(Exception x) 
                        { 
                            msg = "[ERROR] " + x.getMessage(); 
                            error = x; 
                        } 

                        System.out.println(counter + ") processing " + objid + "... [" + sdate + " " + shour + ", targetDS="+destDS+"] " + msg); 
                        if (error != null) 
                        {                        
                            if (retryOnError) continue;

                            throw error;
                        }
                        
                        counter +=1;
                        break;
                    }
                }
            }
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { conn.close(); }catch(Exception ign) {;} 
            try { connDest.close(); }catch(Exception ign) {;} 
        }         
    }
    
    public void transferRecord(String objid) throws Exception    
    {
        Connection conn = null;
        Connection connDest = null;

        try
        {
            if (srcDS.equals(destDS))
                throw new Exception("source-ds and target-ds must not be the same");
            
            conn = dbConfig.createConnection(srcDS);
            connDest = dbConfig.createConnection(destDS);
            
            Map data = getInfo(conn, objid);
            data.put("restrict", "1");
            
            String msg = "[OK]";

            try { 
                transferImpl(conn, connDest, objid, data); 
            } 
            catch(Exception x) 
            { 
                x.printStackTrace();
                msg = "[ERROR] " + x.getMessage(); 
            } 

            System.out.println("processing " + objid + "... " + msg);                    
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { conn.close(); }catch(Exception ign) {;} 
            try { connDest.close(); }catch(Exception ign) {;} 
        }         
    }    
    
    public void updateRecord(String objid) throws Exception    
    {
        Connection conn = null;

        try
        {
            if (srcDS.equals(destDS))
                throw new Exception("source-ds and target-ds must not be the same");
            
            conn = dbConfig.createConnection(srcDS);
            
            Map data = getInfo(conn, objid);
            String msg = "[OK]";

            try 
            {
                String kptn = (String) data.get("strkptn"); 
                String senderid = (String) data.get("strsenderid"); 
                String receiverid = (String) data.get("strreceiverid"); 
                String controlid = (String) data.get("strcontrolid"); 

                DataService ds = new DataService(); 
                if (controlid != null)
                    ds.transferData(conn, conn, "select * from mlkp.tblcontrol where objid='"+ controlid +"'", "mlkp.tblcontrol", true);

                PersonService ps = new PersonService();
                if (senderid != null) ps.transfer(conn, conn, senderid);
                if (receiverid != null) ps.transfer(conn, conn, receiverid);

                ds.insertOnDuplicateKey(conn, conn, "select * from mlkp.tblsendout where objid='"+ objid +"'", "mlkp.tblsendout");
                ds.transferData(conn, conn,  "select * from mlkp.tblkptnlog where kptn='"+ kptn +"'", "mlkp.tblkptnlog", true);
                ds.transferData(conn, conn,  "select * from mlkp.tblsendoutcharge where parentid='"+ objid +"'", "mlkp.tblsendoutcharge", true);

                exec(conn, "update mlkp.tblsendoutinfo set dtsenderbirthdate=null where objid='"+objid+"' and dtsenderbirthdate='0000-00-00'");
                exec(conn, "update mlkp.tblsendoutinfo set dtreceiverbirthdate=null where objid='"+objid+"' and dtreceiverbirthdate='0000-00-00'");

                ds.insertOnDuplicateKey(conn, conn,  "select * from mlkp.tblsendoutinfo where objid='"+ objid +"'", "mlkp.tblsendoutinfo");
                ds.insertOnDuplicateKey(conn, conn,  "select * from mlkp.tblsendoutext where objid='"+ objid +"'", "mlkp.tblsendoutext");
                ds.insertOnDuplicateKey(conn, conn,  "select * from mlkp.tblsendoutoption where objid='"+ objid +"'", "mlkp.tblsendoutoption");
                ds.insertOnDuplicateKey(conn, conn,  "select * from mlkp.tblsendoutor where objid='"+ objid +"'", "mlkp.tblsendoutor");
                ds.insertOnDuplicateKey(conn, conn,  "select * from mlkp.tblsendoutwalkinid where objid='"+ objid +"'", "mlkp.tblsendoutwalkinid");
                ds.insertOnDuplicateKey(conn, conn,  "select * from mlkp.tblremotesendout where objid='"+ objid +"'", "mlkp.tblremotesendout");            
            } 
            catch(Exception x) { 
                msg = "[ERROR] " + x.getMessage(); 
            } 

            System.out.println("processing " + objid + "... " + msg);                    
        }
        catch(Exception ex) {
            throw ex;
        }
        finally 
        {
            try { conn.close(); }catch(Exception ign) {;} 
        }         
    }        
    
    public void transferByKPTN(String kptn) throws Exception    
    {
        Connection conn = null;
        Connection connDest = null;

        try
        {
            if (srcDS.equals(destDS))
                throw new Exception("source-ds and target-ds must not be the same");
            
            conn = dbConfig.createConnection(srcDS);
            connDest = dbConfig.createConnection(destDS);
            
            Iterator itr = getKPTNLink(conn, kptn).iterator();
            while (itr.hasNext())
            {
                String objid = itr.next().toString();
                Map data = getInfo(conn, objid);
                String msg = "[OK]";

                try 
                {
                    //if (exists(connDest, objid)) return;
                    
                    transferImpl(conn, connDest, objid, data); 
                } 
                catch(Exception x) { 
                    msg = "[ERROR] " + x.getMessage(); 
                } 

                System.out.println("processing " + objid + "... " + msg);                    
            }
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { conn.close(); }catch(Exception ign) {;} 
            try { connDest.close(); }catch(Exception ign) {;} 
        }         
    }        
    
    public void transferByControlNo(String controlno) throws Exception    
    {
        Connection conn = null;
        Connection connDest = null;

        try
        {
            if (srcDS.equals(destDS))
                throw new Exception("source-ds and target-ds must not be the same");
            
            conn = dbConfig.createConnection(srcDS);
            connDest = dbConfig.createConnection(destDS);
            
            Iterator itr = getControlNoLink(conn, controlno).iterator();
            while (itr.hasNext())
            {
                String objid = itr.next().toString();
                Map data = getInfo(conn, objid);
                String msg = "[OK]";

                try 
                {
                    if (exists(connDest, objid)) continue;
                    
                    transferImpl(conn, connDest, objid, data); 
                } 
                catch(Exception x) { 
                    msg = "[ERROR] " + x.getMessage(); 
                } 

                System.out.println("processing " + objid + "... " + msg);                    
            }
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { conn.close(); }catch(Exception ign) {;} 
            try { connDest.close(); }catch(Exception ign) {;} 
        }         
    }            
    
    public void transferByHour(String sdate, int hour) throws Exception    
    {
        Connection conn = null;
        Connection connDest = null;

        java.sql.Date.valueOf(sdate);
        
        try
        {
            if (srcDS.equals(destDS))
                throw new Exception("source-ds and target-ds must not be the same");
            
            conn = dbConfig.createConnection(srcDS);
            connDest = dbConfig.createConnection(destDS);
            
            int counter = 1;
            String shour = hour+"";
            if (hour < 10) shour = "0"+hour;

            String fromdate = sdate + " " + shour + ":00:00";
            String todate   = sdate + " " + shour + ":59:59";                

            System.out.println("fetching sendout ids... [" + sdate + " " + shour + " src="+srcDS+", target="+destDS+"]"); 
            List listDest = getPrimaryIDs(connDest, fromdate, todate); 
            System.out.println("   starting... ");
            List ids = getIds(conn, fromdate, todate, listDest);
            while (!ids.isEmpty())
            {
                Map data = (Map) ids.remove(0);
                String objid = data.get("objid").toString();
                String msg = "[OK]";
                
                try 
                {
                    if (exists(connDest, objid)) continue;
                    
                    transferImpl(conn, connDest, objid, data); 
                } 
                catch(Exception x) { 
                    msg = "[ERROR] " + x.getMessage(); 
                    //x.printStackTrace();
                } 

                System.out.println(counter + ") processing " + objid + "... " + msg);                    
                counter +=1;
            }
            listDest.clear();
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { conn.close(); }catch(Exception ign) {;} 
            try { connDest.close(); }catch(Exception ign) {;} 
        }         
    }    
    
    public void listUnsyncTransactions(String sdate, int hour) throws Exception    
    {
        Connection conn = null;
        Connection connDest = null;

        java.sql.Date.valueOf(sdate);
        
        try
        {
            if (srcDS.equals(destDS))
                throw new Exception("source-ds and target-ds must not be the same");
            
            conn = dbConfig.createConnection(srcDS);
            connDest = dbConfig.createConnection(destDS);
            
            int counter = 1;
            String shour = hour+"";
            if (hour < 10) shour = "0"+hour;

            String fromdate = sdate + " " + shour + ":00:00";
            String todate   = sdate + " " + shour + ":59:59";                

            System.out.println("fetching sendout ids... [" + sdate + " " + shour + " src="+srcDS+", target="+destDS+"]"); 
            List ids = getIds(conn, fromdate, todate); 
            while (!ids.isEmpty())
            {
                Map data = (Map) ids.remove(0);
                String objid = data.get("objid").toString();
                String msg = "";
                
                try 
                {
                    if (exists(connDest, objid)) continue;
                } 
                catch(Exception x) { 
                    msg = "[ERROR] " + x.getMessage(); 
                    //x.printStackTrace();
                } 

                System.out.println(counter + ") processing " + objid + "... " + msg);                    
                counter +=1;
            }
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { conn.close(); }catch(Exception ign) {;} 
            try { connDest.close(); }catch(Exception ign) {;} 
        }         
    }        

    public void transferImpl(Connection conn, Connection connDest, String objid, Map data) throws Exception
    {
        String kptn = (String) data.get("strkptn"); 
        String senderid = (String) data.get("strsenderid"); 
        String receiverid = (String) data.get("strreceiverid"); 
        String controlid = (String) data.get("strcontrolid"); 
        String controlno = (String) data.get("strcontrolno");
        
        DataService ds = new DataService(); 
        if (controlid != null)
            ds.transferData(conn, connDest, "select * from mlkp.tblcontrol where objid='"+ controlid +"'", "mlkp.tblcontrol", true);

        PersonService ps = new PersonService();
        if (senderid != null) ps.transfer(conn, connDest, senderid);
        if (receiverid != null) ps.transfer(conn, connDest, receiverid);
        
        String dtfiled = data.get("dtfiled").toString();         
        if (ds.exists(connDest, "select objid from mlkp.tblsendout where strcontrolno='"+controlno+"' and not(dtfiled='"+dtfiled+"')"))
            ds.exec(connDest, "update mlkp.tblsendout set strcontrolno='"+controlno+"-1' where strcontrolno='"+controlno+"' and not(dtfiled='"+dtfiled+"')"); 
        
        boolean restrict = "1".equals(data.get("restrict")+""); 
        if (restrict) 
            ds.transferData(conn, connDest, "select * from mlkp.tblsendout where objid='"+ objid +"'", "mlkp.tblsendout"); 
        else 
            ds.transferData(conn, connDest, "select * from mlkp.tblsendout where objid='"+ objid +"'", "mlkp.tblsendout", true); 
        
        ds.transferData(conn, connDest,  "select * from mlkp.tblkptnlog where kptn='"+ kptn +"'", "mlkp.tblkptnlog", true);
        ds.transferData(conn, connDest,  "select * from mlkp.tblsendoutcharge where parentid='"+ objid +"'", "mlkp.tblsendoutcharge", true);
        
        try { exec(conn, "update mlkp.tblsendoutinfo set dtsenderbirthdate=null where objid='"+objid+"' and dtsenderbirthdate='0000-00-00'"); }catch(Exception ign){;} 
        try { exec(conn, "update mlkp.tblsendoutinfo set dtreceiverbirthdate=null where objid='"+objid+"' and dtreceiverbirthdate='0000-00-00'"); }catch(Exception ign){;} 
        
        ds.transferData(conn, connDest,  "select * from mlkp.tblsendoutext where objid='"+ objid +"'", "mlkp.tblsendoutext", true);
        ds.transferData(conn, connDest,  "select * from mlkp.tblsendoutinfo where objid='"+ objid +"'", "mlkp.tblsendoutinfo", true);
        ds.transferData(conn, connDest,  "select * from mlkp.tblsendoutoption where objid='"+ objid +"'", "mlkp.tblsendoutoption", true);
        ds.transferData(conn, connDest,  "select * from mlkp.tblsendoutor where objid='"+ objid +"'", "mlkp.tblsendoutor", true);
        ds.transferData(conn, connDest,  "select * from mlkp.tblsendoutwalkinid where objid='"+ objid +"'", "mlkp.tblsendoutwalkinid", true);
        ds.transferData(conn, connDest,  "select * from mlkp.tblremotesendout where objid='"+ objid +"'", "mlkp.tblremotesendout", true);            
    }
    
    private int exec(Connection conn, String sql) throws Exception
    {
        PreparedStatement ps = null;
        try
        {
            ps = conn.prepareStatement(sql);
            return ps.executeUpdate();
        }
        catch(Exception ex) {
            throw ex;
        }
        finally {
            try { ps.close(); }catch(Exception ign) {;}
        }
    }
    
    private List getIds(Connection conn, String fromdate, String todate) throws Exception {
        return getIds(conn, fromdate, todate, new ArrayList());
    }
    
    private List getIds(Connection conn, String fromdate, String todate, List filter) throws Exception
    {
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            String sql = " select objid, dtfiled, strkptn, strsenderid, strreceiverid, strcontrolid " + 
                         " from mlkp.tblsendout where dtfiled between '"+fromdate+"' and '"+todate+"' "; 
            
            ps = conn.prepareStatement(sql); 
            rs = ps.executeQuery(); 
            
            List results = new ArrayList();
            while (rs.next()) 
            {
                String objid = rs.getString("objid");
                if (filter.indexOf(objid) >= 0) continue;
                
                Map data = new HashMap();
                data.put("objid", objid);
                data.put("dtfiled", rs.getString("dtfiled"));
                data.put("strkptn", rs.getString("strkptn"));
                data.put("strsenderid", rs.getString("strsenderid"));
                data.put("strreceiverid", rs.getString("strreceiverid"));
                data.put("strcontrolid", rs.getString("strcontrolid"));
                results.add(data);
            }
            return results;
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { rs.close(); }catch(Exception ign) {;}
            try { ps.close(); }catch(Exception ign) {;}
        } 
    }    
    
    private List getPrimaryIDs(Connection conn, String fromdate, String todate) throws Exception
    {
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        try
        {
            String sql = " select objid from mlkp.tblsendout " + 
                         " where dtfiled between '"+fromdate+"' and '"+todate+"' "; 
            
            ps = conn.prepareStatement(sql); 
            rs = ps.executeQuery(); 
            
            List results = new ArrayList();
            while (rs.next()) {
                results.add(rs.getString("objid")); 
            }
            return results;
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { rs.close(); }catch(Exception ign) {;}
            try { ps.close(); }catch(Exception ign) {;}
        } 
    }    
    
    private Map getInfo(Connection conn, String objid) throws Exception
    {
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        try
        {
            String sql = " select objid, dtfiled, strkptn, strsenderid, strreceiverid, strcontrolid, strcontrolno " + 
                         " from mlkp.tblsendout where objid='"+objid+"' "; 
            
            ps = conn.prepareStatement(sql); 
            rs = ps.executeQuery(); 
            
            Map data = new HashMap();
            if (rs.next()) 
            {
                data.put("objid", rs.getString("objid"));
                data.put("dtfiled", rs.getString("dtfiled"));
                data.put("strkptn", rs.getString("strkptn"));
                data.put("strsenderid", rs.getString("strsenderid"));
                data.put("strreceiverid", rs.getString("strreceiverid"));
                data.put("strcontrolid", rs.getString("strcontrolid"));
                data.put("strcontrolno", rs.getString("strcontrolno"));
            }
            return data;
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { rs.close(); }catch(Exception ign) {;}
            try { ps.close(); }catch(Exception ign) {;}
        } 
    }    
    
    private List getKPTNLink(Connection conn, String kptn) throws Exception
    {
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        try
        {
            String sql = " select objid from mlkp.tblsendout where strkptn='"+kptn+"' "; 
            
            ps = conn.prepareStatement(sql); 
            rs = ps.executeQuery(); 
            
            List data = new ArrayList();
            while (rs.next()) { 
                data.add(rs.getString("objid"));
            }
            return data;
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { rs.close(); }catch(Exception ign) {;}
            try { ps.close(); }catch(Exception ign) {;}
        } 
    }        
    
    private List getControlNoLink(Connection conn, String controlno) throws Exception
    {
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        try
        {
            String sql = " select objid from mlkp.tblsendout where strcontrolno like '"+controlno+"' "; 
            
            ps = conn.prepareStatement(sql); 
            rs = ps.executeQuery(); 
            
            List data = new ArrayList();
            while (rs.next()) { 
                data.add(rs.getString("objid"));
            }
            return data;
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { rs.close(); }catch(Exception ign) {;}
            try { ps.close(); }catch(Exception ign) {;}
        } 
    }            
    
    private boolean exists(Connection conn, String objid) throws Exception
    {
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        try
        {
            String sql = " select objid from mlkp.tblsendout where objid='"+objid+"' "; 
            
            ps = conn.prepareStatement(sql); 
            rs = ps.executeQuery(); 
            boolean b = rs.next(); 
            return b;
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { rs.close(); }catch(Exception ign) {;}
            try { ps.close(); }catch(Exception ign) {;}
        } 
    }    
}
