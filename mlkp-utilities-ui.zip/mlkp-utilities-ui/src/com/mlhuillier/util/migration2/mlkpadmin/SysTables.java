package com.mlhuillier.util.migration2.mlkpadmin;

import com.mlhuillier.util.DBConfig;
import com.mlhuillier.util.migration2.DataService;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class SysTables 
{
    public static void main1(String[] args) throws Exception 
    {
        SysTables b = new SysTables("DB-204", "DB-212");
        b.transfer();
    }
    
    private DBConfig dbConfig;
    private String srcDS;
    private String destDS;
    
    public SysTables(String srcDS, String destDS) 
    {
        this.srcDS = srcDS;
        this.destDS = destDS;
        this.dbConfig = new DBConfig();
    }
    
    public void transfer() throws Exception 
    {
        Connection conn = null;
        Connection connDest = null;

        try
        {
            if (srcDS.equals(destDS))
                throw new Exception("source-ds and target-ds must not be the same");
            
            conn = dbConfig.createConnection(srcDS);
            connDest = dbConfig.createConnection(destDS);
            
            long counter = 1;
            DataService dataService = new DataService();
            System.out.println("processing sys_app...");
            dataService.insertOnDuplicateKey(conn, connDest, "select * from mlkp_admin.sys_app", "mlkp_admin.sys_app"); 
            System.out.println("processing sys_control_series...");
            dataService.insertOnDuplicateKey(conn, connDest, "select * from mlkp_admin.sys_control_series", "mlkp_admin.sys_control_series"); 
            System.out.println("processing sys_data...");
            dataService.insertOnDuplicateKey(conn, connDest, "select * from mlkp_admin.sys_data", "mlkp_admin.sys_data"); 
            System.out.println("processing sys_date_bean...");
            dataService.insertOnDuplicateKey(conn, connDest, "select * from mlkp_admin.sys_date_bean", "mlkp_admin.sys_date_bean"); 
            System.out.println("processing sys_global...");
            dataService.insertOnDuplicateKey(conn, connDest, "select * from mlkp_admin.sys_global", "mlkp_admin.sys_global"); 
            System.out.println("processing sys_message...");
            dataService.insertOnDuplicateKey(conn, connDest, "select * from mlkp_admin.sys_message", "mlkp_admin.sys_message"); 
            System.out.println("processing sys_object...");
            dataService.insertOnDuplicateKey(conn, connDest, "select * from mlkp_admin.sys_object", "mlkp_admin.sys_object"); 
            System.out.println("processing sys_object_action...");
            dataService.insertOnDuplicateKey(conn, connDest, "select * from mlkp_admin.sys_object_action", "mlkp_admin.sys_object_action"); 
            System.out.println("processing sys_report...");
            dataService.insertOnDuplicateKey(conn, connDest, "select * from mlkp_admin.sys_report", "mlkp_admin.sys_report"); 
            System.out.println("processing sys_report_template...");
            dataService.insertOnDuplicateKey(conn, connDest, "select * from mlkp_admin.sys_report_template", "mlkp_admin.sys_report_template"); 
            System.out.println("processing sys_role...");
            dataService.insertOnDuplicateKey(conn, connDest, "select * from mlkp_admin.sys_role", "mlkp_admin.sys_role"); 
            System.out.println("processing sys_role_permission...");
            dataService.insertOnDuplicateKey(conn, connDest, "select * from mlkp_admin.sys_role_permission", "mlkp_admin.sys_role_permission"); 
            System.out.println("processing sys_rule...");
            dataService.insertOnDuplicateKey(conn, connDest, "select * from mlkp_admin.sys_rule", "mlkp_admin.sys_rule"); 
            System.out.println("processing sys_schema...");
            dataService.insertOnDuplicateKey(conn, connDest, "select * from mlkp_admin.sys_schema", "mlkp_admin.sys_schema"); 
            System.out.println("processing sys_screen...");
            dataService.insertOnDuplicateKey(conn, connDest, "select * from mlkp_admin.sys_screen", "mlkp_admin.sys_screen"); 
            System.out.println("processing sys_terminal...");
            dataService.insertOnDuplicateKey(conn, connDest, "select * from mlkp_admin.sys_terminal", "mlkp_admin.sys_terminal"); 
            System.out.println("processing sys_user...");
            dataService.insertOnDuplicateKey(conn, connDest, "select * from mlkp_admin.sys_user", "mlkp_admin.sys_user"); 
            System.out.println("processing sys_user_alias...");
            dataService.insertOnDuplicateKey(conn, connDest, "select * from mlkp_admin.sys_user_alias", "mlkp_admin.sys_user_alias"); 
            System.out.println("processing sys_user_company...");
            dataService.insertOnDuplicateKey(conn, connDest, "select * from mlkp_admin.sys_user_company", "mlkp_admin.sys_user_company"); 
            
//            dataService.exec(conn, "update mlkp_admin.sys_user_machine set dtregistered=null where dtregistered='0000-00-00 00:00:00'");  
            System.out.println("processing sys_user_machine...");
            dataService.insertOnDuplicateKey(conn, connDest, "select * from mlkp_admin.sys_user_machine", "mlkp_admin.sys_user_machine"); 
            System.out.println("processing sys_user_permission...");
            dataService.insertOnDuplicateKey(conn, connDest, "select * from mlkp_admin.sys_user_permission", "mlkp_admin.sys_user_permission"); 
            System.out.println("processing sys_role_user...");
            dataService.insertOnDuplicateKey(conn, connDest, "select * from mlkp_admin.sys_role_user", "mlkp_admin.sys_role_user"); 
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { conn.close(); }catch(Exception ign) {;} 
            try { connDest.close(); }catch(Exception ign) {;} 
        }         
    }
    
    private int exec(Connection conn, String sql) throws Exception
    {
        PreparedStatement ps = null;
        try
        {
            ps = conn.prepareStatement(sql);
            return ps.executeUpdate();
        }
        catch(Exception ex) {
            throw ex;
        }
        finally {
            try { ps.close(); }catch(Exception ign) {;}
        }
    }

    private List getListByPrimary(Connection conn, String sql) throws Exception
    {
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        try
        {
            ps = conn.prepareStatement(sql); 
            rs = ps.executeQuery(); 
            
            List results = new ArrayList();
            while (rs.next()) {
                results.add(rs.getString(1));
            }
            return results;
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { rs.close(); }catch(Exception ign) {;}
            try { ps.close(); }catch(Exception ign) {;}
        } 
    }
    
    private boolean exist(Connection conn, String sql) throws Exception
    {
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        try
        {
            ps = conn.prepareStatement(sql); 
            rs = ps.executeQuery(); 
            return rs.next();
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { rs.close(); }catch(Exception ign) {;}
            try { ps.close(); }catch(Exception ign) {;}
        } 
    }    
}
