package com.mlhuillier.util.migration2;

import com.mlhuillier.util.DBConfig;
import java.sql.Connection;
import java.util.List;
import java.util.Map;

public class Resend 
{
    public static void main(String[] args) throws Exception 
    {
        Resend r = new Resend("DB-212", "DB-204"); 
        for (int day=1; day<=9; day++)
        {
            String sday = day+"";
            if (day < 10) sday = "0"+day;
            
            //r.transfer("2010-05-" + sday);
        }
    }
    
    private DBConfig dbConfig;
    private String srcDS;
    private String destDS;
    
    public Resend(String srcDS, String destDS) 
    {
        this.srcDS = srcDS;
        this.destDS = destDS;
        this.dbConfig = new DBConfig();
    }
    
    public void transfer(String sdate) throws Exception    
    {
        Connection conn = null;
        Connection connDest = null;

        java.sql.Date.valueOf(sdate);
        
        try
        {
            if (srcDS.equals(destDS))
                throw new Exception("source-ds and target-ds must not be the same");
            
            conn = dbConfig.createConnection(srcDS);
            connDest = dbConfig.createConnection(destDS);
            
            DataService ds = new DataService(); 
            
            System.out.println("processing " + sdate + "...");
            List list = ds.getList(conn, " select objid from mlkp.tblresend where dttxndate between '"+sdate+" 00:00:00' and '"+sdate+" 23:59:59' ");
            while (!list.isEmpty())
            {
                Map listitem = (Map) list.remove(0); 
                String txnid = listitem.get("objid").toString();
                ds.transferData(conn, connDest, " select * from mlkp.tblresend where objid='"+txnid+"' ", "mlkp.tblresend", true);
            }
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { conn.close(); }catch(Exception ign) {;} 
            try { connDest.close(); }catch(Exception ign) {;} 
        }         
    }    
}
