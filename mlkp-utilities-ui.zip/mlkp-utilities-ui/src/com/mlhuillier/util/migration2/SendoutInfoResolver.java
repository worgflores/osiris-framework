package com.mlhuillier.util.migration2;

import com.mlhuillier.util.DBConfig;
import java.sql.Connection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class SendoutInfoResolver 
{
    public static void main(String[] args) throws Exception 
    {
        SendoutInfoResolver r = new SendoutInfoResolver("DB-212", "DB-204"); 
        for (int day=1; day<=31; day++)
        {
            String sday = day+"";
            if (day < 10) sday = "0"+day;
            
            String sdate = "2010-04-" + sday; 
            System.out.println("processing " + sdate + "..."); 
            r.update(sdate); 
        }
    }
    
    private DBConfig dbConfig;
    private String srcDS;
    private String destDS;
    
    public SendoutInfoResolver(String srcDS, String destDS) 
    {
        this.srcDS = srcDS;
        this.destDS = destDS;
        this.dbConfig = new DBConfig();
    }
    
    public void update(String sdate) throws Exception    
    {
        Connection conn = null;
        Connection connDest = null;

        java.sql.Date.valueOf(sdate);
        
        try
        {
            if (srcDS.equals(destDS))
                throw new Exception("source-ds and target-ds must not be the same");
            
            conn = dbConfig.createConnection(srcDS);
            connDest = dbConfig.createConnection(destDS);
            
            DataService ds = new DataService(); 
            List branches = ds.getList(conn, " select b.objid from mlkp.tblbranch b " + 
                                             "    inner join mlkp.tblorganization o on b.strorganizationid=o.objid " + 
                                             " where o.intcorporate=1 order by b.objid ");
            Iterator itr = branches.iterator();
            while (itr.hasNext())
            {
                String branchid = ((Map) itr.next()).get("objid").toString();
                System.out.println("   " + branchid + "...");
                
                List txnlist = ds.getList(conn, " select objid, (select strccrefno from mlkp.tblsendoutinfo where objid=bt.objid) as strccrefno " +  
                                                " from (select objid, strbranchid from mlkp.tblsendout where dtfiled between '"+ sdate +" 00:00:00' and '"+ sdate +" 23:59:59' having strbranchid='"+branchid+"')bt "); 
                while (!txnlist.isEmpty())
                {
                    Map txndata = (Map) txnlist.remove(0); 
                    String txnid = txndata.get("objid").toString();
                    Object ccrefno = txndata.get("strccrefno");
                    
                    if (!ds.exists(connDest, "select objid from mlkp.tblsendoutinfo where objid='"+txnid+"'"))
                    {
                        ds.transferData(conn, connDest, "select * from mlkp.tblsendoutinfo where objid='"+txnid+"'", "mlkp.tblsendoutinfo");
                    }
                    else if (ccrefno != null)
                    {
                        try
                        {
                            ds.exec(connDest, " update mlkp.tblsendoutinfo set strccrefno='"+ccrefno+"' where objid='"+txnid+"' "); 
                            ds.exec(connDest, " update mlkp.qryunclaim set strccrefno='"+ccrefno+"' where objid='"+txnid+"' "); 
                            ds.exec(connDest, " update mlkp.qrycustomerservice set strccrefno='"+ccrefno+"' where objid='"+txnid+"' "); 
                        }
                        catch(Exception e1) 
                        {
                            System.out.println("      [ERROR: "+ccrefno+", "+txnid+" ] " + e1.getMessage());
                            //throw e1;
                        }
                    }
                }
            }
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { conn.close(); }catch(Exception ign) {;} 
            try { connDest.close(); }catch(Exception ign) {;} 
        }         
    }    
}
