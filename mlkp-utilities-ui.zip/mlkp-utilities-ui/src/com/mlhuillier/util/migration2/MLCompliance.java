package com.mlhuillier.util.migration2;

import com.mlhuillier.util.DBConfig;
import java.sql.Connection;
import java.sql.PreparedStatement;

public class MLCompliance 
{
    public static void main1(String[] args) throws Exception 
    {
        MLCompliance b = new MLCompliance("DB-204", "DB-202");
        b.transfer();
    }
    
    private DBConfig dbConfig;
    private String srcDS;
    private String destDS;
    
    public MLCompliance(String srcDS, String destDS) 
    {
        this.srcDS = srcDS;
        this.destDS = destDS;
        this.dbConfig = new DBConfig();
    }
    
    public void transfer() throws Exception 
    {
        Connection conn = null;
        Connection connDest = null;

        try
        {
            if (srcDS.equals(destDS))
                throw new Exception("source-ds and target-ds must not be the same");
            
            conn = dbConfig.createConnection(srcDS);
            connDest = dbConfig.createConnection(destDS);
            
            DataService dataService = new DataService();
            String[] tables = new String[]
            {
                "blockedlist", "blockedlist1", "bsp", "bsp1", 
                "casenoseries", "hitlist1", "watchlist" 
            };
            
            for (int i=0; i<tables.length; i++)
            {
                String tablename = tables[i];
                System.out.println("[mlcompliance."+tablename+"]");
                dataService.insertOnDuplicateKey(conn, connDest, "select * from mlcompliance."+tablename, "mlcompliance."+tablename); 
            }
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { conn.close(); }catch(Exception ign) {;} 
            try { connDest.close(); }catch(Exception ign) {;} 
        }         
    }
    
    private int exec(Connection conn, String sql) throws Exception
    {
        PreparedStatement ps = null;
        try
        {
            ps = conn.prepareStatement(sql);
            return ps.executeUpdate();
        }
        catch(Exception ex) {
            throw ex;
        }
        finally {
            try { ps.close(); }catch(Exception ign) {;}
        }
    }

}
