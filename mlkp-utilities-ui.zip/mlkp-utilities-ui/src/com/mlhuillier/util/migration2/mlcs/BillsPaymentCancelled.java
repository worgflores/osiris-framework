package com.mlhuillier.util.migration2.mlcs;

import com.mlhuillier.util.DBConfig;
import com.mlhuillier.util.migration2.DataService;
import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class BillsPaymentCancelled 
{
    public static void main1(String[] args) throws Exception 
    {
        BillsPaymentCancelled b = new BillsPaymentCancelled("DB-204", "DB-212");
        b.transferDesc("2004-01-01", "2010-09-30");
    }
    
    private SimpleDateFormat YMD = new SimpleDateFormat("yyyy-MM-dd");
    private DBConfig dbConfig;
    private String srcDS;
    private String destDS;
    
    public BillsPaymentCancelled(String srcDS, String destDS) 
    {
        this.srcDS = srcDS;
        this.destDS = destDS;
        this.dbConfig = new DBConfig();
    }
    
    public void transfer(String startdate, String enddate) throws Exception 
    {
        Connection conn = null;
        Connection connDest = null;

        Date dtstart = java.sql.Date.valueOf(startdate);
        Date dtend = java.sql.Date.valueOf(enddate);
        
        try
        {
            if (srcDS.equals(destDS))
                throw new Exception("source-ds and target-ds must not be the same");
            
            conn = dbConfig.createConnection(srcDS);
            connDest = dbConfig.createConnection(destDS);
            
            DataService dataService = new DataService();
            Calendar cal = new GregorianCalendar(); 
            cal.setTime(dtstart);
            while (true)
            {
                Date dt = cal.getTime();
                if (dt.after(dtend)) break;
                
                String sdate = YMD.format(dt);
                String fromdate = sdate + " 00:00:00";
                String todate = sdate + " 23:59:59";
                
                System.out.println("processing billspaymentcancelled transfer... ["+sdate+", targetDS="+destDS+"]");
                transfer(conn, connDest, dataService, fromdate, todate);
                
                cal.add(Calendar.DATE, 1);
            }
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { conn.close(); }catch(Exception ign) {;} 
            try { connDest.close(); }catch(Exception ign) {;} 
        }         
    }   
    
    public void transferDesc(String startdate, String enddate) throws Exception 
    {
        Connection conn = null;
        Connection connDest = null;

        Date dtstart = java.sql.Date.valueOf(startdate);
        Date dtend = java.sql.Date.valueOf(enddate);
        
        try
        {
            if (srcDS.equals(destDS))
                throw new Exception("source-ds and target-ds must not be the same");
            
            conn = dbConfig.createConnection(srcDS);
            connDest = dbConfig.createConnection(destDS);
            
            DataService dataService = new DataService();
            Calendar cal = new GregorianCalendar(); 
            cal.setTime(dtend);
            while (true)
            {
                Date dt = cal.getTime();
                if (dt.before(dtstart)) break;
                
                String sdate = YMD.format(dt);
                String fromdate = sdate + " 00:00:00";
                String todate = sdate + " 23:59:59";
                
                System.out.println("processing billspaymentcancelled transfer... ["+sdate+"]");
                transfer(conn, connDest, dataService, fromdate, todate);
                
                cal.add(Calendar.DATE, -1);
            }
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { conn.close(); }catch(Exception ign) {;} 
            try { connDest.close(); }catch(Exception ign) {;} 
        }         
    }   
    
    private void transfer(Connection connSrc, Connection connDest, DataService dataService, String fromdate, String todate) throws Exception 
    {
        String sql = " select * from mlcs.tblcancelbillpayment where dtcancelled between '"+fromdate+"' and '"+todate+"'"; 
        dataService.transferData(connSrc, connDest, sql, "mlcs.tblcancelbillpayment", true); 
    }
    
}
