package com.mlhuillier.util.migration2.mlcs;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class MLCSTransfer 
{
    public static void main1(String[] args) throws Exception
    {
        String fromDS   = "DB-204";
        String toDS     = "DB-212";
        String fromdate = "2005-12-01";
        String todate   = "2010-09-30";
        
        Date dtstart = java.sql.Date.valueOf(fromdate);
        Date dtend = java.sql.Date.valueOf(todate);
        SimpleDateFormat YMD = new SimpleDateFormat("yyyy-MM-dd");
        Calendar cal = new GregorianCalendar(); 
        cal.setTime(dtstart);
        
        while (true)
        {
            Date dt = cal.getTime();
            if (dt.after(dtend)) break;

            String sdate = YMD.format(dt);

            try
            {
                new BillsPayment(fromDS, toDS).transfer(sdate, sdate);
                new BillsPaymentCancelled(fromDS, toDS).transfer(sdate, sdate);
                new BillsPaymentInvalidated(fromDS, toDS).transfer(sdate, sdate);
                new BillsPaymentPosting(fromDS, toDS).transfer(sdate, sdate);
                new BillsPaymentRequest(fromDS, toDS).transfer(sdate, sdate);

                cal.add(Calendar.DATE, 1);
            }
            catch(Exception ex) {
                System.out.println("[ERROR] " + ex.getMessage());
            }
        }        
        
    }
    
}
