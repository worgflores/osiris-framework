package com.mlhuillier.util.migration2.jollibee;

import com.mlhuillier.util.DBConfig;
import com.mlhuillier.util.migration2.DataService;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class JollibeeTransfer 
{
    public static void main1(String[] args) throws Exception 
    {
        JollibeeTransfer t = new JollibeeTransfer("DB-204", "DB-202");
        t.transfer(); 
    }
    
    private DBConfig dbConfig;
    private String srcDS;
    private String destDS;
    
    public JollibeeTransfer(String srcDS, String destDS) 
    {
        this.srcDS = srcDS;
        this.destDS = destDS;
        this.dbConfig = new DBConfig();
    }
    
    public void transfer() throws Exception 
    {
        Connection conn = null;
        Connection connDest = null;
        DataService dataService = new DataService(); 
        
        try
        {
            if (srcDS.equals(destDS))
                throw new Exception("source-ds and target-ds must not be the same");
            
            conn = dbConfig.createConnection(srcDS);
            connDest = dbConfig.createConnection(destDS);

            System.out.println("[key_gen]");
            dataService.insertOnDuplicateKey(conn, connDest, "select * from jollibeedb.key_gen", "jollibeedb.key_gen"); 
            System.out.println("[jollibeerule]");
            dataService.insertOnDuplicateKey(conn, connDest, "select * from jollibeedb.jollibeerule", "jollibeedb.jollibeerule"); 
            System.out.println("[jollibeeitem]");
            dataService.insertOnDuplicateKey(conn, connDest, "select * from jollibeedb.jollibeeitem", "jollibeedb.jollibeeitem"); 
            System.out.println("[jollibeeorder]");
            dataService.insertOnDuplicateKey(conn, connDest, "select * from jollibeedb.jollibeeorder", "jollibeedb.jollibeeorder"); 
            System.out.println("[jollibeeorderitem]");
            dataService.transferData(conn, connDest, "select * from jollibeedb.jollibeeorderitem", "jollibeedb.jollibeeorderitem", true); 
            System.out.println("[jollibeeopenorder]");
            dataService.transferData(conn, connDest, "select * from jollibeedb.jollibeeopenorder", "jollibeedb.jollibeeopenorder", true); 
            System.out.println("[jollibeecancelorder]");
            dataService.transferData(conn, connDest, "select * from jollibeedb.jollibeecancelorder", "jollibeedb.jollibeecancelorder", true); 
            System.out.println("[jollibeecloseorder]");
            dataService.transferData(conn, connDest, "select * from jollibeedb.jollibeecloseorder", "jollibeedb.jollibeecloseorder", true); 
            System.out.println("[jollibeelog]");
            dataService.transferData(conn, connDest, "select * from jollibeedb.jollibeelog", "jollibeedb.jollibeelog", true); 
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { conn.close(); }catch(Exception ign) {;} 
            try { connDest.close(); }catch(Exception ign) {;} 
        }         
    }
    
    public void transferModules() throws Exception 
    {
        Connection conn = null;
        Connection connDest = null;
        DataService dataService = new DataService(); 
        
        try
        {
            if (srcDS.equals(destDS))
                throw new Exception("source-ds and target-ds must not be the same");
            
            conn = dbConfig.createConnection(srcDS);
            connDest = dbConfig.createConnection(destDS);

            dataService.transferData(conn, connDest, "select * from mlkp_admin.sys_screen where scrname like '%jollibee%'", "mlkp_admin.sys_screen", true); 
            dataService.transferData(conn, connDest, "select * from mlkp_admin.sys_rule where rulename like '%jollibee%'", "mlkp_admin.sys_rule", true); 
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { conn.close(); }catch(Exception ign) {;} 
            try { connDest.close(); }catch(Exception ign) {;} 
        }         
    }    
    
    private int exec(Connection conn, String sql) throws Exception
    {
        PreparedStatement ps = null;
        try
        {
            ps = conn.prepareStatement(sql);
            return ps.executeUpdate();
        }
        catch(Exception ex) {
            throw ex;
        }
        finally {
            try { ps.close(); }catch(Exception ign) {;}
        }
    }

    private List getList(Connection conn, String sql) throws Exception
    {
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        try
        {
            ps = conn.prepareStatement(sql); 
            rs = ps.executeQuery(); 
            
            List results = new ArrayList();
            while (rs.next()) 
            {
                results.add(rs.getString("objid"));
            }
            return results;
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { rs.close(); }catch(Exception ign) {;}
            try { ps.close(); }catch(Exception ign) {;}
        } 
    }
    
    private boolean exists(Connection conn, String objid) throws Exception
    {
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        try
        {
            String sql = " select objid from mlkp.tblperson where objid='"+objid+"' "; 
            
            ps = conn.prepareStatement(sql); 
            rs = ps.executeQuery(); 
            boolean b = rs.next(); 
            return b;
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { rs.close(); }catch(Exception ign) {;}
            try { ps.close(); }catch(Exception ign) {;}
        } 
    }    
    
}
