package com.mlhuillier.util.migration2;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DataService 
{
    private boolean debug = false;
    
    public DataService() {}
    
    public DataService(boolean debug) {
        this.debug = debug;
    }   

    public Map getSingleResult(Connection conn, String sql) throws Exception
    {
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            
            ResultSetMetaData meta = rs.getMetaData();
            int colCount = meta.getColumnCount();
            
            Map data = new HashMap(); 
            if (rs.next())
            {
                for (int i=1; i<=colCount; i++) {
                    data.put(meta.getColumnName(i), rs.getObject(i));
                }
            }
            return data;
        }
        catch(Exception ex) {
            throw ex;
        }
        finally 
        {
            try { rs.close(); }catch(Exception ign) {;}
            try { ps.close(); }catch(Exception ign) {;}
        }        
    }

    public List getList(Connection conn, String sql) throws Exception
    {
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            
            ResultSetMetaData meta = rs.getMetaData();
            int colCount = meta.getColumnCount();
            
            List list = new ArrayList();
            while (rs.next())
            {
                Map data = new HashMap(); 
                for (int i=1; i<=colCount; i++) {
                    data.put(meta.getColumnName(i), rs.getObject(i));
                }
                list.add(data);
            }
            return list;
        }
        catch(Exception ex) {
            throw ex;
        }
        finally 
        {
            try { rs.close(); }catch(Exception ign) {;}
            try { ps.close(); }catch(Exception ign) {;}
        }        
    }
    
    
    public boolean exists(Connection conn, String sql) throws Exception
    {
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            return rs.next(); 
        }
        catch(Exception ex) {
            throw ex;
        }
        finally 
        {
            try { rs.close(); }catch(Exception ign) {;}
            try { ps.close(); }catch(Exception ign) {;}
        }        
    }
    
    public int exec(Connection conn, String sql) throws Exception
    {
        PreparedStatement ps = null;
        try
        {
            ps = conn.prepareStatement(sql);
            return ps.executeUpdate();
        }
        catch(Exception ex) {
            throw ex;
        }
        finally {
            try { ps.close(); }catch(Exception ign) {;}
        }
    } 
    
    public void transferData(Connection connSrc, Connection connDest, String sql, String targetTable) throws Exception { 
        transferData(connSrc, connDest, sql, targetTable, false); 
    } 
    
    public void transferData(Connection connSrc, Connection connDest, String sql, String targetTable, boolean ignore) throws Exception
    {
        PreparedStatement ps = null;
        ResultSet rs = null;

        int startRow = 0;
        int limit = 10000;
        while (true)
        {
            int batchSize = limit + 1;
            int counter = 0;
            
            try
            {
                ps = connSrc.prepareStatement(sql + " LIMIT " + startRow + "," + batchSize);
                rs = ps.executeQuery();
                while (rs.next()) 
                {
                    copyData(connDest, rs, targetTable, ignore);
                    counter +=1 ;
                }
            }
            catch(Exception ex) {
                throw ex;
            }
            finally 
            {
                try { rs.close(); }catch(Exception ign) {;}
                try { ps.close(); }catch(Exception ign) {;}
            }
            
            if (counter <= limit) break;
            
            startRow += limit;
        }
    }

    private void copyData(Connection conn, ResultSet rs, String targetTable, boolean ignore) throws Exception
    {
        ResultSetMetaData meta = rs.getMetaData();
        int columnCount = meta.getColumnCount();
        
        StringBuffer sql = new StringBuffer();
        sql.append(" INSERT ");
        if (ignore) sql.append(" IGNORE ");
        
        sql.append(" INTO " + targetTable +"\n\t (");
        for (int i=1; i<=columnCount; i++)
        {
            if (i > 1) sql.append(",");
            
            sql.append(meta.getColumnName(i));
        }
        sql.append(" ) \n");
        sql.append(" VALUES \n\t (");
        for (int i=0; i<columnCount; i++)
        {
            if (i > 0) sql.append(",");
            
            sql.append("?");
        }        
        sql.append(")");

        PreparedStatement ps = null;
        try
        {
            ps = conn.prepareStatement(sql.toString());
                        
            for (int i=1; i<=columnCount; i++) {
                ps.setObject(i, rs.getObject(i));
            }
            
            ps.execute();
        }
        catch(Exception ex) 
        {
            if (debug) System.out.println("   " + targetTable + ": " + rs.getObject(1));
            
            throw ex;
        }
        finally {
            try { ps.close(); }catch(Exception ign) {;}
        } 
    }
    
    public void replaceData(Connection connSrc, Connection connDest, String sql, String targetTable) throws Exception
    {
        PreparedStatement ps = null;
        ResultSet rs = null;

        int startRow = 0;
        int limit = 100000;
        while (true)
        {
            int batchSize = limit + 1;
            int counter = 0;
            
            try
            {
                ps = connSrc.prepareStatement(sql + " LIMIT " + startRow + "," + batchSize);
                rs = ps.executeQuery();
                while (rs.next()) 
                {
                    replaceDataImpl(connDest, rs, targetTable);
                    counter +=1 ;
                }
            }
            catch(Exception ex) {
                throw ex;
            }
            finally 
            {
                try { rs.close(); }catch(Exception ign) {;}
                try { ps.close(); }catch(Exception ign) {;}
            }
            
            if (counter <= limit) break;
            
            startRow += limit;
        }
    }
    
    private void replaceDataImpl(Connection conn, ResultSet rs, String targetTable) throws Exception
    {
        ResultSetMetaData meta = rs.getMetaData();
        int columnCount = meta.getColumnCount();
        
        StringBuffer sql = new StringBuffer();
        sql.append(" REPLACE INTO " + targetTable +"\n\t (");
        for (int i=1; i<=columnCount; i++) 
        {
            if (i > 1) sql.append(",");
            
            sql.append(meta.getColumnName(i));
        }
        sql.append(" ) \n");
        sql.append(" VALUES \n\t (");
        for (int i=0; i<columnCount; i++)
        {
            if (i > 0) sql.append(",");
            
            sql.append("?");
        }        
        sql.append(")");

        PreparedStatement ps = null;
        try
        {
            ps = conn.prepareStatement(sql.toString());
                        
            for (int i=1; i<=columnCount; i++) {
                ps.setObject(i, rs.getObject(i));
            }
            
            ps.execute();
        }
        catch(Exception ex) 
        {
            if (debug) System.out.println("   " + targetTable + ": " + rs.getObject(1));
            
            throw ex;
        }
        finally {
            try { ps.close(); }catch(Exception ign) {;}
        } 
    }   
    
    public void insertOnDuplicateKey(Connection connSrc, Connection connDest, String sql, String targetTable) throws Exception
    {
        PreparedStatement ps = null;
        ResultSet rs = null;

        int startRow = 0;
        int limit = 100000;
        while (true)
        {
            int batchSize = limit + 1;
            int counter = 0;
            
            try
            {
                ps = connSrc.prepareStatement(sql + " LIMIT " + startRow + "," + batchSize);
                rs = ps.executeQuery();
                while (rs.next()) 
                {
                    insertOnDuplicateKeyImpl(connDest, rs, targetTable);
                    counter +=1 ;
                }
            }
            catch(Exception ex) {
                throw ex;
            }
            finally 
            {
                try { rs.close(); }catch(Exception ign) {;}
                try { ps.close(); }catch(Exception ign) {;}
            }
            
            if (counter <= limit) break;
            
            startRow += limit;
        }
    }
    
    private void insertOnDuplicateKeyImpl(Connection conn, ResultSet rs, String targetTable) throws Exception
    {
        ResultSetMetaData meta = rs.getMetaData();
        int columnCount = meta.getColumnCount();
        
        StringBuffer sql = new StringBuffer();
        sql.append(" INSERT INTO " + targetTable +"\n\t (");
        for (int i=1; i<=columnCount; i++) 
        {
            if (i > 1) sql.append(",");
            
            sql.append(meta.getColumnName(i));
        }
        sql.append(" ) \n");
        sql.append(" VALUES \n\t (");
        for (int i=0; i<columnCount; i++)
        {
            if (i > 0) sql.append(",");
            
            sql.append("?");
        }        
        sql.append(") \n");
        sql.append(" ON DUPLICATE KEY UPDATE \n"); 
        
        boolean hasUpdateValues = false;
        for (int i=1; i<=columnCount; i++) 
        {
            String cname = meta.getColumnName(i);
            if (!cname.equals("objid"))
            {
                if (hasUpdateValues) sql.append(", ");
                
                sql.append(cname + "=VALUES("+cname+")"); 
                hasUpdateValues = true;
            }
        } 

        PreparedStatement ps = null;
        try
        {
            ps = conn.prepareStatement(sql.toString());
            
            for (int i=1; i<=columnCount; i++) 
            {
                Object rsv = null;
                try {
                    rsv = rs.getObject(i); 
                } 
                catch(SQLException sqle) 
                {
                    String sqlemsg = sqle.getMessage()+"";
                    if (sqlemsg.indexOf("'0000-00-00' can not be represented ") < 0) 
                        throw sqle;
                }
                catch(Exception e1) {
                    throw e1;
                }
                
                ps.setObject(i, rsv);
            }
            
            ps.execute();
        }
        catch(Exception ex) 
        { 
            if (debug) System.out.println("   " + targetTable + ": " + rs.getObject(1));
            
            throw ex; 
        } 
        finally {
            try { ps.close(); }catch(Exception ign) {;}
        } 
    }   
    
}
