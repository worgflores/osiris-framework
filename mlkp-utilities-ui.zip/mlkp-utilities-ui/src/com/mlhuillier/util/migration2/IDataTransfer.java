package com.mlhuillier.util.migration2;

public interface IDataTransfer 
{
    void transfer(String date) throws Exception;
}
