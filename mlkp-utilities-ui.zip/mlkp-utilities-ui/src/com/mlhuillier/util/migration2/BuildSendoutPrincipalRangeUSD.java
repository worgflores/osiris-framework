package com.mlhuillier.util.migration2;

import com.mlhuillier.util.DBConfig;
import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class BuildSendoutPrincipalRangeUSD 
{
    public static void main(String[] args) throws Exception 
    {
        new BuildSendoutPrincipalRangeUSD("DB-204", "DEV-1263").transfer("2010-01-01", "2010-12-31");
    } 
    
    private DBConfig dbConfig;
    private String srcDS;
    private String destDS;
    private boolean retryOnError; 
    
    public BuildSendoutPrincipalRangeUSD(String srcDS, String destDS) {
        this(srcDS, destDS, false);
    }
    
    public BuildSendoutPrincipalRangeUSD(String srcDS, String destDS, boolean retryOnError) 
    {
        this.srcDS = srcDS;
        this.destDS = destDS;
        this.retryOnError = retryOnError;
        this.dbConfig = new DBConfig();
    }    
    
    public void transfer(String startdate, String enddate) throws Exception    
    {
        Connection conn = null;
        Connection connDest = null;

        Date dtfrom = java.sql.Date.valueOf(startdate);
        Date dtto   = java.sql.Date.valueOf(enddate);
        
        try
        {
            System.out.println(getClass().getSimpleName() + ".transfer started...");
            conn = dbConfig.createConnection(srcDS);
            connDest = dbConfig.createConnection(destDS);
            
            SimpleDateFormat YMD = new SimpleDateFormat("yyyy-MM-dd");
            Calendar cal = new GregorianCalendar(); 
            cal.setTime(dtfrom);
            while (true)
            {
                Date dt = cal.getTime();
                if (dt.after(dtto)) break;
                
                String sdate = YMD.format(dt); 
                for (int h=0; h < 24; h++)
                {
                    String shour = h+"";
                    if (h < 10) shour = "0"+h;

                    String fromdate = sdate + " " + shour + ":00:00";
                    String todate   = sdate + " " + shour + ":59:59"; 

                    System.out.println("   processing " + sdate + " " + shour + "...");
                    buildImpl(conn, connDest, fromdate, todate); 
                } 
                cal.add(Calendar.DATE, 1); 
            }
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { conn.close(); }catch(Exception ign) {;} 
            try { connDest.close(); }catch(Exception ign) {;} 
            
            System.out.println(getClass().getSimpleName() + ".transfer ended.");
        }         
    }
    
    private void buildImpl(Connection conn, Connection connDest, String fromdate, String todate) throws Exception
    {
        StringBuffer sb = new StringBuffer(); 
        sb.append(" select "); 
        sb.append(" 	objid, date_format(dtfiled, '%Y-%m-%d') as dtfiled, strbranchid as branchid,  "); 
        sb.append(" 	ifnull((select strcurrencyid from mlkp.tblsendoutinfo where objid=s.objid),'PHP') as currency,  "); 
        sb.append(" 	ifnull((select strchargecurrencyid from mlkp.tblsendoutinfo where objid=s.objid),'PHP') as chargecurrency,  "); 
        sb.append(" 	curprincipal as principal, curcharge as charge, state  "); 
        sb.append(" from mlkp.tblsendout s  ");  
        sb.append(" where dtfiled between '"+fromdate+"' and '"+todate+"' ");
        sb.append(" having currency='USD' and chargecurrency='USD' ");         
        
        //if (true) throw new Exception(sb.toString()); 

        DataService ds = new DataService(); 
        ds.transferData(conn, connDest, sb.toString(), "test.sendoutprincipalrange", true);
    }

}
