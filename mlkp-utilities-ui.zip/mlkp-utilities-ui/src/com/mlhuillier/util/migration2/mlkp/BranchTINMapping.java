package com.mlhuillier.util.migration2.mlkp;

import com.mlhuillier.util.DBConfig;
import com.mlhuillier.util.migration2.DataService;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class BranchTINMapping 
{
    public static void xmain(String[] args) throws Exception 
    {
        new BranchTINMapping("DB-204", "DB-206").sync();
    }
    
    private DBConfig dbConfig;
    private String srcDS;
    private String destDS;
    
    public BranchTINMapping(String srcDS, String destDS) 
    {
        this.srcDS = srcDS;
        this.destDS = destDS;
        this.dbConfig = new DBConfig();
    }
    
    public void sync() throws Exception 
    {
        Connection conn = null;
        Connection connDest = null;

        try
        {
            if (srcDS.equals(destDS))
                throw new Exception("source-ds and target-ds must not be the same");
            
            conn = dbConfig.createConnection(srcDS);
            connDest = dbConfig.createConnection(destDS);
            
            DataService dataService = new DataService();
            long counter = 1;
            List list = dataService.getList(conn, " select " + 
                                                  "    objid, " + 
                                                  "    (select strtinno from mlkp.tblbranchtinmapping where strbranchid=b.objid) as tin " + 
                                                  " from mlkp.tblbranch b ");
            while (!list.isEmpty())
            {
                Map data = (Map) list.remove(0);
                String objid = data.get("objid").toString();
                Object tin = data.get("tin");
                if (tin == null) tin = "";
                
                String errmsg = "OK";
                
                try 
                {
                    dataService.exec(connDest, "update mlkp.tblbranchtinmapping set strtinno='"+tin+"' where strbranchid='"+objid+"'"); 
                    dataService.exec(connDest, "insert ignore into mlkp.tblbranchtinmapping (strbranchid,strtinno) values ('"+objid+"','"+tin+"')"); 
                } 
                catch(Exception x) {
                    errmsg = "[ERROR] " + x.getMessage();
                }

                System.out.println(counter + ") processed " + objid + "... " + errmsg);
                counter +=1;
            }
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { conn.close(); }catch(Exception ign) {;} 
            try { connDest.close(); }catch(Exception ign) {;} 
        }         
    }
}
