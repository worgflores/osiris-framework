package com.mlhuillier.util.migration2.mlkp;

import com.mlhuillier.util.DBConfig;
import com.mlhuillier.util.migration2.DataService;
import java.sql.Connection;
import java.util.Iterator;
import java.util.Map;

public class QryCustomerService 
{
    public static void main(String[] args) throws Exception 
    {
        QryCustomerService r = new QryCustomerService("DB-204"); 
        for (int day=1; day<=31; day++)
        {
            String sday = day+"";
            if (day < 10) sday = "0"+day;
            
            String sdate = "2010-03-" + sday; 
            System.out.println("processing " + sdate + "..."); 
            r.buildPayout(sdate); 
        }
    }
    
    private DBConfig dbConfig;
    private String srcDS;
    private String destDS;
    
    public QryCustomerService(String srcDS) 
    {
        this.srcDS = srcDS;
        this.dbConfig = new DBConfig();
    }
    
    public void buildPayout(String sdate) throws Exception    
    {
        Connection conn = null;

        java.sql.Date.valueOf(sdate);
        
        try
        {
            conn = dbConfig.createConnection(srcDS);
            
            DataService ds = new DataService(); 
            Iterator itr = ds.getList(conn, " select objid from mlkp.tblbranch order by objid ").iterator();
            while (itr.hasNext()) 
            {
                String branchid = ((Map) itr.next()).get("objid").toString();
                System.out.println("   " + branchid + "...");
                
                StringBuffer sql = new StringBuffer(); 
                sql.append(" select ");
                sql.append("    s.objid, 1 as state, s.strkptn, s.strcontrolno, s.dtfiled, ");
                sql.append("    s.strsenderfname, s.strsenderlname, s.strsendermname, ");
                sql.append("    s.strreceiverfname, s.strreceiverlname, s.strreceivermname, ");
                sql.append("    s.curprincipal, s.strbranchid as strbranch, s.struserid as stroperator,  ");
                sql.append("    p.strbranchid as strreceiverbranch, p.struserid as strreceiveroperator, p.strcontrolno as strpayoutcontrol,  ");
                sql.append("    sif.strccrefno, sif.strcurrencyid, pif.strcurrencyid as strpaycurrencyid,  ");
                sql.append("    sif.strrelationtoreceiver, pif.curamtpaid, p.dtclaimed as dttxndate  ");
                sql.append(" from ( ");
                sql.append("        select objid, strbranchid from mlkp.tblpayout  ");
                sql.append("        where dtclaimed between '"+sdate+" 00:00:00' and '"+sdate+" 23:59:59'  ");
                sql.append("        having strbranchid='"+branchid+"' ");
                sql.append("      )bt  ");
                sql.append("    inner join mlkp.tblpayout p on bt.objid=p.objid  ");
                sql.append("    inner join mlkp.tblsendout s on p.strsendoutid=s.objid  ");
                sql.append("    left join mlkp.tblsendoutinfo sif on s.objid=sif.objid  ");
                sql.append("    left join mlkp.tblpayoutinfo pif on p.objid=pif.objid  ");           
                
                ds.transferData(conn, conn, sql.toString(), "mlkp.qrycustomerservice", true);
            }
        }
        catch(Exception ex) { 
            throw ex; 
        } 
        finally
        {
            try { conn.close(); }catch(Exception ign) {;} 
        }         
    }    
}
