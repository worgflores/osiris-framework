package com.mlhuillier.util.migration2.mlkp;

import com.mlhuillier.util.DBConfig;
import com.mlhuillier.util.migration2.DataService;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class ControlSeriesChecker 
{
    public static void main(String[] args) throws Exception 
    {
        ControlSeriesChecker b = new ControlSeriesChecker(new String[] {
            "DB-204", "DB-212", "DB-206" 
        }); 
        //b.start("sendout"); 
        b.correct("DB-204", "sendout"); 
    }

    DataService ds = new DataService(); 
    private String[] datasources;
    private DBConfig dbConfig;
    private String srcDS;
    private String destDS;
    
    public ControlSeriesChecker(String[] datasources) 
    {
        this.dbConfig = new DBConfig();
        this.datasources = (datasources != null) ? datasources : new String[]{}; 
    }
    
    public void start(String formname) throws Exception 
    {
        List connections = new ArrayList(); 

        try
        {
            for (int i=0; i<datasources.length; i++) {
                connections.add(dbConfig.createConnection(datasources[i])); 
            } 
            
            Connection mainConn = (Connection) connections.get(0); 
            List branches = ds.getList(mainConn, "select objid from mlkp.tblbranch where objid like 'a%' order by objid");

            System.out.println("");
            System.out.print(getRightPadded("BRANCHID", 15));
            System.out.print(getRightPadded("PREFIX", 20));
            System.out.print(getRightPadded("SERIESNO", 20));
            for (int i=0; i<datasources.length; i++) 
                System.out.print(getRightPadded(datasources[i], 20));
                
            System.out.print(getRightPadded("PREFERRED-SERIES", 20));
            System.out.print("\n");
            while (!branches.isEmpty())
            {
                String branchid = ((Map) branches.remove(0)).get("objid").toString(); 

                List branchseries = ds.getList(mainConn, " select strprefix, intnextseries from mlkp.tblcontrol " + 
                                                         " where strbranchid='"+branchid+"' and strformname='"+formname+"' order by strprefix "); 
                while (!branchseries.isEmpty())
                {
                    Map branchseriesitem = (Map) branchseries.remove(0); 
                    String prefix = branchseriesitem.get("strprefix")+"";
                    String nextseries = branchseriesitem.get("intnextseries")+"";
                    
                    StringBuffer buff = new StringBuffer(); 
                    buff.append(getRightPadded(branchid, 15));
                    buff.append(getRightPadded(prefix, 20));
                    buff.append(getRightPadded(nextseries, 20));
                    
                    boolean matched = true;
                    long preferredseriesno = Long.parseLong(nextseries);
                    
                    Iterator conns = connections.iterator(); 
                    while (conns.hasNext())
                    {
                        Connection conn = (Connection) conns.next(); 
                        String seriesno = getLatestSeriesNo(conn, formname, prefix);
                        
                        long lseriesno = 0;
                        try { lseriesno = Long.parseLong(seriesno)+1; }catch(Exception ign){;} 
                        
                        seriesno = lseriesno+"";
                        if (nextseries.equals(seriesno))
                            buff.append(getRightPadded(seriesno, 20));
                        else
                        {
                            buff.append(getRightPadded(seriesno+"*", 20));
                            matched = false;
                        }
                        
                        try {
                            preferredseriesno = Math.max(preferredseriesno, lseriesno);
                        } catch(Exception ign) {;} 
                    }
                    
                    if (!matched) 
                    {
                        buff.append(getRightPadded((preferredseriesno)+"", 20));
                        System.out.println(buff);
                    }
                }
            }
        } 
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            while (!connections.isEmpty())
            {
                Connection conn = (Connection) connections.remove(0); 
                try { conn.close(); }catch(Exception ign) {;}     
            }
        }         
    }
    
    public void correct(String datasource, String formname) throws Exception 
    {
        Connection conn = null;

        try
        {
            conn = dbConfig.createConnection(datasource);
            
            List branches = ds.getList(conn, "select objid from mlkp.tblbranch where objid like 'a%' order by objid");
            while (!branches.isEmpty())
            {
                String branchid = ((Map) branches.remove(0)).get("objid").toString(); 

                List branchseries = ds.getList(conn, " select strprefix, intnextseries from mlkp.tblcontrol " + 
                                                     " where strbranchid='"+branchid+"' and strformname='"+formname+"' order by strprefix "); 
                while (!branchseries.isEmpty())
                {
                    Map branchseriesitem = (Map) branchseries.remove(0);  
                    String prefix = branchseriesitem.get("strprefix").toString(); 
                    long nextseries = Long.parseLong(branchseriesitem.get("intnextseries").toString()); 
                    
                    String seriesno = getLatestSeriesNo(conn, formname, prefix);
                        
                    long lseriesno = 0;
                    try { lseriesno = Long.parseLong(seriesno)+1; }catch(Exception ign){;} 

                    if (lseriesno == 0) continue; 
                    if (nextseries == lseriesno) continue;
                    if (nextseries >= lseriesno) continue;
                    
                    System.out.println(getRightPadded(branchid, 15) + " " + getRightPadded(prefix, 30) + " " + getRightPadded(nextseries+"", 20) + " " + getRightPadded(lseriesno+"", 20));
                } 
            } 
        } 
        catch(Exception ex) {
            throw ex;
        }
        finally {
            try { conn.close(); }catch(Exception ign) {;}     
        }         
    }    
    
    private String getLatestSeriesNo(Connection conn, String formname, String prefix) throws Exception 
    {
        Map data = null;
        if ("sendout".equals(formname))
        {
            data = ds.getSingleResult(conn, " select cast(substring_index(strcontrolno,'-',-1) as unsigned) as seriesno from mlkp.tblsendout " + 
                                            " where strcontrolno like '"+prefix+"%' order by strcontrolno desc limit 1");
        }
        else if ("payout".equals(formname))
        {
            data = ds.getSingleResult(conn, " select cast(substring_index(strcontrolno,'-',-1) as unsigned) as seriesno from mlkp.tblpayout " + 
                                            " where strcontrolno like '"+prefix+"%' order by strcontrolno desc limit 1");
        }
        else if ("bill".equals(formname))
        {
            data = ds.getSingleResult(conn, " select cast(substring_index(strcontrolno,'-',-1) as unsigned) as seriesno from mlcs.tblbillpayment " + 
                                            " where strcontrolno like '"+prefix+"%' order by strcontrolno desc limit 1");
        }
        
        if (data != null && !data.isEmpty()) 
            return data.get("seriesno").toString(); 
        
        return null;
    }
    
    private String getRightPadded(String value, int length)
    {
        String sval = value+"";
        int ilen = length - sval.length();
        
        StringBuffer sb = new StringBuffer(sval);
        for (int i=0; i<ilen; i++) sb.append(" ");
        
        return sb.toString(); 
    }             
}
