package com.mlhuillier.util.migration2.mlkp;

import com.mlhuillier.util.DBConfig;
import com.mlhuillier.util.migration2.DataService;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Date;
import java.util.List;
import java.util.Map;

public class ForexRateHistory 
{
    public static void main1(String[] args) throws Exception 
    {
        ForexRateHistory b = new ForexRateHistory("DB-212");
        b.updateGlobalRate("2008-05-01", "2010-04-30"); 
    }
    
    private DBConfig dbConfig;
    private String srcDS;
    
    public ForexRateHistory(String srcDS) 
    {
        this.srcDS = srcDS;
        this.dbConfig = new DBConfig();
    }
    
    public void updateGlobalRate(String startdate, String enddate) throws Exception 
    {
        Connection conn = null;

        Date dtfrom = java.sql.Date.valueOf(startdate);
        Date dtto = java.sql.Date.valueOf(enddate);
        
        try
        {
            
            conn = dbConfig.createConnection(srcDS); 
            
            DataService dataService = new DataService(); 
            
            //update the forexrate table 
            /*
            String sql0 = " select h.*, " + 
                          "    ifnull(( " + 
                          "             select rate from mlkp.tblglobalratehistory " + 
                          "             where lastupdated <= h.lastupdated and currency=h.currency " + 
                          "             order by lastupdated desc limit 1 " + 
                          "          ),0.0) as calculatedrate " + 
                          " from mlkp.tblforexrate h " + 
                          " where lastupdated is not null "; 
            
            List list0 = dataService.getList(conn, sql0);
            while (!list0.isEmpty())
            {
                Map data = (Map) list0.remove(0);
                String objid = data.get("objid").toString();
                String rate  = data.get("calculatedrate").toString();
                dataService.exec(conn, " update mlkp.tblforexrate set globalrate="+rate+" where objid='"+objid+"' ");
            }
            */
            
            //update the forexratehistory table 
            /*
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            Calendar cal = new GregorianCalendar(); 
            cal.setTime(dtfrom);
            
            while (true)
            {
                Date dt = cal.getTime();
                if (dt.after(dtto)) break;
                
                String sdate = sdf.format(dt);
                String sql = " select h.*, " + 
                             "    ifnull(( " + 
                             "             select rate from mlkp.tblglobalratehistory " + 
                             "             where lastupdated <= h.txndate and currency=h.currency " + 
                             "             order by lastupdated desc limit 1 " + 
                             "          ),0.0) as calculatedrate " + 
                             " from mlkp.tblforexratehistory h " + 
                             " where txndate between '"+sdate+" 00:00:00' and '"+sdate+" 23:59:59' "; 
                
                System.out.println("  processing " + sdate + "...");
                
                List list = dataService.getList(conn, sql);
                while (!list.isEmpty())
                {
                    Map data = (Map) list.remove(0);
                    String objid = data.get("objid").toString();
                    String rate  = data.get("calculatedrate").toString();
                    dataService.exec(conn, " update mlkp.tblforexratehistory set globalrate="+rate+" where objid='"+objid+"' ");
                }
                
                cal.add(Calendar.DATE, 1);
            }
             */
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { conn.close(); }catch(Exception ign) {;} 
        }         
    }
    
    private int exec(Connection conn, String sql) throws Exception
    {
        PreparedStatement ps = null;
        try
        {
            ps = conn.prepareStatement(sql);
            return ps.executeUpdate();
        }
        catch(Exception ex) {
            throw ex;
        }
        finally {
            try { ps.close(); }catch(Exception ign) {;}
        }
    }
}
