package com.mlhuillier.util.migration2.mlkp;

import com.mlhuillier.util.DBConfig;
import com.mlhuillier.util.migration2.DataService;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class Branch 
{
    public static void main1(String[] args) throws Exception 
    {
        Branch b = new Branch("DB-204", "DB-212");
        b.sync();
    }
    
    private DBConfig dbConfig;
    private String srcDS;
    private String destDS;
    
    public Branch(String srcDS, String destDS) 
    {
        this.srcDS = srcDS;
        this.destDS = destDS;
        this.dbConfig = new DBConfig();
    }
    
    public void sync() throws Exception 
    {
        Connection conn = null;
        Connection connDest = null;

        try
        {
            if (srcDS.equals(destDS))
                throw new Exception("source-ds and target-ds must not be the same");
            
            conn = dbConfig.createConnection(srcDS);
            connDest = dbConfig.createConnection(destDS);
            
            DataService dataService = new DataService();
            dataService.insertOnDuplicateKey(conn, connDest, "select * from mlkp.tblloop", "mlkp.tblloop"); 
            dataService.insertOnDuplicateKey(conn, connDest, "select * from mlkp.tblregion", "mlkp.tblregion"); 
            dataService.insertOnDuplicateKey(conn, connDest, "select * from mlkp.tblarea", "mlkp.tblarea"); 
            
            long counter = 1;
            List list = getListByPrimary(conn, "select objid from mlkp.tblbranch ");
            while (!list.isEmpty())
            {
                String objid = list.remove(0).toString();
                String errmsg = "OK";
                
                try 
                {
                    dataService.insertOnDuplicateKey(conn, connDest, "select * from mlkp.tblbranch where objid='"+objid+"' ", "mlkp.tblbranch"); 
                    dataService.transferData(conn, connDest, "select * from mlkp.tblbranchoption where objid='"+objid+"'", "mlkp.tblbranchoption", true); 
                    dataService.transferData(conn, connDest, "select * from mlkp.tblbranchterminal where strbranchid='"+objid+"'", "mlkp.tblbranchterminal", true); 
                    dataService.transferData(conn, connDest, "select * from mlkp.tblbranchtinmapping where strbranchid='"+objid+"'", "mlkp.tblbranchtinmapping", true); 
                    dataService.transferData(conn, connDest, "select * from mlkp.tblbranchuser where strbranchid='"+objid+"'", "mlkp.tblbranchuser", true); 
                    dataService.transferData(conn, connDest, "select * from mlkp.tbluserterminal where strbranchid='"+objid+"'", "mlkp.tbluserterminal", true); 
                } 
                catch(Exception x) {
                    errmsg = "[ERROR] " + x.getMessage();
                }

                System.out.println(counter + ") processed " + objid + "... " + errmsg);
                counter +=1;
            }
            
            dataService.transferData(conn, connDest, "select * from mlkp.tbltransferterminal", "mlkp.tbltransferterminal", true); 
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { conn.close(); }catch(Exception ign) {;} 
            try { connDest.close(); }catch(Exception ign) {;} 
        }         
    }
    
    private int exec(Connection conn, String sql) throws Exception
    {
        PreparedStatement ps = null;
        try
        {
            ps = conn.prepareStatement(sql);
            return ps.executeUpdate();
        }
        catch(Exception ex) {
            throw ex;
        }
        finally {
            try { ps.close(); }catch(Exception ign) {;}
        }
    }

    private List getListByPrimary(Connection conn, String sql) throws Exception
    {
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        try
        {
            ps = conn.prepareStatement(sql); 
            rs = ps.executeQuery(); 
            
            List results = new ArrayList();
            while (rs.next()) {
                results.add(rs.getString(1));
            }
            return results;
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { rs.close(); }catch(Exception ign) {;}
            try { ps.close(); }catch(Exception ign) {;}
        } 
    }
    
    private boolean exist(Connection conn, String sql) throws Exception
    {
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        try
        {
            ps = conn.prepareStatement(sql); 
            rs = ps.executeQuery(); 
            return rs.next();
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { rs.close(); }catch(Exception ign) {;}
            try { ps.close(); }catch(Exception ign) {;}
        } 
    }    
}
