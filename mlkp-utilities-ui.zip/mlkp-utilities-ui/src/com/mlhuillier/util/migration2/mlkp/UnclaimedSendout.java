package com.mlhuillier.util.migration2.mlkp;

import com.mlhuillier.util.DBConfig;
import com.mlhuillier.util.migration2.DataService;
import com.mlhuillier.util.migration2.PersonService;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class UnclaimedSendout 
{
    public static void main1(String[] args) throws Exception 
    {
        UnclaimedSendout ts = new UnclaimedSendout("DB-206", "DB-204");
        //ts.transfer("2009-01-01", "2009-12-31");
    }
    
    private DBConfig dbConfig;
    private String srcDS;
    private String destDS;
    
    public UnclaimedSendout(String srcDS, String destDS) 
    {
        this.srcDS = srcDS;
        this.destDS = destDS;
        this.dbConfig = new DBConfig();
    }
    
    public void transfer(String sdate) throws Exception {
        transfer(sdate, sdate);
    }
    
    public void transfer(String startdate, String enddate) throws Exception    
    {
        Connection conn = null;
        Connection connDest = null;

        Date dtfrom = java.sql.Date.valueOf(startdate);
        Date dtto = java.sql.Date.valueOf(enddate);
        
        try
        {
            if (srcDS.equals(destDS))
                throw new Exception("source-ds and target-ds must not be the same");
            
            conn = dbConfig.createConnection(srcDS);
            connDest = dbConfig.createConnection(destDS);
            
            DataService ds = new DataService();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd"); 
            Calendar cal = new GregorianCalendar();
            cal.setTime(dtfrom);
            while (true)
            {
                Date dt = cal.getTime();
                if (dt.after(dtto)) break;
                
                String sdate = sdf.format(dt);
                for (int h=0; h < 24; h++)
                {
                    String shour = h+"";
                    if (h < 10) shour = "0"+h;

                    String fromdate = sdate + " " + shour + ":00:00";
                    String todate   = sdate + " " + shour + ":59:59";   
                    
                    System.out.println("fetching sendout ids... [" + sdate + " " + shour + ", targetDS="+destDS+"]"); 
                    List list = ds.getList(conn, "select objid, state from mlkp.tblsendout where dtfiled between '"+fromdate+"' and '"+todate+"' having state in (0,3) ");
                    while (!list.isEmpty())
                    {
                        String objid = ((Map) list.remove(0)).get("objid").toString(); 
                        
                        try 
                        {
                            boolean hasChildren = ds.exists(connDest, "select objid from mlkp.tblsendoutinfo where objid='"+objid+"'");
                            if (exists(connDest, objid)) 
                            {
                                if (!hasChildren) 
                                {
                                    try { exec(connDest, "update mlkp.tblsendoutinfo set dtsenderbirthdate=null where objid='"+objid+"' and dtsenderbirthdate='0000-00-00'"); }catch(Exception ign){;} 
                                    try { exec(connDest, "update mlkp.tblsendoutinfo set dtreceiverbirthdate=null where objid='"+objid+"' and dtreceiverbirthdate='0000-00-00'"); }catch(Exception ign){;} 
                                    
                                    ds.transferData(conn, connDest,  "select * from mlkp.tblsendoutinfo where objid='"+ objid +"'", "mlkp.tblsendoutinfo", true);
                                    ds.transferData(conn, connDest,  "select * from mlkp.tblsendoutoption where objid='"+ objid +"'", "mlkp.tblsendoutoption", true);
                                    ds.transferData(conn, connDest,  "select * from mlkp.tblsendoutor where objid='"+ objid +"'", "mlkp.tblsendoutor", true);
                                    ds.transferData(conn, connDest,  "select * from mlkp.tblsendoutwalkinid where objid='"+ objid +"'", "mlkp.tblsendoutwalkinid", true);
                                    ds.transferData(conn, connDest,  "select * from mlkp.tblremotesendout where objid='"+ objid +"'", "mlkp.tblremotesendout", true);                                
                                }

                                continue;
                            } 

                            Map data = ds.getSingleResult(conn, "select objid, strkptn, strsenderid, strreceiverid, strcontrolid from mlkp.tblsendout where objid='"+objid+"' ");
                            
                            transferImpl(conn, connDest, objid, data);
                            System.out.println("   processing " + objid + "... [OK]");
                        } 
                        catch(Exception ex1) 
                        {
                            System.out.println("   processing " + objid + "... [ERROR] " + ex1.getMessage()); 
                            throw ex1; 
                        } 
                    }
                }
                
                cal.add(Calendar.DATE, 1);
            }
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { conn.close(); }catch(Exception ign) {;} 
            try { connDest.close(); }catch(Exception ign) {;} 
        }         
    }    
    
    public void transferRecord(String objid) throws Exception    
    {
        Connection conn = null;
        Connection connDest = null;

        try
        {
            if (srcDS.equals(destDS))
                throw new Exception("source-ds and target-ds must not be the same");
            
            conn = dbConfig.createConnection(srcDS);
            connDest = dbConfig.createConnection(destDS);
            
            Map data = getInfo(conn, objid);
            String msg = "[OK]";

            try 
            {
                if (exists(connDest, objid)) return;

                transferImpl(conn, connDest, objid, data); 
            } 
            catch(Exception x) { 
                msg = "[ERROR] " + x.getMessage(); 
            } 

            System.out.println("processing " + objid + "... " + msg);                    
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { conn.close(); }catch(Exception ign) {;} 
            try { connDest.close(); }catch(Exception ign) {;} 
        }         
    }    
    
    public void updateRecord(String objid) throws Exception    
    {
        Connection conn = null;

        try
        {
            if (srcDS.equals(destDS))
                throw new Exception("source-ds and target-ds must not be the same");
            
            conn = dbConfig.createConnection(srcDS);
            
            Map data = getInfo(conn, objid);
            String msg = "[OK]";

            try 
            {
                String kptn = (String) data.get("strkptn"); 
                String senderid = (String) data.get("strsenderid"); 
                String receiverid = (String) data.get("strreceiverid"); 
                String controlid = (String) data.get("strcontrolid"); 

                DataService ds = new DataService(); 
                if (controlid != null)
                    ds.transferData(conn, conn, "select * from mlkp.tblcontrol where objid='"+ controlid +"'", "mlkp.tblcontrol", true);

                PersonService ps = new PersonService();
                if (senderid != null) ps.transfer(conn, conn, senderid);
                if (receiverid != null) ps.transfer(conn, conn, receiverid);

                ds.insertOnDuplicateKey(conn, conn, "select * from mlkp.tblsendout where objid='"+ objid +"'", "mlkp.tblsendout");
                ds.transferData(conn, conn,  "select * from mlkp.tblkptnlog where kptn='"+ kptn +"'", "mlkp.tblkptnlog", true);
                ds.transferData(conn, conn,  "select * from mlkp.tblsendoutcharge where parentid='"+ objid +"'", "mlkp.tblsendoutcharge", true);

                exec(conn, "update mlkp.tblsendoutinfo set dtsenderbirthdate=null where objid='"+objid+"' and dtsenderbirthdate='0000-00-00'");
                exec(conn, "update mlkp.tblsendoutinfo set dtreceiverbirthdate=null where objid='"+objid+"' and dtreceiverbirthdate='0000-00-00'");

                ds.insertOnDuplicateKey(conn, conn,  "select * from mlkp.tblsendoutinfo where objid='"+ objid +"'", "mlkp.tblsendoutinfo");
                ds.insertOnDuplicateKey(conn, conn,  "select * from mlkp.tblsendoutoption where objid='"+ objid +"'", "mlkp.tblsendoutoption");
                ds.insertOnDuplicateKey(conn, conn,  "select * from mlkp.tblsendoutor where objid='"+ objid +"'", "mlkp.tblsendoutor");
                ds.insertOnDuplicateKey(conn, conn,  "select * from mlkp.tblsendoutwalkinid where objid='"+ objid +"'", "mlkp.tblsendoutwalkinid");
                ds.insertOnDuplicateKey(conn, conn,  "select * from mlkp.tblremotesendout where objid='"+ objid +"'", "mlkp.tblremotesendout");            
            } 
            catch(Exception x) { 
                msg = "[ERROR] " + x.getMessage(); 
            } 

            System.out.println("processing " + objid + "... " + msg);                    
        }
        catch(Exception ex) {
            throw ex;
        }
        finally 
        {
            try { conn.close(); }catch(Exception ign) {;} 
        }         
    }        
    
    public void transferByKPTN(String kptn) throws Exception    
    {
        Connection conn = null;
        Connection connDest = null;

        try
        {
            if (srcDS.equals(destDS))
                throw new Exception("source-ds and target-ds must not be the same");
            
            conn = dbConfig.createConnection(srcDS);
            connDest = dbConfig.createConnection(destDS);
            
            Iterator itr = getKPTNLink(conn, kptn).iterator();
            while (itr.hasNext())
            {
                String objid = itr.next().toString();
                Map data = getInfo(conn, objid);
                String msg = "[OK]";

                try 
                {
                    //if (exists(connDest, objid)) return;
                    
                    transferImpl(conn, connDest, objid, data); 
                } 
                catch(Exception x) { 
                    msg = "[ERROR] " + x.getMessage(); 
                } 

                System.out.println("processing " + objid + "... " + msg);                    
            }
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { conn.close(); }catch(Exception ign) {;} 
            try { connDest.close(); }catch(Exception ign) {;} 
        }         
    }        
    
    public void transferByControlNo(String controlno) throws Exception    
    {
        Connection conn = null;
        Connection connDest = null;

        try
        {
            if (srcDS.equals(destDS))
                throw new Exception("source-ds and target-ds must not be the same");
            
            conn = dbConfig.createConnection(srcDS);
            connDest = dbConfig.createConnection(destDS);
            
            Iterator itr = getControlNoLink(conn, controlno).iterator();
            while (itr.hasNext())
            {
                String objid = itr.next().toString();
                Map data = getInfo(conn, objid);
                String msg = "[OK]";

                try 
                {
                    if (exists(connDest, objid)) continue;
                    
                    transferImpl(conn, connDest, objid, data); 
                } 
                catch(Exception x) { 
                    msg = "[ERROR] " + x.getMessage(); 
                } 

                System.out.println("processing " + objid + "... " + msg);                    
            }
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { conn.close(); }catch(Exception ign) {;} 
            try { connDest.close(); }catch(Exception ign) {;} 
        }         
    }            
    
    public void transferByHour(String sdate, int hour) throws Exception    
    {
        Connection conn = null;
        Connection connDest = null;

        java.sql.Date.valueOf(sdate);
        
        try
        {
            if (srcDS.equals(destDS))
                throw new Exception("source-ds and target-ds must not be the same");
            
            conn = dbConfig.createConnection(srcDS);
            connDest = dbConfig.createConnection(destDS);
            
            int counter = 1;
            String shour = hour+"";
            if (hour < 10) shour = "0"+hour;

            String fromdate = sdate + " " + shour + ":00:00";
            String todate   = sdate + " " + shour + ":59:59";                

            System.out.println("fetching sendout ids... [" + sdate + " " + shour + " src="+srcDS+", target="+destDS+"]"); 
            List listDest = getPrimaryIDs(connDest, fromdate, todate); 
            System.out.println("   starting... ");
            List ids = getIds(conn, fromdate, todate, listDest);
            while (!ids.isEmpty())
            {
                Map data = (Map) ids.remove(0);
                String objid = data.get("objid").toString();
                String msg = "[OK]";
                
                try 
                {
                    if (exists(connDest, objid)) continue;
                    
                    transferImpl(conn, connDest, objid, data); 
                } 
                catch(Exception x) { 
                    msg = "[ERROR] " + x.getMessage(); 
                    //x.printStackTrace();
                } 

                System.out.println(counter + ") processing " + objid + "... " + msg);                    
                counter +=1;
            }
            listDest.clear();
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { conn.close(); }catch(Exception ign) {;} 
            try { connDest.close(); }catch(Exception ign) {;} 
        }         
    }    
    
    public void listUnsyncTransactions(String sdate, int hour) throws Exception    
    {
        Connection conn = null;
        Connection connDest = null;

        java.sql.Date.valueOf(sdate);
        
        try
        {
            if (srcDS.equals(destDS))
                throw new Exception("source-ds and target-ds must not be the same");
            
            conn = dbConfig.createConnection(srcDS);
            connDest = dbConfig.createConnection(destDS);
            
            int counter = 1;
            String shour = hour+"";
            if (hour < 10) shour = "0"+hour;

            String fromdate = sdate + " " + shour + ":00:00";
            String todate   = sdate + " " + shour + ":59:59";                

            System.out.println("fetching sendout ids... [" + sdate + " " + shour + " src="+srcDS+", target="+destDS+"]"); 
            List ids = getIds(conn, fromdate, todate); 
            while (!ids.isEmpty())
            {
                Map data = (Map) ids.remove(0);
                String objid = data.get("objid").toString();
                String msg = "";
                
                try 
                {
                    if (exists(connDest, objid)) continue;
                } 
                catch(Exception x) { 
                    msg = "[ERROR] " + x.getMessage(); 
                    //x.printStackTrace();
                } 

                System.out.println(counter + ") processing " + objid + "... " + msg);                    
                counter +=1;
            }
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { conn.close(); }catch(Exception ign) {;} 
            try { connDest.close(); }catch(Exception ign) {;} 
        }         
    }        

    public void transferImpl(Connection conn, Connection connDest, String objid, Map data) throws Exception
    {
        String kptn = (String) data.get("strkptn"); 
        String senderid = (String) data.get("strsenderid"); 
        String receiverid = (String) data.get("strreceiverid"); 
        String controlid = (String) data.get("strcontrolid"); 
        
        DataService ds = new DataService(); 
        if (controlid != null)
            ds.transferData(conn, connDest, "select * from mlkp.tblcontrol where objid='"+ controlid +"'", "mlkp.tblcontrol", true);

        PersonService ps = new PersonService();
        if (senderid != null) ps.transfer(conn, connDest, senderid);
        if (receiverid != null) ps.transfer(conn, connDest, receiverid);
        
        ds.transferData(conn, connDest, "select * from mlkp.tblsendout where objid='"+ objid +"'", "mlkp.tblsendout", true);
        ds.transferData(conn, connDest,  "select * from mlkp.tblkptnlog where kptn='"+ kptn +"'", "mlkp.tblkptnlog", true);
        ds.transferData(conn, connDest,  "select * from mlkp.tblsendoutcharge where parentid='"+ objid +"'", "mlkp.tblsendoutcharge", true);
        
        try { exec(conn, "update mlkp.tblsendoutinfo set dtsenderbirthdate=null where objid='"+objid+"' and dtsenderbirthdate='0000-00-00'"); }catch(Exception ign){;} 
        try { exec(conn, "update mlkp.tblsendoutinfo set dtreceiverbirthdate=null where objid='"+objid+"' and dtreceiverbirthdate='0000-00-00'"); }catch(Exception ign){;} 

        try { exec(connDest, "update mlkp.tblsendoutinfo set dtsenderbirthdate=null where objid='"+objid+"' and dtsenderbirthdate='0000-00-00'"); }catch(Exception ign){;} 
        try { exec(connDest, "update mlkp.tblsendoutinfo set dtreceiverbirthdate=null where objid='"+objid+"' and dtreceiverbirthdate='0000-00-00'"); }catch(Exception ign){;} 
        
        ds.transferData(conn, connDest,  "select * from mlkp.tblsendoutinfo where objid='"+ objid +"'", "mlkp.tblsendoutinfo", true);
        ds.transferData(conn, connDest,  "select * from mlkp.tblsendoutoption where objid='"+ objid +"'", "mlkp.tblsendoutoption", true);
        ds.transferData(conn, connDest,  "select * from mlkp.tblsendoutor where objid='"+ objid +"'", "mlkp.tblsendoutor", true);
        ds.transferData(conn, connDest,  "select * from mlkp.tblsendoutwalkinid where objid='"+ objid +"'", "mlkp.tblsendoutwalkinid", true);
        ds.transferData(conn, connDest,  "select * from mlkp.tblremotesendout where objid='"+ objid +"'", "mlkp.tblremotesendout", true);            
    }
    
    private int exec(Connection conn, String sql) throws Exception
    {
        PreparedStatement ps = null;
        try
        {
            ps = conn.prepareStatement(sql);
            return ps.executeUpdate();
        }
        catch(Exception ex) {
            throw ex;
        }
        finally {
            try { ps.close(); }catch(Exception ign) {;}
        }
    }
    
    private List getIds(Connection conn, String fromdate, String todate) throws Exception {
        return getIds(conn, fromdate, todate, new ArrayList());
    }
    
    private List getIds(Connection conn, String fromdate, String todate, List filter) throws Exception
    {
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            String sql = " select objid, strkptn, strsenderid, strreceiverid, strcontrolid " + 
                         " from mlkp.tblsendout " + 
                         " where dtfiled between '"+fromdate+"' and '"+todate+"' "; 
            
            ps = conn.prepareStatement(sql); 
            rs = ps.executeQuery(); 
            
            List results = new ArrayList();
            while (rs.next()) 
            {
                String objid = rs.getString("objid");
                if (filter.indexOf(objid) >= 0) continue;
                
                Map data = new HashMap();
                data.put("objid", objid);
                data.put("strkptn", rs.getString("strkptn"));
                data.put("strsenderid", rs.getString("strsenderid"));
                data.put("strreceiverid", rs.getString("strreceiverid"));
                data.put("strcontrolid", rs.getString("strcontrolid"));
                results.add(data);
            }
            return results;
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { rs.close(); }catch(Exception ign) {;}
            try { ps.close(); }catch(Exception ign) {;}
        } 
    }    
    
    private List getPrimaryIDs(Connection conn, String fromdate, String todate) throws Exception
    {
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        try
        {
            String sql = " select objid from mlkp.tblsendout " + 
                         " where dtfiled between '"+fromdate+"' and '"+todate+"' "; 
            
            ps = conn.prepareStatement(sql); 
            rs = ps.executeQuery(); 
            
            List results = new ArrayList();
            while (rs.next()) {
                results.add(rs.getString("objid")); 
            }
            return results;
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { rs.close(); }catch(Exception ign) {;}
            try { ps.close(); }catch(Exception ign) {;}
        } 
    }    
    
    private Map getInfo(Connection conn, String objid) throws Exception
    {
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        try
        {
            String sql = " select objid, strkptn, strsenderid, strreceiverid, strcontrolid " + 
                         " from mlkp.tblsendout where objid='"+objid+"' "; 
            
            ps = conn.prepareStatement(sql); 
            rs = ps.executeQuery(); 
            
            Map data = new HashMap();
            if (rs.next()) 
            {
                data.put("objid", rs.getString("objid"));
                data.put("strkptn", rs.getString("strkptn"));
                data.put("strsenderid", rs.getString("strsenderid"));
                data.put("strreceiverid", rs.getString("strreceiverid"));
                data.put("strcontrolid", rs.getString("strcontrolid"));
            }
            return data;
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { rs.close(); }catch(Exception ign) {;}
            try { ps.close(); }catch(Exception ign) {;}
        } 
    }    
    
    private List getKPTNLink(Connection conn, String kptn) throws Exception
    {
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        try
        {
            String sql = " select objid from mlkp.tblsendout where strkptn='"+kptn+"' "; 
            
            ps = conn.prepareStatement(sql); 
            rs = ps.executeQuery(); 
            
            List data = new ArrayList();
            while (rs.next()) { 
                data.add(rs.getString("objid"));
            }
            return data;
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { rs.close(); }catch(Exception ign) {;}
            try { ps.close(); }catch(Exception ign) {;}
        } 
    }        
    
    private List getControlNoLink(Connection conn, String controlno) throws Exception
    {
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        try
        {
            String sql = " select objid from mlkp.tblsendout where strcontrolno like '"+controlno+"' "; 
            
            ps = conn.prepareStatement(sql); 
            rs = ps.executeQuery(); 
            
            List data = new ArrayList();
            while (rs.next()) { 
                data.add(rs.getString("objid"));
            }
            return data;
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { rs.close(); }catch(Exception ign) {;}
            try { ps.close(); }catch(Exception ign) {;}
        } 
    }            
    
    private boolean exists(Connection conn, String objid) throws Exception
    {
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        try
        {
            String sql = " select objid from mlkp.tblsendout where objid='"+objid+"' "; 
            
            ps = conn.prepareStatement(sql); 
            rs = ps.executeQuery(); 
            boolean b = rs.next(); 
            return b;
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { rs.close(); }catch(Exception ign) {;}
            try { ps.close(); }catch(Exception ign) {;}
        } 
    }    
}
