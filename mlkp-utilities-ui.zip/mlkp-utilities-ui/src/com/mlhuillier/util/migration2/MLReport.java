package com.mlhuillier.util.migration2;

import com.mlhuillier.util.DBConfig;
import java.sql.Connection;

public class MLReport 
{
    public static void main1(String[] args) throws Exception 
    {
        MLReport b = new MLReport("DB-204", "DB-212");
        b.transfer();
    }
    
    private DBConfig dbConfig;
    private String srcDS;
    private String destDS;
    
    public MLReport(String srcDS, String destDS) 
    {
        this.srcDS = srcDS;
        this.destDS = destDS;
        this.dbConfig = new DBConfig();
    }
    
    public void transfer() throws Exception 
    {
        Connection conn = null;
        Connection connDest = null;

        try
        {
            if (srcDS.equals(destDS))
                throw new Exception("source-ds and target-ds must not be the same");
            
            conn = dbConfig.createConnection(srcDS);
            connDest = dbConfig.createConnection(destDS);
            
            DataService dataService = new DataService();
            String[] tables = new String[]
            {
                "tblbirrate", "tblcutoffmapping"
            };
            
            for (int i=0; i<tables.length; i++)
            {
                String tablename = tables[i];
                System.out.println("[mlreport."+tablename+"]");
                dataService.transferData(conn, connDest, "select * from mlreport."+tablename, "mlreport."+tablename, true); 
            }
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { conn.close(); }catch(Exception ign) {;} 
            try { connDest.close(); }catch(Exception ign) {;} 
        }         
    }
}
