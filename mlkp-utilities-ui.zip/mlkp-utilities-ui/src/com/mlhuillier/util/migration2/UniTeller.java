package com.mlhuillier.util.migration2;

import com.mlhuillier.util.DBConfig;
import com.mlhuillier.util.migration2.*;
import java.sql.Connection;

public class UniTeller 
{
    public static void main(String[] args) throws Exception 
    {
        UniTeller b = new UniTeller("DB-212", "DB-204");
        b.transfer();
    }
    
    private DBConfig dbConfig;
    private String srcDS;
    private String destDS;
    
    public UniTeller(String srcDS, String destDS) 
    {
        this.srcDS = srcDS;
        this.destDS = destDS;
        this.dbConfig = new DBConfig();
    }
    
    public void transfer() throws Exception 
    {
        Connection conn = null;
        Connection connDest = null;

        try
        {
            if (srcDS.equals(destDS))
                throw new Exception("source-ds and target-ds must not be the same");
            
            conn = dbConfig.createConnection(srcDS);
            connDest = dbConfig.createConnection(destDS);
            
            DataService dataService = new DataService(true);
            String[] tables = new String[]
            {
                "payoutkey", "payout", "reversepayout", 
                "reversepayoutseries",  "tbltxnlog"
            };
            for (int i=0; i<tables.length; i++)
            {
                String tablename = tables[i];
                System.out.println("[uniteller."+tablename+"]");
                dataService.transferData(conn, connDest, "select * from uniteller."+tablename, "uniteller."+tablename, true); 
            }
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { conn.close(); }catch(Exception ign) {;} 
            try { connDest.close(); }catch(Exception ign) {;} 
        }         
    }
}
