package com.mlhuillier.util.migration2;

import com.mlhuillier.util.DBConfig;
import java.security.SecureRandom;
import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class PayVenMobile 
{
    public static void mainx(String[] args) throws Exception 
    {
        PayVenMobile b = new PayVenMobile("DEV-1262"); 
        b.generateCards(500, 249000, java.sql.Date.valueOf("1900-01-01")); 
        //b.generateCards(1000, 250000, java.sql.Date.valueOf("1901-01-01")); 
    }
    
    private DBConfig dbConfig;
    private String srcDS;
    
    public PayVenMobile(String srcDS) 
    {
        this.srcDS = srcDS;
        this.dbConfig = new DBConfig();
    }
    
    public void generateCards(double denomination, long counts, Date date) throws Exception 
    {
        Connection conn = null;

        try
        {
            conn = dbConfig.createConnection(srcDS);
            
            DataService dataService = new DataService();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); 
            Calendar cal = new GregorianCalendar(); 
            cal.setTime(date); 
            
            long counter = 0; 
            while (true) 
            {
                if (counter >= counts) break;
                
                SecureRandom sr = new SecureRandom(); 
                
                int hashcode = System.identityHashCode(sr);
                sr.setSeed(cal.getTimeInMillis() + hashcode);

                int num = 0; 
                while (true) 
                { 
                    num = sr.nextInt();
                    if (num > 0) break; 
                } 
                
                String cardno = getLeftPaddedValue(num, "0", 10); 
                String gnum = num+"";
                if (gnum.length() < 10)
                {
                    int hashcodelen = (hashcode+"").length(); 
                    cardno = (Long.parseLong(cardno.substring(0, hashcodelen)) + hashcode) + "" + cardno.substring(hashcodelen); 
                    cardno = getLeftPaddedValue(Long.parseLong(cardno), "0", 10); 
                }
                
                String dtfiled = sdf.format(new Date()); 
                String currency = "PHP";
                
                StringBuffer pinno = new StringBuffer();
                pinno.append(cardno.charAt(1));
                pinno.append(cardno.charAt(9));
                pinno.append(cardno.charAt(7));
                pinno.append(cardno.charAt(3));
                pinno.append(cardno.charAt(5));
                pinno.append(cardno.charAt(9));
                
                try
                {
                    dataService.exec(conn, " insert into mlpartner.tblmobilecard (objid, state, dtfiled, strpinno, curamount, strcurrencyid) " + 
                                           " values ('"+cardno+"', 1, '"+dtfiled+"', '"+pinno+"', "+ denomination +", '"+currency+"') "); 
                    counter += 1; 
                }
                catch(Exception ex) {
                    System.out.println("[ERROR] " + ex.getMessage());
                }
                
                cal.add(Calendar.SECOND, 1);
            }
        }
        catch(Exception ex) { 
            throw ex; 
        } 
        finally
        {
            try { conn.close(); }catch(Exception ign) {;} 
        }         
    }    
    
    private String getLeftPaddedValue(long num, String pad, int length)
    {
        String s = num+"";  
        if (s.length() >= length) {
            return s.substring(0, length); 
        }
        else if (s.length() < length) 
        {
            StringBuffer sb = new StringBuffer(); 
            for (int i=0, len=length-s.length(); i<len; i++) sb.append(pad);

            sb.append(s);
            s = sb.toString();
        } 
        return s; 
    }     
}
