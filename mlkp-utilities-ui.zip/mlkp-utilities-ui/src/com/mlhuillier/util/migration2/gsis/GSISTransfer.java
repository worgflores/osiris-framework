package com.mlhuillier.util.migration2.gsis;

import com.mlhuillier.util.DBConfig;
import com.mlhuillier.util.migration2.DataService;
import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class GSISTransfer 
{
    public static void main1(String[] args) throws Exception 
    {
        GSISTransfer u = new GSISTransfer("DB-204", "DB-202"); 
        u.transfer("2009-01-01", "2009-12-31"); 
    }
    
    private SimpleDateFormat YMD = new SimpleDateFormat("yyyy-MM-dd");
    private DBConfig dbConfig;
    private String srcDS;
    private String destDS;
    
    public GSISTransfer(String srcDS, String destDS) 
    {
        this.srcDS = srcDS;
        this.destDS = destDS;
        this.dbConfig = new DBConfig();
    }
    
    public void transfer(String startdate, String enddate) throws Exception 
    {
        Connection conn = null;
        Connection connDest = null;

        Date dtstart = java.sql.Date.valueOf(startdate);
        Date dtend = java.sql.Date.valueOf(enddate);
        
        try
        {
            if (srcDS.equals(destDS))
                throw new Exception("source-ds and target-ds must not be the same");
            
            conn = dbConfig.createConnection(srcDS);
            connDest = dbConfig.createConnection(destDS);
            
            DataService dataService = new DataService();
            System.out.println("      transferring master files... ");
            dataService.transferData(conn, connDest, "select * from gsis.tblbranchmapping", "gsis.tblbranchmapping", true);
            
            Calendar cal = new GregorianCalendar(); 
            cal.setTime(dtstart);
            while (true)
            {
                Date dt = cal.getTime();
                if (dt.after(dtend)) break;
                
                String sdate = YMD.format(dt);
                String fromdate = sdate + " 00:00:00";
                String todate = sdate + " 23:59:59";
                
                System.out.println("processing gsis transfer... ["+sdate+"]");
                transferImpl(conn, connDest, dataService, fromdate, todate);
                
                cal.add(Calendar.DATE, 1);
            }
        }
        catch(Exception ex) { 
            throw ex; 
        }
        finally
        {
            try { conn.close(); }catch(Exception ign) {;} 
            try { connDest.close(); }catch(Exception ign) {;} 
        }         
    }   
    
    private void transferImpl(Connection connSrc, Connection connDest, DataService dataService, String fromdate, String todate) throws Exception 
    {
        dataService.transferData(connSrc, connDest, " select objid from gsis.tbldata where txndate between '"+fromdate+"' and '"+todate+"'", "gsis.tbldata", true);                 
    }
    
}
