package com.mlhuillier.util.migration2.mlkyc;

import com.mlhuillier.util.DBConfig;
import com.mlhuillier.util.migration2.DataService;
import java.sql.Connection;

public class TransferMLCardActivated2 
{
    public static void xmain(String[] args) throws Exception 
    {
        new TransferMLCardActivated2("DB-206").transferCardNo("00%");
    } 
    
    private DataService dataService; 
    private DBConfig dbConfig;
    private String srcDS;
    
    public TransferMLCardActivated2(String srcDS) 
    {
        this.srcDS = srcDS;
        this.dbConfig = new DBConfig();
        this.dataService = new DataService(); 
    }

    public void transferCardNo(String cardno) throws Exception    
    {
        Connection conn = null;

        try
        {
            System.out.println(getClass().getSimpleName() + ".transfer started...");
            conn = dbConfig.createConnection(srcDS);

            long startIndex = 0;
            long rowSize    = 10;
            while (true)
            {
                System.out.println("   processing records [startRow="+startIndex+", rowSize="+rowSize+"]...");
                boolean more = dataService.exists(conn, "select cardno from mlkyc.mlcardactivated where cardno like '"+cardno+"' limit "+startIndex+","+rowSize); 
                if (!more) break;
                
                StringBuffer sql = new StringBuffer(); 
                /*
                sql.append(" insert ignore into mlkyc.mlcardactivatednew (cardno, custno, dtexpire, dtfiled, postedby, dtposted) ");
                sql.append(" select "); 
                sql.append(" 	cardno, custno, dtexpire,  "); 
                sql.append(" 	(select dtfiled from mlkyc.customercard where cardno=bt.cardno) as dtfiled,  "); 
                sql.append(" 	(select filedby from mlkyc.customercard where cardno=bt.cardno) as postedby,  "); 
                sql.append(" 	date_sub(dtexpire,interval 2 year) as dtposted  "); 
                sql.append(" from mlkyc.mlcardactivated bt  "); 
                sql.append(" where cardno like '"+cardno+"' "); 
                sql.append(" limit "+startIndex+ "," + rowSize);  
                */
                
                sql.append(" insert ignore into mlkyc.mlcardactivatednew ");
                sql.append("    (cardno, custno, dtexpire, dtfiled, postedby, dtposted, branchid, areaid, regionid, loopid) "); 
                sql.append(" select "); 
                sql.append(" 	a.cardno, a.custno, date_add(cc.dtfiled, interval 2 year) as dtexpire, "); 
                sql.append(" 	cc.dtfiled, cc.filedby as postedby, cc.dtfiled as dtposted, cc.branchfiled as branchid, "); 
                sql.append("    ar.objid as areaid, re.objid as regionid, re.parentid as loopid ");
                sql.append(" from ( "); 
                sql.append("         select cardno from mlkyc.mlcardactivated ");
                sql.append("         where cardno like '"+cardno+"' "); 
                sql.append("         limit "+startIndex+ "," + rowSize);  
                sql.append("      )bt "); 
                sql.append("    inner join mlkyc.mlcardactivated a on bt.cardno=a.cardno ");
                sql.append("    inner join mlkyc.customercard cc on a.cardno=cc.cardno ");
                sql.append("    left join mlkp.tblbranch b on cc.branchfiled=b.objid "); 
                sql.append("    left join mlkp.tblarea ar on b.parentid=ar.objid "); 
                sql.append("    left join mlkp.tblregion re on ar.parentid=re.objid "); 

                dataService.exec(conn, sql.toString()); 
                startIndex += rowSize; 
            }
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { conn.close(); }catch(Exception ign) {;} 
            
            System.out.println(getClass().getSimpleName() + ".transfer ended.");
        }         
    }    
}
