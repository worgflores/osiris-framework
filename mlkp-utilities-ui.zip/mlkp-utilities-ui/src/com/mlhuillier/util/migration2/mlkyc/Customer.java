package com.mlhuillier.util.migration2.mlkyc;

import com.mlhuillier.util.DBConfig;
import com.mlhuillier.util.migration2.DataService;
import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Map;

public class Customer 
{
    public static void main(String[] args) throws Exception 
    {
        Customer b = new Customer("DB-212", "DB-206");
        b.transfer("2010-06-01", "2010-06-30"); 
    }
    
    private DBConfig dbConfig;
    private String srcDS;
    private String destDS;
    private DataService dataService = new DataService();     
    
    public Customer(String srcDS, String destDS) 
    {
        this.srcDS = srcDS;
        this.destDS = destDS;
        this.dbConfig = new DBConfig();
    }
    
    public void transfer(String startdate, String enddate) throws Exception 
    {
        Connection conn = null;
        Connection connDest = null;

        Date dtfrom = java.sql.Date.valueOf(startdate);
        Date dtto   = java.sql.Date.valueOf(enddate);
        
        try
        {
            
            conn = dbConfig.createConnection(srcDS); 
            connDest = dbConfig.createConnection(destDS); 
            
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd"); 
            Calendar cal = new GregorianCalendar();
            cal.setTime(dtfrom);
            while (true)
            {
                Date dt = cal.getTime();
                if (dt.after(dtto)) break;
                
                String sdate = sdf.format(dt);
                for (int h=0; h<24; h++)
                {
                    String shour = h+"";
                    if (h < 10) shour = "0"+h;
                    
                    String sdt1 = sdate + " " + shour + ":00:00";
                    String sdt2 = sdate + " " + shour + ":59:59";
                    System.out.println("processing... ["+sdt1+" " + shour + "]");
                    transfer(conn, connDest, sdt1, sdt2);
                }
                cal.add(Calendar.DATE, 1);
            }
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { conn.close(); }catch(Exception ign) {;} 
            try { connDest.close(); }catch(Exception ign) {;} 
        }         
    }    
    
    private void transfer(Connection connSrc, Connection connDest, String startdate, String enddate) throws Exception
    {
        System.out.println("   transferring new customer...");
        List list = dataService.getList(connSrc, "select custno from mlkyc.customer where dtcreated between '"+startdate+"' and '"+enddate+"' "); 
        while (!list.isEmpty()) 
        { 
            Map data = (Map) list.remove(0); 
            String custno = data.get("custno").toString();
            if (!dataService.exists(connDest, "select custno from mlkyc.customer where custno="+custno))
                dataService.transferData(connSrc, connDest, "select * from mlkyc.customer where custno="+custno, "mlkyc.customer"); 
            
            dataService.transferData(connSrc, connDest, "select * from mlkyc.customercard where custid="+custno, "mlkyc.customercard", true); 
            dataService.transferData(connSrc, connDest, "select * from mlkyc.customercardhistory where custid="+custno, "mlkyc.customercardhistory", true); 
            dataService.transferData(connSrc, connDest, "select * from mlkyc.customeridhistory where custid="+custno, "mlkyc.customeridhistory", true); 
            dataService.transferData(connSrc, connDest, "select * from mlkyc.contactinfohistory where custid="+custno, "mlkyc.contactinfohistory", true); 
            //transferPhoto(connSrc, connDest, custno); 
        } 
        
        System.out.println("   transferring updated customer...");
        list = dataService.getList(connSrc, "select custno from mlkyc.customer where dtmodified between '"+startdate+"' and '"+enddate+"' "); 
        while (!list.isEmpty())
        {
            Map data = (Map) list.remove(0); 
            String custno = data.get("custno").toString();
            if (!dataService.exists(connDest, "select custno from mlkyc.customer where custno="+custno))
                dataService.insertOnDuplicateKey(connSrc, connDest, "select * from mlkyc.customer where custno="+custno, "mlkyc.customer");
            
            dataService.transferData(connSrc, connDest, "select * from mlkyc.customercard where custid="+custno, "mlkyc.customercard", true);
            dataService.transferData(connSrc, connDest, "select * from mlkyc.customercardhistory where custid="+custno, "mlkyc.customercardhistory", true);
            dataService.transferData(connSrc, connDest, "select * from mlkyc.customeridhistory where custid="+custno, "mlkyc.customeridhistory", true);
            dataService.transferData(connSrc, connDest, "select * from mlkyc.contactinfohistory where custid="+custno, "mlkyc.contactinfohistory", true);
            //transferPhoto(connSrc, connDest, custno); 
        } 
        
        System.out.println("   transferring customeridhistory...");
        list = dataService.getList(connSrc, "select id from mlkyc.customeridhistory where dtmodified between '"+startdate+"' and '"+enddate+"' "); 
        while (!list.isEmpty())
        {
            Map data = (Map) list.remove(0); 
            String id = data.get("id").toString();
            dataService.transferData(connSrc, connDest, "select * from mlkyc.customeridhistory where id="+id, "mlkyc.customeridhistory", true);
        } 
        
        System.out.println("   transferring contactinfohistory...");
        list = dataService.getList(connSrc, "select id from mlkyc.contactinfohistory where dtmodified between '"+startdate+"' and '"+enddate+"' "); 
        while (!list.isEmpty())
        {
            Map data = (Map) list.remove(0); 
            String id = data.get("id").toString();
            dataService.transferData(connSrc, connDest, "select * from mlkyc.contactinfohistory where id="+id, "mlkyc.contactinfohistory", true);
        }         
        
        System.out.println("   transferring kycchangerequest...");
        list = dataService.getList(connSrc, "select reqno from mlkyc.kycchangerequest where dtfiled between '"+startdate+"' and '"+enddate+"' "); 
        while (!list.isEmpty())
        {
            Map data = (Map) list.remove(0); 
            String reqno = data.get("reqno").toString();            
            dataService.transferData(connSrc, connDest, "select * from mlkyc.kycchangerequest where reqno="+reqno, "mlkyc.kycchangerequest", true);
            dataService.transferData(connSrc, connDest, "select * from mlkyc.kycchangerequestpending where requestid="+reqno, "mlkyc.kycchangerequestpending", true); 
            dataService.transferData(connSrc, connDest, "select * from mlkyc.addresschangerequest where reqno="+reqno, "mlkyc.addresschangerequest", true); 
            dataService.transferData(connSrc, connDest, "select * from mlkyc.personinfochangerequest where reqno="+reqno, "mlkyc.personinfochangerequest", true); 
        } 
    }
    
    private void transferPhoto(Connection connSrc, Connection connDest, String custno) throws Exception    
    {
        List list = dataService.getList(connSrc, "select id from mlkycphoto.kycphoto where refid="+custno); 
        while (!list.isEmpty()) 
        {
            Map data = (Map) list.remove(0); 
            String id = data.get("id").toString();            
            if (dataService.exists(connDest, "select id from mlkycphoto.kycphoto where id="+id)) continue;
            
            try {
                dataService.transferData(connSrc, connDest, "select * from mlkycphoto.kycphoto where id="+id, "mlkycphoto.kycphoto", true);
            } catch(Exception ex) {
                System.out.println("   [Error: custno="+custno+", id="+id+"] Unable to transfer photo caused by " + ex.getMessage());
            }
        }
        
        list = dataService.getList(connSrc, "select id from mlkycphoto.kycphotohistory where refid="+custno); 
        while (!list.isEmpty()) 
        {
            Map data = (Map) list.remove(0); 
            String id = data.get("id").toString();            
            if (dataService.exists(connDest, "select id from mlkycphoto.kycphotohistory where id="+id)) continue;
            
            try {
                dataService.transferData(connSrc, connDest, "select * from mlkycphoto.kycphotohistory where id="+id, "mlkycphoto.kycphotohistory", true);
            } catch(Exception ex) {
                System.out.println("   [Error: custno="+custno+", id="+id+"] Unable to transfer photohistory caused by " + ex.getMessage());
            }
        }        
    }
}
