package com.mlhuillier.util.migration2.mlkyc;

import com.mlhuillier.util.DBConfig;
import com.mlhuillier.util.migration2.DataService;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Map;

public class CustomerNew 
{
    public static void main(String[] args) throws Exception 
    {
        CustomerNew b = new CustomerNew("DB-206", "DB-206"); 
        b.transfer();
    }
    
    private DBConfig dbConfig;
    private String srcDS;
    private String destDS;
    private DataService dataService = new DataService();     
    
    public CustomerNew(String srcDS, String destDS) 
    {
        this.srcDS = srcDS;
        this.destDS = destDS;
        this.dbConfig = new DBConfig();
    }
    
    public void transfer() throws Exception 
    {
        Connection conn = null;
        Connection connDest = null;

        try
        {
            conn = dbConfig.createConnection(srcDS); 
            connDest = dbConfig.createConnection(destDS); 
            
            long startRow = 700000;
            long rowSize = 1000; 
            while (true)
            {
                if (startRow < 0) break;
                
                System.out.println("   transferring customers... [start="+startRow+", rowSize="+rowSize+"]");
                List list = dataService.getList(conn, "select custno from (select custno from mlkyc.customer limit "+startRow+","+rowSize+")bt order by custno desc"); 
                while (!list.isEmpty()) 
                { 
                    Map data = (Map) list.remove(0); 
                    String custno = data.get("custno").toString();
                    if (!dataService.exists(connDest, "select custno from mlkyc.customer_new where custno="+custno))
                    {
                        try {
                            dataService.insertOnDuplicateKey(conn, connDest, "select * from mlkyc.customer where custno="+custno, "mlkyc.customer_new"); 
                        } 
                        catch(Exception ex) 
                        {
                            System.out.println("      [ERROR] " + ex.getMessage());
                            exec(connDest, "insert into mlkyc.customererror (error) values (?) ", new Object[]{ex.getMessage()}, true); 
                        } 

                        dataService.transferData(conn, connDest, "select * from mlkyc.customercard where custid="+custno, "mlkyc.customercard_new", true); 
                        dataService.transferData(conn, connDest, "select * from mlkyc.customeridhistory where custid="+custno, "mlkyc.customeridhistory_new", true); 
                        dataService.transferData(conn, connDest, "select * from mlkyc.contactinfohistory where custid="+custno, "mlkyc.contactinfohistory_new", true); 
                        //transferPhoto(connSrc, connDest, custno); 
                    }
                } 
                
                startRow -= rowSize;
            } 
        } 
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { conn.close(); }catch(Exception ign) {;} 
            try { connDest.close(); }catch(Exception ign) {;} 
        }         
    }    
    
    public void transferRecord(String lastname, String firstname) throws Exception 
    {
        Connection conn = null;
        Connection connDest = null;

        try
        {
            conn = dbConfig.createConnection(srcDS); 
            connDest = dbConfig.createConnection(destDS); 
            
            System.out.println("   transferring customer... [lastname="+lastname+", firstname="+firstname+"]");
            List list = dataService.getList(conn, " select custno from mlkyc.customer where firstname='" + firstname + "' and lastname='" + lastname + "' "); 
            while (!list.isEmpty())
            {
                String custno = ((Map) list.remove(0)).get("custno").toString();
                System.out.println("      processing " + custno + "...");
                dataService.insertOnDuplicateKey(conn, connDest, "select * from mlkyc.customer where custno="+custno, "mlkyc.customer_new");
                dataService.transferData(conn, connDest, "select * from mlkyc.customercard where custid="+custno, "mlkyc.customercard_new", true); 
                dataService.transferData(conn, connDest, "select * from mlkyc.customeridhistory where custid="+custno, "mlkyc.customeridhistory_new", true); 
                dataService.transferData(conn, connDest, "select * from mlkyc.contactinfohistory where custid="+custno, "mlkyc.contactinfohistory_new", true); 
                //transferPhoto(connSrc, connDest, custno); 
            } 
        } 
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { conn.close(); }catch(Exception ign) {;} 
            try { connDest.close(); }catch(Exception ign) {;} 
        }         
    }        
    
    
    public void transfer(String startdate, String enddate) throws Exception 
    {
        Connection conn = null;
        Connection connDest = null;

        Date dtfrom = java.sql.Date.valueOf(startdate);
        Date dtto   = java.sql.Date.valueOf(enddate);
        
        try
        {
            
            conn = dbConfig.createConnection(srcDS); 
            connDest = dbConfig.createConnection(destDS); 
            
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd"); 
            Calendar cal = new GregorianCalendar();
            cal.setTime(dtfrom);
            while (true)
            {
                Date dt = cal.getTime();
                if (dt.after(dtto)) break;
                
                String sdate = sdf.format(dt);
                for (int h=0; h<24; h++) 
                {
                    String shour = h+""; 
                    if (h < 10) shour = "0"+h; 
                    
                    String sdt1 = sdate + " " + shour + ":00:00"; 
                    String sdt2 = sdate + " " + shour + ":59:59"; 
                    System.out.println("processing... ["+sdt1+" " + shour + ", targetDS="+destDS+"]"); 
                    transfer(conn, connDest, sdt1, sdt2); 
                } 
                cal.add(Calendar.DATE, 1); 
            } 
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { conn.close(); }catch(Exception ign) {;} 
            try { connDest.close(); }catch(Exception ign) {;} 
        }         
    }    
    
    public void transferDesc(String startdate, String enddate) throws Exception 
    {
        Connection conn = null;
        Connection connDest = null;

        Date dtfrom = java.sql.Date.valueOf(startdate);
        Date dtto   = java.sql.Date.valueOf(enddate);
        
        try
        {
            conn = dbConfig.createConnection(srcDS); 
            connDest = dbConfig.createConnection(destDS); 
            
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd"); 
            Calendar cal = new GregorianCalendar();
            cal.setTime(dtto);
            while (true)
            {
                Date dt = cal.getTime();
                if (dt.before(dtfrom)) break;
                
                String sdate = sdf.format(dt);
                for (int h=0; h<24; h++) 
                {
                    String shour = h+""; 
                    if (h < 10) shour = "0"+h; 
                    
                    String sdt1 = sdate + " " + shour + ":00:00"; 
                    String sdt2 = sdate + " " + shour + ":59:59"; 
                    System.out.println("processing... ["+sdt1+" " + shour + ", targetDS="+destDS+"]"); 
                    transfer(conn, connDest, sdt1, sdt2); 
                } 
                
                cal.add(Calendar.DATE, -1); 
            } 
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { conn.close(); }catch(Exception ign) {;} 
            try { connDest.close(); }catch(Exception ign) {;} 
        }         
    }        
    
    private void transfer(Connection connSrc, Connection connDest, String startdate, String enddate) throws Exception
    {
        System.out.println("   transferring new customer...");
        List list = dataService.getList(connSrc, " select custno from mlkyc.customer where dtcreated between '"+startdate+"' and '"+enddate+"' "); 
        while (!list.isEmpty()) 
        { 
            Map data = (Map) list.remove(0); 
            String custno = data.get("custno").toString();
            if (!dataService.exists(connDest, "select custno from mlkyc.customer_new where custno="+custno))
            {
                try {
                    dataService.transferData(connSrc, connDest, "select * from mlkyc.customer where custno="+custno, "mlkyc.customer_new"); 
                } catch(Exception ex) {
                    exec(connDest, "insert into mlkyc.customererror (error) values (?) ", new Object[]{ex.getMessage()}, true); 
                }                
                
                dataService.transferData(connSrc, connDest, "select * from mlkyc.customercard where custid="+custno, "mlkyc.customercard_new", true); 
                dataService.transferData(connSrc, connDest, "select * from mlkyc.customercardhistory where custid="+custno, "mlkyc.customercardhistory_new", true); 
                dataService.transferData(connSrc, connDest, "select * from mlkyc.customeridhistory where custid="+custno, "mlkyc.customeridhistory_new", true); 
                dataService.transferData(connSrc, connDest, "select * from mlkyc.contactinfohistory where custid="+custno, "mlkyc.contactinfohistory_new", true); 
                //transferPhoto(connSrc, connDest, custno); 
            }
        } 
        
        System.out.println("   transferring updated customer...");
        list = dataService.getList(connSrc, "select custno from mlkyc.customer where dtmodified between '"+startdate+"' and '"+enddate+"' "); 
        while (!list.isEmpty())
        {
            Map data = (Map) list.remove(0); 
            String custno = data.get("custno").toString();
            if (!dataService.exists(connDest, "select custno from mlkyc.customer_new where custno="+custno))
            {
                try {
                    dataService.insertOnDuplicateKey(connSrc, connDest, "select * from mlkyc.customer where custno="+custno, "mlkyc.customer_new");
                } catch(Exception ex) {
                    exec(connDest, "insert into mlkyc.customererror (error) values (?) ", new Object[]{ex.getMessage()}, true); 
                }
                
                dataService.transferData(connSrc, connDest, "select * from mlkyc.customercard where custid="+custno, "mlkyc.customercard_new", true);
                dataService.transferData(connSrc, connDest, "select * from mlkyc.customercardhistory where custid="+custno, "mlkyc.customercardhistory_new", true);
                dataService.transferData(connSrc, connDest, "select * from mlkyc.customeridhistory where custid="+custno, "mlkyc.customeridhistory_new", true);
                dataService.transferData(connSrc, connDest, "select * from mlkyc.contactinfohistory where custid="+custno, "mlkyc.contactinfohistory_new", true);
                //transferPhoto(connSrc, connDest, custno); 
            }
        } 
        
        System.out.println("   transferring customeridhistory...");
        list = dataService.getList(connSrc, "select id from mlkyc.customeridhistory where dtmodified between '"+startdate+"' and '"+enddate+"' "); 
        while (!list.isEmpty())
        {
            Map data = (Map) list.remove(0); 
            String id = data.get("id").toString();
            dataService.transferData(connSrc, connDest, "select * from mlkyc.customeridhistory where id="+id, "mlkyc.customeridhistory_new", true);
        } 
        
        System.out.println("   transferring contactinfohistory...");
        list = dataService.getList(connSrc, "select id from mlkyc.contactinfohistory where dtmodified between '"+startdate+"' and '"+enddate+"' "); 
        while (!list.isEmpty())
        {
            Map data = (Map) list.remove(0); 
            String id = data.get("id").toString();
            dataService.transferData(connSrc, connDest, "select * from mlkyc.contactinfohistory where id="+id, "mlkyc.contactinfohistory_new", true);
        }         
        
//        System.out.println("   transferring kycchangerequest...");
//        list = dataService.getList(connSrc, "select reqno from mlkyc.kycchangerequest where dtfiled between '"+startdate+"' and '"+enddate+"' "); 
//        while (!list.isEmpty())
//        {
//            Map data = (Map) list.remove(0); 
//            String reqno = data.get("reqno").toString();            
//            dataService.transferData(connSrc, connDest, "select * from mlkyc.kycchangerequest where reqno="+reqno, "mlkyc.kycchangerequest", true);
//            dataService.transferData(connSrc, connDest, "select * from mlkyc.kycchangerequestpending where requestid="+reqno, "mlkyc.kycchangerequestpending", true); 
//            dataService.transferData(connSrc, connDest, "select * from mlkyc.addresschangerequest where reqno="+reqno, "mlkyc.addresschangerequest", true); 
//            dataService.transferData(connSrc, connDest, "select * from mlkyc.personinfochangerequest where reqno="+reqno, "mlkyc.personinfochangerequest", true); 
//        } 
    }
    
    private void transferPhoto(Connection connSrc, Connection connDest, String custno) throws Exception    
    {
        List list = dataService.getList(connSrc, "select id from mlkycphoto.kycphoto where refid="+custno); 
        while (!list.isEmpty()) 
        {
            Map data = (Map) list.remove(0); 
            String id = data.get("id").toString();            
            if (dataService.exists(connDest, "select id from mlkycphoto.kycphoto where id="+id)) continue;
            
            try {
                dataService.transferData(connSrc, connDest, "select * from mlkycphoto.kycphoto where id="+id, "mlkycphoto.kycphoto", true);
            } catch(Exception ex) {
                System.out.println("   [Error: custno="+custno+", id="+id+"] Unable to transfer photo caused by " + ex.getMessage());
            }
        }
        
        list = dataService.getList(connSrc, "select id from mlkycphoto.kycphotohistory where refid="+custno); 
        while (!list.isEmpty()) 
        {
            Map data = (Map) list.remove(0); 
            String id = data.get("id").toString();            
            if (dataService.exists(connDest, "select id from mlkycphoto.kycphotohistory where id="+id)) continue;
            
            try {
                dataService.transferData(connSrc, connDest, "select * from mlkycphoto.kycphotohistory where id="+id, "mlkycphoto.kycphotohistory", true);
            } catch(Exception ex) {
                System.out.println("   [Error: custno="+custno+", id="+id+"] Unable to transfer photohistory caused by " + ex.getMessage());
            }
        }        
    }
    
    private void exec(Connection conn, String sql, Object[] params, boolean ignoreErrors) throws Exception
    {
        PreparedStatement ps = null;
        try
        {
            ps = conn.prepareStatement(sql);
            if (params != null && params.length > 0)
            {
                for (int i=0; i<params.length; i++)
                    ps.setObject(i+1, params[i]);
            }
            ps.executeUpdate(); 
        }
        catch(Exception ex) 
        {
            if (!ignoreErrors) throw ex;
        }
        finally {
            try { ps.close(); }catch(Exception ing){;} 
        }
    }
}
