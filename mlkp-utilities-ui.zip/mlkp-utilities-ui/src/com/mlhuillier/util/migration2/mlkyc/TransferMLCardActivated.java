package com.mlhuillier.util.migration2.mlkyc;

import com.mlhuillier.util.DBConfig;
import com.mlhuillier.util.migration2.DataService;
import java.sql.Connection;
import java.text.DecimalFormat;

public class TransferMLCardActivated 
{
    public static void main(String[] args) throws Exception 
    {
        new TransferMLCardActivated("DB-206").transfer(1005800);
    } 
    
    private DataService dataService; 
    private DBConfig dbConfig;
    private String srcDS;
    
    public TransferMLCardActivated(String srcDS) 
    {
        this.srcDS = srcDS;
        this.dbConfig = new DBConfig();
        this.dataService = new DataService(); 
    }

    public void transfer(long startIndex) throws Exception    
    {
        Connection conn = null;

        try
        {
            System.out.println(getClass().getSimpleName() + ".transfer started...");
            conn = dbConfig.createConnection(srcDS);

            DecimalFormat formatter = new DecimalFormat("00000000"); 
            long counter = startIndex;
            while (true)
            {
                if (counter > 99999999) break; 

                String s = formatter.format(counter); 
                String cardno = s.substring(0, 2) + "-" + s.substring(2,5) + "-" + s.substring(5,8);

                StringBuffer sql = new StringBuffer(); 
                sql.append(" insert ignore into mlkyc.mlcardactivatednew (cardno, custno, dtexpire, dtfiled, postedby, dtposted) ");
                sql.append(" select "); 
                sql.append(" 	cardno, custno, dtexpire,  "); 
                sql.append(" 	(select dtfiled from mlkyc.customercard where cardno=bt.cardno) as dtfiled,  "); 
                sql.append(" 	(select filedby from mlkyc.customercard where cardno=bt.cardno) as postedby,  "); 
                sql.append(" 	date_sub(dtexpire,interval 2 year) as dtposted  "); 
                sql.append(" from mlkyc.mlcardactivated bt  "); 
                sql.append(" where cardno='"+cardno+"' ");
                
                dataService.exec(conn, sql.toString()); 
                counter += 1;
            }
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { conn.close(); }catch(Exception ign) {;} 
            
            System.out.println(getClass().getSimpleName() + ".transfer ended.");
        }         
    }
}
