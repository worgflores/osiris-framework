package com.mlhuillier.util.migration2.mlkyc;

import com.mlhuillier.util.DBConfig;
import com.mlhuillier.util.migration2.DataService;
import java.sql.Connection;
import java.util.List;
import java.util.Map;

public class CustomerRecord 
{
    public static void xmain(String[] args) throws Exception 
    {
        CustomerRecord b = new CustomerRecord("DB-206", "DB-206");
        b.transferCustno("265955");
    }
    
    private DBConfig dbConfig;
    private String srcDS;
    private String destDS;
    private DataService dataService = new DataService();     
    
    public CustomerRecord(String srcDS, String destDS) 
    {
        this.srcDS = srcDS;
        this.destDS = destDS;
        this.dbConfig = new DBConfig();
    }
    
    public void transferRequest(String reqno) throws Exception 
    {
        Connection conn = null;
        Connection connDest = null;
        if (srcDS.equalsIgnoreCase(destDS))
            throw new Exception("Datasources must not be the same"); 
        
        try
        {
            conn = dbConfig.createConnection(srcDS); 
            connDest = dbConfig.createConnection(destDS); 
            
            transferRequest(conn, connDest, reqno);
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { conn.close(); }catch(Exception ign) {;} 
            try { connDest.close(); }catch(Exception ign) {;} 
        }         
    }    
    
    public void transferCustno(String custno) throws Exception 
    {
        Connection conn = null;
        Connection connDest = null;
        
        try
        {
            conn = dbConfig.createConnection(srcDS); 
            connDest = dbConfig.createConnection(destDS); 
            
            DataService ds = new DataService(); 
            ds.insertOnDuplicateKey(conn, connDest, "select * from mlkyc.customer_bak1 where custno="+custno, "mlkyc.customer"); 
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { conn.close(); }catch(Exception ign) {;} 
            try { connDest.close(); }catch(Exception ign) {;} 
        }         
    }        
    
    private void transferRequest(Connection connSrc, Connection connDest, String reqno) throws Exception
    {
        List list = dataService.getList(connSrc, "select kycid from mlkyc.kycchangerequest where reqno=" + reqno); 
        if (!list.isEmpty()) 
        { 
            Map data = (Map) list.remove(0); 
            String kycid = data.get("kycid").toString();
            
            dataService.transferData(connSrc, connDest, "select * from mlkyc.customer where custno="+kycid, "mlkyc.customer", true); 
            dataService.transferData(connSrc, connDest, "select * from mlkyc.customercard where custid="+kycid, "mlkyc.customercard", true); 
            dataService.transferData(connSrc, connDest, "select * from mlkyc.customercardhistory where custid="+kycid, "mlkyc.customercardhistory", true); 
            dataService.transferData(connSrc, connDest, "select * from mlkyc.customeridhistory where custid="+kycid, "mlkyc.customeridhistory", true); 
            dataService.transferData(connSrc, connDest, "select * from mlkyc.contactinfohistory where custid="+kycid, "mlkyc.contactinfohistory", true); 
            transferPhoto(connSrc, connDest, kycid); 
            
            dataService.transferData(connSrc, connDest, "select * from mlkyc.kycchangerequest where reqno="+reqno, "mlkyc.kycchangerequest", true); 
            dataService.transferData(connSrc, connDest, "select * from mlkyc.kycchangerequestpending where requestid="+reqno, "mlkyc.kycchangerequestpending", true); 
        } 
    }
    
    private void transferPhoto(Connection connSrc, Connection connDest, String custno) throws Exception    
    {
        List list = dataService.getList(connSrc, "select id from mlkycphoto.kycphoto where refid="+custno); 
        while (!list.isEmpty()) 
        {
            Map data = (Map) list.remove(0); 
            String id = data.get("id").toString();            
            if (dataService.exists(connDest, "select id from mlkycphoto.kycphoto where id="+id)) continue;
            
            try {
                dataService.transferData(connSrc, connDest, "select * from mlkycphoto.kycphoto where id="+id, "mlkycphoto.kycphoto", true);
            } catch(Exception ex) {
                System.out.println("   [Error: custno="+custno+", id="+id+"] Unable to transfer photo caused by " + ex.getMessage());
            }
        }
        
        list = dataService.getList(connSrc, "select id from mlkycphoto.kycphotohistory where refid="+custno); 
        while (!list.isEmpty()) 
        {
            Map data = (Map) list.remove(0); 
            String id = data.get("id").toString();            
            if (dataService.exists(connDest, "select id from mlkycphoto.kycphotohistory where id="+id)) continue;
            
            try {
                dataService.transferData(connSrc, connDest, "select * from mlkycphoto.kycphotohistory where id="+id, "mlkycphoto.kycphotohistory", true);
            } catch(Exception ex) {
                System.out.println("   [Error: custno="+custno+", id="+id+"] Unable to transfer photohistory caused by " + ex.getMessage());
            }
        }        
    }
}
