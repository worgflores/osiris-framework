package com.mlhuillier.util.migration2.mlkyc;

import com.mlhuillier.util.DBConfig;
import com.mlhuillier.util.migration2.DataService;
import java.sql.Connection;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Map;

public class MLRewardUpdateCardExpiry 
{
    public static void xmain(String[] args) throws Exception 
    {
        new MLRewardUpdateCardExpiry("DB-206", "DB-204").update("2011-01-01", "2011-01-06"); 
    } 
    
    private DataService dataService; 
    private DBConfig dbConfig;
    private String kycDS;
    private String rewardDS;
    
    public MLRewardUpdateCardExpiry(String kycDS, String rewardDS) 
    {
        this.kycDS = kycDS;
        this.rewardDS = rewardDS; 
        this.dbConfig = new DBConfig();
        this.dataService = new DataService(); 
    }

    public void update(String startdate, String enddate) throws Exception    
    {
        Date dtfrom = java.sql.Date.valueOf(startdate);
        Date dtto   = java.sql.Date.valueOf(enddate);
        
        Connection kycConn = null;
        Connection rewardConn = null;

        try
        {
            System.out.println(getClass().getSimpleName() + ".transfer started...");
            kycConn = dbConfig.createConnection(kycDS);
            rewardConn = dbConfig.createConnection(rewardDS);

            SimpleDateFormat YMD = new SimpleDateFormat("yyyy-MM-dd"); 
            DataService dataService = new DataService(); 
            Calendar cal = new GregorianCalendar(); 
            cal.setTime(dtfrom);
            while (true)
            {
                Date dt = cal.getTime();
                if (dt.after(dtto)) break;

                String sdate = YMD.format(dt); 
                System.out.println("   processing " + sdate + "...");
                StringBuffer sb = new StringBuffer(); 
                sb.append(" select "); 
                sb.append("         cardno, date_format(dtfiled,'%Y-%m-%d') as cardfiled, dtissued as cardissued,  "); 
                sb.append("         date_format(date_add(dtfiled,interval 2 year),'%Y-%m-%d') as cardexpiry  "); 
                sb.append(" from mlkyc.customercard  "); 
                sb.append(" where dtfiled between '"+sdate+" 00:00:00' and '"+sdate+" 23:59:59'  "); 
                sb.append(" having not(cardfiled=dtissued) "); 
                List list = dataService.getList(kycConn, sb.toString());
                while (!list.isEmpty())
                {
                    Map data = (Map) list.remove(0); 
                    String cardno = data.get("cardno").toString(); 
                    String cardexpiry = data.get("cardexpiry").toString(); 
                    dataService.exec(kycConn, "update mlkyc.mlcardactivated set dtexpire='"+cardexpiry+"' where cardno='"+cardno+"'");
                    dataService.exec(rewardConn, "update mlreward.tblcardpoints set cardexpiry='"+cardexpiry+"' where cardno='"+cardno+"'");
                } 
                
                cal.add(Calendar.DATE, 1); 
            }
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { kycConn.close(); }catch(Exception ign) {;} 
            try { rewardConn.close(); }catch(Exception ign) {;} 
            
            System.out.println(getClass().getSimpleName() + ".transfer ended.");
        }         
    }
}
