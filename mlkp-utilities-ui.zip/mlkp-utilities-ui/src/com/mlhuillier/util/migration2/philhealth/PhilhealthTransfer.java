package com.mlhuillier.util.migration2.philhealth;

import com.mlhuillier.util.DBConfig;
import com.mlhuillier.util.migration2.*;
import java.sql.Connection;
import java.util.List;
import java.util.Map;

public class PhilhealthTransfer implements IDataTransfer 
{
    public static void main1(String[] args) throws Exception 
    {
        new PhilhealthTransfer("DB-204", "DB-212").transfer();
    }
    
    private DBConfig dbConfig;
    private String srcDS;
    private String destDS;
    
    public PhilhealthTransfer(String srcDS, String destDS) 
    {
        this.srcDS = srcDS;
        this.destDS = destDS;
        this.dbConfig = new DBConfig();
    }
    
    public void transfer() throws Exception 
    {
        Connection conn = null;
        Connection connDest = null;

        try
        {
            if (srcDS.equals(destDS))
                throw new Exception("source-ds and target-ds must not be the same");
            
            conn = dbConfig.createConnection(srcDS);
            connDest = dbConfig.createConnection(destDS);
            
            System.out.println("   transferring data to " + destDS + "...");
            DataService dataService = new DataService();
            String[] tables = new String[]
            {
                "barangay", "municipality", "province", "tblprovince", "tblbranchmapping", "tblparnoseries", 
                "tblcharge", "tblchargedetail", "tblcontrolseries" 
            };
            for (int i=0; i<tables.length; i++)
            {
                String tablename = tables[i];
                System.out.println("[philhealth."+tablename+"]");
                dataService.insertOnDuplicateKey(conn, connDest, "select * from philhealth."+tablename, "philhealth."+tablename); 
            }
            
            //dataService.exec(conn, "update philhealth.tblmemberindividual set birthday=null where birthday='0000-00-00' ");
            //dataService.exec(conn, "update philhealth.tblmemberindividual set employ_date=null where employ_date='0000-00-00' ");
            
            dataService.transferData(conn, connDest, " " + 
                                                    " select " + 
                                                    "	pin_no, lastname, firstname, middlename, ext_name, mem_category, mem_type, fund_type, status, " + 
                                                    "	street, address, barangay, municipality, province, region, id_printed, tin_no, sss_no, " + 
                                                    "   case when birthday='0000-00-00' then null else birthday end as birthday, " +
                                                    "   sex, date_created, empid_no, emp_stat, " +
                                                    "   case when employ_date='0000-00-00' then null else employ_date end as employ_date " + 
                                                    " from philhealth.tblmemberindividual ", "philhealth.tblmemberindividual", true);     
            
            tables = new String[] {
                "tblmemberemployer", "tblpaymentposted", "tblpayment", "tblpaymentcancelled", "tbllog"
            };
            for (int i=0; i<tables.length; i++)
            {
                String tablename = tables[i];
                System.out.println("[philhealth."+tablename+"]");
                dataService.transferData(conn, connDest, "select * from philhealth."+tablename, "philhealth."+tablename, true); 
            }
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { conn.close(); }catch(Exception ign) {;} 
            try { connDest.close(); }catch(Exception ign) {;} 
        }         
    }
    
    public void transfer(String sdate) throws Exception 
    {
        Connection conn = null;
        Connection connDest = null;

        try
        {
            if (srcDS.equals(destDS))
                throw new Exception("source-ds and target-ds must not be the same");
            
            conn = dbConfig.createConnection(srcDS);
            connDest = dbConfig.createConnection(destDS);
            
            DataService dataService = new DataService(); 
            System.out.println("processing philhealth data... [sdate="+sdate+", targetDS="+destDS+"]");
            
            List list = dataService.getList(conn, "select par_no, pin_no, pen_no from philhealth.tblpayment where dtpaid between '"+sdate+" 00:00:00' and '"+sdate+" 23:59:59'");  
            while (!list.isEmpty())
            {
                Map listitem = (Map) list.remove(0); 
                String parno = listitem.get("par_no").toString();
                String pinno = listitem.get("pin_no")+"";
                String penno = listitem.get("pen_no")+"";
                
                try { dataService.exec(conn, "update philhealth.tblmemberindividual set birthday=null where pin_no='"+pinno+"' and birthday='0000-00-00' "); }catch(Exception ign){;} 
                try { dataService.exec(conn, "update philhealth.tblmemberindividual set employ_date=null where pen_no='"+pinno+"' and employ_date='0000-00-00' "); }catch(Exception ign){;} 
                
                dataService.insertOnDuplicateKey(conn, connDest, "select * from philhealth.tblmemberindividual where pin_no='"+pinno+"'", "philhealth.tblmemberindividual"); 
                dataService.insertOnDuplicateKey(conn, connDest, "select * from philhealth.tblmemberemployer where pen_no='"+penno+"'", "philhealth.tblmemberemployer"); 
                dataService.insertOnDuplicateKey(conn, connDest, "select * from philhealth.tblpayment where par_no='"+parno+"'", "philhealth.tblpayment"); 
                
                dataService.transferData(conn, connDest, "select * from philhealth.tblpaymentcancelled where dtpaid between '"+sdate+" 00:00:00' and '"+sdate+" 23:59:59'", "philhealth.tblpaymentcancelled", true); 
                dataService.transferData(conn, connDest, "select * from philhealth.tbllog where dtlog between '"+sdate+" 00:00:00' and '"+sdate+" 23:59:59'", "philhealth.tbllog", true); 
            }
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { conn.close(); }catch(Exception ign) {;} 
            try { connDest.close(); }catch(Exception ign) {;} 
        }         
    }    
}
