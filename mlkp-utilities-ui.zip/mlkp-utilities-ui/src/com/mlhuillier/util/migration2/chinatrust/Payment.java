package com.mlhuillier.util.migration2.chinatrust;

import com.mlhuillier.util.DBConfig;
import com.mlhuillier.util.migration2.DataService;
import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Map;

public class Payment 
{
    private SimpleDateFormat YMD = new SimpleDateFormat("yyyy-MM-dd");
    private DBConfig dbConfig;
    private String srcDS;
    private String destDS;
    
    public Payment(String srcDS, String destDS) 
    {
        this.srcDS = srcDS;
        this.destDS = destDS;
        this.dbConfig = new DBConfig();
    }
    
    public void transfer(String startdate, String enddate) throws Exception 
    {
        Connection conn = null;
        Connection connDest = null;

        Date dtstart = java.sql.Date.valueOf(startdate);
        Date dtend = java.sql.Date.valueOf(enddate);
        
        try
        {
            if (srcDS.equals(destDS))
                throw new Exception("source-ds and target-ds must not be the same");
            
            conn = dbConfig.createConnection(srcDS);
            connDest = dbConfig.createConnection(destDS);
            
            DataService dataService = new DataService();
            Calendar cal = new GregorianCalendar(); 
            cal.setTime(dtstart);
            while (true)
            {
                Date dt = cal.getTime();
                if (dt.after(dtend)) break;
                
                String sdate = YMD.format(dt);
                String fromdate = sdate + " 00:00:00";
                String todate = sdate + " 23:59:59";
                
                System.out.println("processing chinatrust-payment transfer... ["+sdate+"]");
                transferImpl(conn, connDest, dataService, fromdate, todate);
                
                cal.add(Calendar.DATE, 1);
            }
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { conn.close(); }catch(Exception ign) {;} 
            try { connDest.close(); }catch(Exception ign) {;} 
        }         
    }   
    
    private void transferImpl(Connection connSrc, Connection connDest, DataService dataService, String fromdate, String todate) throws Exception 
    {
        List list = dataService.getList(connSrc, " select objid from chinatrust.tblpayment where dtfiled between '"+fromdate+"' and '"+todate+"'"); 
        while (!list.isEmpty())
        {
            String objid = ((Map) list.remove(0)).get("objid").toString();
            
            try {
                dataService.transferData(connSrc, connDest, "select * from chinatrust.tblpayment where objid='"+ objid +"'", "chinatrust.tblpayment", true); 
            }
            catch(Exception ex) 
            {
                System.out.println("Error processing '" + objid + "'");
                throw ex;
            }
        }
        
        list = dataService.getList(connSrc, " select objid from chinatrust.tblpaymentdraft where dtfiled between '"+fromdate+"' and '"+todate+"'"); 
        while (!list.isEmpty())
        {
            String objid = ((Map) list.remove(0)).get("objid").toString();
            
            try {
                dataService.transferData(connSrc, connDest, "select * from chinatrust.tblpaymentdraft where objid='"+ objid +"'", "chinatrust.tblpaymentdraft", true); 
            }
            catch(Exception ex) 
            {
                System.out.println("Error processing '" + objid + "'");
                throw ex;
            }
        }        
    }
    
}
