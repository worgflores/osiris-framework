package com.mlhuillier.util.migration2.chinatrust;

import com.mlhuillier.util.DBConfig;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class CTLTxnCount 
{
    public static void main1(String[] args) throws Exception 
    {
        new CTLTxnCount().process(null); 
    }
    
    private DBConfig dbConfig; 
    
    private String ds1 = "DB-204";
    private String ds2 = "DB-212";
    private String ds3 = "DB-202";
    private String ds4 = "DB-206";
    
    public CTLTxnCount() {
        this.dbConfig = new DBConfig(); 
    } 
    
    public void process(String sdate) throws Exception 
    {
        log(" DATES     \t\t" + ds1 + "\t" + ds2 + "\t" + ds3 + "\t" + ds4);
        
        
        process(null, "select count(*) from chinatrust.tblcashcard", "tblcashcard");
        process(null, "select count(*) from chinatrust.tblcashcardopen", "tblcashcardopen");
        process(null, "select count(*) from chinatrust.tblcontrolseries", "tblcontrolseries");
        process(sdate, "select count(*) from chinatrust.tblcustomer", "tblcustomer");
        process(sdate, "select count(*) from chinatrust.tblcustomercard", "tblcustomercard");
        process(sdate, "select count(*) from chinatrust.tbllog", "tbllog");
        process(sdate, "select count(*) from chinatrust.tblpayment", "tblpayment");
        process(sdate, "select count(*) from chinatrust.tblpaymentdraft", "tblpaymentdraft");
    }
    
    private void process(String sdate, String sql, String name) throws Exception
    {
        Connection conn1 = null;
        Connection conn2 = null;
        Connection conn3 = null;
        Connection conn4 = null;
        
        try
        {
            conn1 = dbConfig.createConnection(ds1); 
            conn2 = dbConfig.createConnection(ds2); 
            conn3 = dbConfig.createConnection(ds3); 
            conn4 = dbConfig.createConnection(ds4); 
            
            log(" [ " + name + " ]");

            String fromdate = sdate + " 00:00:00";
            String todate   = sdate + " 23:59:59";
            if (sdate == null) 
            {
                fromdate = null;
                todate = null;
            }

            long count1=-1,  count2=-1, count3=-1, count4=-1;
            try { count1 = getCount(conn1, sql, fromdate, todate); }catch(Exception ign) {;} 
            try { count2 = getCount(conn2, sql, fromdate, todate); }catch(Exception ign) {;} 
            try { count3 = getCount(conn3, sql, fromdate, todate); }catch(Exception ign) {;} 
            try { count4 = getCount(conn4, sql, fromdate, todate); }catch(Exception ign) {;} 

            long maincount = count1;                

            String sdt = sdate;
            StringBuffer sb = new StringBuffer();
            sb.append(sdt);
            sb.append("\t\t" + count1);
            sb.append("\t\t" + count2);
            if (count2 != maincount) sb.append(" *");

            sb.append("\t\t" + count3);
            if (count3 != maincount) sb.append(" *");

            sb.append("\t\t" + count4);
            if (count4 != maincount) sb.append(" *");

            log(sb);
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { conn1.close(); }catch(Exception ign){;}
            try { conn2.close(); }catch(Exception ign){;}
            try { conn3.close(); }catch(Exception ign){;}
            try { conn4.close(); }catch(Exception ign){;}
            
        }
    }
    
    private long getCount(Connection conn, String sql, String fromdate, String todate) throws Exception
    {
        long count = 0; 

        PreparedStatement ps = null; 
        ResultSet rs = null;
        try
        {
            ps = conn.prepareStatement(sql);
            
            if (fromdate != null && todate != null)
            {
                ps.setString(1, fromdate);
                ps.setString(2, todate);
            }

            rs = ps.executeQuery();
            if (rs.next()) count = rs.getLong(1);
            
            return count;
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { rs.close(); }catch(Exception ign) {;}
            try { ps.close(); }catch(Exception ign) {;}
        }
    }  
    
    private void log(Object msg)
    {
        System.out.println(msg);
    }
}
