package com.mlhuillier.util.migration2.chinatrust;

public class CTLTransfer 
{
    public static void main1(String[] args) throws Exception
    {
        String fromDS = "DB-204";
        String toDS   = "DB-202";
        String fromdate = "2009-01-01";
        String todate = "2009-12-31";
        
        new ControlSeries(fromDS, toDS).transfer(fromdate, todate);
        new Customer(fromDS, toDS).transfer(fromdate, todate);
        new Log(fromDS, toDS).transfer(fromdate, todate);
        new Payment(fromDS, toDS).transfer(fromdate, todate);
    }
    
}
