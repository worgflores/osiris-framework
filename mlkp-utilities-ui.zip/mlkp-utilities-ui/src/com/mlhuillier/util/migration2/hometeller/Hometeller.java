package com.mlhuillier.util.migration2.hometeller;

import com.mlhuillier.util.DBConfig;
import com.mlhuillier.util.migration2.DataService;
import com.mlhuillier.util.migration2.hometeller.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class Hometeller 
{
    public static void main(String[] args) throws Exception 
    {
        Hometeller b = new Hometeller("DB-212", "DB-204");
        b.transfer();
    }
    
    private DBConfig dbConfig;
    private String srcDS;
    private String destDS;
    
    public Hometeller(String srcDS, String destDS) 
    {
        this.srcDS = srcDS;
        this.destDS = destDS;
        this.dbConfig = new DBConfig();
    }
    
    public void transfer() throws Exception 
    {
        Connection conn = null;
        Connection connDest = null;

        try
        {
            if (srcDS.equals(destDS))
                throw new Exception("source-ds and target-ds must not be the same");
            
            conn = dbConfig.createConnection(srcDS);
            connDest = dbConfig.createConnection(destDS);
            
            DataService dataService = new DataService();
//            dataService.transferData(conn, connDest, "select * from hometeller.agentcommissionrule", "hometeller.agentcommissionrule", true); 
//            dataService.transferData(conn, connDest, "select * from hometeller.commissionrule", "hometeller.commissionrule", true); 
//            dataService.transferData(conn, connDest, "select * from hometeller.stockdoc", "hometeller.stockdoc", true); 
//            dataService.transferData(conn, connDest, "select * from hometeller.draftstockdoc", "hometeller.draftstockdoc", true); 
//            dataService.transferData(conn, connDest, "select * from hometeller.homeatmaccount", "hometeller.homeatmaccount", true); 
//            dataService.transferData(conn, connDest, "select * from hometeller.homeatmaccountcard", "hometeller.homeatmaccountcard", true); 
//            dataService.transferData(conn, connDest, "select * from hometeller.homeatmdevice", "hometeller.homeatmdevice", true); 
//            dataService.transferData(conn, connDest, "select * from hometeller.stockitem", "hometeller.stockitem", true); 
//            dataService.transferData(conn, connDest, "select * from hometeller.stockitemintransit", "hometeller.stockitemintransit", true); 
//            dataService.transferData(conn, connDest, "select * from hometeller.homeatmdocno", "hometeller.homeatmdocno", true); 
//            dataService.transferData(conn, connDest, "select * from hometeller.homeatmtxnlog", "hometeller.homeatmtxnlog", true); 
//            dataService.transferData(conn, connDest, "select * from hometeller.hometellertxn", "hometeller.hometellertxn", true); 
//            dataService.transferData(conn, connDest, "select * from hometeller.key_gen", "hometeller.key_gen", true); 
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { conn.close(); }catch(Exception ign) {;} 
            try { connDest.close(); }catch(Exception ign) {;} 
        }         
    }
    
    private int exec(Connection conn, String sql) throws Exception
    {
        PreparedStatement ps = null;
        try
        {
            ps = conn.prepareStatement(sql);
            return ps.executeUpdate();
        }
        catch(Exception ex) {
            throw ex;
        }
        finally {
            try { ps.close(); }catch(Exception ign) {;}
        }
    }

    private List getListByPrimary(Connection conn, String sql) throws Exception
    {
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        try
        {
            ps = conn.prepareStatement(sql); 
            rs = ps.executeQuery(); 
            
            List results = new ArrayList();
            while (rs.next()) {
                results.add(rs.getString(1));
            }
            return results;
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { rs.close(); }catch(Exception ign) {;}
            try { ps.close(); }catch(Exception ign) {;}
        } 
    }
    
    private boolean exist(Connection conn, String sql) throws Exception
    {
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        try
        {
            ps = conn.prepareStatement(sql); 
            rs = ps.executeQuery(); 
            return rs.next();
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { rs.close(); }catch(Exception ign) {;}
            try { ps.close(); }catch(Exception ign) {;}
        } 
    }    
}
