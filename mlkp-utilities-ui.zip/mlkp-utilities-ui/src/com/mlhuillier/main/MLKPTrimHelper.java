package com.mlhuillier.main;

import com.mlhuillier.util.DBConfig;
import com.mlhuillier.util.migration2.DataService;
import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Map;

public class MLKPTrimHelper 
{
    private static String getArrayValue(String[] args, int index, String title)
    {
        try {
            return args[index]; 
        } 
        catch(Exception ex) {
            throw new IllegalStateException("Unable to get " + title + " caused by " + ex.getMessage(), ex); 
        }
    }
    
    public static void main(String[] args) throws Exception 
    {
        String dsname = getArrayValue(args, 0, "'datasource'"); 
        String fromdate = getArrayValue(args, 1, "'startdate'"); 
        String todate = getArrayValue(args, 2, "'enddate'"); 

        Date dtfrom = java.sql.Date.valueOf(fromdate);
        Date dtto = java.sql.Date.valueOf(todate);
        
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd"); 
        if (!sdf.format(dtfrom).equals(fromdate)) throw new Exception("'startdate' is invalid"); 
        if (!sdf.format(dtto).equals(todate)) throw new Exception("'enddate' is invalid"); 
        
        Calendar cal = new GregorianCalendar(); 
        cal.setTime(dtfrom); 
        
        DBConfig dbConfig = new DBConfig();
        while (true)
        {
            Date dt = cal.getTime();
            if (dt.after(dtto)) break;
            
            String sdate = sdf.format(dt); 
            new PayoutRemover(dbConfig, dsname).start(sdate);
            new RTSRemover(dbConfig, dsname).start(sdate);
            new CancelSendoutRemover(dbConfig, dsname).start(sdate);
            new InvalidateSendoutRemover(dbConfig, dsname).start(sdate);
            
            cal.add(Calendar.DATE, 1);
        } 
    }
    
    MLKPTrimHelper() 
    {
    }
    
    private static class PayoutCreditRemover
    {
        private DataService dataService = new DataService();
        private DBConfig dbConfig;
        private String dsname;
        
        PayoutCreditRemover(DBConfig dbConfig, String dsname)
        {
            this.dbConfig = dbConfig;
            this.dsname = dsname;
        }
        
        public void start(String sdate) throws Exception
        {
            for (int hour=0; hour<24; hour++)
            {
                String shour = hour+"";
                if (hour < 10) shour = "0"+hour;

                String startdate = sdate + " " + shour + ":00:00";
                String enddate   = sdate + " " + shour + ":59:59";

                Connection conn = dbConfig.createConnection(dsname); 
                List list = new ArrayList(); 

                try 
                {
                    System.out.println("fetching creditpayout records for remove... [dsname="+dsname+", date="+sdate+" "+shour+"]");
                    list = dataService.getList(conn, " select " + 
                                                     "    objid, strpayoutid, " + 
                                                     "    (select strsendoutid from mlkp.tblpayout where objid=bt.strpayoutid) as strsendoutid, " + 
                                                     "    (select strkptn from mlkp.tblpayout p inner join mlkp.tblsendout s on p.strsendoutid=s.objid where p.objid=bt.strpayoutid) as strkptn " + 
                                                     " from mlkp.tblcreditpayouttoremote bt " + 
                                                     " where txndate between '"+startdate+"' and '"+enddate+"' "); 
                } 
                catch(Exception ex0) { 
                    throw ex0; 
                } 
                finally { 
                    try { conn.close(); }catch(Exception ign){;} 
                }

                while (!list.isEmpty())
                {
                    Map data = (Map) list.remove(0); 
                    String objid = data.get("objid").toString();
                    String poutid = data.get("strpayoutid").toString(); 
                    String soutid = data.get("strsendoutid").toString(); 
                    String kptn = data.get("strkptn").toString(); 
                    remove(objid, poutid, soutid, kptn);
                }
            }
        }
        
        private void remove(String objid, String poutid, String soutid, String kptn) throws Exception
        {
            Connection conn = null;
            try
            {
                conn = dbConfig.createConnection(dsname); 
                conn.setAutoCommit(false);
                
                dataService.exec(conn, "delete from mlkp.tblcreditpayouttoremote where objid='"+objid+"'"); 
                
                dataService.exec(conn, "delete from mlkp.tblremotepayout where objid='"+poutid+"'"); 
                dataService.exec(conn, "delete from mlkp.tblpayoutinfo where objid='"+poutid+"'"); 
                dataService.exec(conn, "delete from mlkp.tblpayout where objid='"+poutid+"'"); 
                
                dataService.exec(conn, "delete from mlkp.qrycustomerservice where objid='"+soutid+"'"); 
                dataService.exec(conn, "delete from mlkp.qryunclaim where objid='"+soutid+"'"); 

                dataService.exec(conn, "delete from mlkp.tblinvalidatesendout where objid='"+soutid+"'");   
                
                dataService.exec(conn, "delete from mlkp.tblremotesendout where objid='"+soutid+"'"); 
                dataService.exec(conn, "delete from mlkp.tblsendoutwalkinid where objid='"+soutid+"'"); 
                dataService.exec(conn, "delete from mlkp.tblsendoutoption where objid='"+soutid+"'"); 
                dataService.exec(conn, "delete from mlkp.tblsendoutor where objid='"+soutid+"'"); 
                dataService.exec(conn, "delete from mlkp.tblsendoutext where objid='"+soutid+"'");                 
                dataService.exec(conn, "delete from mlkp.tblsendoutcharge where parentid='"+soutid+"'");
                dataService.exec(conn, "delete from mlkp.tblsendoutinfo where objid='"+soutid+"'");
                dataService.exec(conn, "delete from mlkp.tblsendout where objid='"+soutid+"'");
                
                dataService.exec(conn, "delete from mlkp.tblkptnlog where kptn='"+kptn+"'"); 
                conn.commit();
            }
            catch(Exception ex) 
            {
                try { conn.rollback(); }catch(Exception ign){;} 
             
                System.out.println("   Unable to remove record [objid="+objid+", soutid="+soutid+"] ");
                throw ex;
            }
            finally {
                try { conn.close(); }catch(Exception ing){;} 
            }
        }
    }
    
    private static class SendoutCreditRemover
    {
        private DataService dataService = new DataService();
        private DBConfig dbConfig;
        private String dsname;
        
        SendoutCreditRemover(DBConfig dbConfig, String dsname)
        {
            this.dbConfig = dbConfig;
            this.dsname = dsname;
        }
        
        public void start(String sdate) throws Exception
        {
            for (int hour=0; hour<24; hour++)
            {
                String shour = hour+"";
                if (hour < 10) shour = "0"+hour;

                String startdate = sdate + " " + shour + ":00:00";
                String enddate   = sdate + " " + shour + ":59:59";

                Connection conn = dbConfig.createConnection(dsname); 
                List list = new ArrayList(); 

                try 
                {
                    System.out.println("fetching creditsendout records for remove... [dsname="+dsname+", date="+sdate+" "+shour+"]");
                    list = dataService.getList(conn, " select " + 
                                                     "    objid, strsendoutid, " + 
                                                     "    (select strkptn from mlkp.tblsendout where objid=bt.strsendoutid) as strkptn " + 
                                                     " from mlkp.tblcreditsendouttoremote bt " + 
                                                     " where txndate between '"+startdate+"' and '"+enddate+"' "); 
                } 
                catch(Exception ex0) { 
                    throw ex0; 
                } 
                finally { 
                    try { conn.close(); }catch(Exception ign){;} 
                }

                while (!list.isEmpty())
                {
                    Map data = (Map) list.remove(0); 
                    String objid = data.get("objid").toString();
                    String soutid = data.get("strsendoutid").toString(); 
                    String kptn = data.get("strkptn").toString(); 
                    remove(objid, soutid, kptn);
                }
            }
        }
        
        private void remove(String objid, String soutid, String kptn) throws Exception
        {
            Connection conn = null;
            try
            {
                conn = dbConfig.createConnection(dsname); 
                conn.setAutoCommit(false);
                
                dataService.exec(conn, "delete from mlkp.tblcreditsendouttoremote where objid='"+objid+"'"); 
                dataService.exec(conn, "delete from mlkp.tblinvalidatesendout where objid='"+soutid+"'");   
                
                dataService.exec(conn, "delete from mlkp.qrycustomerservice where objid='"+soutid+"'"); 
                dataService.exec(conn, "delete from mlkp.qryunclaim where objid='"+soutid+"'"); 
                dataService.exec(conn, "delete from mlkp.tblremotesendout where objid='"+soutid+"'"); 
                dataService.exec(conn, "delete from mlkp.tblsendoutwalkinid where objid='"+soutid+"'"); 
                dataService.exec(conn, "delete from mlkp.tblsendoutoption where objid='"+soutid+"'"); 
                dataService.exec(conn, "delete from mlkp.tblsendoutor where objid='"+soutid+"'"); 
                dataService.exec(conn, "delete from mlkp.tblsendoutext where objid='"+soutid+"'");                 
                dataService.exec(conn, "delete from mlkp.tblsendoutcharge where parentid='"+soutid+"'");
                dataService.exec(conn, "delete from mlkp.tblsendoutinfo where objid='"+soutid+"'");
                dataService.exec(conn, "delete from mlkp.tblsendout where objid='"+soutid+"'");
                
                dataService.exec(conn, "delete from mlkp.tblkptnlog where kptn='"+kptn+"'"); 
                conn.commit();
            }
            catch(Exception ex) 
            {
                try { conn.rollback(); }catch(Exception ign){;} 
             
                System.out.println("   Unable to remove record [objid="+objid+", soutid="+soutid+"] ");
                throw ex;
            }
            finally {
                try { conn.close(); }catch(Exception ing){;} 
            }
        }
    }
    
    private static class PayoutRemover
    {
        private DataService dataService = new DataService();
        private DBConfig dbConfig;
        private String dsname;
        
        PayoutRemover(DBConfig dbConfig, String dsname)
        {
            this.dbConfig = dbConfig;
            this.dsname = dsname;
        }
        
        public void start(String sdate) throws Exception
        {
            for (int hour=0; hour<24; hour++)
            {
                String shour = hour+"";
                if (hour < 10) shour = "0"+hour;

                String startdate = sdate + " " + shour + ":00:00";
                String enddate   = sdate + " " + shour + ":59:59";

                Connection conn = dbConfig.createConnection(dsname); 
                List list = new ArrayList(); 

                try 
                {
                    System.out.println("fetching payout records for remove... [dsname="+dsname+", date="+sdate+" "+shour+"]");
                    list = dataService.getList(conn, " select " + 
                                                     "    objid, strsendoutid, " + 
                                                     "    (select strkptn from mlkp.tblsendout where objid=p.strsendoutid) as strkptn " + 
                                                     " from mlkp.tblpayout p " + 
                                                     " where dtclaimed between '"+startdate+"' and '"+enddate+"' "); 
                } 
                catch(Exception ex0) { 
                    throw ex0; 
                } 
                finally { 
                    try { conn.close(); }catch(Exception ign){;} 
                }

                while (!list.isEmpty())
                {
                    Map data = (Map) list.remove(0); 
                    String objid = data.get("objid").toString();
                    String soutid = data.get("strsendoutid").toString(); 
                    String kptn = data.get("strkptn").toString(); 
                    remove(objid, soutid, kptn);
                }
            }
        }
        
        private void remove(String objid, String soutid, String kptn) throws Exception
        {
            Connection conn = null;
            try
            {
                conn = dbConfig.createConnection(dsname); 
                conn.setAutoCommit(false);
                
                dataService.exec(conn, "delete from mlkp.tblcreditpayouttoremote where strpayoutid='"+objid+"'"); 
                dataService.exec(conn, "delete from mlkp.tblinvalidatesendout where objid='"+soutid+"'");   
                
                dataService.exec(conn, "delete from mlkp.tblremotepayout where objid='"+objid+"'"); 
                dataService.exec(conn, "delete from mlkp.tblpayoutinfo where objid='"+objid+"'"); 
                dataService.exec(conn, "delete from mlkp.tblpayout where objid='"+objid+"'"); 
                
                dataService.exec(conn, "delete from mlkp.qrycustomerservice where objid='"+soutid+"'"); 
                dataService.exec(conn, "delete from mlkp.qryunclaim where objid='"+soutid+"'"); 
                dataService.exec(conn, "delete from mlkp.tblremotesendout where objid='"+soutid+"'"); 
                dataService.exec(conn, "delete from mlkp.tblsendoutlock where objid='"+soutid+"'"); 
                dataService.exec(conn, "delete from mlkp.tblsendoutwalkinid where objid='"+soutid+"'"); 
                dataService.exec(conn, "delete from mlkp.tblsendoutoption where objid='"+soutid+"'"); 
                dataService.exec(conn, "delete from mlkp.tblsendoutor where objid='"+soutid+"'"); 
                dataService.exec(conn, "delete from mlkp.tblsendoutext where objid='"+soutid+"'");                 
                dataService.exec(conn, "delete from mlkp.tblsendoutcharge where parentid='"+soutid+"'");
                dataService.exec(conn, "delete from mlkp.tblsendoutinfo where objid='"+soutid+"'");
                dataService.exec(conn, "delete from mlkp.tblsendout where objid='"+soutid+"'");
                
                dataService.exec(conn, "delete from mlkp.tblkptnlog where kptn='"+kptn+"'"); 
                conn.commit();
            }
            catch(Exception ex) 
            {
                try { conn.rollback(); }catch(Exception ign){;} 
             
                System.out.println("   Unable to remove record [objid="+objid+", soutid="+soutid+"] ");
                throw ex;
            }
            finally {
                try { conn.close(); }catch(Exception ing){;} 
            }
        }
    }
    
    private static class RTSRemover
    {
        private DataService dataService = new DataService();
        private DBConfig dbConfig;
        private String dsname;
        
        RTSRemover(DBConfig dbConfig, String dsname)
        {
            this.dbConfig = dbConfig;
            this.dsname = dsname;
        }
        
        public void start(String sdate) throws Exception
        {
            for (int hour=0; hour<24; hour++)
            {
                String shour = hour+"";
                if (hour < 10) shour = "0"+hour;

                String startdate = sdate + " " + shour + ":00:00";
                String enddate   = sdate + " " + shour + ":59:59";

                Connection conn = dbConfig.createConnection(dsname); 
                List list = new ArrayList(); 

                try 
                {
                    System.out.println("fetching returntosender records for remove... [dsname="+dsname+", date="+sdate+" "+shour+"]");
                    list = dataService.getList(conn, " select " + 
                                                     "    objid, strsendoutid, " + 
                                                     "    (select strkptn from mlkp.tblsendout where objid=rts.strsendoutid) as strkptn " + 
                                                     " from mlkp.tblreturntosender rts " + 
                                                     " where dtreturned between '"+startdate+"' and '"+enddate+"' "); 
                } 
                catch(Exception ex0) { 
                    throw ex0; 
                } 
                finally { 
                    try { conn.close(); }catch(Exception ign){;} 
                }

                while (!list.isEmpty())
                {
                    Map data = (Map) list.remove(0); 
                    String objid = data.get("objid").toString();
                    String soutid = data.get("strsendoutid").toString(); 
                    String kptn = data.get("strkptn").toString(); 
                    remove(objid, soutid, kptn);
                }
            }
        }
        
        private void remove(String objid, String soutid, String kptn) throws Exception
        {
            Connection conn = null;
            try
            {
                conn = dbConfig.createConnection(dsname); 
                conn.setAutoCommit(false);
                
                dataService.exec(conn, "delete from mlkp.tblreturntosender where objid='"+objid+"'"); 
                dataService.exec(conn, "delete from mlkp.tblinvalidatesendout where objid='"+soutid+"'");   
                
                dataService.exec(conn, "delete from mlkp.qrycustomerservice where objid='"+soutid+"'"); 
                dataService.exec(conn, "delete from mlkp.qryunclaim where objid='"+soutid+"'"); 
                dataService.exec(conn, "delete from mlkp.tblremotesendout where objid='"+soutid+"'"); 
                dataService.exec(conn, "delete from mlkp.tblsendoutlock where objid='"+soutid+"'"); 
                dataService.exec(conn, "delete from mlkp.tblsendoutwalkinid where objid='"+soutid+"'"); 
                dataService.exec(conn, "delete from mlkp.tblsendoutoption where objid='"+soutid+"'"); 
                dataService.exec(conn, "delete from mlkp.tblsendoutor where objid='"+soutid+"'"); 
                dataService.exec(conn, "delete from mlkp.tblsendoutext where objid='"+soutid+"'");                 
                dataService.exec(conn, "delete from mlkp.tblsendoutcharge where parentid='"+soutid+"'");
                dataService.exec(conn, "delete from mlkp.tblsendoutinfo where objid='"+soutid+"'");
                dataService.exec(conn, "delete from mlkp.tblsendout where objid='"+soutid+"'");
                
                dataService.exec(conn, "delete from mlkp.tblkptnlog where kptn='"+kptn+"'"); 
                conn.commit();
            }
            catch(Exception ex) 
            {
                try { conn.rollback(); }catch(Exception ign){;} 
             
                System.out.println("   Unable to remove record [objid="+objid+", soutid="+soutid+"] ");
                throw ex;
            }
            finally {
                try { conn.close(); }catch(Exception ing){;} 
            }
        }
    }
    
    private static class CancelSendoutRemover
    {
        private DataService dataService = new DataService();
        private DBConfig dbConfig;
        private String dsname;
        
        CancelSendoutRemover(DBConfig dbConfig, String dsname)
        {
            this.dbConfig = dbConfig;
            this.dsname = dsname;
        }
        
        public void start(String sdate) throws Exception
        {
            for (int hour=0; hour<24; hour++)
            {
                String shour = hour+"";
                if (hour < 10) shour = "0"+hour;

                String startdate = sdate + " " + shour + ":00:00";
                String enddate   = sdate + " " + shour + ":59:59";

                Connection conn = dbConfig.createConnection(dsname); 
                List list = new ArrayList(); 

                try 
                {
                    System.out.println("fetching cancelsendout records for remove... [dsname="+dsname+", date="+sdate+" "+shour+"]");
                    list = dataService.getList(conn, " select " + 
                                                     "    objid, strsendoutid, " + 
                                                     "    (select strkptn from mlkp.tblsendout where objid=cs.strsendoutid) as strkptn " + 
                                                     " from mlkp.tblcancelsendout cs " + 
                                                     " where dtcancelled between '"+startdate+"' and '"+enddate+"' "); 
                } 
                catch(Exception ex0) { 
                    throw ex0; 
                } 
                finally { 
                    try { conn.close(); }catch(Exception ign){;} 
                }

                while (!list.isEmpty())
                {
                    Map data = (Map) list.remove(0); 
                    String objid = data.get("objid").toString();
                    String soutid = data.get("strsendoutid").toString(); 
                    String kptn = data.get("strkptn").toString(); 
                    remove(objid, soutid, kptn);
                }
            }
        }
        
        private void remove(String objid, String soutid, String kptn) throws Exception
        {
            Connection conn = null;
            try
            {
                conn = dbConfig.createConnection(dsname); 
                conn.setAutoCommit(false);
                
                dataService.exec(conn, "delete from mlkp.tblcancelsendout where objid='"+objid+"'"); 
                dataService.exec(conn, "delete from mlkp.tblinvalidatesendout where objid='"+soutid+"'");   
                
                dataService.exec(conn, "delete from mlkp.qrycustomerservice where objid='"+soutid+"'"); 
                dataService.exec(conn, "delete from mlkp.qryunclaim where objid='"+soutid+"'"); 
                dataService.exec(conn, "delete from mlkp.tblremotesendout where objid='"+soutid+"'"); 
                dataService.exec(conn, "delete from mlkp.tblsendoutlock where objid='"+soutid+"'"); 
                dataService.exec(conn, "delete from mlkp.tblsendoutwalkinid where objid='"+soutid+"'"); 
                dataService.exec(conn, "delete from mlkp.tblsendoutoption where objid='"+soutid+"'"); 
                dataService.exec(conn, "delete from mlkp.tblsendoutor where objid='"+soutid+"'"); 
                dataService.exec(conn, "delete from mlkp.tblsendoutext where objid='"+soutid+"'");                 
                dataService.exec(conn, "delete from mlkp.tblsendoutcharge where parentid='"+soutid+"'");
                dataService.exec(conn, "delete from mlkp.tblsendoutinfo where objid='"+soutid+"'");
                dataService.exec(conn, "delete from mlkp.tblsendout where objid='"+soutid+"'");
                
                dataService.exec(conn, "delete from mlkp.tblkptnlog where kptn='"+kptn+"'"); 
                conn.commit();
            }
            catch(Exception ex) 
            {
                try { conn.rollback(); }catch(Exception ign){;} 
             
                System.out.println("   Unable to remove record [objid="+objid+", soutid="+soutid+"] ");
                throw ex;
            }
            finally {
                try { conn.close(); }catch(Exception ing){;} 
            }
        }
    }

    private static class InvalidateSendoutRemover
    {
        private DataService dataService = new DataService();
        private DBConfig dbConfig;
        private String dsname;
        
        InvalidateSendoutRemover(DBConfig dbConfig, String dsname)
        {
            this.dbConfig = dbConfig;
            this.dsname = dsname;
        }
        
        public void start(String sdate) throws Exception
        {
            for (int hour=0; hour<24; hour++)
            {
                String shour = hour+"";
                if (hour < 10) shour = "0"+hour;

                String startdate = sdate + " " + shour + ":00:00";
                String enddate   = sdate + " " + shour + ":59:59";

                Connection conn = dbConfig.createConnection(dsname); 
                List list = new ArrayList(); 

                try 
                {
                    System.out.println("fetching invalidatesendout records for remove... [dsname="+dsname+", date="+sdate+" "+shour+"]");
                    list = dataService.getList(conn, " select " + 
                                                     "    objid, strsendoutid, " + 
                                                     "    (select strkptn from mlkp.tblsendout where objid=bt.strsendoutid) as strkptn " + 
                                                     " from mlkp.tblinvalidatesendout bt " + 
                                                     " where dtmodified between '"+startdate+"' and '"+enddate+"' "); 
                } 
                catch(Exception ex0) { 
                    throw ex0; 
                } 
                finally { 
                    try { conn.close(); }catch(Exception ign){;} 
                }

                while (!list.isEmpty())
                {
                    Map data = (Map) list.remove(0); 
                    String objid = data.get("objid").toString();
                    String soutid = data.get("strsendoutid").toString(); 
                    String kptn = data.get("strkptn").toString(); 
                    remove(objid, soutid, kptn);
                }
            }
        }
        
        private void remove(String objid, String soutid, String kptn) throws Exception
        {
            Connection conn = null;
            try
            {
                conn = dbConfig.createConnection(dsname); 
                conn.setAutoCommit(false);
                
                dataService.exec(conn, "delete from mlkp.tblinvalidatesendout where objid='"+objid+"'");
                
                dataService.exec(conn, "delete from mlkp.qrycustomerservice where objid='"+soutid+"'"); 
                dataService.exec(conn, "delete from mlkp.qryunclaim where objid='"+soutid+"'"); 
                dataService.exec(conn, "delete from mlkp.tblremotesendout where objid='"+soutid+"'"); 
                dataService.exec(conn, "delete from mlkp.tblsendoutlock where objid='"+soutid+"'"); 
                dataService.exec(conn, "delete from mlkp.tblsendoutwalkinid where objid='"+soutid+"'"); 
                dataService.exec(conn, "delete from mlkp.tblsendoutoption where objid='"+soutid+"'"); 
                dataService.exec(conn, "delete from mlkp.tblsendoutor where objid='"+soutid+"'"); 
                dataService.exec(conn, "delete from mlkp.tblsendoutext where objid='"+soutid+"'"); 
                dataService.exec(conn, "delete from mlkp.tblsendoutcharge where parentid='"+soutid+"'"); 
                dataService.exec(conn, "delete from mlkp.tblsendoutinfo where objid='"+soutid+"'"); 
                dataService.exec(conn, "delete from mlkp.tblsendout where objid='"+soutid+"'");
                
                dataService.exec(conn, "delete from mlkp.tblkptnlog where kptn='"+kptn+"'"); 
                conn.commit();
            }
            catch(Exception ex) 
            {
                try { conn.rollback(); }catch(Exception ign){;} 
             
                System.out.println("   Unable to remove record [objid="+objid+", soutid="+soutid+"] ");
                throw ex;
            }
            finally {
                try { conn.close(); }catch(Exception ing){;} 
            }
        }
    }
    
}
