package com.mlhuillier.main;

import com.mlhuillier.util.migration2.IDataTransfer;
import com.mlhuillier.util.migration2.TransferPayout;
import com.mlhuillier.util.migration2.TransferSendout;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class MainTransfer 
{
    public static void main(String[] args) throws Exception 
    { 
        mainImpl(args);
//        mainImpl(new String[]{ 
//            "sendout", "2010-01-01", "2010-01-31", "DB-212", "DB-159" 
//        }); 
    }
    
    public static void mainImpl(String[] args) throws Exception 
    {
        String type = (args[0]+"").toLowerCase();
        String fromdate = args[1];
        String todate = args[2];
        String fromDS = args[3];
        String toDS = args[4];

        Date dtfrom = java.sql.Date.valueOf(fromdate);
        Date dtto = java.sql.Date.valueOf(todate);
        
        IDataTransfer idt = null;
        if ("sendout".equals(type))
            idt = new TransferSendout(fromDS, toDS);    
        else if ("payout".equals(type))
            idt = new TransferPayout(fromDS, toDS);    
        else
            throw new Exception("'"+type+"' type not supported");

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd"); 
        Calendar cal = new GregorianCalendar(); 
        cal.setTime(dtfrom); 
        
        while (true)
        {
            Date dt = cal.getTime();
            if (dt.after(dtto)) break;
            
            idt.transfer(sdf.format(dt));
            cal.add(Calendar.DATE, 1);
        }
    }
    
    public MainTransfer() {
    }
    
}
