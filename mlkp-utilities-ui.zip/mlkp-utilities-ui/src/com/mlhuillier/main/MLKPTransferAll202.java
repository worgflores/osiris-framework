package com.mlhuillier.main;

import com.mlhuillier.util.ui.TransferService;

public class MLKPTransferAll202 
{
    public static void main(String[] args) throws Exception 
    {
        TransferService ts = new TransferService(); 

        while (true)
        {
            try {
                ts.start("DB-204", "DB-206", "2010-07-24", "2010-07-26"); 
            } catch(Exception ex) {
                System.out.println("[ERROR] " + ex.getMessage());
            }
        }
    } 
    
}
