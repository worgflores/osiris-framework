package com.mlhuillier.main; 

import com.mlhuillier.util.ui.TransferService; 

public class MLKPTransferAll 
{ 
    public static void main(String[] args) throws Exception 
    { 
        String fromdate = args[0]; 
        String todate =   args[1]; 
        String fromDS =   args[2]; 
        String toDS =     args[3]; 
        
        boolean loop = false;
        try { 
            loop = "true".equals(args[4].toLowerCase()); 
        } catch(Exception ign){;} 

        TransferService ts = new TransferService(); 
        while (true) 
        {
            ts.start(fromDS, toDS, fromdate, todate);        
            
            if (!loop) break;
        }
    } 
} 

