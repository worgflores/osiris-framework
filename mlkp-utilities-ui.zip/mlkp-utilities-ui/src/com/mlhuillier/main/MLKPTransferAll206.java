package com.mlhuillier.main;

import com.mlhuillier.util.ui.TransferService;

public class MLKPTransferAll206 
{
    public static void main(String[] args) throws Exception 
    {
        TransferService ts = new TransferService(); 
        
        while (true) 
        {
            try { 
                ts.start("DB-204", "DB-206", "2010-07-27", "2010-07-27"); 
            } catch(Exception ex) { 
                System.out.println("[ERROR] " + ex.getMessage()); 
            } 
        } 
    } 
}
