package test.fx;

import com.mlhuillier.util.DBConfig;
import com.mlhuillier.util.migration2.DataService;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.sql.Connection;
import junit.framework.*;

public class ChangeForexClassTest extends TestCase 
{
    
    public ChangeForexClassTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception { 
    }

    protected void tearDown() throws Exception {
    }
    
    
    public void xtest0000() throws Exception
    {
        changeForexClass("test/fx/special-std-vm.txt", "MLSTD");
        changeForexClass("test/fx/std-special-luz.txt", "MLSPEC");
        changeForexClass("test/fx/std-special-vm.txt", "MLSPEC");
        changeForexClass("test/fx/std_ext-vm.txt", "MLEXT");
    } 
    
    private void changeForexClass(String resourceName, String toFXClass) throws Exception
    {
        DBConfig dbconfig = new DBConfig(); 
        DataService ds = new DataService(); 
        BufferedReader reader = null; 
        Connection conn = null; 
        
        try
        {
            conn = dbconfig.createConnection("DB-204"); 
            if (!ds.exists(conn, "select objid from mlkp.tblforexgroupsetting where objid='"+toFXClass+"'")) 
                throw new Exception("'"+toFXClass+"' forex classification not found"); 
            
            ClassLoader loader = Thread.currentThread().getContextClassLoader(); 
            URL url = loader.getResource(resourceName); 
            if (url == null) throw new Exception("'"+resourceName+"' resource not found"); 
            
            String line = null; 
            reader = new BufferedReader(new InputStreamReader(url.openStream())); 
            while ((line=reader.readLine()) != null) 
            {
                String branchid = line.trim(); 
                if (branchid.length() == 0) continue; 
                
                try
                {
                    System.out.println("processing " + branchid + " to " + toFXClass + "...");
                    if (ds.exists(conn, "select * from mlkp.tblforexgroupbranch where strbranchid='"+branchid+"' limit 1"))
                        ds.exec(conn, "update mlkp.tblforexgroupbranch set strforexgroupid='"+toFXClass+"' where strbranchid='"+branchid+"'"); 
                    else
                        ds.exec(conn, "insert into mlkp.tblforexgroupbranch (strforexgroupid, strbranchid) values ('"+toFXClass+"', '"+branchid+"')"); 
                }
                catch(Exception ex) { 
                    System.out.println("    [ERROR] (branchid="+branchid+") " + ex.getMessage()); 
                }
            }
        }
        catch(Exception ex) { 
            throw ex; 
        }
        finally 
        {
            try { conn.close(); }catch(Exception ign){;} 
            try { reader.close(); }catch(Exception ign){;} 
        }        
    }    
}
