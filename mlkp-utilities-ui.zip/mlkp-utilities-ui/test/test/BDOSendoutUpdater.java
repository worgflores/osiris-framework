package test;

import com.mlhuillier.util.DBConfig;
import com.mlhuillier.util.migration2.DataService;
import java.sql.Connection;
import java.util.List;
import java.util.Map;

public class BDOSendoutUpdater 
{
    
    private DBConfig dbConfig;
    private String srcDS;
    
    public BDOSendoutUpdater(String srcDS) 
    {
        this.srcDS = srcDS;
        this.dbConfig = new DBConfig();
    }
    
    public void transfer(String sdate) throws Exception    
    {
        Connection conn = null;
        
        java.sql.Date.valueOf(sdate);

        try
        {
            conn = dbConfig.createConnection(srcDS);

            DataService ds = new DataService(); 
            for (int h=0; h < 24; h++)
            {
                String shour = h+"";
                if (h < 10) shour = "0"+h;

                String fromdate = sdate + " " + shour + ":00:00";
                String todate   = sdate + " " + shour + ":59:59";                

                System.out.println("fetching bdo-sendout ids... [" + sdate + " " + shour + "]"); 
                List list = ds.getList(conn, " select objid, strsenderlname from mlkp.tblsendout " + 
                                             " where dtfiled between '"+fromdate+"' and '"+todate+"' " + 
                                             " having strsenderlname is null ");
                while (!list.isEmpty())
                {
                    String objid = ((Map) list.remove(0)).get("objid").toString(); 
                    ds.exec(conn, " update mlkp.tblsendout set strsenderlname=ifnull(strsenderlname,'.') where objid='"+objid+"' and strsenderlname is null ");
                }
                
                list = ds.getList(conn, " select objid, strsenderfname from mlkp.tblsendout " + 
                                        " where dtfiled between '"+fromdate+"' and '"+todate+"' " + 
                                        " having strsenderfname is null ");
                while (!list.isEmpty())
                {
                    String objid = ((Map) list.remove(0)).get("objid").toString(); 
                    ds.exec(conn, " update mlkp.tblsendout set strsenderfname=ifnull(strsenderfname,'.') where objid='"+objid+"' and strsenderfname is null ");
                }                
                
                list = ds.getList(conn, " select objid, strsendermname from mlkp.tblsendout " + 
                                        " where dtfiled between '"+fromdate+"' and '"+todate+"' " + 
                                        " having strsendermname is null ");
                while (!list.isEmpty())
                {
                    String objid = ((Map) list.remove(0)).get("objid").toString(); 
                    ds.exec(conn, " update mlkp.tblsendout set strsendermname=ifnull(strsendermname,'.') where objid='"+objid+"' and strsendermname is null ");
                }                                
            }
        }
        catch(Exception ex) {
            throw ex;
        }
        finally {
            try { conn.close(); }catch(Exception ign) {;} 
        }         
    }
}
