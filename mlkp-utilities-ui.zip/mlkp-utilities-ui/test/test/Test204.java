package test;

import junit.framework.*;

public class Test204 extends TestCase 
{
    
    public Test204(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
    }

    protected void tearDown() throws Exception {
    }
    
    public void test000() throws Exception 
    {
//        TransferJollibee t = new TransferJollibee("204", "212");
//        t.transferModules();
    }

}
