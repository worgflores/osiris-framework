package test;

import com.mlhuillier.util.migration2.mlkyc.TransferMLCardActivated3;
import junit.framework.*;

public class TransferMLCardActivatedTest3 extends TestCase 
{
    
    public TransferMLCardActivatedTest3(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
    }

    protected void tearDown() throws Exception {
    }
    
    public void test0000() throws Exception
    {
        new TransferMLCardActivated3("DB-206").transferCardNo("05%");
    }
}
