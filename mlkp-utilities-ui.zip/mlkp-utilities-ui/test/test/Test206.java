package test;

import com.mlhuillier.util.ui.TransferService;
import junit.framework.*;

public class Test206 extends TestCase 
{
    
    public Test206(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
    }

    protected void tearDown() throws Exception {
    }
    
    public void test000() throws Exception 
    { 
//        TransferService s = new TransferService(); 
//        s.start("212", "206", "2010-03-15", "2010-03-15"); 
        
        
    } 

}
