package test;

import com.mlhuillier.util.migration2.BuildSendoutPrincipalRangeUSD;
import junit.framework.*;

public class SendoutPrincipalRangeUSDTester201005 extends TestCase 
{
    
    public SendoutPrincipalRangeUSDTester201005(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
    }

    protected void tearDown() throws Exception {
    }
    
    public void test0000() throws Exception
    {
        new BuildSendoutPrincipalRangeUSD("DB-204", "DEV-1263").transfer("2010-05-01", "2010-05-31");
    }
}
