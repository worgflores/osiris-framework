package test;

import com.mlhuillier.util.migration2.TransferPayout;
import com.mlhuillier.util.migration2.TransferSendout;
import junit.framework.*;

public class TransferTestUnit extends TestCase 
{
    
    public TransferTestUnit(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
    }

    protected void tearDown() throws Exception {
    }
    
    public void test0001() throws Exception 
    {
        //new TransferSendout("DB-204", "DB-206").transferRecord("SOUT1787a634:12b8a538080:ace"); 
        new TransferSendout("DB-204", "DB-206", true).transfer("2010-10-08"); 
        new TransferPayout("DB-204", "DB-206", true).transfer("2010-10-08");    
        
        new TransferPayout("DB-204", "DB-206", true).transfer("2010-10-09");
        new TransferPayout("DB-204", "DB-206", true).transfer("2010-10-11");
        new TransferSendout("DB-204", "DB-206", true).transfer("2010-10-12"); 
        new TransferPayout("DB-204", "DB-206", true).transfer("2010-10-13");
        new TransferPayout("DB-204", "DB-206", true).transfer("2010-10-14");
        new TransferSendout("DB-204", "DB-206", true).transfer("2010-10-15"); 
        new TransferSendout("DB-204", "DB-206", true).transfer("2010-10-16"); 
        new TransferPayout("DB-204", "DB-206", true).transfer("2010-10-16");
        new TransferPayout("DB-204", "DB-206", true).transfer("2010-10-18");
        new TransferSendout("DB-204", "DB-206", true).transfer("2010-10-21"); 
        new TransferPayout("DB-204", "DB-206", true).transfer("2010-10-21");
        new TransferSendout("DB-204", "DB-206", true).transfer("2010-10-24"); 
        new TransferPayout("DB-204", "DB-206", true).transfer("2010-10-24");
        new TransferSendout("DB-204", "DB-206", true).transfer("2010-10-25"); 
        new TransferSendout("DB-204", "DB-206", true).transfer("2010-10-27"); 
        new TransferSendout("DB-204", "DB-206", true).transfer("2010-10-28"); 
        new TransferSendout("DB-204", "DB-206", true).transfer("2010-10-29"); 
        new TransferSendout("DB-204", "DB-206", true).transfer("2010-10-30"); 
        new TransferSendout("DB-204", "DB-206", true).transfer("2010-10-31"); 
        
    }
}
