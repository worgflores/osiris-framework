package test;

import com.mlhuillier.main.MLKPTrimHelper;
import junit.framework.*;

public class MLKPRemoverTest extends TestCase 
{
    
    public MLKPRemoverTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
    }

    protected void tearDown() throws Exception {
    }
    
    public void test0000() throws Exception 
    {
        MLKPTrimHelper.main(new String[]{"DB-TRIM", "2009-02-17", "2009-12-31"});
    }

}
