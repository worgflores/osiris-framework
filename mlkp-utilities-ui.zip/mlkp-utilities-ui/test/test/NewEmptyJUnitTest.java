package test;

import java.io.InputStream;
import java.net.URL;
import java.rmi.server.UID;
import java.security.MessageDigest;
import junit.framework.*;

public class NewEmptyJUnitTest extends TestCase 
{
    
    public NewEmptyJUnitTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception 
    {
        
    }

    protected void tearDown() throws Exception {
    }
    
    private String createHash(String value) throws Exception 
    {
        MessageDigest md = MessageDigest.getInstance("MD5");
        md.update(value.getBytes());
        byte[] hash = md.digest();

        String hexDigit = "0123456789abcdef";
        StringBuffer sb = new StringBuffer(hash.length);
        for (int i=0; i< hash.length; i++) 
        {
            int b = hash[i] & 0xFF;
            sb.append(hexDigit.charAt(b >>> 4));
            sb.append(hexDigit.charAt(b & 0xF));
        }
        return sb.toString();
    }    
    
    public void xtest000() throws Exception 
    {
        String username = createHash("mlkp_iremit");
        String password = createHash("mlkp1q2w3e");
        String refno = "NAFEX0000184490";
        String path = "http://192.168.3.211:8080/wsproxy/redirect/" + 
                      "http://intranet2.iremit-inc.com/mlkp_ntp/mlkp_ntp_update.php" + 
                      "?ml_ntp_psswd="+password+"&ml_ntp_uname="+username+"&trans_id="+refno; 
        
        
        InputStream in = null;
        try 
        {
            URL url = new URL(path);
            in = url.openStream(); 
            
            int i = -1;
            StringBuffer sb = new StringBuffer();
            while ((i=in.read()) != -1) { 
                sb.append((char)i);
            }
            System.out.println(sb);
            
            if ("0".equals(sb.toString())) {
                System.out.println("Updated successfully");
            } else if("1".equals(sb.toString())) {
                System.out.println("Unable to update ccrefno");				
            } else if("2".equals(sb.toString())) {
                System.out.println("Invalid username and password");
            }	            
        }
        catch(Exception ex) {
            throw ex;
        }
        finally {
            try { in.close(); }catch(Exception ing){;}
        }
    }
    
    public void test0002() throws Exception
    {
        //DB-01FUENT1-10-999999
        System.out.println("-".hashCode());
//        for (int i=0; i<100; i++)
//        {
//            String uid = "D2B" + new UID(); 
//            System.out.println(uid + " => " + uid.hashCode());
//            Thread.sleep(500);
//        }
    }

}
