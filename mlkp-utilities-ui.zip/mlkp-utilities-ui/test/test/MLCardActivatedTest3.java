package test;

import com.mlhuillier.util.migration2.BuildSendoutPrincipalRangeUSD;
import com.mlhuillier.util.migration2.mlkyc.TransferMLCardActivated;
import junit.framework.*;

public class MLCardActivatedTest3 extends TestCase 
{
    
    public MLCardActivatedTest3(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
    }

    protected void tearDown() throws Exception {
    }
    
    public void test0000() throws Exception
    {
        new TransferMLCardActivated("DB-206").transfer(4000000);
    }
}
