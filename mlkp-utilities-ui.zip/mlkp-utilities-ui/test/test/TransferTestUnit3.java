package test;

import com.mlhuillier.util.migration2.TransferPayout;
import com.mlhuillier.util.migration2.TransferSendout;
import junit.framework.*;

public class TransferTestUnit3 extends TestCase 
{
    
    public TransferTestUnit3(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
    }

    protected void tearDown() throws Exception {
    }
    
    public void xtestSendout() throws Exception 
    {
        for (int day=1; day<=10; day++)
        {
            String sday = day+"";
            if (day < 10) sday = "0"+day;
            
            String sdate = "2010-11-" + sday;
            while (true)
            {
                System.out.println("transferring sendout 204-206: ["+sdate+"]...");
                new TransferSendout("DB-204", "DB-206").transfer(sdate);    
                break;
            }
        }         
    }
    
    public void xtestPayout() throws Exception 
    {
        new TransferPayout("DB-204", "DB-206").transferRecord("POUT1787a634:12b8a94832b:455e"); 
        
        for (int day=8; day<=31; day++)
        {
            String sday = day+"";
            if (day < 10) sday = "0"+day;
            
            String sdate = "2010-10-" + sday;
            while (true)
            {
                System.out.println("transferring payout 204-206: ["+sdate+"]...");
                new TransferPayout("DB-204", "DB-206").transfer(sdate);    
                break;
            }
        } 
    }    
    
    public void test000() throws Exception
    {
        String s = "REF. 1234567890".toLowerCase();
        if (s.startsWith("ref. "))
            s = s.substring(5);
        
        System.out.println(s);
    }
}
