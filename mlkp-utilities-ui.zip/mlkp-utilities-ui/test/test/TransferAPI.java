package test;

import com.mlhuillier.util.migration2.IDataTransfer;
import com.mlhuillier.util.migration2.TransferBillsPayment;
import com.mlhuillier.util.migration2.TransferBillsPaymentCancelled;
import com.mlhuillier.util.migration2.TransferBillsPaymentInvalidated;
import com.mlhuillier.util.migration2.TransferChangeRequest;
import com.mlhuillier.util.migration2.TransferPayout;
import com.mlhuillier.util.migration2.TransferPayoutCreditRemote;
import com.mlhuillier.util.migration2.TransferPerson;
import com.mlhuillier.util.migration2.TransferRTS;
import com.mlhuillier.util.migration2.TransferSendout;
import com.mlhuillier.util.migration2.TransferSendoutCancel;
import com.mlhuillier.util.migration2.TransferSendoutCreditRemote;
import com.mlhuillier.util.migration2.TransferSendoutInvalidate;
import com.mlhuillier.util.migration2.TransferUniTeller;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class TransferAPI 
{
    
    public void transferAll(String startdate, String enddate, String sourceDS, String targetDS) throws Exception
    {
        Date dtstart = java.sql.Date.valueOf(startdate);
        Date dtend = java.sql.Date.valueOf(enddate);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Calendar cal = new GregorianCalendar();
        cal.setTime(dtstart);

        while (true)
        {
            Date dt = cal.getTime(); 
            if (dt.after(dtend)) break;

            String date = sdf.format(dt);

            System.out.println("Starting changerequest... ["+date+"]");
            IDataTransfer idt = new TransferChangeRequest(sourceDS, targetDS);
            idt.transfer(date);                

            System.out.println("Starting person... ["+date+"]");
            idt = new TransferPerson(sourceDS, targetDS);
            idt.transfer(date);

            System.out.println("Starting sendout... ["+date+"]");
            idt = new TransferSendout(sourceDS, targetDS);
            idt.transfer(date);

            System.out.println("Starting sendoutcancel... ["+date+"]");
            idt = new TransferSendoutCancel(sourceDS, targetDS);
            idt.transfer(date);            

            System.out.println("Starting sendoutcredit... ["+date+"]");
            idt = new TransferSendoutCreditRemote(sourceDS, targetDS);
            idt.transfer(date);            

            System.out.println("Starting sendoutinvalidate... ["+date+"]");
            idt = new TransferSendoutInvalidate(sourceDS, targetDS);
            idt.transfer(date);            

            System.out.println("Starting returntosender... ["+date+"]");
            idt = new TransferRTS(sourceDS, targetDS);
            idt.transfer(date);            

            System.out.println("Starting payout... ["+date+"]");
            idt = new TransferPayout(sourceDS, targetDS);
            idt.transfer(date);     

            System.out.println("Starting payoutcredit... ["+date+"]");
            idt = new TransferPayoutCreditRemote(sourceDS, targetDS);
            idt.transfer(date); 

            System.out.println("Starting uniteller... ["+date+"]");
            idt = new TransferUniTeller(sourceDS, targetDS);
            idt.transfer(date);

            System.out.println("Starting billspayment... ["+date+"]");
            idt = new TransferBillsPayment(sourceDS, targetDS);
            idt.transfer(date);                

            System.out.println("Starting billspaymentcancelled... ["+date+"]");
            idt = new TransferBillsPaymentCancelled(sourceDS, targetDS);
            idt.transfer(date);                                

            System.out.println("Starting billspaymentinvalidated... ["+date+"]");
            idt = new TransferBillsPaymentInvalidated(sourceDS, targetDS);
            idt.transfer(date);                                                

            cal.add(Calendar.DATE, 1);
        }
    }
}
