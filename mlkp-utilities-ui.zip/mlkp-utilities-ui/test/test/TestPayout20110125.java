package test;

import com.mlhuillier.util.DBConfig;
import com.mlhuillier.util.migration2.DataService;
import java.sql.Connection;
import java.util.List;
import java.util.Map;
import junit.framework.*;

public class TestPayout20110125 extends TestCase 
{
    
    public TestPayout20110125(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
    }

    protected void tearDown() throws Exception {
    }
    
    public void xtest0000() throws Exception
    {
        DBConfig dbconfig = new DBConfig();
        DataService ds = new DataService();
        Connection conn = null;
        try
        {
            conn = dbconfig.createConnection("DB-204"); 
            
            String sql = " select b.objid " +  
                         " from (select strorganizationid from mlkp.tblcharge where dteffectivefrom between '2011-01-25 00:00:00' and '2011-01-25 23:59:59'  order by strorganizationid)bt " + 
                         "     inner join mlkp.tblbranch b on bt.strorganizationid=b.strorganizationid " + 
                         " order by b.objid "; 
            List list = ds.getList(conn, sql); 
            while (!list.isEmpty())
            {
                String branchid = ((Map) list.remove(0)).get("objid").toString(); 
                sql = " select strcurrencyid, ifnull(sum(curprincipal),0.0) as curprincipal, count(objid) as intcount " + 
                      " from ( " + 
                      "        select bt.*,  (select strcurrencyid from mlkp.tblsendoutinfo where objid=bt.objid) as strcurrencyid " + 
                      "        from ( " + 
		      "               select objid, strbranchid, curprincipal from mlkp.tblsendout " + 
		      "               where dtfiled between '2011-01-25 00:00:00' and '2011-01-25 23:59:59' " + 
		      "               having strbranchid='"+branchid+"' and curprincipal > 100000.0 " + 
		      "             )bt " + 
                      "      )bt " + 
                      " group by strcurrencyid " + 
                      " having intcount > 0 "; 

                Map data = ds.getSingleResult(conn, sql); 
                if (data != null) 
                {
                    System.out.println(branchid + ": " + data); 
                    //System.out.println(branchid + ":  [count=" + data.get("intcount") + ", totalamount=" + data.get("curprincipal") + "]"); 
                }
            }
            
        }
        catch(Exception ex) {
            throw ex; 
        }
        finally {
            try { conn.close(); }catch(Exception ign){;} 
        }
    }
    
    public void test0001() throws Exception
    {
        DBConfig dbconfig = new DBConfig();
        DataService ds = new DataService();
        Connection conn = null;
        try
        {
            conn = dbconfig.createConnection("DB-204"); 
            
            String sql = " select bt.*,  (select strcurrencyid from mlkp.tblsendoutinfo where objid=bt.objid) as strcurrencyid " + 
                      "    from ( " + 
		      "           select objid, strkptn, dtfiled, strbranchid, curprincipal from mlkp.tblsendout " + 
		      "           where dtfiled between '2011-01-25 00:00:00' and '2011-01-25 23:59:59' " + 
		      "           having strbranchid='fsd46' and curprincipal > 100000.0 " + 
		      "         )bt "; 

            List list = ds.getList(conn, sql); 
            while (!list.isEmpty())
            {
                System.out.println(list.remove(0));
            }
            
        }
        catch(Exception ex) {
            throw ex; 
        }
        finally {
            try { conn.close(); }catch(Exception ign){;} 
        }
    }    
}
