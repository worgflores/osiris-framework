package test;

import junit.framework.*;

public class BDOSendoutUpdaterTest extends TestCase {
    
    public BDOSendoutUpdaterTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
    }

    protected void tearDown() throws Exception {
    }
    
    public void test0000() throws Exception 
    {
        BDOSendoutUpdater ts = new BDOSendoutUpdater("DB-206");
        ts.transfer("2010-07-16");        
    }

}
