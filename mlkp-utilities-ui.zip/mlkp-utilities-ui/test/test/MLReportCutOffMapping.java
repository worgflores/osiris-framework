package test;

import com.mlhuillier.util.DBConfig;
import com.mlhuillier.util.migration2.DataService;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Map;
import junit.framework.*;

public class MLReportCutOffMapping extends TestCase 
{
    
    private String srcDS = "DB-204";
    private String destDS = "DB-212";
    private DBConfig dbConfig = null; 
    private DataService dataService = null; 
    
    public MLReportCutOffMapping(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception 
    { 
        dbConfig = new DBConfig(); 
        dataService = new DataService(); 
    }

    protected void tearDown() throws Exception {
    }
    
    public void testfirst() throws Exception 
    {
        int hashcode = "".hashCode(); 
        String shashcode = hashcode+""; 
        shashcode = shashcode.replaceAll("-","45"); 
    } 

    public void xtest0() throws Exception 
    { 
        Date dtfrom = java.sql.Date.valueOf("2011-01-01");
        Date dtto   = java.sql.Date.valueOf("2020-12-31");
        Connection conn = null;
        
        try 
        {
            conn = dbConfig.createConnection(srcDS);
            
            SimpleDateFormat YMD = new SimpleDateFormat("yyyy-MM-dd"); 
            Calendar cal = new GregorianCalendar(); 
            cal.setTime(dtfrom);
            while (true)
            {
                Date dt = cal.getTime();
                if (dt.after(dtto)) break;

                String sdate = YMD.format(dt); 
                buildCutOffMapping(conn, sdate); 
                cal.add(Calendar.DATE, 1);
            }
        }
        catch(Exception ex) 
        {
            System.out.println("[ERROR] " + ex.getClass().getName() + ": " +  ex.getMessage());
        } 
        finally
        {
            try { conn.close(); }catch(Exception ign){;} 
        }        
    } 

    private int buildCutOffMapping(Connection conn, String sdate) throws Exception
    {
        DataService dataService = new DataService(); 
        PreparedStatement ps = null;
        
        try
        {
            String[] dates = sdate.split("-");
            String startdate = sdate + " 00:00:00";
            String enddate   = sdate + " 23:59:59";
            
            ps = conn.prepareStatement(" insert into mlreport.tblcutoffmapping (intyear, intmonth, intday, dtstartdate, dtenddate) " + 
                                       " values (?, ?, ?, ?, ?) ");
            ps.setObject(1, dates[0]);
            ps.setObject(2, dates[1]);
            ps.setObject(3, dates[2]);
            ps.setObject(4, startdate);
            ps.setObject(5, enddate);
            int rowsaffected = ps.executeUpdate(); 
            return rowsaffected; 
        } 
        catch(Exception ex) 
        {
            System.out.println("[ERROR] " + ex.getClass().getName() + ": " +  ex.getMessage());
            return 0;
        } 
        finally {
            try { ps.close(); }catch(Exception ign){;} 
        } 
    } 
    
    private void copyData(String tblName, String fromDS, String toDS) throws Exception {
        copyData(tblName, tblName, fromDS, toDS); 
    }    
    
    private void copyData(String fromTbl, String toTbl, String fromDS, String toDS) throws Exception
    {
        Connection conn = null;
        Connection connDest = null; 
        DBConfig dbConfig = new DBConfig(); 
        DataService dataService = new DataService(); 

        try
        {
            conn = dbConfig.createConnection(fromDS);
            connDest = dbConfig.createConnection(toDS);

            System.out.println("copying data "+fromTbl+" to "+ toTbl +"...");
            String sql = "select * from " + fromTbl; 

            dataService.exec(connDest, "set FOREIGN_KEY_CHECKS=0"); 
            dataService.transferData(conn, connDest, sql, toTbl, true); 
        }
        catch(Exception ex) 
        {
            System.out.println("[ERROR] " + ex.getClass().getName() + ": " +  ex.getMessage());
        } 
        finally
        {
            try { dataService.exec(connDest, "set FOREIGN_KEY_CHECKS=1"); }catch(Exception ign){;} 
            try { conn.close(); }catch(Exception ign){;} 
            try { connDest.close(); }catch(Exception ign){;} 
        }
    } 
    
    private void copyData(String dbName) throws Exception
    {
        Connection conn = null;
        Connection connDest = null; 
        DBConfig dbConfig = new DBConfig(); 
        DataService dataService = new DataService(); 
        
        try
        {
            conn = dbConfig.createConnection(srcDS);
            connDest = dbConfig.createConnection(destDS);
            
            dataService.exec(connDest, "set FOREIGN_KEY_CHECKS=0"); 
            dataService.exec(connDest, "use " + dbName);
                
            System.out.println("[copying "+dbName+"]");
            List tables = dataService.getList(conn, "show tables from " + dbName);
            while (!tables.isEmpty())
            {
                String tblName = ((Map) tables.remove(0)).get("Tables_in_" + dbName).toString(); 
                String tblSource = dbName + "." + tblName;    
                
                try 
                {
                    System.out.println("   transferring data from " + tblSource);
                    dataService.transferData(conn, connDest, "select * from " + tblSource, tblSource, true);
                }
                catch(Exception ex) { 
                    System.out.println("[ERROR] " + ex.getMessage()); 
                } 
            }
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { dataService.exec(connDest, "set FOREIGN_KEY_CHECKS=1"); }catch(Exception ign){;} 
            try { conn.close(); }catch(Exception ign){;} 
            try { connDest.close(); }catch(Exception ign){;} 
        }
    }    
        
    private void transferData(String sql, String toTblName, String fromDS, String toDS) throws Exception
    {
        Connection conn = null;
        Connection connDest = null; 
        DBConfig dbConfig = new DBConfig(); 
        DataService dataService = new DataService(); 

        try
        {
            conn = dbConfig.createConnection(fromDS);
            connDest = dbConfig.createConnection(toDS);

            System.out.println("transferring data "+sql+" to "+ toTblName +"...");
            dataService.transferData(conn, connDest, sql, toTblName, true); 
        }
        catch(Exception ex) 
        {
            System.out.println("[ERROR] " + ex.getClass().getName() + ": " +  ex.getMessage());
        } 
        finally
        {
            try { conn.close(); }catch(Exception ign){;} 
            try { connDest.close(); }catch(Exception ign){;} 
        }
    } 
    
}
