
select 	
	cardno, 
	cardtype, 
	dtfiled, 
	filedby, 
	branchfiled, 
	dtissued, 
	dtexpire, 
	custid, 
	state
from 
	mlkyc.customercard 
