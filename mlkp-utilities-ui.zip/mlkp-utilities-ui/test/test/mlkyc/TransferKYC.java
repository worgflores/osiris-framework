package test.mlkyc;

import com.mlhuillier.util.DBConfig;
import com.mlhuillier.util.migration2.DataService;
import java.io.InputStream;
import java.sql.Connection;
import java.text.SimpleDateFormat;
import junit.framework.*;

public class TransferKYC extends TestCase 
{
    private SimpleDateFormat YMD = new SimpleDateFormat("yyyy-MM-dd"); 
    private DataService dataService = new DataService();
    private DBConfig dbconfig = new DBConfig();
    
    public TransferKYC(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
    }

    protected void tearDown() throws Exception {
    }
    
    public void xtest00001() throws Exception
    {
        DBConfig dbconfig = new DBConfig(); 
        Connection conn1 = null;
        Connection conn2 = null;
        
        try
        { 
            System.out.println(getClass().getSimpleName() + " started...");
            conn1 = dbconfig.createConnection("DEV-1262"); 
            conn2 = dbconfig.createConnection("DB-188"); 
            
            System.out.println("transferring customer...");
            dataService.transferData(conn1, conn2, getResourceContent("kyc-customer-select.sql"), "mlkyc.customer"); 
            System.out.println("transferring customercard...");
            dataService.transferData(conn1, conn2, getResourceContent("kyc-customercard-select.sql"), "mlkyc.customercard"); 
        }
        catch(Exception ex) {
            throw ex; 
        }
        finally 
        {
            try { conn1.close(); }catch(Exception ex) {;} 
            try { conn2.close(); }catch(Exception ex) {;} 
            
            System.out.println(getClass().getSimpleName() + " finished.");
        }
    }

    private String getResourceContent(String name) throws Exception
    {
        InputStream in = getClass().getResourceAsStream(name); 
        if (in == null) return null; 
        
        int read = -1;
        StringBuffer sb = new StringBuffer(); 
        while ((read=in.read()) != -1) { sb.append((char) read);  }
        
        return sb.toString();
        
    }
    
}
