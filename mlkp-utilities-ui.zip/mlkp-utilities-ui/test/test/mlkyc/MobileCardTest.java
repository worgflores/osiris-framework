package test.mlkyc;

import com.mlhuillier.util.DBConfig;
import com.mlhuillier.util.migration2.DataService;
import java.sql.Connection;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Map;
import junit.framework.*;

public class MobileCardTest extends TestCase 
{
    private SimpleDateFormat YMD = new SimpleDateFormat("yyyy-MM-dd"); 
    private DataService dataService = new DataService();
    
    public MobileCardTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
    }

    protected void tearDown() throws Exception {
    }
    
    public void xtest00001() throws Exception
    {
        DBConfig dbconfig = new DBConfig(); 
        Connection conn = null;
        
        try
        { 
            System.out.println(getClass().getSimpleName() + " started...");
            conn = dbconfig.createConnection("DB-204"); 
            
            DecimalFormat dec = new DecimalFormat("000000000000"); 
            long counter = 1;
            List list = dataService.getList(conn, "select objid from mlpartner.tblmobilecard order by dtfiled");
            while (!list.isEmpty())
            {
                String objid = ((Map) list.remove(0)).get("objid").toString();
                dataService.exec(conn, "update mlpartner.tblmobilecard set strseries='"+dec.format(counter)+"' where objid='"+objid+"'"); 
                counter += 1;
            }
        }
        catch(Exception ex) {
            throw ex; 
        }
        finally 
        {
            try { conn.close(); }catch(Exception ex) {;} 
            
            System.out.println(getClass().getSimpleName() + " finished.");
        }
    }

}
