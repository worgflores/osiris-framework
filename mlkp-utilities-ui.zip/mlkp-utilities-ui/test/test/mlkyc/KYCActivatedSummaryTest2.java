package test.mlkyc;

import com.mlhuillier.util.DBConfig;
import com.mlhuillier.util.migration2.DataService;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import junit.framework.*;

public class KYCActivatedSummaryTest2 extends TestCase 
{
    private SimpleDateFormat YMD = new SimpleDateFormat("yyyy-MM-dd"); 
    private DataService dataService = new DataService();
    
    public KYCActivatedSummaryTest2(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
    }

    protected void tearDown() throws Exception {
    }
    
    public void xtest00001() throws Exception
    {
        DBConfig dbconfig = new DBConfig(); 
        Connection conn = null;
        
        Date dtfrom = java.sql.Date.valueOf("2009-03-01"); 
        Date dtto   = java.sql.Date.valueOf("2010-11-30"); 
        
        try
        { 
            System.out.println(getClass().getSimpleName() + " started...");
            conn = dbconfig.createConnection("DB-206"); 
            
            
            Calendar cal = new GregorianCalendar();
            cal.setTime(dtfrom);
            while (true)
            {
                Date dt = cal.getTime();
                if (dt.after(dtto)) break;
                
                String sdate = YMD.format(dt); 
                System.out.println("   processing " + sdate + "...");
                build(conn, sdate); 
                cal.add(Calendar.DATE, 1); 
            }
        }
        catch(Exception ex) {
            throw ex; 
        }
        finally 
        {
            try { conn.close(); }catch(Exception ex) {;} 
            
            System.out.println(getClass().getSimpleName() + " finished.");
        }
    }
    
    private void build(Connection conn, String sdate) throws Exception
    {
        dataService.exec(conn, "delete from test.kyc_activatedsummary where dtfiled='"+sdate+"'");
        
        Calendar cal = new GregorianCalendar(); 
        cal.setTime(java.sql.Date.valueOf(sdate)); 
        cal.set(Calendar.DATE, cal.getActualMaximum(Calendar.DATE)); 
        String lastdate = YMD.format(cal.getTime()); 
        
        StringBuffer sql = new StringBuffer(); 
        sql.append(" insert ignore into test.kyc_activatedsummary ");
        sql.append(" ( "); 
        sql.append("    dtfiled, branchid, areaid, regionid, loopid, ");
        sql.append("    branchdesc, areadesc, regiondesc, loopdesc, icount ");
        sql.append(" ) "); 
        sql.append(" select "); 
        sql.append(" 	bt.dtfiled, bt.branchid, a.objid as areaid, r.objid as regionid, r.parentid as loopid, "); 
        sql.append(" 	b.strdescription as branchdesc, a.strcode as areadesc, r.strcode as regiondesc, "); 
        sql.append(" 	r.parentid as loopdesc, bt.icount "); 
        sql.append(" from (  "); 
        sql.append("            select  "); 
        sql.append(" 		    date_format(cc.dtfiled,'%Y-%m-%d') as dtfiled,  "); 
        sql.append(" 		    ifnull(cc.branchfiled,c.branch) as branchid, sum(bt.icount) as icount  "); 
        sql.append(" 		from (  "); 
        sql.append(" 		         select cardno, custid, state, '"+lastdate+"' as dtcurrent, 1 as icount    "); 
        sql.append(" 			 from mlkyc.customercard  "); 
        sql.append(" 			 where dtfiled between '"+sdate+" 00:00:00' and  "); 
        sql.append(" 			                       '"+sdate+" 23:59:59' ");  
        sql.append(" 			 having state=1  "); 
        sql.append(" 		     ) bt  "); 
        sql.append(" 		    inner join mlkyc.customercard cc on bt.cardno=cc.cardno  "); 
        sql.append(" 		    inner join mlkyc.customer c on (bt.custid=c.custno  and c.activated=1)  "); 
        //sql.append(" 		where  "); 
        //sql.append(" 		    date_format(c.dtcreated,'%Y-%m-%d')=date_format(cc.dtfiled,'%Y-%m-%d') and  "); 
        //sql.append(" 		    c.id1_expirydate > bt.dtcurrent   "); 
        sql.append(" 		group by dtfiled, branchid  "); 
        sql.append(" 	 )bt  "); 
        sql.append(" 	inner join mlkp.tblbranch b on bt.branchid=b.objid  "); 
        sql.append(" 	inner join mlkp.tblarea a on b.parentid=a.objid  "); 
        sql.append(" 	inner join mlkp.tblregion r on a.parentid=r.objid  "); 
        
        //if (true) throw new Exception(sql.toString()); 
    
        dataService.exec(conn, sql.toString()); 
    }    
    
    private void insert(Connection conn, String dtfiled, String[] data) throws Exception
    {
        PreparedStatement ps = null;
        
        try
        {
            ps = conn.prepareStatement(" insert into test.kyc_activatedsummary (dtfiled,branchid,regiondesc,loopdesc,loopid,icount) " + 
                                       " values (?,?,?,?,?,?) "); 
            ps.setObject(1, dtfiled);
            ps.setObject(2, decode(data[2]));
            ps.setObject(3, decode(data[1]));
            ps.setObject(4, decode(data[0]));
            ps.setObject(5, decode(data[0]));
            ps.setObject(6, Long.valueOf(decode(data[3])));
            ps.executeUpdate(); 
        }
        catch(Exception ex) { 
            System.out.println("[ERROR] " + ex.getMessage());
        } 
        finally { 
            try { ps.close(); }catch(Exception ign){;} 
        } 
    }
    
    private String decode(String value)
    {
        if (value == null) return value; 
        if (value.length() <= 2) return value;
        if (value.startsWith("\"") && value.endsWith("\"")) 
            return value.substring(1, value.length()-1); 
        else
            return value; 
    }
}
