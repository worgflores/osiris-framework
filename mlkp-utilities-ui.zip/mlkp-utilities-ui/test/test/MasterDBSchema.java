package test;

import com.mlhuillier.util.DBConfig;
import com.mlhuillier.util.migration2.DataService;
import java.sql.Connection;
import java.util.List;
import java.util.Map;
import junit.framework.*;

public class MasterDBSchema extends TestCase 
{
    
    private String srcDS = "DB-204";
    private String destDS = "DB-212";
    
    public MasterDBSchema(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
    }

    protected void tearDown() throws Exception {
    }

    public void test0() throws Exception 
    { 
        //copyTableStructures("mlreward", "DB-204", "DEV-1263"); 
        //copyTableStructure("mlreport", "tblbirrate", "DB-204", "DEV-1263"); 
        
        //copyData("mlkp_admin.sys_user_permission", "mlkp_admin.sys_user_permission", "DB-204", "DEV-1263"); 
        //transferData("select * from mlkp_admin.sys_screen where scrname like '%mobilecard%' order by scrname", "mlkp_admin.sys_screen", "DEV-1263", "DB-204");  
        //transferData("select * from mlkp_admin.sys_rule where rulename like '%mobilecard%' order by rulename", "mlkp_admin.sys_rule", "DEV-1263", "DB-204");  
    } 
    
    public void xtest0000() throws Exception 
    { 
//        copyTableStructures("mlkp", "DB-204", "DEV-1263");
//        copyData("test_mlkp.qryunclaim", "mlkp.qryunclaim", "DEV-1263", "DEV-1263");
//        copyData("test_mlkp.tblarea", "mlkp.tblarea", "DEV-1263", "DEV-1263");
//        copyData("test_mlkp.tblbranch", "mlkp.tblbranch", "DEV-1263", "DEV-1263");
//        copyData("test_mlkp.tblbranchoption", "mlkp.tblbranchoption", "DEV-1263", "DEV-1263");
//        copyData("test_mlkp.tblbranchterminal", "mlkp.tblbranchterminal", "DEV-1263", "DEV-1263");
//        copyData("test_mlkp.tblbranchtinmapping", "mlkp.tblbranchtinmapping", "DEV-1263", "DEV-1263");
//        copyData("test_mlkp.tblbranchuser", "mlkp.tblbranchuser", "DEV-1263", "DEV-1263");
//        copyData("test_mlkp.tblbusinesspartner", "mlkp.tblbusinesspartner", "DEV-1263", "DEV-1263");
//        copyData("test_mlkp.tblbusinesspartnerpermission", "mlkp.tblbusinesspartnerpermission", "DEV-1263", "DEV-1263");
//        copyData("test_mlkp.tblcancelpayout", "mlkp.tblcancelpayout", "DEV-1263", "DEV-1263");
//        copyData("test_mlkp.tblcancelsendout", "mlkp.tblcancelsendout", "DEV-1263", "DEV-1263");
//        copyData("test_mlkp.tblchangerequest", "mlkp.tblchangerequest", "DEV-1263", "DEV-1263");
//        copyData("test_mlkp.tblchangerequestchargesetting", "mlkp.tblchangerequestchargesetting", "DEV-1263", "DEV-1263");
//        copyData("test_mlkp.tblchangerequestlock", "mlkp.tblchangerequestlock", "DEV-1263", "DEV-1263");
//        copyData("test_mlkp.tblchangerequestor", "mlkp.tblchangerequestor", "DEV-1263", "DEV-1263");
//        copyData("test_mlkp.tblchangerequestseries", "mlkp.tblchangerequestseries", "DEV-1263", "DEV-1263");
//        copyData("test_mlkp.tblcharge", "mlkp.tblcharge", "DEV-1263", "DEV-1263");
//        copyData("test_mlkp.tblchargedetail", "mlkp.tblchargedetail", "DEV-1263", "DEV-1263");
//        copyData("test_mlkp.tblcontrol", "mlkp.tblcontrol", "DEV-1263", "DEV-1263");
//        copyData("test_mlkp.tblcreditpayouttoremote", "mlkp.tblcreditpayouttoremote", "DEV-1263", "DEV-1263");
//        copyData("test_mlkp.tblcreditsendouttoremote", "mlkp.tblcreditsendouttoremote", "DEV-1263", "DEV-1263");
//        copyData("test_mlkp.tblcurrency", "mlkp.tblcurrency", "DEV-1263", "DEV-1263");
//        copyData("test_mlkp.tblforexclassification", "mlkp.tblforexclassification", "DEV-1263", "DEV-1263");
//        copyData("test_mlkp.tblforexgroup", "mlkp.tblforexgroup", "DEV-1263", "DEV-1263");
//        copyData("test_mlkp.tblforexgroupbranch", "mlkp.tblforexgroupbranch", "DEV-1263", "DEV-1263");
//        copyData("test_mlkp.tblforexgroupitem", "mlkp.tblforexgroupitem", "DEV-1263", "DEV-1263");
//        copyData("test_mlkp.tblforexgroupsetting", "mlkp.tblforexgroupsetting", "DEV-1263", "DEV-1263");
//        copyData("test_mlkp.tblforexrate", "mlkp.tblforexrate", "DEV-1263", "DEV-1263");
//        copyData("test_mlkp.tblforexratedemo", "mlkp.tblforexratedemo", "DEV-1263", "DEV-1263");
//        copyData("test_mlkp.tblforexratedemohistory", "mlkp.tblforexratedemohistory", "DEV-1263", "DEV-1263");
//        copyData("test_mlkp.tblforexrateformula", "mlkp.tblforexrateformula", "DEV-1263", "DEV-1263");
//        copyData("test_mlkp.tblforexrateformulahistory", "mlkp.tblforexrateformulahistory", "DEV-1263", "DEV-1263");
//        copyData("test_mlkp.tblforexratehistory", "mlkp.tblforexratehistory", "DEV-1263", "DEV-1263");
//        copyData("test_mlkp.tblglobalcurrency", "mlkp.tblglobalcurrency", "DEV-1263", "DEV-1263");
//        copyData("test_mlkp.tblglobalrate", "mlkp.tblglobalrate", "DEV-1263", "DEV-1263");
//        copyData("test_mlkp.tblglobalratehistory", "mlkp.tblglobalratehistory", "DEV-1263", "DEV-1263");
//        copyData("test_mlkp.tblidtype", "mlkp.tblidtype", "DEV-1263", "DEV-1263");
//        copyData("test_mlkp.tblinvalidatesendout", "mlkp.tblinvalidatesendout", "DEV-1263", "DEV-1263");
//        copyData("test_mlkp.tblkptnlog", "mlkp.tblkptnlog", "DEV-1263", "DEV-1263");
//        copyData("test_mlkp.tblloop", "mlkp.tblloop", "DEV-1263", "DEV-1263");
//        copyData("test_mlkp.tblorganization", "mlkp.tblorganization", "DEV-1263", "DEV-1263");
//        copyData("test_mlkp.tblorgcurrency", "mlkp.tblorgcurrency", "DEV-1263", "DEV-1263");
//        copyData("test_mlkp.tblpartnerfund", "mlkp.tblpartnerfund", "DEV-1263", "DEV-1263");
//        copyData("test_mlkp.tblpartnerfundadj", "mlkp.tblpartnerfundadj", "DEV-1263", "DEV-1263");
//        copyData("test_mlkp.tblpartnerfunddetail", "mlkp.tblpartnerfunddetail", "DEV-1263", "DEV-1263");
//        copyData("test_mlkp.tblpartnerfundlog", "mlkp.tblpartnerfundlog", "DEV-1263", "DEV-1263");
//        copyData("test_mlkp.tblpartnerfundlogger", "mlkp.tblpartnerfundlogger", "DEV-1263", "DEV-1263");
//        copyData("test_mlkp.tblpayout", "mlkp.tblpayout", "DEV-1263", "DEV-1263");
//        copyData("test_mlkp.tblpayoutinfo", "mlkp.tblpayoutinfo", "DEV-1263", "DEV-1263");
//        copyData("test_mlkp.tblperson", "mlkp.tblperson", "DEV-1263", "DEV-1263");
//        copyData("test_mlkp.tblpersonfamilyinfo", "mlkp.tblpersonfamilyinfo", "DEV-1263", "DEV-1263");
//        copyData("test_mlkp.tblpersonkyc", "mlkp.tblpersonkyc", "DEV-1263", "DEV-1263");
//        copyData("test_mlkp.tblpersonworkinfo", "mlkp.tblpersonworkinfo", "DEV-1263", "DEV-1263");
//        copyData("test_mlkp.tblreceiver", "mlkp.tblreceiver", "DEV-1263", "DEV-1263");
//        copyData("test_mlkp.tblregion", "mlkp.tblregion", "DEV-1263", "DEV-1263");
//        copyData("test_mlkp.tblrelationtype", "mlkp.tblrelationtype", "DEV-1263", "DEV-1263");
//        copyData("test_mlkp.tblremotepayout", "mlkp.tblremotepayout", "DEV-1263", "DEV-1263");
//        copyData("test_mlkp.tblremotesendout", "mlkp.tblremotesendout", "DEV-1263", "DEV-1263");
//        copyData("test_mlkp.tblresend", "mlkp.tblresend", "DEV-1263", "DEV-1263");
//        copyData("test_mlkp.tblreturntosender", "mlkp.tblreturntosender", "DEV-1263", "DEV-1263");
//        copyData("test_mlkp.tblsendout", "mlkp.tblsendout", "DEV-1263", "DEV-1263");
//        copyData("test_mlkp.tblsendoutchangecharge", "mlkp.tblsendoutchangecharge", "DEV-1263", "DEV-1263");
//        copyData("test_mlkp.tblsendoutcharge", "mlkp.tblsendoutcharge", "DEV-1263", "DEV-1263");
//        copyData("test_mlkp.tblsendoutext", "mlkp.tblsendoutext", "DEV-1263", "DEV-1263");
//        copyData("test_mlkp.tblsendoutinfo", "mlkp.tblsendoutinfo", "DEV-1263", "DEV-1263");
//        copyData("test_mlkp.tblsendoutoption", "mlkp.tblsendoutoption", "DEV-1263", "DEV-1263");
//        copyData("test_mlkp.tblsendoutor", "mlkp.tblsendoutor", "DEV-1263", "DEV-1263");
//        copyData("test_mlkp.tblsendoutpeeplog", "mlkp.tblsendoutpeeplog", "DEV-1263", "DEV-1263");
//        copyData("test_mlkp.tblsendoutpeeplogitem", "mlkp.tblsendoutpeeplogitem", "DEV-1263", "DEV-1263");
//        copyData("test_mlkp.tblsendoutpeeplogopen", "mlkp.tblsendoutpeeplogopen", "DEV-1263", "DEV-1263");
//        copyData("test_mlkp.tblsendoutreinstated", "mlkp.tblsendoutreinstated", "DEV-1263", "DEV-1263");
//        copyData("test_mlkp.tblsendoutwalkinid", "mlkp.tblsendoutwalkinid", "DEV-1263", "DEV-1263");
//        copyData("test_mlkp.tblstatus", "mlkp.tblstatus", "DEV-1263", "DEV-1263");
//        copyData("test_mlkp.tbltransferterminal", "mlkp.tbltransferterminal", "DEV-1263", "DEV-1263");
//        copyData("test_mlkp.tbltxnlog", "mlkp.tbltxnlog", "DEV-1263", "DEV-1263");
//        copyData("test_mlkp.tbluserterminal", "mlkp.tbluserterminal", "DEV-1263", "DEV-1263");
//        copyData("test_mlkp.tblvoidpayout", "mlkp.tblvoidpayout", "DEV-1263", "DEV-1263");
    }

    public void xtestCopyDatabases() throws Exception
    {
        Connection conn = null; 
        Connection connDest = null; 
        DBConfig dbConfig = new DBConfig(); 
        DataService dataService = new DataService(); 
        
        try 
        { 
            conn = dbConfig.createConnection(srcDS); 
            connDest = dbConfig.createConnection(destDS); 
            
            List list = dataService.getList(conn, "show databases"); 
            while (!list.isEmpty()) 
            { 
                String databaseName = ((Map) list.remove(0)).get("Database").toString(); 
                if (databaseName.equals("mysql") || databaseName.equals("test")) continue; 
                
                try { 
                    dataService.exec(connDest, "create database " + databaseName); 
                } catch(Exception ex) { 
                    System.out.println("[ERROR] " + ex.getMessage()); 
                } 
            } 
        } 
        catch(Exception ex) { 
            throw ex; 
        } 
        finally 
        { 
            try { conn.close(); }catch(Exception ign){;} 
            try { connDest.close(); }catch(Exception ign){;} 
        } 
    } 
    
    public void xtestCopyTables() throws Exception
    { 
        Connection conn = null; 
        Connection connDest = null; 
        DBConfig dbConfig = new DBConfig(); 
        DataService dataService = new DataService(); 
        
        try
        {
            conn = dbConfig.createConnection(srcDS);
            connDest = dbConfig.createConnection(destDS);
            
            dataService.exec(connDest, "set FOREIGN_KEY_CHECKS=0"); 
            
            List dblist = dataService.getList(conn, "show databases");
            while (!dblist.isEmpty()) 
            { 
                String dbName = ((Map) dblist.remove(0)).get("Database").toString(); 
                if (dbName.equals("mysql") || dbName.equals("test")) continue;

                dataService.exec(connDest, "use " + dbName);
                
                System.out.println("["+dbName+"]");
                List tables = dataService.getList(conn, "show tables from " + dbName);
                while (!tables.isEmpty())
                {
                    String tblName = ((Map) tables.remove(0)).get("Tables_in_" + dbName).toString(); 
                    String script = ((Map) dataService.getSingleResult(conn, "show create table " + dbName + "." + tblName)).get("Create Table").toString(); 
                 
                    try { 
                        dataService.exec(connDest, script); 
                    } catch(Exception ex) { 
                        System.out.println("[ERROR] " + ex.getMessage()); 
                    } 
                } 
            } 
        } 
        catch(Exception ex) { 
            throw ex; 
        } 
        finally 
        { 
            try { dataService.exec(connDest, "set FOREIGN_KEY_CHECKS=1"); }catch(Exception ign){;} 
            try { conn.close(); }catch(Exception ign){;} 
            try { connDest.close(); }catch(Exception ign){;} 
        } 
    }
    
    private void copyTableStructures(String dbname, String fromDS, String toDS) throws Exception
    {
        Connection conn = null;
        Connection connDest = null; 
        DBConfig dbConfig = new DBConfig(); 
        DataService dataService = new DataService(); 
        
        try
        {
            conn = dbConfig.createConnection(fromDS);
            connDest = dbConfig.createConnection(toDS);
            
            dataService.exec(connDest, "set FOREIGN_KEY_CHECKS=0"); 
            dataService.exec(connDest, "create database if not exists " + dbname); 
            dataService.exec(connDest, "use " + dbname);
                
            System.out.println("["+dbname+" table structures]");
            List tables = dataService.getList(conn, "show tables from " + dbname);
            while (!tables.isEmpty())
            {
                String tblName = ((Map) tables.remove(0)).get("Tables_in_" + dbname).toString(); 
                System.out.println("copying " + tblName);
                
                String script = ((Map) dataService.getSingleResult(conn, "show create table " + dbname + "." + tblName)).get("Create Table").toString(); 

                try {
                    dataService.exec(connDest, script); 
                } catch(Exception ex) { 
                    System.out.println("[ERROR] " + ex.getMessage()); 
                } 
            }
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { dataService.exec(connDest, "set FOREIGN_KEY_CHECKS=1"); }catch(Exception ign){;} 
            try { conn.close(); }catch(Exception ign){;} 
            try { connDest.close(); }catch(Exception ign){;} 
        }
    }

    private void copyTableStructure(String db, String tblname, String fromDS, String toDS) throws Exception
    {
        Connection conn = null;
        Connection connDest = null; 
        DBConfig dbConfig = new DBConfig(); 
        DataService dataService = new DataService(); 
        
        try
        {
            conn = dbConfig.createConnection(fromDS);
            connDest = dbConfig.createConnection(toDS);
            
            dataService.exec(connDest, "set FOREIGN_KEY_CHECKS=0"); 
            dataService.exec(connDest, "use " + db); 
                
            System.out.println("copying " + db + "." + tblname);

            String script = ((Map) dataService.getSingleResult(conn, "show create table " + db + "." + tblname)).get("Create Table").toString(); 

            try {
                dataService.exec(connDest, script); 
            } catch(Exception ex) { 
                System.out.println("[ERROR] " + ex.getMessage()); 
            } 
        } 
        catch(Exception ex) { 
            throw ex; 
        } 
        finally
        {
            try { dataService.exec(connDest, "set FOREIGN_KEY_CHECKS=1"); }catch(Exception ign){;} 
            try { conn.close(); }catch(Exception ign){;} 
            try { connDest.close(); }catch(Exception ign){;} 
        }
    }
    
    private void copyData(String tblName, String fromDS, String toDS) throws Exception {
        copyData(tblName, tblName, fromDS, toDS); 
    }    
    
    private void copyData(String fromTbl, String toTbl, String fromDS, String toDS) throws Exception
    {
        Connection conn = null;
        Connection connDest = null; 
        DBConfig dbConfig = new DBConfig(); 
        DataService dataService = new DataService(); 

        try
        {
            conn = dbConfig.createConnection(fromDS);
            connDest = dbConfig.createConnection(toDS);

            System.out.println("copying data "+fromTbl+" to "+ toTbl +"...");
            String sql = "select * from " + fromTbl; 

            dataService.exec(connDest, "set FOREIGN_KEY_CHECKS=0"); 
            dataService.transferData(conn, connDest, sql, toTbl, true); 
        }
        catch(Exception ex) 
        {
            System.out.println("[ERROR] " + ex.getClass().getName() + ": " +  ex.getMessage());
        } 
        finally
        {
            try { dataService.exec(connDest, "set FOREIGN_KEY_CHECKS=1"); }catch(Exception ign){;} 
            try { conn.close(); }catch(Exception ign){;} 
            try { connDest.close(); }catch(Exception ign){;} 
        }
    } 
    
    private void copyData(String dbName) throws Exception
    {
        Connection conn = null;
        Connection connDest = null; 
        DBConfig dbConfig = new DBConfig(); 
        DataService dataService = new DataService(); 
        
        try
        {
            conn = dbConfig.createConnection(srcDS);
            connDest = dbConfig.createConnection(destDS);
            
            dataService.exec(connDest, "set FOREIGN_KEY_CHECKS=0"); 
            dataService.exec(connDest, "use " + dbName);
                
            System.out.println("[copying "+dbName+"]");
            List tables = dataService.getList(conn, "show tables from " + dbName);
            while (!tables.isEmpty())
            {
                String tblName = ((Map) tables.remove(0)).get("Tables_in_" + dbName).toString(); 
                String tblSource = dbName + "." + tblName;    
                
                try 
                {
                    System.out.println("   transferring data from " + tblSource);
                    dataService.transferData(conn, connDest, "select * from " + tblSource, tblSource, true);
                }
                catch(Exception ex) { 
                    System.out.println("[ERROR] " + ex.getMessage()); 
                } 
            }
        }
        catch(Exception ex) {
            throw ex;
        }
        finally
        {
            try { dataService.exec(connDest, "set FOREIGN_KEY_CHECKS=1"); }catch(Exception ign){;} 
            try { conn.close(); }catch(Exception ign){;} 
            try { connDest.close(); }catch(Exception ign){;} 
        }
    }    
        
    private void transferData(String sql, String toTblName, String fromDS, String toDS) throws Exception
    {
        Connection conn = null;
        Connection connDest = null; 
        DBConfig dbConfig = new DBConfig(); 
        DataService dataService = new DataService(); 

        try
        {
            conn = dbConfig.createConnection(fromDS);
            connDest = dbConfig.createConnection(toDS);

            System.out.println("transferring data "+sql+" to "+ toTblName +"...");
            dataService.transferData(conn, connDest, sql, toTblName, true); 
        }
        catch(Exception ex) 
        {
            System.out.println("[ERROR] " + ex.getClass().getName() + ": " +  ex.getMessage());
        } 
        finally
        {
            try { conn.close(); }catch(Exception ign){;} 
            try { connDest.close(); }catch(Exception ign){;} 
        }
    } 
    
}
