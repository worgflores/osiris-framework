package test;

import com.mlhuillier.util.migration2.TransferPayout;
import com.mlhuillier.util.migration2.TransferSendout;
import junit.framework.*;

public class TransferTestUnit2 extends TestCase 
{
    
    public TransferTestUnit2(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
    }

    protected void tearDown() throws Exception {
    }
    
    public void test0001() throws Exception 
    {
        new TransferPayout("DB-204", "DB-206").transfer("2010-10-09");
        new TransferPayout("DB-204", "DB-206").transfer("2010-10-11");
        new TransferPayout("DB-204", "DB-206").transfer("2010-10-13");
        new TransferPayout("DB-204", "DB-206").transfer("2010-10-14");
    }
}
