package test;

import com.mlhuillier.util.migration2.TransferSendout;
import junit.framework.*;

public class Test212 extends TestCase 
{
    
    public Test212(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
    }

    protected void tearDown() throws Exception {
    }
    
    public void test000() throws Exception 
    {
        TransferSendout s = new TransferSendout("DB-212", "DB-206"); 
        s.transferRecord("SOUT2ca6e39f:1277e006520:1a16");
    }

}
