CREATE TABLE IF NOT EXISTS test.tblsendoutwalkinid${SUFFIX} 
(
  `objid` varchar(32) NOT NULL default '',
  `stridtype` varchar(50) NOT NULL default '',
  `stridno` varchar(30) NOT NULL default '',
  `stridexpiry` varchar(30) NOT NULL default '',
  PRIMARY KEY  (`objid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1
