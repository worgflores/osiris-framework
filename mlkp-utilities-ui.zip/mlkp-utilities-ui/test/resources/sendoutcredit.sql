CREATE TABLE IF NOT EXISTS test.tblsendoutcredit${SUFFIX}   
(
  `objid` varchar(32) NOT NULL default '',
  `state` int(11) default '1',
  `txndate` datetime default NULL,
  `strrefno` varchar(25) default NULL,
  `strsendoutid` varchar(32) default NULL,
  `strremotebranch` varchar(50) default NULL,
  `strremoteoperator` varchar(50) default NULL,
  `strremoteterminalid` varchar(50) default NULL,
  `strmainbranch` varchar(50) default NULL,
  `strmainoperator` varchar(50) default NULL,
  `strmainterminalid` varchar(50) default NULL,
  PRIMARY KEY  (`objid`),
  KEY `idx_creditsendouttoremote_strsendoutid` (`strsendoutid`),
  KEY `strrefno` (`strrefno`),
  KEY `idx_txndate` (`txndate`),
  CONSTRAINT `tblcreditsendouttoremote_ibfk_1` FOREIGN KEY (`strrefno`) REFERENCES `tblchangerequest` (`strrefno`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1
