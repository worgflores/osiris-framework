CREATE TABLE IF NOT EXISTS test.tblsendoutinfo${SUFFIX} 
(
  `objid` varchar(32) NOT NULL default '',
  `strcurrencyid` char(3) default NULL,
  `strchargecurrencyid` char(3) default NULL,
  `curforex` decimal(15,8) default NULL,
  `strccrefno` varchar(25) default NULL,
  `strfundsource` varchar(15) default NULL,
  `strrelationtoreceiver` varchar(20) default NULL,
  `dtsenderbirthdate` date default NULL,
  `dtreceiverbirthdate` date default NULL,
  `intchargesms` int(11) default '0',
  `strsendermobile` varchar(11) default NULL,
  `strreceivermobile` varchar(11) default NULL,
  `strpurpose` varchar(50) default NULL,
  PRIMARY KEY  (`objid`),
  KEY `ux_strccrefno` (`strccrefno`),
  KEY `FK_tblsendoutinfo` (`strchargecurrencyid`),
  KEY `FK_tblsendoutinfo_currencyid` (`strcurrencyid`),
  CONSTRAINT `tblsendoutinfo_ibfk_1` FOREIGN KEY (`objid`) REFERENCES `tblsendout` (`objid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1