CREATE TABLE IF NOT EXISTS test.tblchangerequest  
(
  `objid` varchar(32) NOT NULL default '',
  `state` smallint(6) default NULL,
  `strkptn` varchar(32) default NULL,
  `strrefno` varchar(25) default NULL,
  `dtfiled` datetime default NULL,
  `strrequesterid` varchar(32) default NULL,
  `inttxntype` smallint(6) default NULL,
  `intinitiator` smallint(6) default NULL,
  `txtreason` text,
  `strchargeto` varchar(50) default NULL,
  `strsendoutid` varchar(32) default NULL,
  `strchargetobranchid` varchar(32) default NULL,
  `strrequesterbranchid` varchar(32) default NULL,
  `strpostedbyid` varchar(32) default NULL,
  `dtposted` datetime default NULL,
  PRIMARY KEY  (`objid`),
  UNIQUE KEY `strrefno` (`strrefno`),
  KEY `strkptn` (`strkptn`),
  KEY `idx_tblchangerequest_dtfiled` (`dtfiled`),
  KEY `strsendoutid` (`strsendoutid`),
  KEY `ix_txntype` (`inttxntype`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1