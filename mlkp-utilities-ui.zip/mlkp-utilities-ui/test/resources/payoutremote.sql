CREATE TABLE IF NOT EXISTS test.tblpayoutremote${SUFFIX}   
(
  `objid` varchar(32) NOT NULL default '',
  `strbranchid` varchar(32) default NULL,
  `stroperatorid` varchar(32) default NULL,
  `strterminalid` varchar(32) default NULL,
  `intreason` smallint(6) default '0',
  PRIMARY KEY  (`objid`),
  KEY `idx_remotepayout_branch` (`strbranchid`),
  KEY `idx_remotepayout_operator` (`stroperatorid`),
  CONSTRAINT `tblremotepayout_ibfk_1` FOREIGN KEY (`objid`) REFERENCES `tblpayout` (`objid`) 
) ENGINE=MyISAM DEFAULT CHARSET=latin1 
