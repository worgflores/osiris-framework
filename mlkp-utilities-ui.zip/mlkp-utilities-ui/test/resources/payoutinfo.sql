CREATE TABLE IF NOT EXISTS test.tblpayoutinfo${SUFFIX}   
(
  `objid` varchar(32) NOT NULL default '',
  `strcurrencyid` varchar(32) default NULL,
  `curforex` decimal(15,8) default NULL,
  `curamtpaid` decimal(12,2) default NULL,
  `strpaycommissionid` varchar(32) default NULL,
  `stridexpiry` varchar(25) default NULL,
  PRIMARY KEY  (`objid`),
  KEY `ix_strpaycommissionid` (`strpaycommissionid`),
  KEY `FK_tblpayoutinfo` (`strcurrencyid`),
  CONSTRAINT `tblpayoutinfo_ibfk_2` FOREIGN KEY (`objid`) REFERENCES `tblpayout` (`objid`) 
) ENGINE=MyISAM DEFAULT CHARSET=latin1
