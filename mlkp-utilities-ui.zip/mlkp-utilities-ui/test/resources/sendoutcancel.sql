CREATE TABLE IF NOT EXISTS test.tblsendoutcancel${SUFFIX}   
(
  `objid` varchar(32) NOT NULL default '',
  `strsendoutid` varchar(32) default NULL,
  `dtcancelled` datetime default NULL,
  `strremarks` varchar(255) default NULL,
  `strrefno` varchar(25) default NULL,
  PRIMARY KEY  (`objid`),
  UNIQUE KEY `idx_tblcancelledsendout_sendoutid` (`strsendoutid`),
  KEY `idx_tblcancelsendout_dtcancelled` (`dtcancelled`),
  KEY `strrefno` (`strrefno`),
  CONSTRAINT `tblcancelsendout_ibfk_1` FOREIGN KEY (`strsendoutid`) REFERENCES `tblsendout` (`objid`),
  CONSTRAINT `tblcancelsendout_ibfk_2` FOREIGN KEY (`strrefno`) REFERENCES `tblchangerequest` (`strrefno`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1
