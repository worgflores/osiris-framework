CREATE TABLE IF NOT EXISTS test.tblsendoutinvalidated${SUFFIX}   
(
  `objid` varchar(32) NOT NULL default '',
  `strsendoutid` varchar(32) NOT NULL default '',
  `intinvalidationtype` smallint(6) default NULL,
  `dtmodified` datetime default NULL,
  `strrefno` varchar(25) default NULL,
  PRIMARY KEY  (`objid`),
  KEY `strsendoutid` (`strsendoutid`),
  KEY `dtmodified` (`dtmodified`),
  CONSTRAINT `tblinvalidatesendout_ibfk_1` FOREIGN KEY (`strsendoutid`) REFERENCES `tblsendout` (`objid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1