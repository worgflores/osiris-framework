CREATE TABLE IF NOT EXISTS test.tblkptnlog  
(
  `txnid` varchar(32) NOT NULL default '',
  `kptn` varchar(32) NOT NULL default '',
  `action` varchar(50) default NULL,
  `uid` varchar(50) default NULL,
  `txndate` datetime default NULL,
  `refid` varchar(32) default NULL,
  `remarks` text,
  `branch` varchar(50) default NULL,
  `terminalid` varchar(50) default NULL,
  PRIMARY KEY  (`txnid`),
  KEY `sendoutid` (`kptn`),
  KEY `txndate` (`txndate`),
  KEY `refid` (`refid`),
  KEY `ix_uid` (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1