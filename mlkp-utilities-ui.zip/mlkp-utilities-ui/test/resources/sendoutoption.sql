CREATE TABLE IF NOT EXISTS test.tblsendoutoption${SUFFIX} 
(
  `objid` varchar(32) NOT NULL default '',
  `intnotifysender` smallint(6) default '0',
  `intnotifyreceiver` smallint(6) default '0',
  `strmessage` varchar(255) default NULL,
  `intusepwd` smallint(6) default NULL,
  `intuseid` smallint(6) default NULL,
  `strpassword` varchar(50) default NULL,
  `strquestion` varchar(100) default NULL,
  `stranswer` varchar(50) default NULL,
  `stridtype` varchar(10) default NULL,
  `stridno` varchar(50) default NULL,
  PRIMARY KEY  (`objid`),
  CONSTRAINT `tblsendoutoption_ibfk_1` FOREIGN KEY (`objid`) REFERENCES `tblsendout` (`objid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1