CREATE TABLE IF NOT EXISTS test.tblpayoutvoid${SUFFIX}   
(
  `objid` varchar(32) NOT NULL default '',
  `strpayoutid` varchar(32) default NULL,
  `dtvoid` datetime default NULL,
  `strrefno` varchar(25) default NULL,
  PRIMARY KEY  (`objid`),
  UNIQUE KEY `idx_voidpayout_strrefno` (`strrefno`),
  KEY `idx_voidpayout_strpayoutid` (`strpayoutid`),
  KEY `idx_voidpayout_dtvoid` (`dtvoid`),
  CONSTRAINT `tblvoidpayout_ibfk_1` FOREIGN KEY (`strrefno`) REFERENCES `tblchangerequest` (`strrefno`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1
