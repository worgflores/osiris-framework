CREATE TABLE IF NOT EXISTS test.tblsendoutor${SUFFIX} 
(
  `objid` varchar(32) NOT NULL default '',
  `strorno` varchar(32) default NULL,
  `dtordate` datetime default NULL,
  PRIMARY KEY  (`objid`),
  KEY `strorno` (`strorno`),
  CONSTRAINT `tblsendoutor_ibfk_1` FOREIGN KEY (`objid`) REFERENCES `tblsendout` (`objid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1
