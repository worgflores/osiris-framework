CREATE TABLE IF NOT EXISTS test.tblsendoutremote${SUFFIX} 
(
  `objid` varchar(32) NOT NULL default '',
  `strbranchid` varchar(32) default NULL,
  `stroperatorid` varchar(32) default NULL,
  `strterminalid` varchar(32) default NULL,
  `intreason` smallint(6) default '0',
  PRIMARY KEY  (`objid`),
  KEY `idx_remotesendout_branch` (`strbranchid`),
  KEY `idx_remotesendout_operator` (`stroperatorid`),
  CONSTRAINT `tblremotesendout_ibfk_1` FOREIGN KEY (`objid`) REFERENCES `tblsendout` (`objid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1