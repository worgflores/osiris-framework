CREATE TABLE IF NOT EXISTS test.tblpayoutcancel${SUFFIX}   
(
  `objid` varchar(32) NOT NULL default '',
  `strpayoutid` varchar(32) default NULL,
  `dtcancelled` datetime default NULL,
  `strreason` text,
  `struserid` varchar(32) default NULL,
  `strterminalid` varchar(32) default NULL,
  `strbranchid` varchar(32) default NULL,
  PRIMARY KEY  (`objid`),
  UNIQUE KEY `strpayoutid` (`strpayoutid`),
  KEY `strbranchid` (`strbranchid`),
  KEY `dtcancelled` (`dtcancelled`),
  CONSTRAINT `tblcancelpayout_ibfk_1` FOREIGN KEY (`strpayoutid`) REFERENCES `tblpayout` (`objid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1