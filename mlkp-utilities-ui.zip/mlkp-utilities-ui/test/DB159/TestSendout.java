package DB159;

import junit.framework.*;

public class TestSendout extends TestCase 
{
    
    public TestSendout(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
    }

    protected void tearDown() throws Exception {
    }
    
    public void test00000() throws Exception 
    {
        new TransferSendout().start("2000-01-01", "2005-12-31"); 
    } 

}
