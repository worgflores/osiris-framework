package DB159;

import java.lang.reflect.Method;
import junit.framework.*;

public class TestPayout200504 extends TestCase 
{
    
    public TestPayout200504(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
    }

    protected void tearDown() throws Exception {
    }
    
    public void test00000() throws Exception 
    {
        new TransferPayout().start("2005-12-21", "2005-12-31"); 
    } 

}
