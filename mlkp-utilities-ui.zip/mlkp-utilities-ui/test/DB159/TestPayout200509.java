package DB159;

import junit.framework.*;

public class TestPayout200509 extends TestCase 
{
    
    public TestPayout200509(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
    }

    protected void tearDown() throws Exception {
    }
    
    public void test00000() throws Exception 
    {
        new TransferPayout().start("2005-09-01", "2005-09-30"); 
    } 

}
