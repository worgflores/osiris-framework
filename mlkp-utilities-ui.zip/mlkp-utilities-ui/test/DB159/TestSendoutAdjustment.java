package DB159;

import junit.framework.*;

public class TestSendoutAdjustment extends TestCase 
{
    
    public TestSendoutAdjustment(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
    }

    protected void tearDown() throws Exception {
    }
    
    public void test00000() throws Exception 
    {
        new TransferSendoutCancel().start("2000-01-01", "2005-12-31"); 
        new TransferSendoutCredit().start("2000-01-01", "2005-12-31"); 
        new TransferSendoutInvalidated().start("2000-01-01", "2005-12-31"); 
        new TransferRTS().start("2000-01-01", "2005-12-31"); 
    } 

}
