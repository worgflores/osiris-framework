package DB159;

import com.mlhuillier.util.DBConfig;
import com.mlhuillier.util.migration2.DataService;
import java.io.InputStream;
import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Map;

public class TransferSendoutCancel 
{    
    private String dsname = "DB-159"; 
    private DBConfig dbConfig;
    
    public TransferSendoutCancel() { 
        dbConfig = new DBConfig(); 
    }
    
    public void start(String fromdate, String todate) throws Exception
    {
        Date dtfrom = java.sql.Date.valueOf(fromdate);
        Date dtto = java.sql.Date.valueOf(todate); 
        
        Connection connSrc = null;
        Connection connDest = null;
        
        try
        {
            connSrc = dbConfig.createConnection(dsname); 
            connDest = dbConfig.createConnection(dsname); 
            
            SimpleDateFormat sdfYMD = new SimpleDateFormat("yyyy-MM-dd"); 
            SimpleDateFormat sdfY = new SimpleDateFormat("yyyy"); 
            Calendar cal = new GregorianCalendar(); 
            cal.setTime(dtfrom); 
            while (true)
            {
                Date dt = cal.getTime();
                if (dt.after(dtto)) break; 

                String syear = sdfY.format(dt);
                System.out.println("initializing sendout tables for year " + syear + "...");
                doInitTables(connDest, syear); 
                
                String sdate = sdfYMD.format(dt);
                System.out.println("transferring data ["+sdate+"]");                
                
                for (int hour=0; hour<24; hour++)
                {
                    String shour = hour+"";
                    if (hour < 10) shour = "0"+hour;
                    
                    String sdt1 = sdate + " " + shour + ":00:00"; 
                    String sdt2 = sdate + " " + shour + ":59:59"; 
                    doTransfer(connSrc, connDest, sdt1, sdt2, syear); 
                }
                
                cal.add(Calendar.DATE, 1); 
            }
        }
        catch(Exception ex) {
            throw ex; 
        }
        finally 
        {
            try { connSrc.close(); }catch(Exception ign){;} 
            try { connDest.close(); }catch(Exception ign){;} 
        }
    }
    
    private void doInitTables(Connection connDest, String syear) throws Exception 
    {
        String[] arr = new String[] { 
            "sendout.sql", "sendoutcancel.sql", "sendoutcredit.sql", "sendoutinfo.sql", 
            "sendoutinvalidated.sql", "sendoutoption.sql", "sendoutor.sql", "sendoutremote.sql",
            "sendoutwalkinid.sql", "kptnlog.sql" 
        }; 
        
        DataService ds = new DataService(); 
        for (int i=0; i<arr.length; i++) 
        {
            InputStream ins = Thread.currentThread().getContextClassLoader().getResourceAsStream("resources/" + arr[i]); 
            String sql = toString(ins); 
            sql = sql.replaceAll("\\$\\{SUFFIX\\}", syear); 
            ds.exec(connDest, sql);  
        } 
    }
    
    private String toString(InputStream ins) throws Exception
    {
        try
        {
            StringBuffer sb = new StringBuffer(); 
            
            int read = -1;
            while ((read=ins.read()) != -1) {
                sb.append((char) read); 
            }
            return sb.toString(); 
        } 
        catch(Exception ex) { 
            throw ex;  
        }  
        finally { 
            try { ins.close(); }catch(Exception ing){;} 
        } 
        
    }

    private void doTransfer(Connection connSrc, Connection connDest, String sdt1, String sdt2, String syear) throws Exception 
    {
        DataService ds = new DataService(); 
        List list = ds.getList(connSrc, "select objid, strsendoutid, (select strkptn from mlkp.tblsendout where objid=cs.strsendoutid) as strkptn " + 
                                        "from mlkp.tblcancelsendout cs where dtcancelled between '"+sdt1+"' and '"+sdt2+"'"); 
        while (!list.isEmpty())
        {
            Map item = (Map) list.remove(0); 
            String objid = item.get("objid").toString(); 
            String kptn = item.get("strkptn").toString();
            String soutid = item.get("strsendoutid").toString();
            
            ds.transferData(connSrc, connDest, "select * from mlkp.tblsendout where objid='"+soutid+"'", "test.tblsendout"+syear, true); 
            ds.transferData(connSrc, connDest, "select * from mlkp.tblsendoutinfo where objid='"+soutid+"'", "test.tblsendoutinfo"+syear, true); 
            ds.transferData(connSrc, connDest, "select * from mlkp.tblsendoutoption where objid='"+soutid+"'", "test.tblsendoutoption"+syear, true); 
            ds.transferData(connSrc, connDest, "select * from mlkp.tblsendoutor where objid='"+soutid+"'", "test.tblsendoutor"+syear, true); 
            ds.transferData(connSrc, connDest, "select * from mlkp.tblremotesendout where objid='"+soutid+"'", "test.tblsendoutremote"+syear, true); 
            ds.transferData(connSrc, connDest, "select * from mlkp.tblsendoutwalkinid where objid='"+soutid+"'", "test.tblsendoutwalkinid"+syear, true); 
            ds.transferData(connSrc, connDest, "select * from mlkp.tblcancelsendout where objid='"+objid+"'", "test.tblsendoutcancel"+syear, true);
            
            ds.transferData(connSrc, connDest, "select txnid, kptn, action, uid, refid, remarks, branch, terminalid, " + 
                                               "   case when txndate='0000-00-00' then null else txndate end as txndate " + 
                                               "from mlkp.tblkptnlog where kptn='"+kptn+"'", "test.tblkptnlog", true);
            
            try { 
                ds.transferData(connSrc, connDest, "select txnid, kptn, action, uid, refid, remarks, branch, terminalid, " + 
                                                   "   case when txndate='0000-00-00' then null else txndate end as txndate " + 
                                                   "from mlkp.tblkptnlog_old where kptn='"+kptn+"'", "test.tblkptnlog", true); 
            } catch(Exception ign) {
                System.out.println("[ERROR] " + ign.getMessage());
            } 
            try { 
                ds.transferData(connSrc, connDest, "select txnid, kptn, action, uid, refid, remarks, branch, terminalid, " + 
                                                   "   case when txndate='0000-00-00' then null else txndate end as txndate " + 
                                                   "from mlkp.tblkptnlog_new where kptn='"+kptn+"'", "test.tblkptnlog", true); 
            } catch(Exception ign) {
                System.out.println("[ERROR] " + ign.getMessage());
            }             
            try { 
                ds.transferData(connSrc, connDest, "select txnid, kptn, action, uid, refid, remarks, branch, terminalid, " + 
                                                   "   case when txndate='0000-00-00' then null else txndate end as txndate " + 
                                                   "from mlkp.tblkptnlog_new2 where kptn='"+kptn+"'", "test.tblkptnlog", true); 
            } catch(Exception ign) {
                System.out.println("[ERROR] " + ign.getMessage());
            }                         
        } 
    } 
} 
