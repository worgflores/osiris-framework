package DB159;

import junit.framework.*;

public class TestPayout extends TestCase 
{
    
    public TestPayout(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
    }

    protected void tearDown() throws Exception {
    }
    
    public void test00000() throws Exception 
    {
        new TransferPayout().start("2005-01-01", "2005-12-31"); 
    } 

}
