package DB159;

import junit.framework.*;

public class TestPayout200503 extends TestCase 
{
    
    public TestPayout200503(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
    }

    protected void tearDown() throws Exception {
    }
    
    public void test00000() throws Exception 
    {
        new TransferPayout().start("2005-03-09", "2005-03-31"); 
    } 

}
