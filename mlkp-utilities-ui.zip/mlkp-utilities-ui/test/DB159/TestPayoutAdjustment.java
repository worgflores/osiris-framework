package DB159;

import junit.framework.*;

public class TestPayoutAdjustment extends TestCase 
{
    
    public TestPayoutAdjustment(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
    }

    protected void tearDown() throws Exception {
    }
    
    public void test00000() throws Exception 
    {
        new TransferPayoutCancel().start("2000-01-01", "2005-12-31"); 
        new TransferPayoutCredit().start("2000-01-01", "2005-12-31"); 
        new TransferPayoutVoid().start("2000-01-01", "2005-12-31"); 
    } 

}
